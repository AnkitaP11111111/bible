package king.james.bible.android.adapter.holder;

import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;
import king.james.bible.android.R;
import king.james.bible.android.model.SelectChapter;
import king.james.bible.android.utils.BiblePreferences;

public class ViewEditDailyVerseViewHolder extends EditDailyVerseViewHolder {
    private SelectChapterHolder$ChapterHolderListener holderListener;
    private SelectChapter mModel;
    private CheckBox selectedCheckBox;
    private TextView titleTextView;

    public ViewEditDailyVerseViewHolder(View view, SelectChapterHolder$ChapterHolderListener selectChapterHolder$ChapterHolderListener) {
        super(view);
        this.holderListener = selectChapterHolder$ChapterHolderListener;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter.BaseViewHolder
    public void mapViews(View view) {
        this.selectedCheckBox = (CheckBox) view.findViewById(R.id.selectedCheckBox);
        this.titleTextView = (TextView) view.findViewById(R.id.titleTextView);
    }

    @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter.BaseViewHolder
    public void updateView(Object obj) {
        SelectChapter selectChapter = (SelectChapter) obj;
        this.mModel = selectChapter;
        this.selectedCheckBox.setChecked(selectChapter.isSelected());
        this.titleTextView.setText(this.mModel.getTitle());
        this.selectedCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            /* class king.james.bible.android.adapter.holder.ViewEditDailyVerseViewHolder.AnonymousClass1 */

            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                ViewEditDailyVerseViewHolder.this.mModel.setSelected(z);
                if (ViewEditDailyVerseViewHolder.this.holderListener != null) {
                    ViewEditDailyVerseViewHolder.this.holderListener.setSelected(z);
                }
            }
        });
        boolean isNightMode = BiblePreferences.getInstance().isNightMode();
        int mode = this.mModel.getMode();
        this.titleTextView.setTextColor(this.itemView.getContext().getResources().getColorStateList(mode != 1 ? mode != 2 ? mode != 3 ? 0 : isNightMode ? R.color.green_light_text_selectable_n : R.color.green_light_text_selectable : R.color.red_light_text_selectable : isNightMode ? R.color.dark_light_text_selectable : R.color.dark_light_text_selectable_n));
    }
}
