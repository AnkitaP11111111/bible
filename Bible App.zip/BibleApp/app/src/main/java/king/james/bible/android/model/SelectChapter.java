package king.james.bible.android.model;

public class SelectChapter {
    private Long id;
    private int mode;
    private boolean selected = false;
    private String title;

    public SelectChapter(Long l, String str) {
        this.id = l;
        this.title = str;
    }

    public Long getId() {
        return this.id;
    }

    public String getTitle() {
        return this.title;
    }

    public boolean isSelected() {
        return this.selected;
    }

    public void setSelected(boolean z) {
        this.selected = z;
    }

    public int getMode() {
        return this.mode;
    }

    public void setMode(int i) {
        this.mode = i;
    }
}
