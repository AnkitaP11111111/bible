package king.james.bible.android.adapter.recycler;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import king.james.bible.android.R;
import java.util.ArrayList;
import java.util.List;
import king.james.bible.android.adapter.holder.SearchItemViewHolder;
import king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter;
import king.james.bible.android.model.SearchTextResult;
import king.james.bible.android.utils.BiblePreferences;

public class SearchRecycleViewAdapter extends BaseRecyclerViewAdapter<SearchItemViewHolder> {
    private int allCount;
    private List<SearchTextResult> models = new ArrayList();

    public SearchRecycleViewAdapter(OnItemClickListener onItemClickListener) {
        super(onItemClickListener);
    }

    public void setModels(List<SearchTextResult> list) {
        this.models = list;
        if (list == null) {
            clearModels();
        }
    }

    public void addModels(List<SearchTextResult> list) {
        if (this.models == null) {
            clearModels();
        }
        this.models.addAll(list);
        checkAllCount();
    }

    public void setAllCount(int i) {
        this.allCount = i;
    }

    private void checkAllCount() {
        checkAllCount(getRealItemCount());
    }

    public void checkAllCount(int i) {
        if (this.allCount < i) {
            this.allCount = i;
        }
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter
    public SearchItemViewHolder doCreateViewHolder(ViewGroup viewGroup, int i) {
        return new SearchItemViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(i, viewGroup, false));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemViewType(int i) {
        return isNight() ? R.layout.search_item_layout_n : R.layout.search_item_layout;
    }

    private boolean isNight() {
        return BiblePreferences.getInstance().isNightMode();
    }

    @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter
    public SearchTextResult getModel(int i) {
        if (i < 0 || i >= this.models.size()) {
            return null;
        }
        return this.models.get(i);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        checkAllCount();
        return this.allCount;
    }

    public void clearModels() {
        List<SearchTextResult> list = this.models;
        if (list != null) {
            list.clear();
        }
        this.allCount = 0;
        this.models = new ArrayList();
    }

    public int getRealItemCount() {
        return this.models.size();
    }
}
