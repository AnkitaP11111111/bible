//package king.james.bible.android.ad;
//
//import java.util.HashSet;
//import java.util.Set;
//import king.james.bible.android.ad.RewardAdsDialog;
//
//public class RewardAdsListenerObservable implements RewardAdsDialog.RewardAdsListener {
//    private static RewardAdsListenerObservable instance;
//    private Set<RewardAdsDialog.RewardAdsListener> listeners;
//
//    private RewardAdsListenerObservable() {
//    }
//
//    public static RewardAdsListenerObservable getInstance() {
//        if (instance == null) {
//            synchronized (RewardAdsListenerObservable.class) {
//                if (instance == null) {
//                    instance = new RewardAdsListenerObservable();
//                }
//            }
//        }
//        return instance;
//    }
//
//    public void subscribe(RewardAdsDialog.RewardAdsListener rewardAdsListener) {
//        checkList();
//        this.listeners.add(rewardAdsListener);
//    }
//
//    public void remove(RewardAdsDialog.RewardAdsListener rewardAdsListener) {
//        checkList();
//        this.listeners.remove(rewardAdsListener);
//    }
//
//    private void checkList() {
//        if (this.listeners == null) {
//            this.listeners = new HashSet();
//        }
//    }
//
//    @Override // king.james.bible.android.ad.RewardAdsDialog.RewardAdsListener
//    public void selectShowRewardAds() {
//        checkList();
//        for (RewardAdsDialog.RewardAdsListener rewardAdsListener : this.listeners) {
//            if (rewardAdsListener != null) {
//                rewardAdsListener.selectShowRewardAds();
//            }
//        }
//    }
//
//    @Override // king.james.bible.android.ad.RewardAdsDialog.RewardAdsListener
//    public void selectCancelRewardAdsDialog() {
//        checkList();
//        for (RewardAdsDialog.RewardAdsListener rewardAdsListener : this.listeners) {
//            if (rewardAdsListener != null) {
//                rewardAdsListener.selectCancelRewardAdsDialog();
//            }
//        }
//    }
//}
