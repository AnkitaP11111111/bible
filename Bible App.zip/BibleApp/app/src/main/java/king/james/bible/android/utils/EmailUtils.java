package king.james.bible.android.utils;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import king.james.bible.android.R;
import java.io.File;

public class EmailUtils {
    public static void sentEmail(Context context, String[] strArr, String str, String str2, String str3, String str4) {
        if (str3 == null || str4 == null) {
            sentEmail(context, strArr, str, str2, null);
        } else {
            sentEmail(context, strArr, str, str2, new File(new File(context.getExternalFilesDir(null), str3), str4));
        }
    }

    public static void sentEmail(Context context, String[] strArr, String str, String str2, File file) {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setType("text/plain");
        intent.setData(Uri.parse("mailto:" + strArr[0] + "?subject=" + str + "&body=" + str2));
        if (strArr != null) {
            intent.putExtra("android.intent.extra.EMAIL", strArr);
        }
        if (str != null) {
            intent.putExtra("android.intent.extra.SUBJECT", str);
        }
        if (str2 != null) {
            intent.putExtra("android.intent.extra.TEXT", str2);
        }
        if (file != null && file.exists() && file.canRead()) {
            intent.putExtra("android.intent.extra.STREAM", Uri.parse("file://" + file));
        }
        try {
            context.startActivity(Intent.createChooser(intent, context.getResources().getString(R.string.chooseremail)));
        } catch (Exception unused) {
            BibleToast.showShortDurationToast(context, R.string.error);
        }
    }

    public static void sentShare(Context context, String[] strArr, String str, String str2) {
        sentShare(context, strArr, str, str2, false, null);
    }

    private static void sentShare(Context context, String[] strArr, String str, String str2, boolean z, File file) {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("text/plain");
        if (strArr != null) {
            intent.putExtra("android.intent.extra.EMAIL", strArr);
        }
        if (str != null) {
            intent.putExtra("android.intent.extra.SUBJECT", str);
        }
        if (str2 != null) {
            intent.putExtra("android.intent.extra.TEXT", str2);
        }
        if (z) {
            if (!file.exists() || !file.canRead()) {
                BibleToast.showShortDurationToast(context, R.string.errorfile_not_found);
                return;
            }
            intent.putExtra("android.intent.extra.STREAM", Uri.parse("file://" + file));
        }
        try {
            context.startActivity(Intent.createChooser(intent, context.getResources().getString(R.string.choosershare)));
        } catch (Exception unused) {
            BibleToast.showShortDurationToast(context, R.string.error);
        }
    }
}
