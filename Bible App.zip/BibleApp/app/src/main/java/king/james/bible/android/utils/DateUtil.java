package king.james.bible.android.utils;

import android.content.Context;
import android.text.format.DateFormat;
import com.karumi.dexter.BuildConfig;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

public class DateUtil {
    private static DateUtil instance;
    private SimpleDateFormat bookmarksTime12Format = new SimpleDateFormat("yyyy-MM-dd hh:mm ");
    private SimpleDateFormat bookmarksTimeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
    private SimpleDateFormat notificationsDateFormat = new SimpleDateFormat("yyyy-MM-dd");
    private SimpleDateFormat notifyTime12Format = new SimpleDateFormat("hh:mm ");
    private SimpleDateFormat notifyTimeFormat = new SimpleDateFormat("HH:mm");

    public String getDayPart(int i) {
        return i == 1 ? "AM" : i == 2 ? "PM" : BuildConfig.FLAVOR;
    }

    private DateUtil() {
        this.notifyTimeFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
        this.notifyTime12Format.setTimeZone(TimeZone.getTimeZone("GMT"));
    }

    public static DateUtil getInstance() {
        if (instance == null) {
            synchronized (DateUtil.class) {
                if (instance == null) {
                    instance = new DateUtil();
                }
            }
        }
        return instance;
    }

    public String getBookmarkTime(long j, Context context) {
        if (is24HourFormat(context)) {
            return this.bookmarksTimeFormat.format(new Date(j));
        }
        return this.bookmarksTime12Format.format(Long.valueOf(j)) + getDayPart(j - getStartDayTime());
    }

    public String getNotificationsTime(long j, Context context) {
        String str;
        String format = this.notificationsDateFormat.format(new Date(System.currentTimeMillis()));
        if (is24HourFormat(context)) {
            str = this.notifyTimeFormat.format(new Date(j));
        } else {
            str = this.notifyTime12Format.format(Long.valueOf(j)) + getDayPart(j);
        }
        return format + " " + str;
    }

    private String getDayPart(long j) {
        return getDayPart(((int) TimeUnit.MILLISECONDS.toHours(j)) < 12 ? 1 : 2);
    }

    public String getNotifyTime(long j, Context context) {
        if (is24HourFormat(context)) {
            return this.notifyTimeFormat.format(new Date(j));
        }
        return this.notifyTime12Format.format(new Date(j)) + getDayPart(j);
    }

    private boolean is24HourFormat(Context context) {
        return DateFormat.is24HourFormat(context);
    }

    public static long getStartDayTime() {
        Calendar instance2 = Calendar.getInstance();
        instance2.set(11, 0);
        instance2.set(12, 0);
        instance2.set(13, 0);
        instance2.set(14, 0);
        return instance2.getTimeInMillis();
    }
}
