package king.james.bible.android.db;

import android.content.SharedPreferences;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.karumi.dexter.BuildConfig;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import king.james.bible.android.Application;
import king.james.bible.android.MyApplication;
import king.james.bible.android.model.UpdateRecord;
import king.james.bible.android.model.export.DailyVerseSimple;
import king.james.bible.android.model.export.PlanExport;
import king.james.bible.android.utils.builder.DailyReadingBuilder;
import king.james.bible.android.utils.builder.DailyVerseModelsBuilder;

public class MigrationUserDataUtil {
    private static MigrationUserDataUtil instance;
    private List<DailyVerseSimple> dailyVerseSimples;
    private List<PlanExport> planExportModels;
    private List<UpdateRecord> records;

    private MigrationUserDataUtil() {
    }

    public static MigrationUserDataUtil getInstance() {
        if (instance == null) {
            synchronized (MigrationUserDataUtil.class) {
                if (instance == null) {
                    instance = new MigrationUserDataUtil();
                }
            }
        }
        return instance;
    }

    private void restore() {
        SharedPreferences sharedPreferences = MyApplication.getContext().getSharedPreferences("MigrationUserDataUtil_preference", 0);
        if (sharedPreferences != null) {
            this.records = readList(sharedPreferences, "records", new TypeToken<List<UpdateRecord>>(this) {
                /* class king.james.bible.android.db.MigrationUserDataUtil.AnonymousClass1 */
            }.getType());
            this.planExportModels = readList(sharedPreferences, "planExportModels", new TypeToken<List<PlanExport>>(this) {
                /* class king.james.bible.android.db.MigrationUserDataUtil.AnonymousClass2 */
            }.getType());
            this.dailyVerseSimples = readList(sharedPreferences, "dailyVerseSimples", new TypeToken<List<DailyVerseSimple>>(this) {
                /* class king.james.bible.android.db.MigrationUserDataUtil.AnonymousClass3 */
            }.getType());
        }
    }

    private <T> List<T> readList(SharedPreferences sharedPreferences, String str, Type type) {
        List<T> list = (List) new GsonBuilder().create().fromJson(sharedPreferences.getString(str, BuildConfig.FLAVOR), type);
        return list == null ? new ArrayList() : list;
    }

    private void save() {
        SharedPreferences.Editor edit;
        SharedPreferences sharedPreferences = MyApplication.getContext().getSharedPreferences("MigrationUserDataUtil_preference", 0);
        if (sharedPreferences != null && (edit = sharedPreferences.edit()) != null) {
            if (this.records == null) {
                this.records = new ArrayList();
            }
            if (this.planExportModels == null) {
                this.planExportModels = new ArrayList();
            }
            if (this.dailyVerseSimples == null) {
                this.dailyVerseSimples = new ArrayList();
            }
            Gson create = new GsonBuilder().create();
            edit.putString("records", create.toJson(this.records));
            edit.putString("planExportModels", create.toJson(this.planExportModels));
            edit.putString("dailyVerseSimples", create.toJson(this.dailyVerseSimples));
            edit.apply();
        }
    }

    public /* synthetic */ void lambda$readUserDataAsync$0$MigrationUserDataUtil() {
        readUserData(false);
    }

    public void readUserDataAsync() {
        new Thread(new Runnable() {
            /* class king.james.bible.android.db.$$Lambda$MigrationUserDataUtil$J78tFoaznHf7ijzPH32p5Zfirvc */

            public final void run() {
                MigrationUserDataUtil.this.lambda$readUserDataAsync$0$MigrationUserDataUtil();
            }
        }).start();
    }

    /* access modifiers changed from: package-private */
    public void readUserData(boolean z) {
        BibleDataBase bibleDataBase = null;
        try {
            bibleDataBase = BibleDataBase.getInstance();
            if (z) {
                bibleDataBase.openForMigration();
            }
            readRecords(bibleDataBase);
            readDailyReading();
            readDailyVerse();
            if (!z || bibleDataBase == null || !bibleDataBase.isOpen()) {
                return;
            }
        } catch (Exception unused) {
            if (!z || 0 == 0 || !bibleDataBase.isOpen()) {
                return;
            }
        } catch (Throwable th) {
            if (z && 0 != 0 && bibleDataBase.isOpen()) {
                bibleDataBase.close();
            }
            throw th;
        }
        bibleDataBase.close();
    }

    public boolean isEmptyDBRecords() {
        try {
            return BibleDataBase.getInstance().getUpdateRecords().isEmpty();
        } catch (Exception unused) {
            return false;
        }
    }

    private void readRecords(BibleDataBase bibleDataBase) {
        try {
            this.records = bibleDataBase.getUpdateRecords();
            save();
        } catch (Exception unused) {
        }
    }

    private void readDailyReading() {
        try {
            this.planExportModels = DailyReadingBuilder.getExportModels();
            save();
        } catch (Exception unused) {
        }
    }

    private void readDailyVerse() {
        try {
            this.dailyVerseSimples = DailyVerseModelsBuilder.getExportModels();
            save();
        } catch (Exception unused) {
        }
    }

    public void writeUserData() {
        writeUserData(false);
    }

    /* access modifiers changed from: package-private */
    public void writeUserData(boolean z) {
        restore();
        BibleDataBase bibleDataBase = null;
        try {
            bibleDataBase = BibleDataBase.getInstance();
            if (z) {
                bibleDataBase.openForMigration();
            }
            writeRecords(bibleDataBase);
            writeDailyReading();
            writeDailyVerse();
            if (!z || bibleDataBase == null || !bibleDataBase.isOpen()) {
                return;
            }
        } catch (Exception unused) {
            if (!z || 0 == 0 || !bibleDataBase.isOpen()) {
                return;
            }
        } catch (Throwable th) {
            if (z && 0 != 0 && bibleDataBase.isOpen()) {
                bibleDataBase.close();
            }
            throw th;
        }
        bibleDataBase.close();
    }

    private void writeRecords(BibleDataBase bibleDataBase) {
        List<UpdateRecord> list = this.records;
        if (list != null && !list.isEmpty()) {
            try {
                bibleDataBase.updateRecords(this.records);
            } catch (Exception unused) {
            }
        }
    }

    private void writeDailyReading() {
        List<PlanExport> list = this.planExportModels;
        if (list != null && !list.isEmpty()) {
            try {
                DailyReadingBuilder.writeDailyReading(this.planExportModels);
            } catch (Exception unused) {
            }
        }
    }

    private void writeDailyVerse() {
        List<DailyVerseSimple> list = this.dailyVerseSimples;
        if (list != null && !list.isEmpty()) {
            try {
                DailyVerseModelsBuilder.writeDailyVerses(this.dailyVerseSimples);
            } catch (Exception unused) {
            }
        }
    }
}
