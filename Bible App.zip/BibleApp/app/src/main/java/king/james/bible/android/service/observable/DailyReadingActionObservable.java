package king.james.bible.android.service.observable;

import java.util.HashSet;
import java.util.Set;
import king.james.bible.android.adapter.recycler.DailyReadingRecyclerViewAdapter;
import king.james.bible.android.model.Plan;
import king.james.bible.android.model.PlanChapterDay;
import king.james.bible.android.model.PlanDay;
import king.james.bible.android.model.PlanMode;

public class DailyReadingActionObservable implements DailyReadingRecyclerViewAdapter.DailyReadingActionListener {
    private static DailyReadingActionObservable instance;
    private Set<DailyReadingRecyclerViewAdapter.DailyReadingActionListener> listeners;

    private DailyReadingActionObservable() {
    }

    public static DailyReadingActionObservable getInstance() {
        if (instance == null) {
            synchronized (DailyReadingActionObservable.class) {
                if (instance == null) {
                    instance = new DailyReadingActionObservable();
                }
            }
        }
        return instance;
    }

    public void subscribe(DailyReadingRecyclerViewAdapter.DailyReadingActionListener dailyReadingActionListener) {
        checkList();
        this.listeners.add(dailyReadingActionListener);
    }

    public void remove(DailyReadingRecyclerViewAdapter.DailyReadingActionListener dailyReadingActionListener) {
        checkList();
        this.listeners.remove(dailyReadingActionListener);
    }

    private void checkList() {
        if (this.listeners == null) {
            this.listeners = new HashSet();
        }
    }

    @Override // king.james.bible.android.adapter.recycler.DailyReadingRecyclerViewAdapter.DailyReadingActionListener
    public void onSelectPlan(Plan plan, int i, PlanMode planMode) {
        checkList();
        for (DailyReadingRecyclerViewAdapter.DailyReadingActionListener dailyReadingActionListener : this.listeners) {
            if (dailyReadingActionListener != null) {
                dailyReadingActionListener.onSelectPlan(plan, i, planMode);
            }
        }
    }

    @Override // king.james.bible.android.adapter.recycler.DailyReadingRecyclerViewAdapter.DailyReadingActionListener
    public void onStopPlan(Plan plan) {
        checkList();
        for (DailyReadingRecyclerViewAdapter.DailyReadingActionListener dailyReadingActionListener : this.listeners) {
            if (dailyReadingActionListener != null) {
                dailyReadingActionListener.onStopPlan(plan);
            }
        }
    }

    @Override // king.james.bible.android.adapter.recycler.DailyReadingRecyclerViewAdapter.DailyReadingActionListener
    public void onViewChapter(PlanChapterDay planChapterDay) {
        checkList();
        for (DailyReadingRecyclerViewAdapter.DailyReadingActionListener dailyReadingActionListener : this.listeners) {
            if (dailyReadingActionListener != null) {
                dailyReadingActionListener.onViewChapter(planChapterDay);
            }
        }
    }

    @Override // king.james.bible.android.adapter.recycler.DailyReadingRecyclerViewAdapter.DailyReadingActionListener
    public void onSelectCompleteAll(PlanDay planDay, int i, boolean z, boolean z2) {
        checkList();
        for (DailyReadingRecyclerViewAdapter.DailyReadingActionListener dailyReadingActionListener : this.listeners) {
            if (dailyReadingActionListener != null) {
                dailyReadingActionListener.onSelectCompleteAll(planDay, i, z, z2);
            }
        }
    }

    @Override // king.james.bible.android.adapter.recycler.DailyReadingRecyclerViewAdapter.DailyReadingActionListener
    public void onShowPlanDescription(Plan plan) {
        checkList();
        for (DailyReadingRecyclerViewAdapter.DailyReadingActionListener dailyReadingActionListener : this.listeners) {
            if (dailyReadingActionListener != null) {
                dailyReadingActionListener.onShowPlanDescription(plan);
            }
        }
    }

    @Override // king.james.bible.android.adapter.recycler.DailyReadingRecyclerViewAdapter.DailyReadingActionListener
    public void onDestroyDailyPlanDialog() {
        checkList();
        for (DailyReadingRecyclerViewAdapter.DailyReadingActionListener dailyReadingActionListener : this.listeners) {
            if (dailyReadingActionListener != null) {
                dailyReadingActionListener.onDestroyDailyPlanDialog();
            }
        }
    }
}
