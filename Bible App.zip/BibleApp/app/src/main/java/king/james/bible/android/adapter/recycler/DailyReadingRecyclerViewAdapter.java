package king.james.bible.android.adapter.recycler;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import king.james.bible.android.R;
import java.io.Serializable;
import java.util.List;
import king.james.bible.android.adapter.holder.DailyReadingBaseViewHolder;
import king.james.bible.android.adapter.holder.PlanNotStartedViewHolder;
import king.james.bible.android.adapter.holder.PlanStartedViewHolder;
import king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter;
import king.james.bible.android.model.Plan;
import king.james.bible.android.model.PlanChapterDay;
import king.james.bible.android.model.PlanDay;
import king.james.bible.android.model.PlanMode;
import king.james.bible.android.utils.DailyReadingCache;

public class DailyReadingRecyclerViewAdapter extends BaseRecyclerViewAdapter<DailyReadingBaseViewHolder> {
    private List<Plan> planList;
    private StartedPositionListener positionListener = new StartedPositionListener() {
        /* class king.james.bible.android.adapter.recycler.DailyReadingRecyclerViewAdapter.AnonymousClass1 */

        @Override // king.james.bible.android.adapter.recycler.DailyReadingRecyclerViewAdapter.StartedPositionListener
        public void newPosition(int i, int i2) {
            DailyReadingRecyclerViewAdapter.this.newDayPosition(i, i2);
        }
    };

    public interface DailyReadingActionListener extends Serializable {
        void onDestroyDailyPlanDialog();

        void onSelectCompleteAll(PlanDay planDay, int i, boolean z, boolean z2);

        void onSelectPlan(Plan plan, int i, PlanMode planMode);

        void onShowPlanDescription(Plan plan);

        void onStopPlan(Plan plan);

        void onViewChapter(PlanChapterDay planChapterDay);
    }

    public interface StartedPositionListener {
        void newPosition(int i, int i2);
    }

    public DailyReadingRecyclerViewAdapter(List<Plan> list) {
        super(null);
        this.planList = list;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter
    public DailyReadingBaseViewHolder doCreateViewHolder(ViewGroup viewGroup, int i) {
        View inflate = LayoutInflater.from(viewGroup.getContext()).inflate(i, viewGroup, false);
        if (i == R.layout.item_daily_reading_started) {
            return new PlanStartedViewHolder(inflate);
        }
        return new PlanNotStartedViewHolder(inflate);
    }

    public void onBindViewHolder(DailyReadingBaseViewHolder dailyReadingBaseViewHolder, int i) {
        dailyReadingBaseViewHolder.setActionListener(this.positionListener);
        dailyReadingBaseViewHolder.setDayPosition(DailyReadingCache.getDayPosition(getModel(i).getId()));
        super.onBindViewHolder( dailyReadingBaseViewHolder, i);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemViewType(int i) {
        return this.planList.get(i).isStarted() ? R.layout.item_daily_reading_started : R.layout.item_daily_reading_not_started;
    }

    @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter
    public Plan getModel(int i) {
        List<Plan> list = this.planList;
        if (list == null || list.isEmpty() || i < 0 || i >= this.planList.size()) {
            return null;
        }
        return this.planList.get(i);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.planList.size();
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void newDayPosition(int i, int i2) {
        DailyReadingCache.put(getModel(i).getId(), i2);
    }
}
