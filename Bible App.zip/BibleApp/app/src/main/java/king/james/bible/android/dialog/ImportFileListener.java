package king.james.bible.android.dialog;

import java.io.File;

public interface ImportFileListener {
    void importData(File file);
}
