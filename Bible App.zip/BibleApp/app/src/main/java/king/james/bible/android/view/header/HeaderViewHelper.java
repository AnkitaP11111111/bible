package king.james.bible.android.view.header;

import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Typeface;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import king.james.bible.android.R;
import king.james.bible.android.utils.BiblePreferences;
import king.james.bible.android.utils.ScreenUtil;

public class HeaderViewHelper {
    private static int correctSizeDefault;
    private static int oneCutSizeSp;
    private static int textSizeSpMax;
    private static int textSizeSpMin;

    public static void init(Context context) {
        textSizeSpMax = context.getResources().getInteger(R.integer.max_font_size);
        textSizeSpMin = context.getResources().getInteger(R.integer.min_font_size);
        correctSizeDefault = context.getResources().getDimensionPixelSize(R.dimen.button_size);
        oneCutSizeSp = (textSizeSpMax - textSizeSpMin) / 3;
    }

    public static void updateSizeButton(LinearLayout linearLayout, int i) {
        double d;
        if (ScreenUtil.getInstance().isTablet()) {
            ViewGroup.LayoutParams layoutParams = linearLayout.getLayoutParams();
            double d2 = (double) correctSizeDefault;
            int i2 = textSizeSpMax;
            int i3 = i2 - i;
            int i4 = oneCutSizeSp;
            if (i3 > i4 * 2) {
                d = 1.0d;
                Double.isNaN(d2);
            } else if (i2 - i > i4) {
                d = 1.5d;
                Double.isNaN(d2);
            } else {
                d = 2.0d;
                Double.isNaN(d2);
            }
            int i5 = (int) (d2 * d);
            layoutParams.width = i5;
            layoutParams.height = i5;
            linearLayout.setLayoutParams(layoutParams);
        }
    }

    public static void animItem(View view) {
        ObjectAnimator objectAnimator;
        if (BiblePreferences.getInstance().isNightMode()) {
            objectAnimator = ObjectAnimator.ofObject(view, "backgroundColor", new ArgbEvaluator(), -16777216, -14273992, -16777216);
        } else {
            objectAnimator = ObjectAnimator.ofObject(view, "backgroundColor", new ArgbEvaluator(), -1, -6245959, -1);
        }
        objectAnimator.setDuration(2000L);
        objectAnimator.start();
    }

    public static void setupTextSettings(TextView textView, Typeface typeface, int i, float f) {
        textView.setTypeface(typeface);
        textView.setTextSize(2, (float) i);
        textView.setLineSpacing(0.0f, f);
    }
}
