package king.james.bible.android.view;

import android.content.Context;
import android.util.AttributeSet;
import androidx.recyclerview.widget.GridLayoutManager;

public class ContentsGridLayoutManager extends GridLayoutManager {
    private int headerCount;

    public ContentsGridLayoutManager(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
        setSpanSizeLookup();
    }

    public ContentsGridLayoutManager(Context context, int i, int i2) {
        super(context, i);
        setSpanSizeLookup();
        this.headerCount = i2;
    }

    private void setSpanSizeLookup() {
        setSpanSizeLookup(new VerseSpanSizeLookup(getSpanCount()));
    }

    /* access modifiers changed from: private */
    public class VerseSpanSizeLookup extends SpanSizeLookup {
        private int mSpanCount;

        public VerseSpanSizeLookup(int i) {
            this.mSpanCount = i;
        }

        @Override // androidx.recyclerview.widget.GridLayoutManager.SpanSizeLookup
        public int getSpanSize(int i) {
            if (i == ContentsGridLayoutManager.this.headerCount) {
                return this.mSpanCount;
            }
            return 1;
        }
    }
}
