package king.james.bible.android.model.comparator;

import java.util.Comparator;
import king.james.bible.android.model.DailyPlanMonth;

public class DailyPlanMonthComparator implements Comparator<DailyPlanMonth> {
    public int compare(DailyPlanMonth dailyPlanMonth, DailyPlanMonth dailyPlanMonth2) {
        return Long.valueOf(dailyPlanMonth.getTime()).compareTo(Long.valueOf(dailyPlanMonth2.getTime()));
    }
}
