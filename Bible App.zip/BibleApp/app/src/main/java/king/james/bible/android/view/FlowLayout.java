package king.james.bible.android.view;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.TypedArray;
import android.os.Build;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.List;
import king.james.bible.android.R$styleable;

@TargetApi(14)
public class FlowLayout extends ViewGroup {
    private int mGravity;
    private final List<Integer> mLineHeights;
    private final List<Integer> mLineMargins;
    private final List<List<View>> mLines;

    public FlowLayout(Context context) {
        this(context, null);
    }

    public FlowLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public FlowLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.mGravity = (isIcs() ? 8388611 : 3) | 48;
        this.mLines = new ArrayList();
        this.mLineHeights = new ArrayList();
        this.mLineMargins = new ArrayList();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.FlowLayout, i, 0);
        try {
            int i2 = obtainStyledAttributes.getInt(0, -1);
            if (i2 > 0) {
                setGravity(i2);
            }
        } finally {
            obtainStyledAttributes.recycle();
        }
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Removed duplicated region for block: B:20:0x008c  */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x008f  */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x00b1  */
    /* JADX WARNING: Removed duplicated region for block: B:27:0x00c3  */
    /* JADX WARNING: Removed duplicated region for block: B:29:0x00d4  */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x00d9 A[SYNTHETIC] */
    public void onMeasure(int i, int i2) {
        int i3;
        int i4;
        int i5;
        super.onMeasure(i, i2);
        int size = (MeasureSpec.getSize(i) - getPaddingLeft()) - getPaddingRight();
        int size2 = MeasureSpec.getSize(i2);
        int mode = MeasureSpec.getMode(i);
        int mode2 = MeasureSpec.getMode(i2);
        int childCount = getChildCount();
        int paddingTop = getPaddingTop() + getPaddingBottom();
        int i6 = 0;
        int i7 = 0;
        int i8 = 0;
        int i9 = 0;
        while (i8 < childCount) {
            View childAt = getChildAt(i8);
            boolean z = i8 == childCount + -1;
            if (childAt.getVisibility() == 8) {
                if (z) {
                    i9 = Math.max(i9, i7);
                    paddingTop += i6;
                }
                i3 = size2;
            } else {
                i3 = size2;
                measureChildWithMargins(childAt, i, i7, i2, paddingTop);
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                int i10 = ((MarginLayoutParams) layoutParams).width;
                int i11 = Integer.MIN_VALUE;
                if (i10 == -1) {
                    i10 = size - (((MarginLayoutParams) layoutParams).leftMargin + ((MarginLayoutParams) layoutParams).rightMargin);
                } else if (i10 < 0) {
                    i10 = size;
                    i4 = Integer.MIN_VALUE;
                    i5 = ((MarginLayoutParams) layoutParams).height;
                    if (i5 < 0) {
                        i11 = 1073741824;
                    } else if (mode2 == 0) {
                        i11 = 0;
                        i5 = 0;
                    } else {
                        i5 = i3;
                    }
                    childAt.measure(MeasureSpec.makeMeasureSpec(i10, i4), MeasureSpec.makeMeasureSpec(i5, i11));
                    int measuredWidth = childAt.getMeasuredWidth() + ((MarginLayoutParams) layoutParams).leftMargin + ((MarginLayoutParams) layoutParams).rightMargin;
                    i7 += measuredWidth;
                    if (i7 <= size) {
                        i9 = Math.max(i9, i7);
                        paddingTop += i6;
                        i7 = measuredWidth;
                        i6 = childAt.getMeasuredHeight() + ((MarginLayoutParams) layoutParams).topMargin + ((MarginLayoutParams) layoutParams).bottomMargin;
                    } else {
                        i6 = Math.max(i6, childAt.getMeasuredHeight() + ((MarginLayoutParams) layoutParams).topMargin + ((MarginLayoutParams) layoutParams).bottomMargin);
                    }
                    if (!z) {
                        i9 = Math.max(i9, i7);
                        paddingTop += i6;
                    }
                }
                i4 = 1073741824;
                i5 = ((MarginLayoutParams) layoutParams).height;
                if (i5 < 0) {
                }
                childAt.measure(MeasureSpec.makeMeasureSpec(i10, i4), MeasureSpec.makeMeasureSpec(i5, i11));
                int measuredWidth2 = childAt.getMeasuredWidth() + ((MarginLayoutParams) layoutParams).leftMargin + ((MarginLayoutParams) layoutParams).rightMargin;
                i7 += measuredWidth2;
                if (i7 <= size) {
                }
                if (!z) {
                }
            }
            i8++;
            size2 = i3;
        }
        int paddingLeft = i9 + getPaddingLeft() + getPaddingRight();
        if (mode != 1073741824) {
            size = paddingLeft;
        }
        setMeasuredDimension(size, mode2 == 1073741824 ? size2 : paddingTop);
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int i5;
        int i6;
        int i7;
        List<View> list;
        int i8;
        int i9;
        int i10;
        FlowLayout flowLayout = this;
        flowLayout.mLines.clear();
        flowLayout.mLineHeights.clear();
        flowLayout.mLineMargins.clear();
        int width = getWidth();
        int height = getHeight();
        int paddingTop = getPaddingTop();
        ArrayList arrayList = new ArrayList();
        int i11 = flowLayout.mGravity & 7;
        float f = i11 != 1 ? i11 != 5 ? 0.0f : 1.0f : 0.5f;
        int i12 = 0;
        int i13 = 0;
        int i14 = 0;
        while (true) {
            i5 = 8;
            if (i12 >= getChildCount()) {
                break;
            }
            View childAt = flowLayout.getChildAt(i12);
            if (childAt.getVisibility() != 8) {
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                int measuredWidth = childAt.getMeasuredWidth() + ((MarginLayoutParams) layoutParams).leftMargin + ((MarginLayoutParams) layoutParams).rightMargin;
                int measuredHeight = childAt.getMeasuredHeight() + ((MarginLayoutParams) layoutParams).bottomMargin + ((MarginLayoutParams) layoutParams).topMargin;
                if (i14 + measuredWidth > width) {
                    flowLayout.mLineHeights.add(Integer.valueOf(i13));
                    flowLayout.mLines.add(arrayList);
                    flowLayout.mLineMargins.add(Integer.valueOf(((int) (((float) (width - i14)) * f)) + getPaddingLeft()));
                    paddingTop += i13;
                    arrayList = new ArrayList();
                    i13 = 0;
                    i14 = 0;
                }
                i14 += measuredWidth;
                i13 = Math.max(i13, measuredHeight);
                arrayList.add(childAt);
            }
            i12++;
        }
        flowLayout.mLineHeights.add(Integer.valueOf(i13));
        flowLayout.mLines.add(arrayList);
        flowLayout.mLineMargins.add(Integer.valueOf(((int) (((float) (width - i14)) * f)) + getPaddingLeft()));
        int i15 = paddingTop + i13;
        int i16 = flowLayout.mGravity & 112;
        if (i16 != 16) {
            i6 = i16 != 80 ? 0 : height - i15;
        } else {
            i6 = (height - i15) / 2;
        }
        int size = flowLayout.mLines.size();
        int paddingTop2 = getPaddingTop();
        int i17 = 0;
        while (i17 < size) {
            int intValue = flowLayout.mLineHeights.get(i17).intValue();
            List<View> list2 = flowLayout.mLines.get(i17);
            int intValue2 = flowLayout.mLineMargins.get(i17).intValue();
            int size2 = list2.size();
            int i18 = 0;
            while (i18 < size2) {
                View view = list2.get(i18);
                if (view.getVisibility() == i5) {
                    i7 = width;
                    i8 = size;
                    list = list2;
                } else {
                    LayoutParams layoutParams2 = (LayoutParams) view.getLayoutParams();
                    if (((MarginLayoutParams) layoutParams2).height == -1) {
                        int paddingLeft = width - (((((MarginLayoutParams) layoutParams2).leftMargin + ((MarginLayoutParams) layoutParams2).rightMargin) + getPaddingLeft()) + getPaddingRight());
                        int i19 = ((MarginLayoutParams) layoutParams2).width;
                        if (i19 != -1) {
                            if (i19 >= 0) {
                                paddingLeft = i19;
                            } else {
                                i10 = Integer.MIN_VALUE;
                                view.measure(MeasureSpec.makeMeasureSpec(paddingLeft, i10), MeasureSpec.makeMeasureSpec((intValue - ((MarginLayoutParams) layoutParams2).topMargin) - ((MarginLayoutParams) layoutParams2).bottomMargin, 1073741824));
                            }
                        }
                        i10 = 1073741824;
                        view.measure(MeasureSpec.makeMeasureSpec(paddingLeft, i10), MeasureSpec.makeMeasureSpec((intValue - ((MarginLayoutParams) layoutParams2).topMargin) - ((MarginLayoutParams) layoutParams2).bottomMargin, 1073741824));
                    }
                    int measuredWidth2 = view.getMeasuredWidth();
                    int measuredHeight2 = view.getMeasuredHeight();
                    if (Gravity.isVertical(layoutParams2.gravity)) {
                        int i20 = layoutParams2.gravity;
                        if (i20 == 16 || i20 == 17) {
                            i9 = (((intValue - measuredHeight2) - ((MarginLayoutParams) layoutParams2).topMargin) - ((MarginLayoutParams) layoutParams2).bottomMargin) / 2;
                            int i21 = ((MarginLayoutParams) layoutParams2).leftMargin;
                            i7 = width;
                            i8 = size;
                            int i22 = ((MarginLayoutParams) layoutParams2).topMargin;
                            list = list2;
                            view.layout(intValue2 + i21, paddingTop2 + i22 + i9 + i6, intValue2 + measuredWidth2 + i21, measuredHeight2 + paddingTop2 + i22 + i9 + i6);
                            intValue2 += measuredWidth2 + ((MarginLayoutParams) layoutParams2).leftMargin + ((MarginLayoutParams) layoutParams2).rightMargin;
                        } else if (i20 == 80) {
                            i9 = ((intValue - measuredHeight2) - ((MarginLayoutParams) layoutParams2).topMargin) - ((MarginLayoutParams) layoutParams2).bottomMargin;
                            int i212 = ((MarginLayoutParams) layoutParams2).leftMargin;
                            i7 = width;
                            i8 = size;
                            int i222 = ((MarginLayoutParams) layoutParams2).topMargin;
                            list = list2;
                            view.layout(intValue2 + i212, paddingTop2 + i222 + i9 + i6, intValue2 + measuredWidth2 + i212, measuredHeight2 + paddingTop2 + i222 + i9 + i6);
                            intValue2 += measuredWidth2 + ((MarginLayoutParams) layoutParams2).leftMargin + ((MarginLayoutParams) layoutParams2).rightMargin;
                        }
                    }
                    i9 = 0;
                    int i2122 = ((MarginLayoutParams) layoutParams2).leftMargin;
                    i7 = width;
                    i8 = size;
                    int i2222 = ((MarginLayoutParams) layoutParams2).topMargin;
                    list = list2;
                    view.layout(intValue2 + i2122, paddingTop2 + i2222 + i9 + i6, intValue2 + measuredWidth2 + i2122, measuredHeight2 + paddingTop2 + i2222 + i9 + i6);
                    intValue2 += measuredWidth2 + ((MarginLayoutParams) layoutParams2).leftMargin + ((MarginLayoutParams) layoutParams2).rightMargin;
                }
                i18++;
                width = i7;
                size = i8;
                list2 = list;
                i5 = 8;
            }
            paddingTop2 += intValue;
            i17++;
            i5 = 8;
            flowLayout = this;
        }
    }

    /* access modifiers changed from: protected */
    @Override // android.view.ViewGroup
    public LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new LayoutParams(layoutParams);
    }

    @Override // android.view.ViewGroup
    public LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(getContext(), attributeSet);
    }

    /* access modifiers changed from: protected */
    public LayoutParams generateDefaultLayoutParams() {
        return new LayoutParams(-1, -1);
    }

    /* access modifiers changed from: protected */
    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return super.checkLayoutParams(layoutParams) && (layoutParams instanceof LayoutParams);
    }

    @TargetApi(14)
    public void setGravity(int i) {
        if (this.mGravity != i) {
            if ((8388615 & i) == 0) {
                i |= isIcs() ? 8388611 : 3;
            }
            if ((i & 112) == 0) {
                i |= 48;
            }
            this.mGravity = i;
            requestLayout();
        }
    }

    public int getGravity() {
        return this.mGravity;
    }

    private static boolean isIcs() {
        return Build.VERSION.SDK_INT >= 14;
    }

    public static class LayoutParams extends MarginLayoutParams {
        public int gravity = -1;

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.FlowLayout_Layout);
            try {
                this.gravity = obtainStyledAttributes.getInt(0, -1);
            } finally {
                obtainStyledAttributes.recycle();
            }
        }

        public LayoutParams(int i, int i2) {
            super(i, i2);
        }

        public LayoutParams(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }
    }
}
