package king.james.bible.android.adapter.array;

import android.content.Context;

public class FontSpinnerAdapter extends BaseSpinnerAdapter<String> {
    private String[] myObjs = new String[0];

    public static FontSpinnerAdapter getModeAdapter(Context context, String[] strArr) {
        return new FontSpinnerAdapter(context, BaseSpinnerAdapter.layoutResource(), strArr);
    }

    public FontSpinnerAdapter(Context context, int i, String[] strArr) {
        super(context, i, strArr);
        this.myObjs = strArr;
    }

    public int getCount() {
        return this.myObjs.length;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.adapter.array.BaseSpinnerAdapter
    public String getViewText(int i) {
        return this.myObjs[i];
    }

    @Override // android.widget.ArrayAdapter
    public String getItem(int i) {
        return this.myObjs[i];
    }
}
