package king.james.bible.android.view;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.text.Html;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.BackgroundColorSpan;
import android.text.style.StyleSpan;
import android.text.style.UnderlineSpan;
import android.util.AttributeSet;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.karumi.dexter.BuildConfig;
import king.james.bible.android.R;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import king.james.bible.android.db.listener.UpdateViewHolderListener;
import king.james.bible.android.event.ClickAddEvent;
import king.james.bible.android.event.ClickHeaderEvent;
import king.james.bible.android.model.Text;
import king.james.bible.android.service.BackStackService;
import king.james.bible.android.service.DailyReadingService;
import king.james.bible.android.service.DailyVerseService;
import king.james.bible.android.sound.SoundHelper;
import king.james.bible.android.sound.holder.SoundButtonHolder;
import king.james.bible.android.sound.listener.page.SoundInitListener;
import king.james.bible.android.sound.listener.page.SoundPlayListener;
import king.james.bible.android.sound.model.SoundButtonModel;
import king.james.bible.android.utils.AppUtils;
import king.james.bible.android.utils.BiblePreferences;
import king.james.bible.android.utils.MyLeadingMarginSpan2;
import king.james.bible.android.utils.ScreenUtil;
import king.james.bible.android.view.MarkerTextView;
import king.james.bible.android.view.header.HeaderViewHelper;
import org.greenrobot.eventbus.EventBus;

public class HeaderTextList extends RelativeLayout implements View.OnClickListener, MarkerTextView.OnSelectionListener, SoundInitListener {
    private int chapterSizeSp = 64;
    private int chapterTopMargin = -5;
    private boolean finishInflate = false;
    private Set<Integer> firstRankHeaders;
    private Text firstText;
    private int firstVisibleItemPosition;
    private int heightChapter;
    private TextView item_text1;
    private MarkerTextView item_text2;
    private MarkerTextView item_text2_2;
    private MarkerTextView item_text_head_1;
    private MarkerTextView item_text_head_1_2;
    private MarkerTextView item_text_head_2;
    private MarkerTextView item_text_head_2_2;
    private int leftMargin = 0;
    private float lineSpacing = 0.0f;
    private View llHead;
    private View llHead2;
    private LinearLayout llText2;
    private LinearLayout llText2_2;
    private LinearLayout llTextSound2;
    private LinearLayout llTextSound2_2;
    private int margin;
    private int menuItem = 0;
    private int pagePosition;
    private int positionMin = -1;
    private int positionTextFirst;
    private int positionTextSecond;
    private int positionView = 0;
    private BiblePreferences preferences;
    private int rankView = 0;
    private RelativeLayout rlText2;
    private RelativeLayout rlText2_2;
    private boolean secondHeader;
    private Text secondText;
    private Set<Integer> selectedSet;
    private SoundButtonHolder soundItemButtonFirst;
    private SoundButtonHolder soundItemButtonSecond;
    private SoundPlayListener soundPlayListener;
    private BackgroundColorSpan spanColor;
    private MyLeadingMarginSpan2 spanMargin;
    private List<Text> textList;
    private int textSizeSp = 0;
    private SizeImageView text_item_bookmark;
    private SizeImageView text_item_bookmark_2;
    private Button text_item_menu_button;
    private Button text_item_menu_button_2;
    private SizeImageView text_item_note;
    private SizeImageView text_item_note_2;
    private int unicId;
    private UpdateViewHolderListener updateViewHolderListener;
    private int widthChapter;

    public void setOnSelectionListener(MarkerTextView.OnSelectionListener onSelectionListener) {
    }

    public HeaderTextList(Context context) {
        super(context);
        init();
    }

    public HeaderTextList(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init();
    }

    public HeaderTextList(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        init();
    }

    public HeaderTextList(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
        init();
    }

    private void init() {
        BiblePreferences instance = BiblePreferences.getInstance();
        this.preferences = instance;
        instance.lambda$restoreAsync$0$BiblePreferences();
    }

    public void setPagePosition(int i) {
        this.pagePosition = i;
    }

    public int getPositionView() {
        return this.rankView;
    }

    private void setPositionView(int i) {
        if (i >= this.rankView) {
            this.rankView = i;
        }
    }

    public void setUnicId(int i) {
        this.unicId = i;
    }

    public void setSoundPlayListener(SoundPlayListener soundPlayListener2) {
        this.soundPlayListener = soundPlayListener2;
        this.soundItemButtonFirst.setSoundPlayListener(soundPlayListener2);
        this.soundItemButtonSecond.setSoundPlayListener(soundPlayListener2);
    }

    public void setMenuItem(int i) {
        this.menuItem = i;
    }

    /* access modifiers changed from: protected */
    public void onFinishInflate() {
        super.onFinishInflate();
        this.finishInflate = true;
        ((SizeImageLinearLayout) findViewById(R.id.text_item_icons)).setImageSize();
        ((SizeImageLinearLayout) findViewById(R.id.text_item_icons_1)).setImageSize();
        ((SizeImageLinearLayout) findViewById(R.id.text_item_icons_2)).setImageSize();
        this.item_text_head_1 = (MarkerTextView) findViewById(R.id.item_text_head_1);
        this.item_text_head_2 = (MarkerTextView) findViewById(R.id.item_text_head_2);
        this.item_text_head_1_2 = (MarkerTextView) findViewById(R.id.item_text_head_1_2);
        this.item_text_head_2_2 = (MarkerTextView) findViewById(R.id.item_text_head_2_2);
        this.llHead = findViewById(R.id.llHead);
        this.llHead2 = findViewById(R.id.llHead2);
        this.item_text1 = (TextView) findViewById(R.id.item_text1);
        this.llText2 = (LinearLayout) findViewById(R.id.llText2);
        this.item_text2 = (MarkerTextView) findViewById(R.id.item_text2);
        this.text_item_bookmark = (SizeImageView) findViewById(R.id.text_item_bookmark);
        this.text_item_note = (SizeImageView) findViewById(R.id.text_item_note);
        this.text_item_menu_button = (Button) findViewById(R.id.text_item_menu_button);
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.llTextSound2);
        this.llTextSound2 = linearLayout;
        this.soundItemButtonFirst = SoundButtonHolder.create(linearLayout, new SoundButtonModel(this.pagePosition, 1), this, new SoundButtonHolder.SoundButtonHolderListener() {
            /* class king.james.bible.android.view.$$Lambda$HeaderTextList$JI4qVPtKlOYIOgDrYOVODKkT1Ik */

            @Override // king.james.bible.android.sound.holder.SoundButtonHolder.SoundButtonHolderListener
            public final void setSoundViewAlpha(int i) {
                HeaderTextList.this.lambda$onFinishInflate$0$HeaderTextList(i);
            }
        });
        LinearLayout linearLayout2 = (LinearLayout) findViewById(R.id.llTextSound2_2);
        this.llTextSound2_2 = linearLayout2;
        this.soundItemButtonSecond = SoundButtonHolder.create(linearLayout2, new SoundButtonModel(this.pagePosition, 2), this, new SoundButtonHolder.SoundButtonHolderListener() {
            /* class king.james.bible.android.view.$$Lambda$HeaderTextList$tqfoU2TbXSognKNq0MJ1CJHPpcg */

            @Override // king.james.bible.android.sound.holder.SoundButtonHolder.SoundButtonHolderListener
            public final void setSoundViewAlpha(int i) {
                HeaderTextList.this.lambda$onFinishInflate$1$HeaderTextList(i);
            }
        });
        this.soundItemButtonFirst.setSoundPlayListener(this.soundPlayListener);
        this.soundItemButtonSecond.setSoundPlayListener(this.soundPlayListener);
        this.rlText2 = (RelativeLayout) findViewById(R.id.rlText2);
        this.rlText2_2 = (RelativeLayout) findViewById(R.id.rlText2_2);
        this.llText2_2 = (LinearLayout) findViewById(R.id.llText2_2);
        this.item_text2_2 = (MarkerTextView) findViewById(R.id.item_text2_2);
        this.text_item_bookmark_2 = (SizeImageView) findViewById(R.id.text_item_bookmark_2);
        this.text_item_note_2 = (SizeImageView) findViewById(R.id.text_item_note_2);
        this.text_item_menu_button_2 = (Button) findViewById(R.id.text_item_menu_button_2);
        this.item_text2.setOnClickListener(this);
        this.item_text2_2.setOnClickListener(this);
        this.item_text2.setOnSelectionViewListener(this);
        this.item_text2_2.setOnSelectionViewListener(this);
        this.text_item_menu_button.setOnClickListener(this);
        this.text_item_menu_button_2.setOnClickListener(this);
        this.text_item_bookmark.setTextImageSize();
        this.text_item_note.setTextImageSize();
        this.text_item_bookmark_2.setTextImageSize();
        this.text_item_note_2.setTextImageSize();
    }

    public /* synthetic */ void lambda$onFinishInflate$0$HeaderTextList(int i) {
        setAlpha(this.text_item_menu_button, i);
    }

    public /* synthetic */ void lambda$onFinishInflate$1$HeaderTextList(int i) {
        setAlpha(this.text_item_menu_button_2, i);
    }

    private void setAlpha(Button button, int i) {
        if (button != null && button.getVisibility() == 0 && button.getBackground() != null) {
            try {
                button.getBackground().setAlpha(i);
                button.invalidate();
            } catch (Exception unused) {
            }
        }
    }

    private void prepareView() {
        HeaderViewHelper.updateSizeButton(this.llText2, this.textSizeSp);
        HeaderViewHelper.updateSizeButton(this.llText2_2, this.textSizeSp);
        this.item_text_head_1.setTypeface(this.preferences.getTypeface());
        this.item_text_head_2.setTypeface(this.preferences.getTypeface());
        this.item_text2.setTypeface(this.preferences.getTypeface());
        this.item_text2_2.setTypeface(this.preferences.getTypeface());
    }

    private void initValues() {
        this.textSizeSp = (int) this.preferences.getTextSize();
        this.lineSpacing = this.preferences.getSpacing();
        this.positionMin = -1;
        this.positionTextSecond = 0;
    }

    public void setModel(List<Text> list, Set<Integer> set, boolean z, int i) {
        this.firstVisibleItemPosition = i;
        List<Text> list2 = this.textList;
        if (list2 != null) {
            list2.clear();
        } else {
            this.item_text_head_1.setVisibility(8);
            this.item_text_head_2.setVisibility(8);
            this.item_text_head_1_2.setVisibility(8);
            this.item_text_head_2_2.setVisibility(8);
            this.llHead2.setVisibility(8);
        }
        this.firstText = null;
        Set<Integer> set2 = this.firstRankHeaders;
        if (set2 != null) {
            set2.clear();
        }
        this.firstRankHeaders = new HashSet();
        this.secondText = null;
        this.rankView = 0;
        this.textList = list;
        this.secondHeader = false;
        if (z) {
            initValues();
        }
        this.selectedSet = set;
        if (list != null && !list.isEmpty() && z) {
            initTextObserver();
            prepareView();
            prepareTypeView(false);
        }
    }

    public void updateBySettingsChange() {
        List<Text> list;
        if (this.finishInflate && (list = this.textList) != null && !list.isEmpty()) {
            try {
                this.firstRankHeaders = new HashSet();
                this.rankView = 0;
                this.firstText = null;
                this.secondText = null;
                this.secondHeader = false;
                initValues();
                ((SizeImageLinearLayout) findViewById(R.id.text_item_icons)).setImageSize();
                ((SizeImageLinearLayout) findViewById(R.id.text_item_icons_1)).setImageSize();
                ((SizeImageLinearLayout) findViewById(R.id.text_item_icons_2)).setImageSize();
                this.text_item_bookmark.setTextImageSize();
                this.text_item_note.setTextImageSize();
                this.text_item_bookmark_2.setTextImageSize();
                this.text_item_note_2.setTextImageSize();
                invalidateNumberTextView();
                initTextObserver();
                prepareView();
                prepareTypeView(false);
            } catch (Exception unused) {
            }
        }
    }

    private void prepareTypeView(boolean z) {
        for (int i = 0; i < this.textList.size(); i++) {
            Text text = this.textList.get(i);
            if (!z) {
                if (text.isHeader() && (i == 0 || i == 1)) {
                    this.firstRankHeaders.add(Integer.valueOf(text.getRank()));
                    updateHeader(text, this.item_text_head_1, true, false);
                } else if (!text.isSubHeader() || !(i == 0 || i == 1)) {
                    setFirstModel(text);
                    return;
                } else {
                    this.firstRankHeaders.add(Integer.valueOf(text.getRank()));
                    updateHeader(text, this.item_text_head_2, false, false);
                }
            } else if (text.isHeader() && i > 0 && !this.firstRankHeaders.contains(Integer.valueOf(text.getRank()))) {
                this.secondHeader = true;
                this.llHead2.setVisibility(0);
                if (!this.secondHeader) {
                    updateHead2Padding();
                    this.llHead2.invalidate();
                }
                updateHeader(text, this.item_text_head_1_2, true, true);
            } else if (text.isSubHeader() && i > 0 && !this.firstRankHeaders.contains(Integer.valueOf(text.getRank()))) {
                if (!this.secondHeader) {
                    updateHead2Padding();
                    this.llHead2.invalidate();
                }
                this.secondHeader = true;
                this.llHead2.setVisibility(0);
                updateHeader(text, this.item_text_head_2_2, false, true);
            }
        }
        if (z) {
            updateHead2Padding();
            int measuredHeight = ((View) this.item_text2.getParent()).getMeasuredHeight() + this.margin + 15;
            int textSize = (int) this.item_text1.getTextSize();
            if (!isSecondHeader()) {
                lambda$prepareTypeView$2$HeaderTextList(measuredHeight, textSize);
            } else {
                this.llHead2.postDelayed(new Runnable(measuredHeight, textSize) {
                    /* class king.james.bible.android.view.$$Lambda$HeaderTextList$fd_W2oti8xjFOCI43VD4LA4DuW8 */
                    private final /* synthetic */ int f$1;
                    private final /* synthetic */ int f$2;

                    {
                        this.f$1 = r2;
                        this.f$2 = r3;
                    }

                    public final void run() {
                        HeaderTextList.this.lambda$prepareTypeView$2$HeaderTextList(this.f$1, this.f$2);
                    }
                }, 150);
            }
        }
    }

    private Text getFirstText() {
        Text text = this.firstText;
        if (text != null) {
            return text;
        }
        List<Text> list = this.textList;
        if (list == null) {
            return null;
        }
        for (Text text2 : list) {
            if (text2.isVerse()) {
                this.firstText = text2;
                return text2;
            }
        }
        return null;
    }

    private Text getSecondText() {
        Text text = this.secondText;
        if (text != null) {
            return text;
        }
        List<Text> list = this.textList;
        if (list == null) {
            return null;
        }
        boolean z = false;
        for (Text text2 : list) {
            if (text2.isVerse()) {
                if (z) {
                    this.secondText = text2;
                    return text2;
                }
                z = true;
            }
        }
        return null;
    }

    private void setFirstModel(Text text) {
        this.margin = ScreenUtil.getInstance().getPixelSize(R.dimen.padding_element_first);
        this.rlText2.setVisibility(0);
        this.positionTextFirst = text.getRank();
        setPositionView(text.getRank());
        this.positionView = text.getPosition();
        initFirstItem(text);
        this.soundItemButtonFirst.setModels(this.pagePosition, text.getRank());
        this.rlText2.postDelayed(new Runnable() {
            /* class king.james.bible.android.view.$$Lambda$HeaderTextList$G2_guqyZKS5zuYI4eUgNV3aghI */

            public final void run() {
                HeaderTextList.this.checkSecondView();
            }
        }, 50);
    }

    private void setSecondModel(Text text) {
        this.rlText2_2.setVisibility(0);
        this.positionTextSecond = text.getRank();
        this.positionView = text.getPosition();
        this.positionMin++;
        initSecondItem(text);
        this.soundItemButtonSecond.setModels(this.pagePosition, text.getRank());
    }

    /* access modifiers changed from: private */
    public void checkSecondView() {
        int measuredHeight = ((View) this.item_text2.getParent()).getMeasuredHeight() + this.margin + 15;
        int textSize = (int) this.item_text1.getTextSize();
        this.item_text1.setHeight(textSize);
        if (measuredHeight >= textSize || isSecondHeader()) {
            lambda$prepareTypeView$2$HeaderTextList(measuredHeight, textSize);
        } else {
            prepareTypeView(true);
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: postCheckSecondView */
    public void lambda$prepareTypeView$2$HeaderTextList(int i, int i2) {
        if (isSecondHeader()) {
            i += this.llHead2.getMeasuredHeight() + 15;
        }
        if (i >= i2) {
            if (getFirstText() != null) {
                setPositionView(getFirstText().getRank());
            }
            updateList();
            this.rlText2_2.setVisibility(8);
            this.llText2_2.setVisibility(8);
            this.llTextSound2_2.setVisibility(8);
            this.item_text2_2.setVisibility(8);
            this.item_text2_2.setText(BuildConfig.FLAVOR);
            return;
        }
        Text secondText2 = getSecondText();
        if (secondText2 != null) {
            setPositionView(secondText2.getRank());
            updateList();
            this.llText2_2.setVisibility(0);
            this.item_text2_2.setVisibility(0);
            setSecondModel(secondText2);
        }
    }

    private void updateHead2Padding() {
        this.llHead2.setPadding(this.leftMargin + findViewById(R.id.text_item_icons_1).getMeasuredWidth(), 0, 0, 0);
    }

    private boolean isSecondHeader() {
        return this.secondHeader;
    }

    public void setUpdateViewHolderListener(UpdateViewHolderListener updateViewHolderListener2) {
        this.updateViewHolderListener = updateViewHolderListener2;
    }

    private void updateList() {
        UpdateViewHolderListener updateViewHolderListener2 = this.updateViewHolderListener;
        if (updateViewHolderListener2 != null) {
            updateViewHolderListener2.onCompleteDrawHeader(getPositionView(), this.firstVisibleItemPosition);
        }
    }

    private void updateHeader(Text text, MarkerTextView markerTextView, boolean z, boolean z2) {
        markerTextView.setVisibility(0);
        int i = 1;
        setTag(true);
        if (!z2) {
            markerTextView.setGravity(17);
        }
        double d = (double) this.textSizeSp;
        Double.isNaN(d);
        markerTextView.setTextSize(2, (float) ((int) (d * 1.22d)));
        setPositionView(text.getRank());
        SpannableString spannableString = new SpannableString(Html.fromHtml(text.getText()));
        if (!z) {
            i = 2;
        }
        spannableString.setSpan(new StyleSpan(i), 0, spannableString.length(), 33);
        markerTextView.setText(spannableString);
    }

    private Spanned getModeText(int i, String str) {
        StringBuilder sb = new StringBuilder();
        sb.append("<b><font color=");
        sb.append(this.preferences.isNightMode() ? "'#FFBFBFBF'>" : "'#bf360c'>");
        sb.append(i);
        sb.append("</font></b>   ");
        sb.append(str);
        return Html.fromHtml(sb.toString());
    }

    private void initFirstItem(Text text) {
        initItem(text, this.item_text2, this.text_item_bookmark, this.text_item_note, false);
    }

    private void initSecondItem(Text text) {
        initItem(text, this.item_text2_2, this.text_item_bookmark_2, this.text_item_note_2, true);
    }

    private void initItem(Text text, MarkerTextView markerTextView, SizeImageView sizeImageView, SizeImageView sizeImageView2, boolean z) {
        int i;
        SpannableString spannableString;
        int head = text.getHead();
        int position = text.getPosition();
        if (this.positionMin == -1) {
            this.positionMin = position;
        }
        if (position == 1) {
            i = 0;
        } else {
            i = String.valueOf(position).length() + 1;
        }
        if (z) {
            spannableString = new SpannableString(getModeText(position, text.getText()));
        } else {
            spannableString = new SpannableString(Html.fromHtml(text.getText()));
        }
        prepareSpanViews(text, sizeImageView, sizeImageView2);
        markerTextView.setupTransparent(0);
        markerTextView.setLineSpacing(0.0f, this.lineSpacing);
        setTag(false);
        markerTextView.setGravity(55);
        int i2 = 2;
        markerTextView.setTextSize(2, (float) this.textSizeSp);
        if (position != this.positionMin) {
            this.leftMargin = this.widthChapter + ((int) AppUtils.convertDpToPixel(10.0f, getContext()));
            SpannableString spannableString2 = new SpannableString(markerTextView.getText());
            MyLeadingMarginSpan2[] myLeadingMarginSpan2Arr = (MyLeadingMarginSpan2[]) spannableString2.getSpans(0, spannableString2.length(), MyLeadingMarginSpan2.class);
            if (myLeadingMarginSpan2Arr.length > 0) {
                this.spanMargin = myLeadingMarginSpan2Arr[0];
                i2 = 0;
            } else {
                if (this.lineSpacing >= 1.05f) {
                    i2 = 1;
                }
                this.spanMargin = new MyLeadingMarginSpan2(i2, this.leftMargin);
            }
            spannableString.setSpan(this.spanMargin, 0, spannableString.length(), 0);
        } else {
            markerTextView.setTag(0);
            this.item_text1.setText(Integer.toString(text.getChapterNum()));
            invalidateNumberTextView();
            this.leftMargin = this.widthChapter + ((int) AppUtils.convertDpToPixel(10.0f, getContext()));
            int i3 = (int) (((float) this.chapterSizeSp) / (((float) this.textSizeSp) * this.lineSpacing));
            int i4 = 3;
            if (i3 == 0) {
                i3 = 1;
            } else if (i3 > 3) {
                i3 = 3;
            }
            if (i3 <= 3 || ((double) this.lineSpacing) <= 0.95d) {
                i4 = i3;
            }
            if (z) {
                i4 -= this.item_text2.getLineCount();
                if (((int) this.item_text1.getTextSize()) < ((View) this.item_text2.getParent()).getMeasuredHeight() + this.margin + 15 + ((int) this.item_text2.getTextSize()) && i4 > 1) {
                    i4 = 1;
                }
            }
            MyLeadingMarginSpan2 myLeadingMarginSpan2 = new MyLeadingMarginSpan2(i4, this.leftMargin);
            this.spanMargin = myLeadingMarginSpan2;
            spannableString.setSpan(myLeadingMarginSpan2, 0, spannableString.length(), 0);
            i2 = i3;
        }
        if (head == 0) {
            MyLeadingMarginSpan2 myLeadingMarginSpan22 = this.spanMargin;
            if (myLeadingMarginSpan22 != null) {
                if (myLeadingMarginSpan22.getLeadingMarginLineCount() == 0) {
                    this.leftMargin = this.spanMargin.getLeadingMargin(true);
                }
                i2 = this.spanMargin.getLeadingMarginLineCount();
            }
            if (markerTextView.getText().length() > 0) {
                this.spanColor = new BackgroundColorSpan(16777215);
            }
            spannableString.setSpan(this.spanColor, 0, spannableString.length(), 18);
            if (text.isUnderline()) {
                spannableString.setSpan(new UnderlineSpan(), i, spannableString.length(), 18);
            } else if (text.isColor()) {
                markerTextView.setup(text.getHighlight(), (float) this.leftMargin, i2);
            }
        }
        if (!this.selectedSet.isEmpty()) {
            if (this.menuItem == 0) {
                prepareMenuItem();
            }
            returnHeaderItem();
        }
        updateButtons();
        markerTextView.setText(spannableString, text.getRank());
    }

    private void invalidateNumberTextView() {
        this.chapterSizeSp = (int) ((((float) this.textSizeSp) * 64.0f) / ((float) getResources().getInteger(R.integer.def_font_size)));
        this.chapterTopMargin = (int) ((((float) this.textSizeSp) * -5.0f) / ((float) getResources().getInteger(R.integer.def_font_size)));
        this.item_text1.setTextSize(2, (float) this.chapterSizeSp);
        this.item_text1.requestLayout();
        this.item_text1.invalidate();
        this.item_text1.measure(MeasureSpec.makeMeasureSpec(0, 0), MeasureSpec.makeMeasureSpec(0, 0));
        this.widthChapter = this.item_text1.getMeasuredWidth();
        this.heightChapter = this.item_text1.getMeasuredHeight();
        LayoutParams layoutParams = (LayoutParams) this.item_text1.getLayoutParams();
        if (Build.VERSION.SDK_INT < 18) {
            layoutParams.bottomMargin = this.heightChapter * -1;
        }
        layoutParams.topMargin = (int) (((float) this.chapterTopMargin) * getResources().getDisplayMetrics().density);
        this.item_text1.setLayoutParams(layoutParams);
        this.item_text1.setGravity(48);
        this.item_text1.requestLayout();
        this.item_text1.invalidate();
    }

    private void prepareSpanViews(Text text, SizeImageView sizeImageView, SizeImageView sizeImageView2) {
        int i = 0;
        sizeImageView.setVisibility(text.isBookmark() ? 0 : 8);
        if (!text.isNote()) {
            i = 8;
        }
        sizeImageView2.setVisibility(i);
    }

    private void prepareMenuItem() {
        if (this.selectedSet.size() == 1) {
            if (this.selectedSet.contains(Integer.valueOf(this.positionTextFirst))) {
                this.menuItem = this.positionTextFirst;
            }
            if (this.selectedSet.contains(Integer.valueOf(this.positionTextSecond)) && this.positionView > this.positionTextFirst) {
                this.menuItem = this.positionTextSecond;
            }
        }
        if (this.selectedSet.size() == 2 && this.selectedSet.contains(Integer.valueOf(this.positionTextFirst)) && this.selectedSet.contains(Integer.valueOf(this.positionTextSecond)) && this.positionView > this.positionTextFirst) {
            this.menuItem = this.positionTextSecond;
        }
    }

    public void setSelectedSet(Set<Integer> set) {
        this.selectedSet = set;
    }

    private void updateFirstButton() {
        hideButtons(this.text_item_menu_button, this.llText2, this.soundItemButtonFirst);
        Text firstText2 = getFirstText();
        if (firstText2 != null && this.menuItem == firstText2.getRank()) {
            updateButtons(this.text_item_menu_button, this.llText2, this.soundItemButtonFirst);
        }
    }

    private void updateSecondButton() {
        hideButtons(this.text_item_menu_button_2, this.llText2_2, this.soundItemButtonSecond);
        Text secondText2 = getSecondText();
        if (secondText2 != null && this.menuItem == secondText2.getRank() && getPositionView() >= secondText2.getRank()) {
            updateButtons(this.text_item_menu_button_2, this.llText2_2, this.soundItemButtonSecond);
        }
    }

    public void updateButtons() {
        updateFirstButton();
        updateSecondButton();
    }

    private void hideButtons(Button button, LinearLayout linearLayout, SoundButtonHolder soundButtonHolder) {
        button.setVisibility(8);
        soundButtonHolder.hideButton();
        linearLayout.setVisibility(8);
    }

    private void updateButtons(Button button, LinearLayout linearLayout, SoundButtonHolder soundButtonHolder) {
        button.setVisibility(0);
        linearLayout.setVisibility(0);
        soundButtonHolder.showButton();
    }

    public void prepareSoundPauseBackground() {
        this.llText2.postDelayed(new Runnable() {
            /* class king.james.bible.android.view.$$Lambda$HeaderTextList$3TEKyZMxXZI9b8x65LHEC8ZzpE */

            public final void run() {
                HeaderTextList.this.lambda$prepareSoundPauseBackground$3$HeaderTextList();
            }
        }, 300);
    }

    public /* synthetic */ void lambda$prepareSoundPauseBackground$3$HeaderTextList() {
        try {
            Text firstText2 = getFirstText();
            if (firstText2 != null && this.menuItem == firstText2.getRank()) {
                this.soundItemButtonFirst.preparePauseBackground();
                this.soundItemButtonFirst.prepareRepeatPauseBackground();
                if (this.soundItemButtonFirst.isPlay()) {
                    this.soundItemButtonFirst.preparePlayBackground();
                }
                if (this.soundItemButtonFirst.isPlayRepeat()) {
                    this.soundItemButtonFirst.prepareRepeatPlayBackground();
                }
            }
            Text secondText2 = getSecondText();
            if (secondText2 != null && this.menuItem == secondText2.getRank() && getPositionView() >= secondText2.getRank()) {
                this.soundItemButtonSecond.preparePauseBackground();
                this.soundItemButtonSecond.prepareRepeatPauseBackground();
                if (this.soundItemButtonSecond.isPlay()) {
                    this.soundItemButtonSecond.preparePlayBackground();
                }
                if (this.soundItemButtonSecond.isPlayRepeat()) {
                    this.soundItemButtonSecond.prepareRepeatPlayBackground();
                }
            }
        } catch (Exception unused) {
        }
    }

    public void returnHeaderItem() {
        Text firstText2 = getFirstText();
        if (firstText2 != null) {
            returnHeaderItem(this.item_text2, firstText2.getRank());
        }
        Text secondText2 = getSecondText();
        if (secondText2 != null && this.positionTextSecond > 0) {
            returnHeaderItem(this.item_text2_2, secondText2.getRank());
        }
        updateButtons();
    }

    private void returnHeaderItem(MarkerTextView markerTextView, int i) {
        if (this.selectedSet.contains(Integer.valueOf(i))) {
            correctText(markerTextView);
        } else {
            clearText(markerTextView);
        }
    }

    private void correctText(MarkerTextView markerTextView) {
        SpannableString spannableString = new SpannableString(markerTextView.getText());
        spannableString.setSpan(new BackgroundColorSpan(getResources().getColor(this.preferences.isNightMode() ? R.color.selected_item_text_n : R.color.selected_item_text)), 0, spannableString.length(), 18);
        markerTextView.setText(spannableString);
    }

    private void clearText(MarkerTextView markerTextView) {
        SpannableString spannableString = new SpannableString(markerTextView.getText());
        spannableString.setSpan(new BackgroundColorSpan(getResources().getColor(17170445)), 0, spannableString.length(), 18);
        markerTextView.setText(spannableString);
    }

    private void initTextObserver() {
        HeaderViewHelper.setupTextSettings(this.item_text2, this.preferences.getTypeface(), this.textSizeSp, this.lineSpacing);
        HeaderViewHelper.setupTextSettings(this.item_text2_2, this.preferences.getTypeface(), this.textSizeSp, this.lineSpacing);
    }

    public void animItem(int i) {
        if (getFirstText() != null) {
            HeaderViewHelper.animItem(i <= getFirstText().getRank() ? this.item_text2 : this.item_text2_2);
        }
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.item_text2:
                itemTextClick(getFirstText());
                return;
            case R.id.item_text2_2:
                itemTextClick(getSecondText());
                return;
            case R.id.text_item_menu_button:
            case R.id.text_item_menu_button_2:
                EventBus.getDefault().post(new ClickAddEvent(this.unicId));
                SoundHelper.getInstance().pause();
                return;
            default:
                return;
        }
    }

    private void itemTextClick(Text text) {
        if (text != null) {
            DailyVerseService.getInstance().clearDailyVerseBackStack();
            DailyReadingService.getInstance().clearDailyReadingBackStack();
            BackStackService.getInstance().clear();
            SoundHelper.getInstance().pause();
            EventBus.getDefault().post(new ClickHeaderEvent(text.getRank(), this.unicId));
        }
    }

    @Override // king.james.bible.android.sound.listener.page.SoundInitListener
    public void startInitService(int i) {
        ((Activity) getContext()).runOnUiThread(new Runnable(i) {
            /* class king.james.bible.android.view.$$Lambda$HeaderTextList$rYlZlmMKhncZzPEz7ozLJRcYWq4 */
            private final /* synthetic */ int f$1;

            {
                this.f$1 = r2;
            }

            public final void run() {
                HeaderTextList.this.lambda$startInitService$5$HeaderTextList(this.f$1);
            }
        });
    }

    public /* synthetic */ void lambda$startInitService$5$HeaderTextList(int i) {
        SoundButtonHolder holder = getHolder(i);
        if (holder != null && holder.getSoundButton() != null) {
            holder.getSoundButton().postDelayed(new Runnable() {
                /* class king.james.bible.android.view.$$Lambda$HeaderTextList$53JMf7pPzWi0YubYi0kYlHNxKg */

                public final void run() {
                    HeaderTextList.lambda$null$4(SoundButtonHolder.this);
                }
            }, 300);
        }
    }

    static /* synthetic */ void lambda$null$4(SoundButtonHolder soundButtonHolder) {
        try {
            soundButtonHolder.showProgress();
        } catch (Exception unused) {
        }
    }

    private SoundButtonHolder getHolder(int i) {
        SoundButtonHolder soundButtonHolder = this.soundItemButtonFirst;
        if (soundButtonHolder != null && soundButtonHolder.getRank() == i) {
            return this.soundItemButtonFirst;
        }
        SoundButtonHolder soundButtonHolder2 = this.soundItemButtonSecond;
        if (soundButtonHolder2 == null || soundButtonHolder2.getRank() != i) {
            return null;
        }
        return this.soundItemButtonSecond;
    }

    @Override // king.james.bible.android.sound.listener.page.SoundInitListener
    public void completeInitService(int i) {
        ((Activity) getContext()).runOnUiThread(new Runnable(i) {
            /* class king.james.bible.android.view.$$Lambda$HeaderTextList$7ZXT66peDji8cEcPqTiHUdS_Ms */
            private final /* synthetic */ int f$1;

            {
                this.f$1 = r2;
            }

            public final void run() {
                HeaderTextList.this.lambda$completeInitService$7$HeaderTextList(this.f$1);
            }
        });
    }

    public /* synthetic */ void lambda$completeInitService$7$HeaderTextList(int i) {
        SoundButtonHolder holder = getHolder(i);
        if (holder != null && holder.getSoundButton() != null) {
            holder.getSoundButton().postDelayed(new Runnable() {
                /* class king.james.bible.android.view.$$Lambda$HeaderTextList$c1GZOAhaVDKp4b9yC2urSdsP9Tg */

                public final void run() {
                    HeaderTextList.lambda$null$6(SoundButtonHolder.this);
                }
            }, 300);
        }
    }

    static /* synthetic */ void lambda$null$6(SoundButtonHolder soundButtonHolder) {
        try {
            soundButtonHolder.hideProgress();
        } catch (Exception unused) {
        }
    }

    @Override // king.james.bible.android.view.MarkerTextView.OnSelectionListener
    public void onTextViewClick(View view, int i) {
        Text firstText2 = getFirstText();
        if (firstText2 == null || i != firstText2.getRank()) {
            Text secondText2 = getSecondText();
            if (secondText2 != null && i == secondText2.getRank()) {
                itemTextClick(secondText2);
                return;
            }
            return;
        }
        itemTextClick(firstText2);
    }
}
