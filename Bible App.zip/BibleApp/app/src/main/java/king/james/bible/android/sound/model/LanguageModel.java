package king.james.bible.android.sound.model;

import com.karumi.dexter.BuildConfig;

public class LanguageModel {
    private String country;
    private String id;
    private String language;
    private String name;

    public LanguageModel(String str, String str2, String str3) {
        str = str == null ? BuildConfig.FLAVOR : str;
        str2 = str2 == null ? BuildConfig.FLAVOR : str2;
        str3 = str3 == null ? BuildConfig.FLAVOR : str3;
        this.id = str2 + "_" + str3;
        this.name = str;
        this.language = str2;
        this.country = str3;
    }

    public String getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public String getLanguage() {
        return this.language;
    }

    public String getCountry() {
        return this.country;
    }
}
