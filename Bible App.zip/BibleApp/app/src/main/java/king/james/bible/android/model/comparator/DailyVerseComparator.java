package king.james.bible.android.model.comparator;

import java.util.Comparator;
import king.james.bible.android.model.DailyVerse;

public class DailyVerseComparator implements Comparator<DailyVerse> {
    public int compare(DailyVerse dailyVerse, DailyVerse dailyVerse2) {
        return Long.valueOf(dailyVerse2.getId()).compareTo(Long.valueOf(dailyVerse.getId()));
    }
}
