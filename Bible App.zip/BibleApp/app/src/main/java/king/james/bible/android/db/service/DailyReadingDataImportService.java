package king.james.bible.android.db.service;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import king.james.bible.android.PlanModeUtil;
import king.james.bible.android.model.Plan;
import king.james.bible.android.model.PlanChapterDay;
import king.james.bible.android.model.PlanDay;
import king.james.bible.android.model.export.PlanChapterDayExport;
import king.james.bible.android.model.export.PlanDayExport;
import king.james.bible.android.model.export.PlanExport;

public class DailyReadingDataImportService {
    private DailyReadingDataService service = new DailyReadingDataService();

    public void importData(List<PlanExport> list) {
        List<Plan> planList;
        if (!(list == null || list.isEmpty() || (planList = this.service.getPlanList()) == null || planList.isEmpty())) {
            HashMap hashMap = new HashMap();
            for (PlanExport planExport : list) {
                hashMap.put(Long.valueOf(planExport.getId()), planExport);
            }
            for (Plan plan : planList) {
                if (hashMap.containsKey(Long.valueOf(plan.getId()))) {
                    PlanExport planExport2 = (PlanExport) hashMap.get(Long.valueOf(plan.getId()));
                    plan.setStarted(true);
                    plan.setModeId(planExport2.getModeId());
                    plan.setStartDate(((long) ((int) (planExport2.getStartDate() / 86400000))) * 86400000);
                    plan.setNotify(planExport2.isNotify());
                    plan.setNotifyTime(planExport2.getNotifyTime());
                    importData(this.service.startPlan(plan, PlanModeUtil.plansMode.get(Integer.valueOf(plan.getModeId()))), planExport2);
                }
            }
        }
    }

    private void importData(Plan plan, PlanExport planExport) {
        for (PlanDay planDay : plan.getPlanDays()) {
            if (planExport.getPlanDays().containsKey(Integer.valueOf(planDay.getDay()))) {
                PlanDayExport planDayExport = planExport.getPlanDays().get(Integer.valueOf(planDay.getDay()));
                planDay.setReaded(planDayExport.isReaded());
                this.service.completeAll(planDay, plan.getModeId());
                if (planDayExport.getPlanChapterDays().isEmpty()) {
                    planExport.getPlanDays().remove(Integer.valueOf(planDay.getDay()));
                } else {
                    importData(planDay, planDayExport);
                    planExport.getPlanDays().remove(Integer.valueOf(planDay.getDay()));
                }
            }
        }
    }

    private void importData(PlanDay planDay, PlanDayExport planDayExport) {
        for (PlanChapterDay planChapterDay : planDay.getPlanChapterDays()) {
            Iterator<PlanChapterDayExport> it = planDayExport.getPlanChapterDays().iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                PlanChapterDayExport next = it.next();
                if (planChapterDay.getChapterNum() == next.getChapterNum() && planChapterDay.getChapterOrder() == next.getChapterOrder()) {
                    planChapterDay.setViewed(true);
                    this.service.viewChapter(planChapterDay);
                    break;
                }
            }
        }
    }
}
