package king.james.bible.android.service.observable;

import java.util.HashMap;
import java.util.Map;
import king.james.bible.android.dialog.SelectActionDialog;
import king.james.bible.android.model.DialogDataBookmark;

public class SelectActionDialogListenerObservable implements SelectActionDialog.SelectActionDialogListener {
    private static SelectActionDialogListenerObservable instance;
    private Map<Integer, SelectActionDialog.SelectActionDialogListener> listeners;

    private SelectActionDialogListenerObservable() {
    }

    public static SelectActionDialogListenerObservable getInstance() {
        if (instance == null) {
            synchronized (SelectActionDialogListenerObservable.class) {
                if (instance == null) {
                    instance = new SelectActionDialogListenerObservable();
                }
            }
        }
        return instance;
    }

    public void subscribe(int i, SelectActionDialog.SelectActionDialogListener selectActionDialogListener) {
        checkList();
        this.listeners.put(Integer.valueOf(i), selectActionDialogListener);
    }

    public void remove(int i) {
        checkList();
        this.listeners.remove(Integer.valueOf(i));
    }

    private void checkList() {
        if (this.listeners == null) {
            this.listeners = new HashMap();
        }
    }

    @Override // king.james.bible.android.dialog.SelectActionDialog.SelectActionDialogListener
    public void onActionSelected(int i, SelectActionDialog.DialogActions dialogActions, DialogDataBookmark dialogDataBookmark) {
        checkList();
        if (this.listeners.containsKey(Integer.valueOf(i))) {
            this.listeners.get(Integer.valueOf(i)).onActionSelected(i, dialogActions, dialogDataBookmark);
        }
    }
}
