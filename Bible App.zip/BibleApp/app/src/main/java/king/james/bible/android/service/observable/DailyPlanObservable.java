package king.james.bible.android.service.observable;

import java.util.HashSet;
import java.util.Set;
import king.james.bible.android.model.Plan;
import king.james.bible.android.service.observable.listener.DailyPlanListener;

public class DailyPlanObservable implements DailyPlanListener {
    private static DailyPlanObservable instance;
    private Set<DailyPlanListener> listeners;

    private DailyPlanObservable() {
    }

    public static DailyPlanObservable getInstance() {
        if (instance == null) {
            synchronized (DailyPlanObservable.class) {
                if (instance == null) {
                    instance = new DailyPlanObservable();
                }
            }
        }
        return instance;
    }

    public void subscribe(DailyPlanListener dailyPlanListener) {
        checkList();
        this.listeners.add(dailyPlanListener);
    }

    public void remove(DailyPlanListener dailyPlanListener) {
        checkList();
        this.listeners.remove(dailyPlanListener);
    }

    private void checkList() {
        if (this.listeners == null) {
            this.listeners = new HashSet();
        }
    }

    @Override // king.james.bible.android.service.observable.listener.DailyPlanListener
    public void loadDailyPlanComplete(Plan plan) {
        checkList();
        for (DailyPlanListener dailyPlanListener : this.listeners) {
            if (dailyPlanListener != null) {
                dailyPlanListener.loadDailyPlanComplete(plan);
            }
        }
    }
}
