package king.james.bible.android.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.text.SpannableString;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;
import king.james.bible.android.model.SpanType;
import king.james.bible.android.utils.BitmapSpanUtil;
import king.james.bible.android.utils.ColorUtil;

public class MarkerTextView extends TextView {
    private int chapterLines = 0;
    private float leftMargin = 0.0f;
    private OnSelectionListener mOnSelectionListener;
    private int markerResId = 0;
    private Paint paint;
    private int position;
    private long startClickTime;

    public interface OnSelectionListener {
        void onTextViewClick(View view, int i);
    }

    public MarkerTextView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init();
    }

    private void init() {
        Paint paint2 = new Paint();
        this.paint = paint2;
        paint2.setStyle(Paint.Style.FILL);
        this.paint.setColor(0);
    }

    /* access modifiers changed from: protected */
    public void onDraw(Canvas canvas) {
        onDrawBackground(canvas);
        super.onDraw(canvas);
    }

    /* access modifiers changed from: protected */
    public void onDrawBackground(Canvas canvas) {
        if (this.markerResId != 0) {
            float paddingLeft = (float) getPaddingLeft();
            float paddingTop = (float) getPaddingTop();
            for (int i = 0; i < getLineCount(); i++) {
                float measureText = getPaint().measureText(getText(), getLayout().getLineStart(i), getLayout().getLineEnd(i));
                if (((int) measureText) != 0) {
                    float lineHeight = (float) (getLineHeight() * i);
                    int lineHeight2 = getLineHeight() > 0 ? getLineHeight() : 1;
                    int i2 = this.chapterLines;
                    if (i2 > 0) {
                        if (i < i2) {
                            drawBitmap(canvas, measureText, lineHeight2, this.leftMargin + paddingLeft, paddingTop + lineHeight);
                        } else {
                            drawBitmap(canvas, measureText, lineHeight2, paddingLeft, paddingTop + lineHeight);
                        }
                    } else if (i == 0) {
                        float f = this.leftMargin;
                        drawBitmap(canvas, measureText - f, lineHeight2, f + paddingLeft, paddingTop + lineHeight);
                    } else {
                        drawBitmap(canvas, measureText, lineHeight2, paddingLeft, paddingTop + lineHeight);
                    }
                } else {
                    return;
                }
            }
        }
    }

    private void drawBitmap(Canvas canvas, float f, int i, float f2, float f3) {
        Bitmap bitmapFromResource = BitmapSpanUtil.getInstance().getBitmapFromResource(this.markerResId, (int) f, i);
        if (bitmapFromResource != null) {
            canvas.drawBitmap(bitmapFromResource, f2, f3, (Paint) null);
        }
    }

    public void setupTransparent(int i) {
        this.markerResId = 0;
        setup(0.0f, i);
    }

    public void setup(SpanType spanType, float f, int i) {
        this.markerResId = ColorUtil.getColorDrawableByValue(spanType);
        setup(f, i);
    }

    private void setup(float f, int i) {
        this.leftMargin = f;
        this.chapterLines = i;
        invalidate();
    }

    public void setOnSelectionViewListener(OnSelectionListener onSelectionListener) {
        this.mOnSelectionListener = onSelectionListener;
    }

    public void setText(SpannableString spannableString, int i) {
        this.position = i;
        setText(spannableString);
    }

    public void setText(SpannableString spannableString) {
        super.setText((CharSequence) spannableString);
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        try {
            if (this.mOnSelectionListener == null) {
                return super.onTouchEvent(motionEvent);
            }
            int action = motionEvent.getAction();
            if (action == 0) {
                this.startClickTime = System.currentTimeMillis();
            } else if (action == 1) {
                if (System.currentTimeMillis() - this.startClickTime < 1200) {
                    onClick(motionEvent);
                }
            }
            return true;
        } catch (Exception unused) {
        }
    }

    private void onClick(MotionEvent motionEvent) {
        if (this.mOnSelectionListener != null && motionEvent != null && getOffsetForPosition(motionEvent.getX(), motionEvent.getY()) > 0) {
            this.mOnSelectionListener.onTextViewClick((View) getParent(), this.position);
        }
    }
}
