package king.james.bible.android.dialog;

import android.annotation.SuppressLint;
import android.view.View;
import android.widget.TextView;
import king.james.bible.android.R;
import king.james.bible.android.service.PowerManagerService;
import king.james.bible.android.utils.BiblePreferences;
@SuppressLint({"NewApi", "WrongConstant"})

public class CompletePlanDialog extends BaseForegroundDialog implements View.OnClickListener {
    private TextView textTextView;
    private TextView yesTextView;

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.BaseDialogFragment
    public int getLayoutResourceId() {
        return BiblePreferences.getInstance().isNightMode() ? R.layout.delete_dialog_n : R.layout.delete_dialog;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.BaseDialogFragment
    public void mapViews(View view) {
        view.findViewById(R.id.noButton).setVisibility(8);
        view.findViewById(R.id.yesButton).setOnClickListener(this);
        this.textTextView = (TextView) view.findViewById(R.id.textTextView);
        this.yesTextView = (TextView) view.findViewById(R.id.yesTextView);
        PowerManagerService.getInstance().start();
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.BaseDialogFragment
    public void initActions() {
        this.textTextView.setText(R.string.daily_readingplancomplete);
        this.yesTextView.setText(R.string.ok);
    }

    public void onClick(View view) {
        if (view.getId() == R.id.yesButton) {
            dismiss();
        }
    }
}
