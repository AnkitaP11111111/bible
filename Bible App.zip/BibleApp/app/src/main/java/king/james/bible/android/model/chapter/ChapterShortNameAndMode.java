package king.james.bible.android.model.chapter;

public class ChapterShortNameAndMode {
    private int chapterID;
    private String longName;
    private int mode;
    private int num;

    public ChapterShortNameAndMode() {
    }

    public ChapterShortNameAndMode(String str, String str2, int i, int i2) {
        this.longName = str2;
        this.mode = i;
        this.chapterID = i2;
    }

    public String getLongName() {
        return this.longName;
    }

    public int getMode() {
        return this.mode;
    }

    public int getChapterID() {
        return this.chapterID;
    }

    public int getNum() {
        return this.num;
    }

    public void setNum(int i) {
        this.num = i;
    }
}
