package king.james.bible.android.view;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ImageView;
import king.james.bible.android.utils.BiblePreferences;

public class SizeImageView extends ImageView {
    public SizeImageView(Context context) {
        super(context);
    }

    public SizeImageView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public SizeImageView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    public SizeImageView(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
    }

    public void setVisibility(int i) {
        if (getParent() instanceof SizeImageLinearLayout) {
            ((SizeImageLinearLayout) getParent()).setImageSize();
        }
        setTextImageSize();
        super.setVisibility(i);
    }

    public void setTextImageSize() {
        int textImageSize = (int) BiblePreferences.getInstance().getTextImageSize();
        setMeasuredDimension(textImageSize, textImageSize);
        getLayoutParams().width = textImageSize;
        getLayoutParams().height = textImageSize;
        invalidate();
    }
}
