package king.james.bible.android.model.comparator;

import java.util.Comparator;
import king.james.bible.android.model.SelectChapter;

public class SelectChapterComparator implements Comparator<SelectChapter> {
    public int compare(SelectChapter selectChapter, SelectChapter selectChapter2) {
        return Long.valueOf(selectChapter.getId().longValue()).compareTo(selectChapter2.getId());
    }
}
