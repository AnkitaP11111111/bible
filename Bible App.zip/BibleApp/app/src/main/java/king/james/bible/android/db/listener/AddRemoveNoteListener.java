package king.james.bible.android.db.listener;

public interface AddRemoveNoteListener {
    void onComplete(long j);
}
