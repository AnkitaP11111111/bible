package king.james.bible.android.model.chapter;

public class ChapterSubChapterResult {
    private int chapter;
    private int id;
    private int subChapter;
    private String title;

    public ChapterSubChapterResult(int i, int i2, int i3, String str) {
        this.chapter = i;
        this.subChapter = i2;
        this.id = i3;
        this.title = str;
    }

    public int getChapter() {
        return this.chapter;
    }

    public int getSubChapter() {
        return this.subChapter;
    }

    public void setSubChapter(int i) {
        this.subChapter = i;
    }

    public int getId() {
        return this.id;
    }

    public String getTitle() {
        return this.title;
    }
}
