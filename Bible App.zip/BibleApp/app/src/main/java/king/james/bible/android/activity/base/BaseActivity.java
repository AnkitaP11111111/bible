package king.james.bible.android.activity.base;

import android.annotation.SuppressLint;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import king.james.bible.android.R;
import java.util.Timer;
import java.util.TimerTask;
import king.james.bible.android.db.MigrationUserDataUtil;
import king.james.bible.android.sound.SoundHelper;
import king.james.bible.android.utils.BiblePreferences;

public class BaseActivity extends AppCompatActivity {
    public static boolean NEED_SAVE_BACKUP = false;
    private BiblePreferences preferences;
    private Timer timer;

    /* access modifiers changed from: protected */
    @Override // androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, androidx.fragment.app.FragmentActivity
    @SuppressLint({"NewApi"})
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        try {
            BiblePreferences instance = BiblePreferences.getInstance();
            this.preferences = instance;
            instance.lambda$restoreAsync$0$BiblePreferences();
        } catch (Exception unused) {
        }
        customStatusBar();
        startTimer();
    }

    private void startTimer() {
        Timer timer2 = new Timer();
        this.timer = timer2;
        timer2.schedule(new TimerTask() {
            /* class king.james.bible.android.activity.base.BaseActivity.AnonymousClass1 */

            public void run() {
                try {
                    if (BaseActivity.NEED_SAVE_BACKUP) {
                        MigrationUserDataUtil.getInstance().readUserDataAsync();
                        BaseActivity.NEED_SAVE_BACKUP = false;
                    }
                } catch (Exception unused) {
                }
            }
        }, 300000, 300000);
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        customStatusBar();
    }

    @SuppressLint({"NewApi"})
    public void customStatusBar() {
        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().addFlags(Integer.MIN_VALUE);
            if (!this.preferences.isNightMode()) {
                getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.title_bar_color));
                getWindow().setNavigationBarColor(ContextCompat.getColor(this, R.color.title_bar_color));
                return;
            }
            getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.title_bar_color_n));
            getWindow().setNavigationBarColor(ContextCompat.getColor(this, R.color.title_bar_color_n));
        }
    }

    /* access modifiers changed from: protected */
    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity
    public void onDestroy() {
        SoundHelper.getInstance().stopForeground();
        stopTimer();
        super.onDestroy();
    }

    private void stopTimer() {
        Timer timer2 = this.timer;
        if (timer2 != null) {
            timer2.cancel();
        }
        this.timer = null;
    }
}
