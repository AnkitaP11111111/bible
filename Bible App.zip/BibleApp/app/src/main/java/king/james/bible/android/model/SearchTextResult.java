package king.james.bible.android.model;

import android.text.SpannableString;

public class SearchTextResult {
    private long id;
    private SpannableString text;

    public long getId() {
        return this.id;
    }

    public void setId(long j) {
        this.id = j;
    }

    public SpannableString getText() {
        return this.text;
    }

    public void setText(SpannableString spannableString) {
        this.text = spannableString;
    }
}
