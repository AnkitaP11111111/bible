package king.james.bible.android.sound.listener.page;

public interface SoundVerseListener {
    void onPauseSound(int i);

    void onPlayError(String str);
}
