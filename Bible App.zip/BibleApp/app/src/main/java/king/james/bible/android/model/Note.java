package king.james.bible.android.model;

public class Note {
    private String note;
    private int position;

    public void setId(long j) {
    }

    public String getNote() {
        return this.note;
    }

    public void setNote(String str) {
        this.note = str;
    }

    public int getPosition() {
        return this.position;
    }

    public void setPosition(int i) {
        this.position = i;
    }
}
