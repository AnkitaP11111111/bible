package king.james.bible.android.model;

import java.io.Serializable;
import java.util.Iterator;
import java.util.List;

public class PlanDay implements Serializable {
    private int day;
    private long id;
    private List<PlanChapterDay> planChapterDays;
    private long planId;
    private boolean readed;

    public long getId() {
        return this.id;
    }

    public void setId(long j) {
        this.id = j;
    }

    public long getPlanId() {
        return this.planId;
    }

    public void setPlanId(long j) {
        this.planId = j;
    }

    public int getDay() {
        return this.day;
    }

    public void setDay(int i) {
        this.day = i;
    }

    public boolean isReaded() {
        return this.readed;
    }

    public void setReaded(boolean z) {
        this.readed = z;
    }

    public List<PlanChapterDay> getPlanChapterDays() {
        return this.planChapterDays;
    }

    public void setPlanChapterDays(List<PlanChapterDay> list) {
        this.planChapterDays = list;
    }

    public boolean isCompeteDay() {
        boolean z;
        if (getPlanChapterDays() == null || getPlanChapterDays().isEmpty()) {
            return false;
        }
        Iterator<PlanChapterDay> it = getPlanChapterDays().iterator();
        while (true) {
            if (it.hasNext()) {
                if (!it.next().isViewed()) {
                    z = false;
                    break;
                }
            } else {
                z = true;
                break;
            }
        }
        if (isReaded() || z) {
            return true;
        }
        return false;
    }
}
