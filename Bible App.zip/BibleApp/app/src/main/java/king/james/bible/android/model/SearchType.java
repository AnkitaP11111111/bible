package king.james.bible.android.model;

public enum SearchType {
    ALL,
    OT,
    NT,
    AP,
    CURRENT
}
