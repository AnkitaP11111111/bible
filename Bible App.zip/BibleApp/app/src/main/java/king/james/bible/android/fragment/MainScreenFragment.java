package king.james.bible.android.fragment;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;
import com.karumi.dexter.BuildConfig;
import king.james.bible.android.R;
import java.util.HashMap;
import java.util.Map;
import king.james.bible.android.activity.MainFragmentActivity;
import king.james.bible.android.activity.base.BaseActivity;
import king.james.bible.android.activity.base.NavigationActivity;
import king.james.bible.android.db.BibleDataBase;
import king.james.bible.android.dialog.WaitAudioDialog;
import king.james.bible.android.event.HidePageSelectionEvent;
import king.james.bible.android.event.PagesSwipeHintHideEvent;
import king.james.bible.android.event.ShowAudioWaitDialogEvent;
import king.james.bible.android.event.UpdateMainFragmentEvent;
import king.james.bible.android.fragment.MainScreenFragment;
import king.james.bible.android.fragment.contents.ContentsMainFragment;
import king.james.bible.android.model.chapter.ChapterSubChapterResult;
import king.james.bible.android.service.BackStackService;
import king.james.bible.android.service.DailyReadingService;
import king.james.bible.android.service.DailyVerseService;
import king.james.bible.android.service.LastChaptersService;
import king.james.bible.android.service.PowerManagerService;
import king.james.bible.android.sound.SoundHelper;
import king.james.bible.android.sound.listener.page.SoundPageListener;
import king.james.bible.android.utils.BiblePreferences;
import king.james.bible.android.view.animator.ContentTitlePageAnimator;
import king.james.bible.android.view.header.HeaderViewHelper;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

public class MainScreenFragment extends BaseFragment implements View.OnClickListener, ViewPager.OnPageChangeListener {
    private  ChapterSubChapterResult r23;
    private View actionbarMain;
    private boolean activityResult = false;
    protected BibleDataBase bibleDB;
    private int currentPosition = 0;
    private String currentTitle = BuildConfig.FLAVOR;
    private boolean customTitleView = false;
    private int firstPagePosition = -1;
    private boolean lockPowerManager = false;
    private ViewPager mPager;
    private ScreenSlidePagerAdapter mPagerAdapter;
    private int numPages = Integer.MAX_VALUE;
    private int outerChapter = 0;
    private int outerPositionRank = 0;
    private int outerSubChapter = 0;
    protected BiblePreferences preferences;
    private boolean scrollToNote = false;
    private  int r2;
    private  int r3;
    private  boolean r5;
    private SoundPageListener soundPageListener = new SoundPageListener() {
        /* class king.james.bible.android.fragment.MainScreenFragment.AnonymousClass1 */

        @Override // king.james.bible.android.sound.listener.page.SoundPageListener
        public void onNextSoundPage(int i, int i2) {
            if (MainScreenFragment.this.getActivity() != null) {
                MainScreenFragment.this.getActivity().runOnUiThread(new Runnable() {
                    /* class king.james.bible.android.fragment.$$Lambda$MainScreenFragment$1$3l5k8ZTf0E0iiolIT_vW0ComcaY */
                    private final /* synthetic */ int f$1;
                    private final /* synthetic */ int f$2;

                    {
                        this.f$1 = r2;
                        this.f$2 = r3;
                    }

                    public final void run() {
                        lambda$onNextSoundPage$2$MainScreenFragment$1(this.f$1, this.f$2);
                    }
                });
            }
        }

        public /* synthetic */ void lambda$onNextSoundPage$2$MainScreenFragment$1(int i, int i2) {
            boolean z;
            int min = Math.min(MainScreenFragment.this.mPagerAdapter.getCount() - 1, i);
            int currentItem = MainScreenFragment.this.mPager.getCurrentItem();
            if (min != MainScreenFragment.this.mPager.getCurrentItem()) {
                MainScreenFragment.this.lockPowerManager = true;
                MainScreenFragment.this.mPager.postDelayed(new Runnable() {
                    /* class king.james.bible.android.fragment.$$Lambda$MainScreenFragment$1$fgSwglMNC4_G7KyjWJzTlbUFTVg */
                    private final /* synthetic */ int f$1;

                    {
                        this.f$1 = r2;
                    }

                    public final void run() {
                        lambda$null$0$MainScreenFragment$1(this.f$1);
                    }
                }, 200);
                z = true;
            } else {
                z = false;
            }
            MainScreenFragment.this.mPager.postDelayed(new Runnable(min, currentItem, i2, z) {
                private  int r4;
                /* class king.james.bible.android.fragment.$$Lambda$MainScreenFragment$1$drWXB7Mk9Tk21MC5nyWRcl9KKLo */
                private final /* synthetic */ int f$1;
                private final /* synthetic */ int f$2;
                private final /* synthetic */ int f$3;
                private final /* synthetic */ boolean f$4;

                {
                    this.f$1 = r2;
                    this.f$2 = r3;
                    this.f$3 = r4;
                    this.f$4 = r5;
                }

                public final void run() {
                lambda$null$1$MainScreenFragment$1(this.f$1, this.f$2, this.f$3, this.f$4);
                }
            }, 500);
        }

        public /* synthetic */ void lambda$null$0$MainScreenFragment$1(int i) {
            MainScreenFragment.this.mPager.setCurrentItem(i);
        }

        public /* synthetic */ void lambda$null$1$MainScreenFragment$1(int i, int i2, int i3, boolean z) {
            if (MainScreenFragment.this.mPagerAdapter != null) {
                if (i != i2) {
                    ScreenSlidePageFragment fragment = MainScreenFragment.this.mPagerAdapter.getFragment(i);
                    if (!(MainScreenFragment.this.getActivity() == null || fragment == null)) {
                        fragment.stopAllVerses();
                    }
                }
                ScreenSlidePageFragment fragment2 = MainScreenFragment.this.mPagerAdapter.getFragment(i + 1);
                if (MainScreenFragment.this.getActivity() != null && fragment2 != null) {
                    fragment2.nextVerse(i3, z);
                    MainScreenFragment.this.lockPowerManager = false;
                }
            }
        }

        @Override // king.james.bible.android.sound.listener.page.SoundPageListener
        public void prepareSoundHeaderPauseBackground(int i) {
            if (MainScreenFragment.this.mPager != null) {
                MainScreenFragment.this.mPager.postDelayed(new Runnable() {
                    /* class king.james.bible.android.fragment.$$Lambda$MainScreenFragment$1$fxmtOK8WtYV1YNXbaEPgMS7mY */
                    private final /* synthetic */ int f$1;

                    {
                        this.f$1 = r2;
                    }

                    public final void run() {
                   lambda$prepareSoundHeaderPauseBackground$3$MainScreenFragment$1(this.f$1);
                    }
                }, 300);
            }
        }

        public /* synthetic */ void lambda$prepareSoundHeaderPauseBackground$3$MainScreenFragment$1(int i) {
            if (MainScreenFragment.this.mPagerAdapter != null) {
                ScreenSlidePageFragment fragment = MainScreenFragment.this.mPagerAdapter.getFragment(Math.min(MainScreenFragment.this.mPagerAdapter.getCount() - 1, i) + 1);
                if (MainScreenFragment.this.getActivity() != null && fragment != null) {
                    fragment.prepareSoundHeaderPauseBackground();
                }
            }
        }
    };
    private TextView titleText;
    private View toolbarMenuView;
    private View toolbarSearchView;
    private boolean updateAgrs = false;
    private boolean updatePagePosition = true;

    @Override // androidx.viewpager.widget.ViewPager.OnPageChangeListener
    public void onPageScrollStateChanged(int i) {
    }

    @Override // androidx.viewpager.widget.ViewPager.OnPageChangeListener
    public void onPageScrolled(int i, float f, int i2) {
    }

    @Override // androidx.fragment.app.Fragment
    @SuppressLint({"NewApi"})
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        BiblePreferences instance = BiblePreferences.getInstance();
        this.preferences = instance;
        instance.lambda$restoreAsync$0$BiblePreferences();
        HeaderViewHelper.init(getActivity());
        SoundHelper.getInstance().init(getActivity());
        try {
            View inflate = layoutInflater.inflate(this.preferences.isNightMode() ? R.layout.fragment_main_screen_layout_n : R.layout.fragment_main_screen_layout, (ViewGroup) null);
            this.titleText = (TextView) inflate.findViewById(R.id.main_page_title_text);
            this.actionbarMain = inflate.findViewById(R.id.actionbar_main);
            this.toolbarMenuView = inflate.findViewById(R.id.main_page_menu_btn);
            this.toolbarSearchView = inflate.findViewById(R.id.main_page_search_btn);
            updateToolbar();
            BibleDataBase instance2 = BibleDataBase.getInstance();
            this.bibleDB = instance2;
            this.numPages = instance2.getTotalPagesCount();
            this.mPager = (ViewPager) inflate.findViewById(R.id.main_page_frame_container);
            initPager();
            ((RelativeLayout) inflate.findViewById(R.id.main_page_title)).setOnClickListener(this);
            return inflate;
        } catch (Exception unused) {
            getActivity().finish();
            return null;
        }
    }

    @Override // king.james.bible.android.fragment.BaseFragment
    public void updateToolbar() {
        View view = this.toolbarMenuView;
        if (view != null) {
            view.setOnClickListener(this);
            this.toolbarSearchView.setOnClickListener(this);
            if (getActivity() instanceof MainFragmentActivity) {
                ((MainFragmentActivity) getActivity()).updateDrawerState();
            }
        }
    }

    private void initPager() {
        ScreenSlidePagerAdapter screenSlidePagerAdapter = new ScreenSlidePagerAdapter(getChildFragmentManager());
        this.mPagerAdapter = screenSlidePagerAdapter;
        this.mPager.setAdapter(screenSlidePagerAdapter);
        this.mPager.addOnPageChangeListener(this);
        this.mPager.postDelayed(new Runnable() {
            /* class king.james.bible.android.fragment.$$Lambda$MainScreenFragment$FkhVBqAlnF16XAoGdYyM2p5Erg */

            public final void run() {
                MainScreenFragment.this.lambda$initPager$0$MainScreenFragment();
            }
        }, 3000);
        int currentPageBible = this.preferences.getCurrentPageBible();
        int i = this.numPages;
        this.mPager.setCurrentItem(currentPageBible < i ? this.preferences.getCurrentPageBible() : i - 1);
        SoundHelper.getInstance().setSoundPageListener(this.soundPageListener);
    }

    public /* synthetic */ void lambda$initPager$0$MainScreenFragment() {
        ViewPager viewPager = this.mPager;
        if (viewPager != null) {
            viewPager.setOffscreenPageLimit(3);
        }
    }

    public boolean hideSelectionsIfNeeded() {
        ScreenSlidePageFragment fragment;
        ScreenSlidePagerAdapter screenSlidePagerAdapter = this.mPagerAdapter;
        if (screenSlidePagerAdapter == null || (fragment = screenSlidePagerAdapter.getFragment(this.currentPosition)) == null || !fragment.isMenuButtonShow()) {
            return false;
        }
        fragment.hideMenuButton();
        return true;
    }

    public void setParameters(int i, int i2, int i3, boolean z) {
        this.outerChapter = i;
        this.outerSubChapter = i2;
        this.outerPositionRank = i3;
        this.updateAgrs = true;
        this.scrollToNote = z;
        noUpdateAgrs();
    }

    @Override // androidx.fragment.app.Fragment
    public void onPause() {
        saveCurrentPage();
        super.onPause();
    }

    private void saveCurrentPage() {
        this.preferences.setCurrentPageBible(this.mPager.getCurrentItem());
        this.preferences.lambda$saveBg$1$BiblePreferences();
    }

    @Override // androidx.fragment.app.Fragment
    public void onResume() {
        SoundPageListener soundPageListener2;
        super.onResume();
        PowerManagerService.getInstance().start();
        if (this.updateAgrs) {
            noUpdateAgrs();
        } else if (this.activityResult) {
            this.activityResult = false;
        } else {
            setCurrentItem();
        }
        SoundHelper.getInstance().setSoundPageListener(this.soundPageListener);
        if (SoundHelper.getInstance().isPlay() && (soundPageListener2 = this.soundPageListener) != null) {
            soundPageListener2.onNextSoundPage(SoundHelper.getInstance().getCurrentPage(), SoundHelper.getInstance().getCurrentPosition());
        }
        EventBus.getDefault().post(new HidePageSelectionEvent(this.mPager.getCurrentItem()));
    }

    private void noUpdateAgrs() {
        if (this.mPager != null) {
            this.mPagerAdapter.clearFirstPagesDelay();
            this.updatePagePosition = true;
            int positionByChapter = this.bibleDB.getPositionByChapter(this.outerChapter, this.outerSubChapter);
            try {
                if (this.scrollToNote) {
                    int i = positionByChapter - 1;
                    this.mPager.setCurrentItem(i, false);
                    setTitle(i);
                } else {
                    this.mPager.setCurrentItem(positionByChapter, false);
                    setTitle(positionByChapter);
                }
                ScreenSlidePageFragment fragment = this.mPagerAdapter.getFragment(this.scrollToNote ? positionByChapter : positionByChapter + 1);
                if (this.scrollToNote) {
                    if (fragment != null) {
                        int i2 = this.outerChapter;
                        int i3 = this.outerSubChapter;
                        int i4 = this.outerPositionRank;
                        fragment.scrollListToNote(i2, i3, i4, i4);
                    } else {
                        ViewPager viewPager = this.mPager;
                        int i5 = this.outerChapter;
                        int i6 = this.outerSubChapter;
                        int i7 = this.outerPositionRank;
                        viewPager.postDelayed(new DelayedScroll(i5, i6, i7, positionByChapter, i7), 300);
                    }
                    this.scrollToNote = false;
                } else if (fragment != null) {
                    fragment.scrollListTo(this.outerPositionRank);
                } else {
                    this.mPager.postDelayed(new DelayedScrollSimple(this.outerPositionRank, positionByChapter), 300);
                }
                this.updatePagePosition = false;
                this.firstPagePosition = this.mPager.getCurrentItem();
                this.updateAgrs = false;
            } catch (Exception unused) {
            }
        }
    }

    private void setCurrentItem() {
        if (this.mPager != null) {
            int currentPageBible = this.preferences.getCurrentPageBible();
            this.mPager.setCurrentItem(currentPageBible);
            setTitle(currentPageBible);
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        EventBus.getDefault().register(this);
        SoundHelper.getInstance().setSoundPageListener(this.soundPageListener);
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroy() {
        SoundHelper.getInstance().pause();
        EventBus.getDefault().unregister(this);
        SoundHelper.getInstance().pause();
        super.onDestroy();
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.main_page_menu_btn:
                if (getActivity() != null) {
                    ((MainFragmentActivity) getActivity()).showHideSideMenu();
                    return;
                }
                return;
            case R.id.main_page_search_btn:
                SoundHelper.getInstance().pause();
                DailyVerseService.getInstance().clearDailyVerseBackStack();
                DailyReadingService.getInstance().clearDailyReadingBackStack();
                if (getActivity() != null) {
                    ((MainFragmentActivity) getActivity()).setDrawerMode(1);
                }
                ChapterSubChapterResult chapterByPosition = null;
                try {
                    chapterByPosition = this.bibleDB.getChapterByPosition(this.currentPosition);
                } catch (Throwable e) {
                    throw new RuntimeException(e);
                }
                if (chapterByPosition != null) {
                    int id = chapterByPosition.getId();
                    SearchFragment searchFragment = new SearchFragment();
                    Bundle bundle = new Bundle();
                    bundle.putInt("chapterId", id);
                    if (getActivity() instanceof NavigationActivity) {
                        ((NavigationActivity) getActivity()).openFragment(searchFragment, bundle);
                        return;
                    }
                    return;
                }
                return;
            case R.id.main_page_title:
                if (this.customTitleView) {
                    clearCustomTitleViewStyle();
                }
                SoundHelper.getInstance().pause();
                DailyVerseService.getInstance().clearDailyVerseBackStack();
                DailyReadingService.getInstance().clearDailyReadingBackStack();
                BackStackService.getInstance().clear();
                if (getActivity() != null) {
                    ((MainFragmentActivity) getActivity()).setDrawerMode(1);
                }
                if (getActivity() instanceof NavigationActivity) {
                    ((NavigationActivity) getActivity()).openFragment(ContentsMainFragment.class);
                    return;
                }
                return;
            default:
                return;
        }
    }

    private void clearCustomTitleViewStyle() {
        this.customTitleView = false;
        this.titleText.setTextSize(2, 23.0f);
        this.titleText.setText(this.currentTitle);
    }

    /* access modifiers changed from: protected */
    public class ScreenSlidePagerAdapter extends FragmentStatePagerAdapter {
        private int firstPages = 6;
        private Map<Integer, ScreenSlidePageFragment> mPageReferenceMap = new HashMap();

        @Override // androidx.viewpager.widget.PagerAdapter
        public void restoreState(Parcelable parcelable, ClassLoader classLoader) {
        }

        ScreenSlidePagerAdapter(FragmentManager fragmentManager) {
            super(fragmentManager);
        }

        /* access modifiers changed from: package-private */
        public void clearFirstPagesDelay() {
            this.firstPages = 0;
        }

        @Override // androidx.fragment.app.FragmentStatePagerAdapter
        public Fragment getItem(int i) {
            int i2;
            int i3;
            ChapterSubChapterResult chapterByPosition;
            int i4 = i + 1;
            BibleDataBase bibleDataBase = MainScreenFragment.this.bibleDB;
            boolean z = false;
            if (bibleDataBase == null || (chapterByPosition = bibleDataBase.getChapterByPosition(i4)) == null) {
                i3 = 0;
                i2 = 0;
            } else {
                i2 = chapterByPosition.getChapter();
                i3 = chapterByPosition.getSubChapter();
            }
            if (this.firstPages > 0 && i != MainScreenFragment.this.preferences.getCurrentPageBible()) {
                this.firstPages--;
                z = true;
            }
            this.mPageReferenceMap.put(Integer.valueOf(i4), ScreenSlidePageFragment.create(i, i2, i3, z));
            return this.mPageReferenceMap.get(Integer.valueOf(i4));
        }

        @Override // androidx.viewpager.widget.PagerAdapter, androidx.fragment.app.FragmentStatePagerAdapter
        public void destroyItem(ViewGroup viewGroup, int i, Object obj) {
            try {
                this.mPageReferenceMap.remove(Integer.valueOf(i + 1));
                super.destroyItem(viewGroup, i, obj);
            } catch (IllegalStateException unused) {
            }
        }

        /* access modifiers changed from: package-private */
        public ScreenSlidePageFragment getFragment(int i) {
            return this.mPageReferenceMap.get(Integer.valueOf(i));
        }

        @Override // androidx.viewpager.widget.PagerAdapter
        public int getCount() {
            return MainScreenFragment.this.numPages;
        }

        @Override // androidx.viewpager.widget.PagerAdapter
        public Parcelable saveState() {
            Bundle bundle = new Bundle();
            bundle.putParcelableArray("states", null);
            return bundle;
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(UpdateMainFragmentEvent updateMainFragmentEvent) {
        this.updateAgrs = true;
        updateMainFragmentEvent.getOuterChapter();
        throw null;
    }

    public void setTitle(int i) {
        new Thread(new Runnable() {
            /* class king.james.bible.android.fragment.$$Lambda$MainScreenFragment$AzPFe9vglV6cddLhI4AYUvCyqEU */
            private final /* synthetic */ int f$1;

            {
                this.f$1 = r2;
            }

            public final void run() {
                MainScreenFragment.this.lambda$setTitle$1$MainScreenFragment(this.f$1);
            }
        }).start();
    }

    public /* synthetic */ void lambda$setTitle$1$MainScreenFragment(int i) {
        try {
            setTitle(this.bibleDB.getChapterByPosition(i), i);
        } catch (Exception unused) {
        } catch (Throwable e) {
            throw new RuntimeException(e);
        }
    }

    private void setTitle(ChapterSubChapterResult chapterSubChapterResult, int i) {
        if (chapterSubChapterResult != null && getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() {
                /* class king.james.bible.android.fragment.$$Lambda$MainScreenFragment$9_BW75vUHAisgWAsoIQr1wtrM */
                private final /* synthetic */ ChapterSubChapterResult f$1;
                private final /* synthetic */ int f$2;

                {
                    this.f$1 = r23;
                    this.f$2 = r3;
                }

                public final void run() {
                    MainScreenFragment.this.lambda$setTitle$2$MainScreenFragment(this.f$1, this.f$2);
                }
            });
        }
    }

    public /* synthetic */ void lambda$setTitle$2$MainScreenFragment(ChapterSubChapterResult chapterSubChapterResult, int i) {
        try {
            LastChaptersService.getInstance().putChapterID(chapterSubChapterResult.getId());
            String str = chapterSubChapterResult.getTitle() + " " + chapterSubChapterResult.getSubChapter();
            this.currentTitle = str;
            if (this.customTitleView) {
                this.titleText.setText(Html.fromHtml("<u>" + this.currentTitle + "</u>"));
            } else {
                this.titleText.setText(str);
            }
            this.currentPosition = i;
        } catch (Exception unused) {
        }
    }

    @Override // androidx.viewpager.widget.ViewPager.OnPageChangeListener
    public void onPageSelected(int i) {
        int i2;
        SoundHelper.getInstance().setSoundPageListener(this.soundPageListener);
        if (SoundHelper.getInstance().getCurrentPage() != i) {
            SoundHelper.getInstance().pause();
        }
        if (!this.lockPowerManager) {
            PowerManagerService.getInstance().start();
        }
        if (getActivity() != null) {
            ((BaseActivity) getActivity()).customStatusBar();
            setTitle(i);
            EventBus.getDefault().post(new HidePageSelectionEvent(i));
            if (!this.updatePagePosition && (i2 = this.firstPagePosition) > 0 && i2 != i) {
                DailyVerseService.getInstance().clearDailyVerseBackStack();
                DailyReadingService.getInstance().clearDailyReadingBackStack();
                BackStackService.getInstance().clear();
            }
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void onActivityResult(int i, int i2, Intent intent) {
        SoundHelper.getInstance().setSoundPageListener(this.soundPageListener);
        switch (i) {
            case 201:
            case 202:
            case 203:
            case 204:
            case 206:
                if (i2 == -1) {
                    int positionByChapter = this.bibleDB.getPositionByChapter(intent.getIntExtra("chapter", 0), intent.getIntExtra("subChapter", 0));
                    this.mPager.setCurrentItem(positionByChapter);
                    setTitle(positionByChapter);
                    ScreenSlidePageFragment fragment = this.mPagerAdapter.getFragment(positionByChapter);
                    if (fragment != null) {
                        fragment.scrollListTo(intent.getIntExtra("position", 0));
                    } else {
                        this.mPager.postDelayed(new DelayedScrollSimple(intent.getIntExtra("position", 0), positionByChapter), 300);
                    }
                    this.activityResult = true;
                    return;
                }
                ScreenSlidePageFragment fragment2 = this.mPagerAdapter.getFragment(this.currentPosition - 1);
                if (fragment2 != null) {
                    fragment2.reloadFragment();
                    return;
                } else {
                    this.mPager.postDelayed(new DelayedReload(this.currentPosition - 1), 300);
                    return;
                }
            case 205:
                if (i2 == -1) {
                    int positionByChapter2 = this.bibleDB.getPositionByChapter(intent.getIntExtra("chapter", 0), intent.getIntExtra("subChapter", 0));
                    this.mPager.setCurrentItem(positionByChapter2);
                    setTitle(positionByChapter2);
                    ScreenSlidePageFragment fragment3 = this.mPagerAdapter.getFragment(positionByChapter2);
                    if (fragment3 != null) {
                        fragment3.scrollListToNote(intent.getIntExtra("chapter", 0), intent.getIntExtra("subChapter", 0), intent.getIntExtra("position", 0), intent.getIntExtra("rank", 0));
                    } else {
                        this.mPager.postDelayed(new DelayedScroll(intent.getIntExtra("chapter", 0), intent.getIntExtra("subChapter", 0), intent.getIntExtra("position", 0), positionByChapter2, intent.getIntExtra("rank", 0)), 300);
                    }
                    this.activityResult = true;
                    return;
                }
                ScreenSlidePageFragment fragment4 = this.mPagerAdapter.getFragment(this.currentPosition - 1);
                if (fragment4 != null) {
                    fragment4.reloadFragment();
                    return;
                } else {
                    this.mPager.postDelayed(new DelayedReload(this.currentPosition - 1), 300);
                    return;
                }
            default:
                return;
        }
    }

    /* access modifiers changed from: private */
    public class DelayedScroll implements Runnable {
        private int chapter;
        private int fragment;
        private int position;
        private int rank;
        private int subChapter;

        DelayedScroll(int i, int i2, int i3, int i4, int i5) {
            this.chapter = i;
            this.subChapter = i2;
            this.position = i3;
            this.fragment = i4;
            this.rank = i5;
        }

        public void run() {
            ScreenSlidePageFragment fragment2 = MainScreenFragment.this.mPagerAdapter.getFragment(this.fragment);
            if (fragment2 != null) {
                fragment2.scrollListToNote(this.chapter, this.subChapter, this.position, this.rank);
            }
        }
    }

    private class DelayedReload implements Runnable {
        private int fragment;

        DelayedReload(int i) {
            this.fragment = i;
        }

        public void run() {
            ScreenSlidePageFragment fragment2 = MainScreenFragment.this.mPagerAdapter.getFragment(this.fragment);
            if (fragment2 != null) {
                fragment2.reloadFragment();
            }
        }
    }

    /* access modifiers changed from: private */
    public class DelayedScrollSimple implements Runnable {
        private int fragment;
        private int position;

        DelayedScrollSimple(int i, int i2) {
            this.position = i;
            this.fragment = i2;
        }

        public void run() {
            ScreenSlidePageFragment fragment2 = MainScreenFragment.this.mPagerAdapter.getFragment(this.fragment + 1);
            if (fragment2 != null) {
                fragment2.scrollListTo(this.position);
            }
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void onConfigurationChanged(Configuration configuration) {
        SoundHelper.getInstance().pause();
        saveCurrentPage();
        super.onConfigurationChanged(configuration);
        initPager();
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(PagesSwipeHintHideEvent pagesSwipeHintHideEvent) {
        animateContentButton();
    }

    private void animateContentButton() {
        if (this.preferences.isAnimateContentTitle()) {
            this.actionbarMain.postDelayed(new Runnable() {
                /* class king.james.bible.android.fragment.$$Lambda$MainScreenFragment$ZBNceDIPYodFZQqfQVnPjeBepB0 */

                public final void run() {
                    MainScreenFragment.this.lambda$animateContentButton$3$MainScreenFragment();
                }
            }, 1000);
        }
    }

    public /* synthetic */ void lambda$animateContentButton$3$MainScreenFragment() {
        if (getActivity() != null && this.actionbarMain != null) {
            this.customTitleView = true;
            this.preferences.setAnimateContentTitle(false);
            this.preferences.saveBg();
            new ContentTitlePageAnimator(this.titleText).start();
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(ShowAudioWaitDialogEvent showAudioWaitDialogEvent) {
        new WaitAudioDialog().show(getChildFragmentManager(), BuildConfig.FLAVOR);
    }
}
