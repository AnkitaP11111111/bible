package king.james.bible.android.adapter.holder;

import android.view.View;
import android.widget.TextView;
import king.james.bible.android.R;
import king.james.bible.android.model.chapter.ChapterShortNameAndMode;
import king.james.bible.android.utils.ColorUtil;
import king.james.bible.android.utils.ScreenUtil;

public class ContentsTabletViewHolder extends ContentsTabletBaseHolder {
    private ChapterShortNameAndMode model;
    private TextView textView;

    public ContentsTabletViewHolder(View view) {
        super(view);
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter.BaseViewHolder
    public void mapViews(View view) {
        this.textView = (TextView) view.findViewById(R.id.content_item_text);
        int dimensionPixelOffset = this.itemView.getContext().getResources().getDimensionPixelOffset(ScreenUtil.getInstance().isTablet() ? R.dimen.indent_large : R.dimen.indent_xmedium);
        this.textView.setPadding(dimensionPixelOffset, 0, dimensionPixelOffset, 0);
    }

    @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter.BaseViewHolder
    public void updateView(Object obj) {
        ChapterShortNameAndMode chapterShortNameAndMode = (ChapterShortNameAndMode) obj;
        this.model = chapterShortNameAndMode;
        if (chapterShortNameAndMode != null) {
            this.textView.setText(chapterShortNameAndMode.getLongName());
            setTextColor(false);
        }
    }

    private void setTextColor(boolean z) {
        TextView textView2;
        if (this.model != null && (textView2 = this.textView) != null) {
            textView2.setTextColor(this.itemView.getContext().getResources().getColorStateList(ColorUtil.getTextColorModeResId(this.model.getMode(), z)));
        }
    }

    public void updateHeaderColor() {
        setTextColor(true);
    }
}
