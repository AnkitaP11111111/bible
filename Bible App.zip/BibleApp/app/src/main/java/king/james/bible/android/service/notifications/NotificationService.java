package king.james.bible.android.service.notifications;

import android.content.Context;
import java.util.List;
import king.james.bible.android.service.notifications.NotificationDataService;

public class NotificationService {
    /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
    static synchronized void actionTimer(Context context, boolean z, long j) {
        synchronized (NotificationService.class) {
            if (NotificationDataService.getInstance().updateNotificationModels(context)) {
                if (z) {
                    notifyReading(context, j);
                } else {
                    notifyVerses(context, j);
                }
            }
        }
    }

    private static void notifyVerses(Context context, long j) {
        notify(context, NotificationDataService.getInstance().getNotifyVersesList(j, context), NotificationMode.VERSE);
    }

    private static void notifyReading(Context context, long j) {
        notify(context, NotificationDataService.getInstance().getNotifyPlanList(j, context), NotificationMode.PLAN);
    }

    private static void notify(Context context, List<NotificationDataService.NotifySimple> list, NotificationMode notificationMode) {
        if (!(list == null || list.isEmpty())) {
            for (NotificationDataService.NotifySimple notifySimple : list) {
                NotificationsReadingForegroundUtil.startForeground(context, notificationMode, notifySimple.title, 0, notifySimple.id);
            }
        }
    }

    public static void checkAsyncNotifications(final Context context) {
        new Thread(new Runnable() {
            /* class king.james.bible.android.service.notifications.NotificationService.AnonymousClass1 */

            public void run() {
                try {
                    NotificationService.checkNotifications(context);
                } catch (Exception unused) {
                }
            }
        }).start();
    }

    static void checkNotifications(Context context) {
        try {
            NotificationDataService.getInstance().restart(context);
        } catch (Exception unused) {
        }
    }
}
