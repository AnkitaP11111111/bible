package king.james.bible.android.fragment.contents;

import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ListAdapter;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import com.karumi.dexter.BuildConfig;
import king.james.bible.android.R;
import java.util.List;
import king.james.bible.android.activity.MainFragmentActivity;
import king.james.bible.android.adapter.list.contents.Contents2FragmentAdapter;
import king.james.bible.android.db.BibleDataBase;
import king.james.bible.android.db.service.TextDataService;
import king.james.bible.android.event.ContentsMainBackEvent;
import king.james.bible.android.event.OpenFromContents3Event;
import king.james.bible.android.fragment.FragmentCallbackListener;
import king.james.bible.android.service.PowerManagerService;
import king.james.bible.android.utils.BiblePreferences;
import org.greenrobot.eventbus.EventBus;

public class Contents3Fragment extends Fragment implements AdapterView.OnItemClickListener {
    public static final String TAG = Contents3Fragment.class.getSimpleName();
    private  int r3;
    private  int r2;
    protected BibleDataBase bibleDB;
    private int chapter;
    private GridView gridview;
    private boolean itemClick = false;
    private List<Integer> itemsList;
    private BiblePreferences preferences;
    private int subChapter;

    public Contents3Fragment() {
        BiblePreferences instance = BiblePreferences.getInstance();
        this.preferences = instance;
        instance.lambda$restoreAsync$0$BiblePreferences();
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.fragment_contents_page, (ViewGroup) null);
        inflate.setBackgroundColor(getActivity().getResources().getColor(this.preferences.isNightMode() ? R.color.black_bg : R.color.white));
        TextView textView = (TextView) inflate.findViewById(R.id.title_text);
        if (this.preferences.isNightMode()) {
            textView.setTextColor(getResources().getColor(R.color.menu_text_color_n));
        }
        this.gridview = (GridView) inflate.findViewById(R.id.gridview);
        this.bibleDB = BibleDataBase.getInstance();
        if (getArguments() != null) {
            textView.setText(getArguments().getString("parameterTitle", BuildConfig.FLAVOR));
            textView.setVisibility(0);
            this.chapter = getArguments().getInt("chapter", 0);
            this.subChapter = getArguments().getInt("subChapter", 0);
        }
        initGrid(this.chapter);
        PowerManagerService.getInstance().start();
        return inflate;
    }

    private void initGrid(int i) {
        new Thread(new Runnable() {
            /* class king.james.bible.android.fragment.contents.$$Lambda$Contents3Fragment$0QisJwBzIPKMkbio0EJtvX538w */
            private final /* synthetic */ int f$1;

            {
                this.f$1 = r2;
            }

            public final void run() {
                Contents3Fragment.this.lambda$initGrid$1$Contents3Fragment(this.f$1);
            }
        }).start();
    }

    public /* synthetic */ void lambda$initGrid$1$Contents3Fragment(int i) {
        this.itemsList = getItemsList(i);
        if (getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() {
                /* class king.james.bible.android.fragment.contents.$$Lambda$Contents3Fragment$3LdZ35XsHvWQSlKp5OC35eJWaw */

                public final void run() {
                    Contents3Fragment.this.lambda$null$0$Contents3Fragment();
                }
            });
        }
    }

    public /* synthetic */ void lambda$null$0$Contents3Fragment() {
        try {
            this.gridview.setColumnWidth(getResources().getDimensionPixelOffset(R.dimen.contents_item_width));
            this.gridview.setAdapter((ListAdapter) new Contents2FragmentAdapter(this.itemsList, getActivity()));
            this.gridview.setOnItemClickListener(this);
        } catch (Exception unused) {
        }
    }

    private List<Integer> getItemsList(int i) {
        return this.bibleDB.getSubChaptersList(i, this.subChapter);
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
        if (getActivity() != null && !this.itemClick) {
            this.itemClick = true;
            PowerManagerService.getInstance().start();
            new Thread(new Runnable() {
                /* class king.james.bible.android.fragment.contents.$$Lambda$Contents3Fragment$oJ78ksNAWS20EZsCVTbZeXXC_w */
                private final /* synthetic */ int f$1;

                {
                    this.f$1 = r2;
                }

                public final void run() {
                    try {
                        Contents3Fragment.this.lambda$onItemClick$2$Contents3Fragment(this.f$1);
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                }
            }).start();
        }
    }

    public /* synthetic */ void lambda$onItemClick$2$Contents3Fragment(int i) throws Exception {
        moveToReadingScreen(i, this.bibleDB.getRankByChapter(this.chapter, this.subChapter, this.itemsList.get(i).intValue()));
    }

    private void moveToReadingScreen(int i, int i2) {
        if (getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() {
                /* class king.james.bible.android.fragment.contents.$$Lambda$Contents3Fragment$SjhYZsuL4E_enV0k7CK8LDOvTpQ */
                private final /* synthetic */ int f$1;
                private final /* synthetic */ int f$2;

                {
                    this.f$1 = r2;
                    this.f$2 = r3;
                }

                public final void run() {
                    Contents3Fragment.this.lambda$moveToReadingScreen$3$Contents3Fragment(this.f$1, this.f$2);
                }
            });
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: moveToReadingScreenUI */
    public void lambda$moveToReadingScreen$3$Contents3Fragment(int i, int i2) {
        FragmentCallbackListener fragmentCallbackListener = getActivity() instanceof FragmentCallbackListener ? (FragmentCallbackListener) getActivity() : null;
        if (Build.VERSION.SDK_INT < 17) {
            EventBus.getDefault().post(new ContentsMainBackEvent());
            this.gridview.postDelayed(new Runnable() {
                /* class king.james.bible.android.fragment.contents.$$Lambda$Contents3Fragment$zFFlY16i3k4FIpFYffjpdFD5yNQ */

                public final void run() {
                    EventBus.getDefault().post(fragmentCallbackListener);
                }
            }, 1000);
            return;
        }
        new Thread(new Runnable() {
            /* class king.james.bible.android.fragment.contents.$$Lambda$Contents3Fragment$S_pgafvY2S61QQu4xbBVpRgxG8k */

            public final void run() {
                Contents3Fragment.this.lambda$moveToReadingScreenUI$5$Contents3Fragment();
            }
        }).start();
        if (getActivity() instanceof MainFragmentActivity) {
            ((MainFragmentActivity) getActivity()).onContentSelect();
        }
        if (fragmentCallbackListener != null) {
            fragmentCallbackListener.onFragmentResultOk(this.chapter, this.subChapter - 1, i, i2, null);
        }
    }

    public /* synthetic */ void lambda$moveToReadingScreenUI$5$Contents3Fragment() {
        TextDataService.doLoadPageModels(this.subChapter, this.chapter);
    }
}
