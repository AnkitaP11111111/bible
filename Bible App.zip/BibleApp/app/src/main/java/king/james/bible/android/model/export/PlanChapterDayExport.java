package king.james.bible.android.model.export;

public class PlanChapterDayExport {
    private int chapterNum;
    private int chapterOrder;

    public PlanChapterDayExport(int i, int i2) {
        this.chapterOrder = i;
        this.chapterNum = i2;
    }

    public int getChapterOrder() {
        return this.chapterOrder;
    }

    public int getChapterNum() {
        return this.chapterNum;
    }
}
