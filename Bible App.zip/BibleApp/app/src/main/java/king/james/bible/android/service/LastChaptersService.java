package king.james.bible.android.service;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.karumi.dexter.BuildConfig;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import king.james.bible.android.db.BibleDataBase;
import king.james.bible.android.model.chapter.ChapterShortNameAndMode;

public class LastChaptersService {
    private static LastChaptersService instance;
    private boolean firstChapter;
    private int firstChapterId;
    private int firstChapterReadCount = 4;
    private Map<Integer, Long> lastChaptersMap;
    private Context mContext;

    private LastChaptersService() {
    }

    public static LastChaptersService getInstance() {
        if (instance == null) {
            synchronized (LastChaptersService.class) {
                if (instance == null) {
                    instance = new LastChaptersService();
                }
            }
        }
        return instance;
    }

    public void init(Context context) {
        this.mContext = context;
        new Thread(new Runnable() {
            /* class king.james.bible.android.service.LastChaptersService.AnonymousClass1 */

            public void run() {
                try {
                    LastChaptersService.this.restore();
                } catch (Exception unused) {
                }
            }
        }).start();
    }

    public void restore() {
        SharedPreferences sharedPreferences = this.mContext.getSharedPreferences("BibleLastChaptersService_preference", 0);
        if (sharedPreferences != null) {
            this.firstChapter = sharedPreferences.getBoolean("firstChapter", true);
            try {
                this.lastChaptersMap = (Map) new GsonBuilder().create().fromJson(sharedPreferences.getString("LastChapters", BuildConfig.FLAVOR), new TypeToken<Map<Integer, Long>>(this) {
                    /* class king.james.bible.android.service.LastChaptersService.AnonymousClass2 */
                }.getType());
            } catch (Exception unused) {
            }
            if (this.lastChaptersMap == null) {
                this.lastChaptersMap = new HashMap();
            }
            if (this.lastChaptersMap.size() > 2) {
                clear();
                save();
            }
        }
    }

    private void clear() {
        if (this.lastChaptersMap.size() > 2) {
            clearOne();
        }
    }

    private void clearOne() {
        long currentTimeMillis = System.currentTimeMillis();
        int i = 0;
        for (Map.Entry<Integer, Long> entry : this.lastChaptersMap.entrySet()) {
            if (entry.getValue().longValue() < currentTimeMillis) {
                currentTimeMillis = entry.getValue().longValue();
                i = entry.getKey().intValue();
            }
        }
        this.lastChaptersMap.remove(Integer.valueOf(i));
    }

    public void save() {
        new Thread(new Runnable() {
            /* class king.james.bible.android.service.LastChaptersService.AnonymousClass3 */

            public void run() {
                try {
                    LastChaptersService.this.saveBackground();
                } catch (Exception unused) {
                }
            }
        }).start();
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void saveBackground() {
        SharedPreferences.Editor edit;
        SharedPreferences sharedPreferences = this.mContext.getSharedPreferences("BibleLastChaptersService_preference", 0);
        if (sharedPreferences != null && (edit = sharedPreferences.edit()) != null) {
            edit.putString("LastChapters", new GsonBuilder().create().toJson(this.lastChaptersMap));
            edit.putBoolean("firstChapter", this.firstChapter);
            edit.apply();
        }
    }

    public void putChapterID(int i) {
        if (this.firstChapterReadCount < 1) {
            clearFirstChapter();
        }
        if (this.firstChapter && this.firstChapterId < 1) {
            this.firstChapterId = BibleDataBase.getInstance().getFirstChaptersId();
        }
        if (this.firstChapter && this.lastChaptersMap.isEmpty() && i == this.firstChapterId) {
            this.firstChapterReadCount--;
        } else if (this.lastChaptersMap.containsKey(Integer.valueOf(i))) {
            putChaptersMap(i);
        } else if (this.lastChaptersMap.size() >= 2) {
            rewrite(i);
        } else {
            putChaptersMap(i);
        }
    }

    private void putChaptersMap(int i) {
        this.lastChaptersMap.put(Integer.valueOf(i), Long.valueOf(System.currentTimeMillis()));
        save();
    }

    private void rewrite(int i) {
        clearOne();
        this.lastChaptersMap.put(Integer.valueOf(i), Long.valueOf(System.currentTimeMillis()));
        save();
    }

    public List<ChapterShortNameAndMode> getLastChaptersModels() {
        ArrayList<LastChapter> arrayList = new ArrayList();
        for (Map.Entry<Integer, Long> entry : this.lastChaptersMap.entrySet()) {
            arrayList.add(new LastChapter(this, entry.getKey().intValue(), entry.getValue().longValue()));
        }
//        Collections.sort(arrayList, new LastChapterComparator());
        ArrayList arrayList2 = new ArrayList();
        for (LastChapter lastChapter : arrayList) {
            ChapterShortNameAndMode chapterFromCache = BibleDataBase.getInstance().getChapterFromCache((long) lastChapter.id);
            if (chapterFromCache != null) {
                arrayList2.add(chapterFromCache);
            }
        }
        return arrayList2;
    }

    /* access modifiers changed from: private */
    public class LastChapter {
        int id;
        long time;

        public LastChapter(LastChaptersService lastChaptersService, int i, long j) {
            this.id = i;
            this.time = j;
        }
    }

    private class LastChapterComparator implements Comparator<LastChapter> {
        private LastChapterComparator(LastChaptersService lastChaptersService) {
        }

        public int compare(LastChapter lastChapter, LastChapter lastChapter2) {
            return Long.valueOf(lastChapter2.time).compareTo(Long.valueOf(lastChapter.time));
        }
    }

    public void clearFirstChapter() {
        this.firstChapter = false;
        save();
    }
}
