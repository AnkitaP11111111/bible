package king.james.bible.android.view;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.LinearLayout;
import king.james.bible.android.utils.BiblePreferences;

public class SizeImageLinearLayout extends LinearLayout {
    public SizeImageLinearLayout(Context context) {
        super(context);
    }

    public SizeImageLinearLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public SizeImageLinearLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    public SizeImageLinearLayout(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
    }

    public void setImageSize() {
        getLayoutParams().width = (int) BiblePreferences.getInstance().getTextImageSize();
        invalidate();
    }

    public void setHeight(int i) {
        getLayoutParams().height = i;
        invalidate();
    }
}
