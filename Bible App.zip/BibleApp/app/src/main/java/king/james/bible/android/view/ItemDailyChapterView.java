package king.james.bible.android.view;

import android.content.Context;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.util.AttributeSet;
import android.widget.TextView;
import king.james.bible.android.R;

public class ItemDailyChapterView extends TextView {
    private int chapterMode;
    private String name;
    private TextView nameTextView;
    private int nameTextViewColor;

    public ItemDailyChapterView(Context context) {
        super(context);
    }

    public ItemDailyChapterView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public ItemDailyChapterView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    public ItemDailyChapterView(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
    }

    /* access modifiers changed from: protected */
    public void onFinishInflate() {
        this.nameTextView = (TextView) findViewById(R.id.nameTextView);
        super.onFinishInflate();
        prepareColor();
        setName();
    }

    public void setNameText(String str) {
        this.name = str;
        if (this.nameTextView != null) {
            setName();
        }
    }

    private void setName() {
        String str = this.name;
        if (str != null) {
            this.nameTextView.setText(str);
            SpannableString spannableString = new SpannableString(this.name);
            spannableString.setSpan(new UnderlineSpan(), 0, this.nameTextView.length(), 18);
            this.nameTextView.setText(spannableString);
        }
    }

    public void setChapterMode(int i) {
        this.chapterMode = i;
    }

    public int getChapterMode() {
        return this.chapterMode;
    }

    public void setModeColor(int i) {
        this.nameTextViewColor = i;
        if (this.nameTextView != null) {
            prepareColor();
        }
    }

    private void prepareColor() {
        if (this.nameTextViewColor != 0) {
            this.nameTextView.setTextColor(getContext().getResources().getColor(this.nameTextViewColor));
        }
    }
}
