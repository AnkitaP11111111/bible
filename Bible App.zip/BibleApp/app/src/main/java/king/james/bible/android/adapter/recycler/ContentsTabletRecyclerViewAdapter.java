package king.james.bible.android.adapter.recycler;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import king.james.bible.android.R;
import java.util.List;
import king.james.bible.android.adapter.holder.ContentsTabletBaseHolder;
import king.james.bible.android.adapter.holder.ContentsTabletDividerHolder;
import king.james.bible.android.adapter.holder.ContentsTabletViewHolder;
import king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter;
import king.james.bible.android.model.chapter.ChapterShortNameAndMode;
import king.james.bible.android.utils.BiblePreferences;

public class ContentsTabletRecyclerViewAdapter extends BaseRecyclerViewAdapter<ContentsTabletBaseHolder> {
    private int VIEW_ID = getViewId();
    private List<ChapterShortNameAndMode> headers;
    private List<ChapterShortNameAndMode> models;

    public ContentsTabletRecyclerViewAdapter(List<ChapterShortNameAndMode> list, List<ChapterShortNameAndMode> list2, OnItemClickListener onItemClickListener) {
        super(onItemClickListener);
        this.models = list;
        this.headers = list2;
    }

    private int getViewId() {
        return BiblePreferences.getInstance().isNightMode() ? R.layout.content_item_tablet_layout_n : R.layout.content_item_tablet_layout;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter
    public ContentsTabletBaseHolder doCreateViewHolder(ViewGroup viewGroup, int i) {
        View inflate = LayoutInflater.from(viewGroup.getContext()).inflate(i, viewGroup, false);
        if (i == R.layout.item_divider) {
            return new ContentsTabletDividerHolder(inflate, !this.headers.isEmpty());
        }
        return new ContentsTabletViewHolder(inflate);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemViewType(int i) {
        if (i == this.headers.size()) {
            return R.layout.item_divider;
        }
        return this.VIEW_ID;
    }

    public void onBindViewHolder(ContentsTabletBaseHolder contentsTabletBaseHolder, int i) {
        super.onBindViewHolder( contentsTabletBaseHolder, i);
        if (i < this.headers.size()) {
            ((ContentsTabletViewHolder) contentsTabletBaseHolder).updateHeaderColor();
        }
    }

    @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter
    public Object getModel(int i) {
        if (i == this.headers.size()) {
            return null;
        }
        if (i < this.headers.size()) {
            return this.headers.get(i);
        }
        return this.models.get((i - this.headers.size()) - 1);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.headers.size() + this.models.size() + 1;
    }
}
