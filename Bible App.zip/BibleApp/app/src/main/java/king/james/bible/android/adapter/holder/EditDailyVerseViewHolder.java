package king.james.bible.android.adapter.holder;

import android.view.View;
import king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter;

public abstract class EditDailyVerseViewHolder extends BaseRecyclerViewAdapter.BaseViewHolder {
    public EditDailyVerseViewHolder(View view) {
        super(view);
    }
}
