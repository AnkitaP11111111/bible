package king.james.bible.android.dialog;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.graphics.Point;
import android.os.Environment;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import king.james.bible.android.R;
import java.io.File;
import java.util.Arrays;
import king.james.bible.android.model.ExportImportFilter;

public class FileChooser {
    private final Activity activity;
    private File currentPath;
    private Dialog dialog;
    private FileSelectedListener fileListener;
    private ListView list;

    public interface FileSelectedListener {
        void fileSelected(File file);
    }

    public FileChooser setFileListener(FileSelectedListener fileSelectedListener) {
        this.fileListener = fileSelectedListener;
        return this;
    }

    public FileChooser(Activity activity2) {
        this.activity = activity2;
        this.dialog = new Dialog(activity2);
        ListView listView = new ListView(activity2);
        this.list = listView;
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            /* class king.james.bible.android.dialog.FileChooser.AnonymousClass1 */

            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                File chosenFile = FileChooser.this.getChosenFile((String) FileChooser.this.list.getItemAtPosition(i));
                if (chosenFile != null) {
                    if (chosenFile.isDirectory()) {
                        FileChooser.this.refresh(chosenFile);
                        return;
                    }
                    if (FileChooser.this.fileListener != null) {
                        FileChooser.this.fileListener.fileSelected(chosenFile);
                    }
                    try {
                        FileChooser.this.dialog.dismiss();
                    } catch (Exception unused) {
                    }
                }
            }
        });
        this.dialog.setContentView(this.list);
        this.dialog.getWindow().setBackgroundDrawableResource(R.drawable.background_chooser_dialog);
        updateSizeDialog();
        refresh(Environment.getExternalStorageDirectory());
    }

    private void updateSizeDialog() {
        Display defaultDisplay = this.dialog.getWindow().getWindowManager().getDefaultDisplay();
        Point point = new Point();
        defaultDisplay.getSize(point);
        this.dialog.getWindow().getDecorView().measure(0, 0);
        int dimensionPixelOffset = this.activity.getResources().getDimensionPixelOffset(R.dimen.dialog_item_padding) * 2;
        int i = point.y - dimensionPixelOffset;
        int i2 = point.x - dimensionPixelOffset;
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-1, -1);
        layoutParams.copyFrom(this.dialog.getWindow().getAttributes());
        layoutParams.height = i;
        layoutParams.width = i2;
        this.dialog.getWindow().setAttributes(layoutParams);
    }

    public void showDialog() {
        this.dialog.show();
    }

    public void closeDialog() {
        this.dialog.cancel();
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    @SuppressLint("ResourceType")
    private void refresh(File file) {
        String[] strArr;
        this.currentPath = file;
        if (file.exists()) {
            File[] listFiles = file.listFiles(new ExportImportFilter() {
                /* class king.james.bible.android.dialog.FileChooser.AnonymousClass2 */

                @Override // king.james.bible.android.model.ExportImportFilter
                public boolean accept(File file) {
                    return file.isDirectory() && file.canRead();
                }
            });
            File[] listFiles2 = file.listFiles(new ExportImportFilter());
            if (listFiles != null && listFiles2 != null) {
                int i = 0;
                int i2 = 1;
                if (file.getParentFile() == null) {
                    strArr = new String[(listFiles.length + listFiles2.length)];
                    i2 = 0;
                } else {
                    strArr = new String[(listFiles.length + listFiles2.length + 1)];
                    strArr[0] = "..";
                }
                Arrays.sort(listFiles);
                Arrays.sort(listFiles2);
                int length = listFiles.length;
                int i3 = 0;
                while (i3 < length) {
                    strArr[i2] = listFiles[i3].getName();
                    i3++;
                    i2++;
                }
                int length2 = listFiles2.length;
                while (i < length2) {
                    strArr[i2] = listFiles2[i].getName();
                    i++;
                    i2++;
                }
                this.dialog.setTitle(this.currentPath.getPath());
                this.list.setAdapter((ListAdapter) new ArrayAdapter( this.activity, 17367043, strArr) {
                    /* class king.james.bible.android.dialog.FileChooser.AnonymousClass3 */

                    public View getView(int i, View view, ViewGroup viewGroup) {
                        View view2 = super.getView(i, view, viewGroup);
                        ((TextView) view2).setSingleLine(true);
                        return view2;
                    }
                });
            }
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private File getChosenFile(String str) {
        if (str.equals("..")) {
            return this.currentPath.getParentFile();
        }
        return new File(this.currentPath, str);
    }
}
