package king.james.bible.android.dialog;

import king.james.bible.android.R;
import king.james.bible.android.event.HideAudioWaitDialogEvent;
import king.james.bible.android.utils.AppUtils;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

public class WaitAudioDialog extends EvaluationDialog {
    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.EvaluationDialog
    public void closeClick() {
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.EvaluationDialog
    public int getActionTextResId() {
        return R.string.audio_hint_dialogbutton_ok;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.EvaluationDialog
    public int getLaterTextResId() {
        return R.string.audio_hint_dialogbutton_tts;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.EvaluationDialog
    public int getTextResId() {
        return R.string.audio_hint_dialogmessage;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.EvaluationDialog
    public int getTitleResId() {
        return R.string.audio_hint_dialogtitle;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.EvaluationDialog
    public boolean showNoButton() {
        return false;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.EvaluationDialog
    public void selectAction() {
        dismiss();
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.EvaluationDialog
    public void selectLater() {
        onOpenTTSDeviceSettingsScreen();
    }

    private void onOpenTTSDeviceSettingsScreen() {
        AppUtils.onOpenTTSDeviceSettingsScreen(getContext());
    }

    @Override // androidx.fragment.app.Fragment
    public void onResume() {
        super.onResume();
        EventBus.getDefault().register(this);
    }

    @Override // androidx.fragment.app.Fragment
    public void onPause() {
        EventBus.getDefault().unregister(this);
        super.onPause();
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(HideAudioWaitDialogEvent hideAudioWaitDialogEvent) {
        dismiss();
    }
}
