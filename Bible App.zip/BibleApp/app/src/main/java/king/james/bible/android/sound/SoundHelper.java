package king.james.bible.android.sound;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import com.karumi.dexter.BuildConfig;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import king.james.bible.android.sound.listener.FirstPlayListener;
import king.james.bible.android.sound.listener.InitAudioListener;
import king.james.bible.android.sound.listener.page.SoundInitListener;
import king.james.bible.android.sound.listener.page.SoundPageListener;
import king.james.bible.android.sound.listener.page.SoundVerseListener;

public class SoundHelper {
    private static SoundHelper INSTANCE;
    private Context context;
    private boolean init = false;
    private InitAudioListener initAudioListener = new InitAudioListener() {
        /* class king.james.bible.android.sound.SoundHelper.AnonymousClass1 */

        @Override // king.james.bible.android.sound.listener.InitAudioListener
        public void completeInitAudio() {
            SoundHelper.this.init = true;
            if (SoundHelper.this.pagePosition >= 0 && SoundHelper.this.itemPosition >= 0) {
                SoundHelper.this.soundService.setFirstPlayListener(new FirstPlayListener() {
                    /* class king.james.bible.android.sound.SoundHelper.AnonymousClass1.AnonymousClass1 */

                    @Override // king.james.bible.android.sound.listener.FirstPlayListener
                    public void onCompleteFirstPlayInit() {
                        if (SoundHelper.this.soundInitListener != null) {
                            SoundHelper.this.soundInitListener.completeInitService(SoundHelper.this.itemPosition);
                            SoundHelper.this.itemPosition = -1;
                            SoundHelper.this.soundInitListener = null;
                        }
                    }
                });
                if (SoundHelper.this.playRepeat || (SoundHelper.this.text != null && !SoundHelper.this.text.isEmpty())) {
                    SoundHelper.this.soundService.play(SoundHelper.this.playRepeat, SoundHelper.this.pagePosition, SoundHelper.this.itemPosition, SoundHelper.this.text, SoundHelper.this.selectedItems);
                } else {
                    SoundHelper.this.soundService.play(SoundHelper.this.pagePosition, SoundHelper.this.itemPosition);
                }
                SoundHelper.this.text = null;
                SoundHelper.this.pagePosition = -1;
            }
        }
    };
    private int itemPosition;
    private int pagePosition;
    private boolean playRepeat = false;
    private Set<Integer> selectedItems;
    private SoundInitListener soundInitListener;
    private SoundPageListener soundPageListener;
    private SoundService soundService;
    private Map<Integer, SoundVerseListener> soundVerseListeners = new HashMap();
    private String text;

    public static SoundHelper getInstance() {
        if (INSTANCE == null) {
            synchronized (SoundHelper.class) {
                if (INSTANCE == null) {
                    INSTANCE = new SoundHelper();
                }
            }
        }
        return INSTANCE;
    }

    public void init(Context context2) {
        this.context = context2;
    }

    public void setSoundService(SoundService soundService2) {
        this.soundService = soundService2;
        if (soundService2 != null) {
            soundService2.setSoundVerseListener(this.soundVerseListeners);
            soundService2.setSoundPageListener(this.soundPageListener);
            soundService2.setInitAudioListener(this.initAudioListener);
        }
    }

    public void play(int i, int i2, SoundInitListener soundInitListener2) {
        this.playRepeat = false;
        SoundService soundService2 = this.soundService;
        if (soundService2 == null) {
            this.pagePosition = i;
            this.itemPosition = i2;
            this.soundInitListener = soundInitListener2;
            if (soundInitListener2 != null) {
                soundInitListener2.startInitService(i2);
            }
            startService();
            return;
        }
        this.soundInitListener = null;
        soundService2.play(i, i2);
    }

    public void playRepeat(int i, int i2, Set<Integer> set, SoundInitListener soundInitListener2) {
        this.playRepeat = true;
        this.text = BuildConfig.FLAVOR;
        SoundService soundService2 = this.soundService;
        if (soundService2 == null) {
            this.pagePosition = i;
            this.itemPosition = i2;
            this.selectedItems = set;
            this.soundInitListener = soundInitListener2;
            if (soundInitListener2 != null) {
                soundInitListener2.startInitService(i2);
            }
            startService();
            return;
        }
        this.soundInitListener = null;
        soundService2.play(true, i, i2, BuildConfig.FLAVOR, set);
    }

    public void play(int i, int i2, String str) {
        this.playRepeat = false;
        SoundService soundService2 = this.soundService;
        if (soundService2 == null) {
            this.pagePosition = i;
            this.itemPosition = i2;
            this.text = str;
            startService();
            return;
        }
        soundService2.play(false, i, i2, str);
    }

    private void startService() {
        if (this.context != null && !isServiceRunning(SoundService.class)) {
            this.context.startService(new Intent(this.context, SoundService.class));
        }
    }

    private boolean isServiceRunning(Class<?> cls) {
        Context context2 = this.context;
        if (context2 == null) {
            return false;
        }
        for (ActivityManager.RunningServiceInfo runningServiceInfo : ((ActivityManager) context2.getSystemService("activity")).getRunningServices(Integer.MAX_VALUE)) {
            if (cls.getName().equals(runningServiceInfo.service.getClassName()) && this.context.getPackageName().equals(runningServiceInfo.service.getPackageName())) {
                return true;
            }
        }
        return false;
    }

    public void pause() {
        SoundService soundService2 = this.soundService;
        if (soundService2 != null) {
            soundService2.pause();
        }
    }

    public int getCurrentPage() {
        SoundService soundService2 = this.soundService;
        if (soundService2 == null) {
            return -1;
        }
        return soundService2.getCurrentPage();
    }

    public int getCurrentPosition() {
        SoundService soundService2 = this.soundService;
        if (soundService2 == null) {
            return -1;
        }
        return soundService2.getCurrentPosition();
    }

    public void updateAudioSettings() {
        SoundService soundService2 = this.soundService;
        if (soundService2 != null) {
            soundService2.updateAudioSettings();
        }
    }

    public boolean isPlay() {
        SoundService soundService2 = this.soundService;
        if (soundService2 == null) {
            return false;
        }
        return soundService2.isPlay();
    }

    public void addSoundVerseListener(int i, SoundVerseListener soundVerseListener) {
        if (this.soundVerseListeners == null) {
            this.soundVerseListeners = new HashMap();
        }
        this.soundVerseListeners.put(Integer.valueOf(i), soundVerseListener);
        SoundService soundService2 = this.soundService;
        if (soundService2 != null) {
            soundService2.addSoundVerseListener(i, soundVerseListener);
        }
    }

    public void clearSoundVerseListener(int i) {
        SoundService soundService2 = this.soundService;
        if (soundService2 != null) {
            soundService2.clearSoundVerseListener(i);
        }
    }

    public boolean isPlayItem(int i, int i2) {
        SoundService soundService2 = this.soundService;
        if (soundService2 != null && this.init) {
            return soundService2.isPlayItem(i, i2);
        }
        if (!this.playRepeat && i == this.pagePosition && i2 == this.itemPosition && !this.init) {
            return true;
        }
        return false;
    }

    public boolean isPlayRepeatItem(int i, int i2) {
        SoundService soundService2 = this.soundService;
        if (soundService2 == null || !this.init) {
            return false;
        }
        return soundService2.isPlayRepeatItem(i, i2);
    }

    public void stop(int i) {
        SoundService soundService2 = this.soundService;
        if (soundService2 != null) {
            soundService2.stop(i);
        }
    }

    public void stopForeground() {
        SoundService soundService2 = this.soundService;
        if (soundService2 != null) {
            soundService2.stopForeground();
        }
    }

    public void setSoundPageListener(SoundPageListener soundPageListener2) {
        this.soundPageListener = soundPageListener2;
        SoundService soundService2 = this.soundService;
        if (soundService2 != null) {
            soundService2.setSoundPageListener(soundPageListener2);
        }
    }

    public void clear() {
        SoundService soundService2 = null;
        this.soundService = null;
        if (0 != 0) {
            soundService2.setSoundVerseListener(new HashMap());
        }
    }
}
