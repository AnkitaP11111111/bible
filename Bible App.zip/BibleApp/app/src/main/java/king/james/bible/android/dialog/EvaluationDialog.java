package king.james.bible.android.dialog;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import king.james.bible.android.R;
import king.james.bible.android.service.PowerManagerService;
import king.james.bible.android.utils.AppUtils;
import king.james.bible.android.utils.BiblePreferences;

public class EvaluationDialog extends BaseForegroundDialog implements View.OnClickListener {
    private boolean existAction;

    /* access modifiers changed from: protected */
    public int getActionTextResId() {
        return R.string.rate_us_button;
    }

    /* access modifiers changed from: protected */
    public int getLaterTextResId() {
        return R.string.later;
    }

    /* access modifiers changed from: protected */
    public int getNoTextResId() {
        return R.string.never_remind;
    }

    /* access modifiers changed from: protected */
    public int getTextResId() {
        return R.string.f153evaluation_dialogtext;
    }

    /* access modifiers changed from: protected */
    public int getTitleResId() {
        return R.string.rate_us;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.BaseDialogFragment
    public void initActions() {
    }

    /* access modifiers changed from: protected */
    public boolean showLaterButton() {
        return true;
    }

    /* access modifiers changed from: protected */
    public boolean showNoButton() {
        return true;
    }

    @Override // androidx.fragment.app.DialogFragment
    public Dialog onCreateDialog(Bundle bundle) {
        this.existAction = false;
        Dialog onCreateDialog = super.onCreateDialog(bundle);
        onCreateDialog.getWindow().requestFeature(1);
        return onCreateDialog;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.BaseDialogFragment
    public int getLayoutResourceId() {
        return BiblePreferences.getInstance().isNightMode() ? R.layout.fragment_evaluation_dialog_n : R.layout.fragment_evaluation_dialog;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.BaseDialogFragment
    public void mapViews(View view) {
        View findViewById = view.findViewById(R.id.neverRemindButton);
        findViewById.setOnClickListener(this);
        int i = 0;
        findViewById.setVisibility(showNoButton() ? 0 : 4);
        View findViewById2 = view.findViewById(R.id.laterButton);
        findViewById2.setOnClickListener(this);
        if (!showLaterButton()) {
            i = 4;
        }
        findViewById2.setVisibility(i);
        view.findViewById(R.id.rateUsButton).setOnClickListener(this);
        view.findViewById(R.id.closeImageButton).setOnClickListener(this);
        ((TextView) view.findViewById(R.id.textTextView)).setText(getTextResId());
        ((TextView) view.findViewById(R.id.titleTextView)).setText(getTitleResId());
        ((TextView) view.findViewById(R.id.noTextView)).setText(getNoTextResId());
        ((TextView) view.findViewById(R.id.laterTextView)).setText(getLaterTextResId());
        ((TextView) view.findViewById(R.id.actionTextView)).setText(getActionTextResId());
        PowerManagerService.getInstance().start();
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.closeImageButton:
                closeClick();
                dismiss();
                return;
            case R.id.laterButton:
                this.existAction = true;
                selectLater();
                dismiss();
                return;
            case R.id.neverRemindButton:
                this.existAction = true;
                dismiss();
                selectNo();
                return;
            case R.id.rateUsButton:
                this.existAction = true;
                dismiss();
                selectAction();
                return;
            default:
                return;
        }
    }

    @Override // androidx.fragment.app.DialogFragment
    public void onDismiss(DialogInterface dialogInterface) {
        super.onDismiss(dialogInterface);
        if (!this.existAction) {
            closeClick();
        }
    }

    /* access modifiers changed from: protected */
    public void closeClick() {
        this.existAction = true;
        selectLater();
    }

    /* access modifiers changed from: protected */
    public void selectAction() {
        BiblePreferences.getInstance().clearStartAppCount();
        AppUtils.openMarketPage(getActivity());
    }

    /* access modifiers changed from: protected */
    public void selectLater() {
        BiblePreferences.getInstance().restoreStartAppCount();
    }

    /* access modifiers changed from: protected */
    public void selectNo() {
        BiblePreferences.getInstance().clearStartAppCount();
    }
}
