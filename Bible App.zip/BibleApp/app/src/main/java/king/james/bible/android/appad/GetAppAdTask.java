package king.james.bible.android.appad;

import android.content.Context;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.util.ArrayList;
import java.util.List;
import king.james.bible.android.service.net.NetworkRequestService;
import king.james.bible.android.task.BaseTask;

/* access modifiers changed from: package-private */
public class GetAppAdTask extends BaseTask<Void, Void, List<AppAd>> {
    GetAppAdTask(Context context, OnCallbackHandler<List<AppAd>> onCallbackHandler) {
        super(context, onCallbackHandler);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.util.List] */
    /* access modifiers changed from: protected */
    /* JADX WARNING: Unknown variable types count: 1 */
    public List<AppAd> doExecute(Void... voidArr) throws Exception {
        ArrayList arrayList = new ArrayList();
        try {
            arrayList = (List) new GsonBuilder().create().fromJson(NetworkRequestService.requestGet(generateUrl()), new TypeToken<List<AppAd>>(this) {
                /* class king.james.bible.android.appad.GetAppAdTask.AnonymousClass1 */
            }.getType());
        } catch (Exception unused) {
        }
        if (arrayList == null) {
            arrayList = new ArrayList();
        }
        AppAdStorage.getInstance().setAppAds(arrayList);
        return arrayList;
    }

    private static String generateUrl() {
        return "https://bible-study-1f5e9.firebaseio.com/ad_app/" + AppAdStorage.getInstance().getAppId() + ".json";
    }
}
