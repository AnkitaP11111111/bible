package king.james.bible.android.model;

import com.bignerdranch.expandablerecyclerview.Model.ParentListItem;
import java.util.List;

public class DailyPlanMonth implements ParentListItem {
    private boolean initiallyExpanded = false;
    private String name;
    private List<PlanDay> planDays;
    private long time;

    public String getName() {
        return this.name;
    }

    public void setName(String str) {
        this.name = str;
    }

    @Override // com.bignerdranch.expandablerecyclerview.Model.ParentListItem
    public List<?> getChildItemList() {
        return this.planDays;
    }

    public List<PlanDay> getPlanDays() {
        return this.planDays;
    }

    public void setPlanDays(List list) {
        this.planDays = list;
    }

    @Override // com.bignerdranch.expandablerecyclerview.Model.ParentListItem
    public boolean isInitiallyExpanded() {
        return this.initiallyExpanded;
    }

    public void setInitiallyExpanded(boolean z) {
        this.initiallyExpanded = z;
    }

    public long getTime() {
        return this.time;
    }

    public void setTime(long j) {
        this.time = j;
    }
}
