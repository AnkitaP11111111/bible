package king.james.bible.android.db.service;

import android.database.Cursor;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import king.james.bible.android.PlanModeUtil;
import king.james.bible.android.db.BibleDataBase;
import king.james.bible.android.db.service.DailyReadingDataService;
import king.james.bible.android.model.Plan;
import king.james.bible.android.model.PlanChapterDay;
import king.james.bible.android.model.PlanDay;
import king.james.bible.android.model.PlanMode;
import king.james.bible.android.model.comparator.PlanDayComparator;

public class DailyReadingDataService {
    private BibleDataBase bibleDB;

    public interface CreatePlanListener {
        void createAllDays(List<PlanDay> list);
    }

    public DailyReadingDataService() {
        BibleDataBase instance = BibleDataBase.getInstance();
        this.bibleDB = instance;
        if (!instance.isOpen()) {
            try {
                this.bibleDB.open();
            } catch (Exception unused) {
            }
        }
    }

    public List<Plan> getPlanList() {
        List<Plan> planList = getPlanList(this.bibleDB.getAllPlans());
        if (planList.isEmpty()) {
            return planList;
        }
        for (Plan plan : planList) {
            plan.setPlanDays(new ArrayList());
            if (plan.isStarted()) {
                plan.getPlanDays().addAll(getDays(plan.getId(), plan.getModeId()));
                Collections.sort(plan.getPlanDays(), new PlanDayComparator());
            }
        }
        return planList;
    }

    public List<Plan> readAllForUpdateNotifications() {
        List<Plan> planList = getPlanList(this.bibleDB.getAllPlans());
        return planList == null ? new ArrayList() : planList;
    }

    private List<Plan> getPlanList(Cursor cursor) {
        return getPlanList(cursor, false);
    }

    private List<Plan> getPlanList(Cursor cursor, boolean z) {
        ArrayList arrayList = new ArrayList();
        if (cursor == null) {
            return arrayList;
        }
        try {
            arrayList.addAll(DailyReadingBuilder.createModels(cursor, z));
        } catch (Exception unused) {
        } catch (Throwable th) {
            cursor.close();
            throw th;
        }
        cursor.close();
        return arrayList;
    }

    private Plan getPlanById(long j) {
        return getPlanById(j, false);
    }

    private Plan getPlanById(long j, boolean z) {
        Cursor planById = this.bibleDB.getPlanById(j);
        if (planById == null) {
            return null;
        }
        try {
            if (!planById.moveToFirst()) {
                return null;
            }
            Plan createModel = DailyReadingBuilder.createModel(planById);
            planById.close();
            createModel.setPlanDays(new ArrayList());
            if (createModel.isStarted() || z) {
                createModel.getPlanDays().addAll(getDays(createModel.getId(), createModel.getModeId()));
                Collections.sort(createModel.getPlanDays(), new PlanDayComparator());
            }
            return createModel;
        } catch (Exception unused) {
            return null;
        } finally {
            planById.close();
        }
    }

    public Plan startPlan(int i, Plan plan, PlanMode planMode, CreatePlanListener createPlanListener) {
        this.bibleDB.deleteAllPlanDay(plan.getId());
        int dayCount = planMode.getDayCount();
        if (createPlanListener == null) {
            dayCount = planMode.getDayCount();
        }
        createDays(i, plan.getId(), dayCount);
        updatePlan(plan);
        Plan planById = getPlanById(plan.getId());
        if (dayCount < planMode.getDayCount()) {
            createDays(plan, dayCount, planMode, createPlanListener);
        }
        return planById;
    }

    /* access modifiers changed from: package-private */
    public Plan startPlan(Plan plan, PlanMode planMode) {
        this.bibleDB.deleteAllPlanDay(plan.getId());
        createDays(1, plan.getId(), planMode.getDayCount());
        updatePlan(plan);
        return getPlanById(plan.getId());
    }

    private void createDays(Plan plan, int i, PlanMode planMode, CreatePlanListener createPlanListener) {
        if (createPlanListener != null) {
            new Thread(new Runnable(i, planMode, plan, createPlanListener) {
                /* class king.james.bible.android.db.service.$$Lambda$DailyReadingDataService$3jI63auleUXUloAzbwWDexCWT0 */
                private final /* synthetic */ int f$1;
                private final /* synthetic */ PlanMode f$2;
                private final /* synthetic */ Plan f$3;
                private final /* synthetic */ CreatePlanListener f$4;

                {
                    this.f$1 = r2;
                    this.f$2 = r3;
                    this.f$3 = r4;
                    this.f$4 = r5;
                }

                public final void run() {
                    DailyReadingDataService.this.lambda$createDays$0$DailyReadingDataService(this.f$1, this.f$2, this.f$3, this.f$4);
                }
            }).start();
        }
    }

    public /* synthetic */ void lambda$createDays$0$DailyReadingDataService(int i, PlanMode planMode, Plan plan, CreatePlanListener createPlanListener) {
        while (true) {
            i++;
            if (i <= planMode.getDayCount()) {
                this.bibleDB.createPlanDay(DailyReadingBuilder.getPlanDayContentValues(plan.getId(), i, false));
            } else {
                createPlanListener.createAllDays(getPlanById(plan.getId()).getPlanDays());
                return;
            }
        }
    }

    private void createDays(int i, long j, int i2) {
        if (i2 != 0) {
            int i3 = 1;
            while (i3 <= i2) {
                this.bibleDB.createPlanDay(DailyReadingBuilder.getPlanDayContentValues(j, i3, i3 < i));
                i3++;
            }
        }
    }

    public void stopPlan(Plan plan) {
        this.bibleDB.clearChapterDaysPlan(plan.getId(), plan.getModeId());
        plan.setStartDate(0);
        plan.setEndDate(0);
        plan.setStarted(false);
        plan.setModeId(0);
        plan.setNotify(false);
        plan.setNotifyTime(0);
        updatePlan(plan);
    }

    public void updatePlan(Plan plan) {
        this.bibleDB.updatePlan(plan.getId(), DailyReadingBuilder.getPlanContentValues(plan));
    }

    private List<PlanDay> getDays(long j, int i) {
        ArrayList arrayList = new ArrayList();
        Cursor allPlanDay = this.bibleDB.getAllPlanDay(j);
        if (allPlanDay == null) {
            return arrayList;
        }
        try {
            arrayList.addAll(DailyReadingBuilder.cretePlanDays(allPlanDay));
        } catch (Exception unused) {
        } catch (Throwable th) {
            allPlanDay.close();
            throw th;
        }
        allPlanDay.close();
        addPlanChapterDay(arrayList, j, i);
        return arrayList;
    }

    private void addPlanChapterDay(List<PlanDay> list, long j, int i) {
        Cursor readingDays = this.bibleDB.getReadingDays(j, i);
        if (readingDays != null) {
            Map<Integer, List<PlanChapterDay>> map = null;
            try {
                map = DailyReadingBuilder.createPlanChapterDaysMap(readingDays);
            } catch (Exception unused) {
            } catch (Throwable th) {
                readingDays.close();
                throw th;
            }
            readingDays.close();
            if (!(map == null || map.isEmpty())) {
                for (PlanDay planDay : list) {
                    planDay.setPlanChapterDays(map.get(Integer.valueOf(planDay.getDay())));
                }
            }
        }
    }

    public void viewChapter(PlanChapterDay planChapterDay) {
        updateChapterDay(planChapterDay);
    }

    private void updateChapterDay(PlanChapterDay planChapterDay) {
        this.bibleDB.updateChapterDay(planChapterDay.getId(), DailyReadingBuilder.getChapterDayContentValues(planChapterDay));
    }

    public void completeAll(PlanDay planDay, int i) {
        updatePlanDay(planDay);
        this.bibleDB.completeAllChapterDaysPlan(planDay.getPlanId(), i, planDay.getDay());
        for (PlanChapterDay planChapterDay : planDay.getPlanChapterDays()) {
            if (planChapterDay.isViewed()) {
                this.bibleDB.updateChapterDay(planChapterDay.getId(), DailyReadingBuilder.getChapterDayContentValues(planChapterDay));
            }
        }
    }

    private void updatePlanDay(PlanDay planDay) {
        this.bibleDB.updatePlanDay(planDay.getId(), DailyReadingBuilder.getPlanDayContentValues(planDay));
    }

    public List<PlanDay> getDaysStartPlan(long j, int i) {
        ArrayList arrayList = new ArrayList();
        int i2 = 0;
        while (i2 < PlanModeUtil.plansMode.get(Integer.valueOf(i)).getDayCount()) {
            PlanDay planDay = new PlanDay();
            i2++;
            planDay.setDay(i2);
            arrayList.add(planDay);
        }
        addPlanChapterDay(arrayList, j, i);
        return arrayList;
    }
}
