package king.james.bible.android.db;

import com.karumi.dexter.BuildConfig;
import java.util.HashSet;
import java.util.Iterator;

public class SqlHtmlTagUtil {
    public static String getIgnoreTagsAndAttributeQuery(String str, String[] strArr) {
        return getIgnoreTagsQuery(str, strArr) + getIgnoreAttributeQuery(str, strArr);
    }

    public static String getIgnoreTagsQuery(String str, String[] strArr) {
        HashSet hashSet = new HashSet();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < strArr.length; i++) {
            Iterator<SqlHtmlTagUtil$HtmlTags$Tag> it = SqlHtmlTagUtil$HtmlTags$Tag.getList().iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                SqlHtmlTagUtil$HtmlTags$Tag next = it.next();
                if (strArr[i].replaceAll("<", BuildConfig.FLAVOR).replaceAll(">", BuildConfig.FLAVOR).replaceAll("/", BuildConfig.FLAVOR).equalsIgnoreCase(next.name()) && !hashSet.contains(next)) {
                    sb.append(getTagSql(str, next));
                    hashSet.add(next);
                    break;
                }
            }
        }
        return sb.toString();
    }

    private static String getTagSql(String str, SqlHtmlTagUtil$HtmlTags$Tag sqlHtmlTagUtil$HtmlTags$Tag) {
        StringBuilder sb = new StringBuilder();
        sb.append(" AND  UPPER(" + str + ") NOT LIKE '%" + "<" + sqlHtmlTagUtil$HtmlTags$Tag.name() + "%' ");
        sb.append(" AND  UPPER(" + str + ") NOT LIKE '%" + sqlHtmlTagUtil$HtmlTags$Tag.name() + ">" + "%' ");
        sb.append(" AND  UPPER(" + str + ") NOT LIKE '%" + "</" + sqlHtmlTagUtil$HtmlTags$Tag.name() + "%' ");
        sb.append(" AND  UPPER(" + str + ") NOT LIKE '%" + "/" + sqlHtmlTagUtil$HtmlTags$Tag.name() + "%' ");
        return sb.toString();
    }

    public static String getIgnoreAttributeQuery(String str, String[] strArr) {
        HashSet hashSet = new HashSet();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < strArr.length; i++) {
            Iterator<SqlHtmlTagUtil$HtmlTags$Attribute> it = SqlHtmlTagUtil$HtmlTags$Attribute.getList().iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                SqlHtmlTagUtil$HtmlTags$Attribute next = it.next();
                if (strArr[i].replaceAll("=", BuildConfig.FLAVOR).replaceAll("\"", BuildConfig.FLAVOR).replaceAll("#", BuildConfig.FLAVOR).equalsIgnoreCase(next.name()) && !hashSet.contains(next)) {
                    sb.append(getAttributeSql(str, next));
                    hashSet.add(next);
                    break;
                }
            }
        }
        return sb.toString();
    }

    private static String getAttributeSql(String str, SqlHtmlTagUtil$HtmlTags$Attribute sqlHtmlTagUtil$HtmlTags$Attribute) {
        StringBuilder sb = new StringBuilder();
        sb.append(" AND  UPPER(" + str + ") NOT LIKE '%" + sqlHtmlTagUtil$HtmlTags$Attribute.name() + "=" + "%' ");
        sb.append(" AND  UPPER(" + str + ") NOT LIKE '%" + sqlHtmlTagUtil$HtmlTags$Attribute.name() + "=" + "\"" + "%' ");
        sb.append(" AND  UPPER(" + str + ") NOT LIKE '%" + sqlHtmlTagUtil$HtmlTags$Attribute.name() + "=" + "\"" + "#" + "%' ");
        return sb.toString();
    }
}
