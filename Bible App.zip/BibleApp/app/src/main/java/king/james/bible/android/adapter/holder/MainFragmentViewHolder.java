package king.james.bible.android.adapter.holder;

import android.view.View;
import king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter;

public abstract class MainFragmentViewHolder extends BaseRecyclerViewAdapter.BaseViewHolder {
    public MainFragmentViewHolder(View view) {
        super(view);
    }
}
