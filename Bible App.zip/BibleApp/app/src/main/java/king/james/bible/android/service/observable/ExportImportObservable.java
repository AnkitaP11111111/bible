package king.james.bible.android.service.observable;

import java.io.File;
import java.util.HashSet;
import java.util.Set;
import king.james.bible.android.dialog.ExportImportDialog;
import king.james.bible.android.dialog.ImportFileListener;

public class ExportImportObservable implements ExportImportDialog.ImportListener, ImportFileListener {
    private static ExportImportObservable instance;
    private Set<ImportFileListener> importListeners;
    private Set<ExportImportDialog.ImportListener> listeners;

    private ExportImportObservable() {
    }

    public static ExportImportObservable getInstance() {
        if (instance == null) {
            synchronized (ExportImportObservable.class) {
                if (instance == null) {
                    instance = new ExportImportObservable();
                }
            }
        }
        return instance;
    }

    public void subscribe(ExportImportDialog.ImportListener importListener) {
        checkList();
        this.listeners.add(importListener);
    }

    public void remove(ExportImportDialog.ImportListener importListener) {
        checkList();
        this.listeners.remove(importListener);
    }

    public void subscribe(ImportFileListener importFileListener) {
        checkImportList();
        this.importListeners.add(importFileListener);
    }

    public void remove(ImportFileListener importFileListener) {
        checkImportList();
        this.importListeners.remove(importFileListener);
    }

    private void checkList() {
        if (this.listeners == null) {
            this.listeners = new HashSet();
        }
    }

    private void checkImportList() {
        if (this.importListeners == null) {
            this.importListeners = new HashSet();
        }
    }

    @Override // king.james.bible.android.dialog.ExportImportDialog.ImportListener
    public void onSuccessImport() {
        checkList();
        for (ExportImportDialog.ImportListener importListener : this.listeners) {
            if (importListener != null) {
                importListener.onSuccessImport();
            }
        }
    }

    @Override // king.james.bible.android.dialog.ExportImportDialog.ImportListener
    public void onErrorImport() {
        checkList();
        for (ExportImportDialog.ImportListener importListener : this.listeners) {
            if (importListener != null) {
                importListener.onErrorImport();
            }
        }
    }

    @Override // king.james.bible.android.dialog.ImportFileListener
    public void importData(File file) {
        checkImportList();
        for (ImportFileListener importFileListener : this.importListeners) {
            if (importFileListener != null) {
                importFileListener.importData(file);
            }
        }
    }
}
