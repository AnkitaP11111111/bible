package king.james.bible.android.db.listener;

public interface RemoveHighLightListener {
    void onComplete();

    void removeFromAdapter(int i);
}
