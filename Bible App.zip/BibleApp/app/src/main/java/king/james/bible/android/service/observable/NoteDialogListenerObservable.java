package king.james.bible.android.service.observable;

import java.util.HashMap;
import java.util.Map;
import king.james.bible.android.dialog.NoteDialog;

public class NoteDialogListenerObservable implements NoteDialog.NoteDialogListener {
    private static NoteDialogListenerObservable instance;
    private Map<Integer, NoteDialog.NoteDialogListener> listeners;

    private NoteDialogListenerObservable() {
    }

    public static NoteDialogListenerObservable getInstance() {
        if (instance == null) {
            synchronized (NoteDialogListenerObservable.class) {
                if (instance == null) {
                    instance = new NoteDialogListenerObservable();
                }
            }
        }
        return instance;
    }

    public void subscribe(int i, NoteDialog.NoteDialogListener noteDialogListener) {
        checkList();
        this.listeners.put(Integer.valueOf(i), noteDialogListener);
    }

    public void remove(int i) {
        checkList();
        this.listeners.remove(Integer.valueOf(i));
    }

    private void checkList() {
        if (this.listeners == null) {
            this.listeners = new HashMap();
        }
    }

    @Override // king.james.bible.android.dialog.NoteDialog.NoteDialogListener
    public void onSaveNoteSelect(int i, String str, int i2) {
        checkList();
        if (this.listeners.containsKey(Integer.valueOf(i))) {
            this.listeners.get(Integer.valueOf(i)).onSaveNoteSelect(i, str, i2);
        }
    }

    @Override // king.james.bible.android.dialog.NoteDialog.NoteDialogListener
    public void onDeleteNoteSelect(int i, int i2, int i3, int i4) {
        checkList();
        if (this.listeners.containsKey(Integer.valueOf(i))) {
            this.listeners.get(Integer.valueOf(i)).onDeleteNoteSelect(i, i2, i3, i4);
        }
    }
}
