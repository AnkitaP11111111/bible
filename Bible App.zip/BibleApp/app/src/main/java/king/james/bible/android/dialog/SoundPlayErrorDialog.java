package king.james.bible.android.dialog;

import king.james.bible.android.R;

public class SoundPlayErrorDialog extends EvaluationDialog {
    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.EvaluationDialog
    public void closeClick() {
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.EvaluationDialog
    public int getActionTextResId() {
        return R.string.sound_play_error_button;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.EvaluationDialog
    public int getTextResId() {
        return R.string.sound_play_error_message;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.EvaluationDialog
    public int getTitleResId() {
        return R.string.sound_play_error_title;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.EvaluationDialog
    public boolean showLaterButton() {
        return false;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.EvaluationDialog
    public boolean showNoButton() {
        return false;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.EvaluationDialog
    public void selectAction() {
        dismiss();
    }
}
