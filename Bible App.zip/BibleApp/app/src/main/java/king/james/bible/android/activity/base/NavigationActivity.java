package king.james.bible.android.activity.base;

import android.annotation.SuppressLint;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import king.james.bible.android.R;
import king.james.bible.android.event.WaitDialogEvent;
import king.james.bible.android.fragment.BaseFragment;
import king.james.bible.android.fragment.MainScreenFragment;
import king.james.bible.android.service.net.NetworkService;
import king.james.bible.android.sound.SoundHelper;
import king.james.bible.android.sound.util.DrawableUtil;
import king.james.bible.android.utils.BiblePreferences;
import king.james.bible.android.utils.BibleToast;
import king.james.bible.android.utils.ScreenUtil;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
@SuppressLint("WrongConstant")

public abstract class NavigationActivity extends BaseActivity implements FragmentManager.OnBackStackChangedListener {
    protected BiblePreferences preferences;
    private long tapBackTime = 0;
    private View waitView;

    /* access modifiers changed from: protected */
    public abstract void closeDrawerLeft();

    /* access modifiers changed from: protected */
    public abstract void loadDBComplete();

    @Override // androidx.fragment.app.FragmentManager.OnBackStackChangedListener
    public void onBackStackChanged() {
    }



    /* access modifiers changed from: protected */
    @Override // androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, androidx.fragment.app.FragmentActivity, king.james.bible.android.activity.base.BaseActivity
    @SuppressLint({"NewApi"})
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        EventBus.getDefault().register(this);
        NetworkService.getInstance().startObservable();
        BiblePreferences instance = BiblePreferences.getInstance();
        this.preferences = instance;
        try {
            setContentView(instance.isNightMode() ? R.layout.activity_fragment_main_n : R.layout.activity_fragment_main);
        } catch (Exception unused) {
            finish();
        }
        this.waitView = findViewById(R.id.waitView);
    }

    /* access modifiers changed from: protected */
    public void clearBackStack() {
        FragmentManager supportFragmentManager = getSupportFragmentManager();
        for (int i = 0; i < supportFragmentManager.getBackStackEntryCount(); i++) {
            supportFragmentManager.popBackStack(getSupportFragmentManager().getBackStackEntryAt(i).getId(), 1);
        }
    }

    /* access modifiers changed from: protected */
    public void loadMainFragment() {
        loadMainFragment(null, false);
    }

    /* access modifiers changed from: protected */
    public void loadMainFragment(Bundle bundle, boolean z) {
        if (!isFinishing()) {
            DrawableUtil.getInstance().init(this);
            this.preferences.lambda$restoreAsync$0$BiblePreferences();
            getSupportFragmentManager().addOnBackStackChangedListener(this);
            if (findViewById(R.id.whole_app_frame_container) != null) {
                MainScreenFragment mainScreenFragment = new MainScreenFragment();
                if (!z) {
                    try {
                        clearBackStack();
                    } catch (Exception unused) {
                    }
                }
                openFragment(mainScreenFragment, bundle);
            }
            customStatusBar();
            new Handler().postDelayed(new Runnable() {
                /* class king.james.bible.android.activity.base.$$Lambda$WMo9Sqap8IkMhwDzUsuhNCCJMro */

                public final void run() {
                    NavigationActivity.this.loadDBComplete();
                }
            }, 900);
        }
    }

    public void openFragment(Class<? extends Fragment> cls) {
        openFragment(cls, (Bundle) null);
    }

    /* access modifiers changed from: protected */
    public void openFragment(Class<? extends Fragment> cls, Bundle bundle) {
        try {
            openFragment((Fragment) cls.newInstance(), bundle);
        } catch (Exception unused) {
        }
    }

    public void openFragment(Fragment fragment, Bundle bundle) {
        try {
            SoundHelper.getInstance().pause();
            if (bundle == null) {
                bundle = new Bundle();
            }
            fragment.setArguments(bundle);
            closeDrawerLeft();
            String tag = getTag(fragment);
            FragmentTransaction beginTransaction = getSupportFragmentManager().beginTransaction();
            beginTransaction.add(R.id.whole_app_frame_container, fragment, tag);
            beginTransaction.addToBackStack(tag);
            beginTransaction.commitAllowingStateLoss();
            hideLastFragment(0);
        } catch (Exception unused) {
        }
    }

    public static String getTag(Fragment fragment) {
        return fragment.getClass().getSimpleName() + "_" + fragment.hashCode();
    }

    /* access modifiers changed from: protected */
    public void hideLastFragment(long j) {
        new Handler().postDelayed(new Runnable() {
            /* class king.james.bible.android.activity.base.$$Lambda$NavigationActivity$Pe6Y01avCrjzPP2ZyqVBII5Xs */

            public final void run() {
                NavigationActivity.this.lambda$hideLastFragment$0$NavigationActivity();
            }
        }, j);
    }

    public /* synthetic */ void lambda$hideLastFragment$0$NavigationActivity() {
        if (!isFinishing()) {
            try {
                FragmentManager supportFragmentManager = getSupportFragmentManager();
                FragmentTransaction beginTransaction = supportFragmentManager.beginTransaction();
                if (supportFragmentManager.getBackStackEntryCount() > 1) {
                    beginTransaction.hide(supportFragmentManager.findFragmentByTag(getSupportFragmentManager().getBackStackEntryAt(supportFragmentManager.getBackStackEntryCount() - 2).getName()));
                    beginTransaction.commitAllowingStateLoss();
                }
            } catch (Exception unused) {
            }
        }
    }

    /* access modifiers changed from: protected */
    public void updateFromBackPressed() {
        FragmentManager supportFragmentManager = getSupportFragmentManager();
        if (supportFragmentManager.getBackStackEntryCount() > 1) {
            Fragment findFragmentByTag = supportFragmentManager.findFragmentByTag(supportFragmentManager.getBackStackEntryAt(supportFragmentManager.getBackStackEntryCount() - 2).getName());
            if (findFragmentByTag instanceof BaseFragment) {
                BaseFragment baseFragment = (BaseFragment) findFragmentByTag;
                baseFragment.onResumeFromBackStack();
                baseFragment.updateToolbar();
            }
            FragmentTransaction beginTransaction = getSupportFragmentManager().beginTransaction();
            beginTransaction.show(findFragmentByTag);
            beginTransaction.commitAllowingStateLoss();
        }
        closeDrawerLeft();
        getSupportFragmentManager().addOnBackStackChangedListener(this);
    }

    /* access modifiers changed from: protected */
    public Fragment getOpenFragment() {
        for (int size = getSupportFragmentManager().getFragments().size() - 1; size > 0; size--) {
            if (getSupportFragmentManager().getFragments().get(size) != null) {
                return getSupportFragmentManager().getFragments().get(size);
            }
        }
        return null;
    }

    /* access modifiers changed from: protected */
    public Fragment getTopFragment() {
        if (getSupportFragmentManager().getFragments().isEmpty()) {
            return null;
        }
        return getSupportFragmentManager().getFragments().get(getSupportFragmentManager().getFragments().size() - 1);
    }

    /* access modifiers changed from: protected */
    public void restoreFragments() {
        FragmentManager supportFragmentManager = getSupportFragmentManager();
        for (Fragment fragment : supportFragmentManager.getFragments()) {
            if (fragment instanceof BaseFragment) {
                ((BaseFragment) fragment).updateToolbar();
            }
        }
        FragmentTransaction beginTransaction = supportFragmentManager.beginTransaction();
        for (int i = 0; i < supportFragmentManager.getBackStackEntryCount() - 1; i++) {
            try {
                beginTransaction.hide(supportFragmentManager.findFragmentByTag(supportFragmentManager.getBackStackEntryAt(i).getName()));
            } catch (Exception unused) {
            }
        }
        beginTransaction.commitAllowingStateLoss();
        closeDrawerLeft();
        getSupportFragmentManager().addOnBackStackChangedListener(this);
        ScreenUtil.getInstance().hideKeyboard(this);
    }

    @Override // androidx.activity.ComponentActivity
    public void onBackPressed() {
        try {
            FragmentManager supportFragmentManager = getSupportFragmentManager();
            if (supportFragmentManager.getBackStackEntryCount() != 1 || getOpenFragment() == null) {
                if (supportFragmentManager.getBackStackEntryCount() == 1 && !exit()) {
                    return;
                }
                if (supportFragmentManager.getBackStackEntryCount() <= 1) {
                    finish();
                    return;
                }
                updateFromBackPressed();
                hideWaitDialog();
                super.onBackPressed();
                ScreenUtil.getInstance().hideKeyboard(this);
            } else if (!(getOpenFragment() instanceof MainScreenFragment) || Build.VERSION.SDK_INT >= 17) {
                clearBackStack();
                loadMainFragment();
            } else {
                finish();
            }
        } catch (Exception unused) {
        }
    }

    public void onBackPressedSuper() {
        hideWaitDialog();
        super.onBackPressed();
    }

    private boolean exit() {
        long currentTimeMillis = System.currentTimeMillis();
        if (currentTimeMillis - 3000 <= this.tapBackTime) {
            return true;
        }
        this.tapBackTime = currentTimeMillis;
        BibleToast.showLongDurationToast(this, (int) R.string.exit_message);
        return false;
    }

    /* access modifiers changed from: protected */
    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, king.james.bible.android.activity.base.BaseActivity
    public void onDestroy() {
        NetworkService.getInstance().stopObservable();
        EventBus.getDefault().unregister(this);
        super.onDestroy();
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(WaitDialogEvent waitDialogEvent) {
        this.waitView.setVisibility(waitDialogEvent.isShowDialog() ? 0 : 8);
    }

    private void hideWaitDialog() {
        this.waitView.setVisibility(8);
    }
}
