//package king.james.bible.android.ad;
//
//import android.view.View;
//
//public interface AdHolderListener {
//    void addView(View view);
//
//    void onAdFailedToLoad(boolean z);
//
//    void onAdLoaded();
//}
