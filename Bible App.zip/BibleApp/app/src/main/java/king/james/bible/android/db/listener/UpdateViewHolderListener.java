package king.james.bible.android.db.listener;

public interface UpdateViewHolderListener {
    void onCompleteDrawHeader(int i, int i2);
}
