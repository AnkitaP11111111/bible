package king.james.bible.android.dialog;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import com.karumi.dexter.BuildConfig;
import king.james.bible.android.R;
import king.james.bible.android.db.BibleDataBase;
import king.james.bible.android.model.Note;
import king.james.bible.android.service.PowerManagerService;
import king.james.bible.android.service.observable.NoteDialogListenerObservable;
import king.james.bible.android.utils.BiblePreferences;
import king.james.bible.android.utils.BibleToast;

public class NoteDialog extends BaseForegroundDialog implements View.OnClickListener {
    private int chapter;
    private String noteRoot;
    private EditText noteText;
    private int pagePosition;
    private int rank;
    private int subChapter;
    private TextView title;
    private TextView txtDelete;

    public interface NoteDialogListener {
        void onDeleteNoteSelect(int i, int i2, int i3, int i4);

        void onSaveNoteSelect(int i, String str, int i2);
    }

    @Override // androidx.fragment.app.DialogFragment
    public int getTheme() {
        return R.style.DialogFullscreenTheme;
    }

    @Override // androidx.fragment.app.DialogFragment
    public Dialog onCreateDialog(Bundle bundle) {
        if (bundle != null) {
            this.pagePosition = bundle.getInt("pagePosition", 0);
            this.chapter = bundle.getInt("chapter", 0);
            this.subChapter = bundle.getInt("subChapter", 0);
            this.rank = bundle.getInt("rank", 0);
        }
        return super.onCreateDialog(bundle);
    }

    @Override // androidx.fragment.app.Fragment, androidx.fragment.app.DialogFragment
    public void onSaveInstanceState(Bundle bundle) {
        if (bundle == null) {
            bundle = new Bundle();
        }
        bundle.putInt("pagePosition", this.pagePosition);
        bundle.putInt("chapter", this.chapter);
        bundle.putInt("subChapter", this.subChapter);
        bundle.putInt("rank", this.rank);
        super.onSaveInstanceState(bundle);
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.BaseDialogFragment
    public int getLayoutResourceId() {
        return BiblePreferences.getInstance().isNightMode() ? R.layout.add_note_dialog_n : R.layout.add_note_dialog;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.BaseDialogFragment
    public void mapViews(View view) {
        view.findViewById(R.id.add_note_delete_btn).setOnClickListener(this);
        view.findViewById(R.id.add_note_done_btn).setOnClickListener(this);
        this.noteText = (EditText) view.findViewById(R.id.add_a_note_edit);
        this.title = (TextView) view.findViewById(R.id.note_dialog_title_text);
        this.txtDelete = (TextView) view.findViewById(R.id.txtDel);
        PowerManagerService.getInstance().start();
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.BaseDialogFragment
    public void initActions() {
        new Thread(new Runnable() {
            /* class king.james.bible.android.dialog.$$Lambda$NoteDialog$sggUWgGxtlnlMrD1KOxSBFTKc8 */

            public final void run() {
                NoteDialog.this.lambda$initActions$1$NoteDialog();
            }
        }).start();
    }

    public /* synthetic */ void lambda$initActions$1$NoteDialog() {
        BibleDataBase instance = BibleDataBase.getInstance();
        String chapterNameById = instance.getChapterNameById((long) this.chapter);
        Note note = instance.getNote(this.chapter, this.subChapter, this.rank);
        if (note != null && this.title != null) {
            this.title.post(new Runnable(note, this.title.getContext().getResources().getString(R.string.note) + ": " + chapterNameById + " " + this.subChapter + ":" + note.getPosition()) {
                /* class king.james.bible.android.dialog.$$Lambda$NoteDialog$T7vC4m0mGvKNQlpmb9YW480YFMA */
                private final /* synthetic */ Note f$1;
                private final /* synthetic */ String f$2;

                {
                    this.f$1 = r2;
                    this.f$2 = r3;
                }

                public final void run() {
                    NoteDialog.this.lambda$null$0$NoteDialog(this.f$1, this.f$2);
                }
            });
        }
    }

    public /* synthetic */ void lambda$null$0$NoteDialog(Note note, String str) {
        String note2 = note.getNote();
        this.noteRoot = note2;
        if (note2 != null) {
            this.noteText.setText(note2);
            this.txtDelete.setText(R.string.delete);
        } else {
            this.noteRoot = BuildConfig.FLAVOR;
            this.txtDelete.setText(R.string.cancel);
        }
        this.title.setText(str);
    }

    /* access modifiers changed from: package-private */
    public void setParameters(int i, int i2, int i3, int i4) {
        this.pagePosition = i;
        this.chapter = i2;
        this.subChapter = i3;
        this.rank = i4;
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.add_note_delete_btn:
                selectDelete();
                dismiss();
                return;
            case R.id.add_note_done_btn:
                selectDone();
                return;
            default:
                return;
        }
    }

    private String getInputText() {
        return this.noteText.getText().toString();
    }

    private void selectDelete() {
        NoteDialogListenerObservable.getInstance().onDeleteNoteSelect(this.pagePosition, this.chapter, this.subChapter, this.rank);
    }

    private void selectDone() {
        String inputText = getInputText();
        if (inputText.isEmpty()) {
            showInputNoteTextToast();
            return;
        }
        if (this.noteRoot == null) {
            this.noteRoot = BuildConfig.FLAVOR;
        }
        if (!this.noteRoot.equals(inputText)) {
            NoteDialogListenerObservable.getInstance().onSaveNoteSelect(this.pagePosition, inputText, this.rank);
        }
        dismiss();
    }

    private void showInputNoteTextToast() {
        EditText editText = this.noteText;
        if (editText != null) {
            BibleToast.showLongDurationToast(editText.getContext(), (int) R.string.f158notetoasttext);
        }
    }
}
