package king.james.bible.android.dialog;

import androidx.fragment.app.FragmentManager;
import com.karumi.dexter.BuildConfig;
import king.james.bible.android.event.WaitDialogEvent;
import king.james.bible.android.model.DialogDataBookmark;
import king.james.bible.android.model.Plan;
import org.greenrobot.eventbus.EventBus;

public class DialogUtil {
    public static void showBackupHintDialog(FragmentManager fragmentManager) {
        try {
            new BackupHintDialog().show(fragmentManager, BuildConfig.FLAVOR);
        } catch (Exception unused) {
        }
    }

    public static void showSoundPlayErrorDialog(FragmentManager fragmentManager) {
        try {
            new SoundPlayErrorDialog().show(fragmentManager, BuildConfig.FLAVOR);
        } catch (Exception unused) {
        }
    }

    public static void showAddANoteDialog(FragmentManager fragmentManager, int i, int i2, int i3, int i4) {
        try {
            NoteDialog noteDialog = new NoteDialog();
            noteDialog.setParameters(i, i2, i3, i4);
            noteDialog.show(fragmentManager, BuildConfig.FLAVOR);
        } catch (Exception unused) {
        }
    }

    public static void showSelectActionDialog(FragmentManager fragmentManager, int i, DialogDataBookmark dialogDataBookmark) {
        if (fragmentManager != null && dialogDataBookmark.getSelectedSet().size() != 0) {
            try {
                SelectActionDialog selectActionDialog = new SelectActionDialog();
                selectActionDialog.setParameters(i, dialogDataBookmark);
                selectActionDialog.show(fragmentManager, BuildConfig.FLAVOR);
            } catch (Exception unused) {
            }
        }
    }

    public static void showProgressDialog() {
        EventBus.getDefault().post(new WaitDialogEvent(true));
    }

    public static void hideProgressDialog() {
        EventBus.getDefault().post(new WaitDialogEvent(false));
    }

    public static void showDeleteDialog(FragmentManager fragmentManager, long j, int i, int i2) {
        try {
            DeleteDialog deleteDialog = new DeleteDialog();
            deleteDialog.setParameters(j, i, i2);
            deleteDialog.show(fragmentManager, BuildConfig.FLAVOR);
        } catch (Exception unused) {
        }
    }

    public static void showEvaluationDialog(FragmentManager fragmentManager) {
        try {
            new EvaluationDialog().show(fragmentManager, BuildConfig.FLAVOR);
        } catch (Exception unused) {
        }
    }

    public static void showShareDialog(FragmentManager fragmentManager) {
        try {
            new ShareDialog().show(fragmentManager, BuildConfig.FLAVOR);
        } catch (Exception unused) {
        }
    }

    public static void showDailyPlanDialog(FragmentManager fragmentManager, Plan plan) {
        try {
            DailyPlanDialog dailyPlanDialog = new DailyPlanDialog();
            dailyPlanDialog.setPlan(plan);
            dailyPlanDialog.show(fragmentManager, BuildConfig.FLAVOR);
        } catch (Exception unused) {
        }
    }

    public static void showCompletePlanDialog(FragmentManager fragmentManager) {
        try {
            new CompletePlanDialog().show(fragmentManager, BuildConfig.FLAVOR);
        } catch (Exception unused) {
        }
    }

    public static void showNotifyDialog(FragmentManager fragmentManager, long j, boolean z, long j2) {
        try {
            NotifyDialog notifyDialog = new NotifyDialog();
            notifyDialog.setParameters(j, z, j2);
            notifyDialog.show(fragmentManager, BuildConfig.FLAVOR);
        } catch (Exception unused) {
        }
    }

    public static void showImportExportDialog(FragmentManager fragmentManager) {
        try {
            ExportImportDialog exportImportDialog = new ExportImportDialog();
            exportImportDialog.setParameters(false);
            exportImportDialog.show(fragmentManager, BuildConfig.FLAVOR);
        } catch (Exception unused) {
        }
    }
}
