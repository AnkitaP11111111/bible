package king.james.bible.android.fragment;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import king.james.bible.android.R;
import king.james.bible.android.activity.MainFragmentActivity;
import king.james.bible.android.utils.BiblePreferences;
import king.james.bible.android.utils.ScreenUtil;
@SuppressLint({"NewApi", "WrongConstant"})

public abstract class BaseDailyFragment extends BaseFragment implements View.OnClickListener {
    protected FragmentMode fragmentMode = FragmentMode.CHILD;
    private ProgressBar progressBar;
    private TextView titleTextView;

    public enum FragmentMode {
        ROOT,
        CHILD
    }

    /* access modifiers changed from: protected */
    public abstract int getViewResId();

    /* access modifiers changed from: protected */
    public abstract void initActions();

    /* access modifiers changed from: protected */
    public abstract void mapViews(View view);

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.fragment_base, (ViewGroup) null);
        this.progressBar = (ProgressBar) inflate.findViewById(R.id.progressBar);
        this.titleTextView = (TextView) inflate.findViewById(R.id.titleTextView);
        hideProgress();
        ((FrameLayout) inflate.findViewById(R.id.container)).addView((ViewGroup) layoutInflater.inflate(getViewResId(), (ViewGroup) null));
        mapViews(inflate);
        prepareModeView(inflate);
        initActions();
        prepareToolbar(inflate);
        return inflate;
    }

    /* access modifiers changed from: protected */
    public void prepareModeView(View view) {
        int i;
        boolean isNightMode = BiblePreferences.getInstance().isNightMode();
        int i2 = R.color.white;
        if (isNightMode) {
            i2 = R.color.black_bg;
            i = R.color.title_bar_color_n;
        } else {
            i = R.color.white;
        }
        view.findViewById(R.id.root_layout).setBackgroundResource(i2);
        view.findViewById(R.id.actionbar).setBackgroundResource(i);
    }

    /* access modifiers changed from: protected */
    public void prepareToolbar(View view) {
        ImageButton imageButton = (ImageButton) view.findViewById(R.id.backImageButton);
        ImageButton imageButton2 = (ImageButton) view.findViewById(R.id.menuImageButton);
        imageButton.setOnClickListener(this);
        imageButton2.setOnClickListener(this);
        int i = AnonymousClass1.$SwitchMap$king$james$bible$android$fragment$BaseDailyFragment$FragmentMode[this.fragmentMode.ordinal()];
        if (i == 1) {
            imageButton.setVisibility(8);
            imageButton2.setVisibility(0);
        } else if (i == 2) {
            imageButton.setVisibility(0);
            imageButton2.setVisibility(8);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: king.james.bible.android.fragment.BaseDailyFragment$1  reason: invalid class name */
    public static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] $SwitchMap$king$james$bible$android$fragment$BaseDailyFragment$FragmentMode;

        /* JADX WARNING: Can't wrap try/catch for region: R(6:0|1|2|3|4|6) */
        /* JADX WARNING: Code restructure failed: missing block: B:7:?, code lost:
            return;
         */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        static {
            int[] iArr = new int[FragmentMode.values().length];
            $SwitchMap$king$james$bible$android$fragment$BaseDailyFragment$FragmentMode = iArr;
            iArr[FragmentMode.ROOT.ordinal()] = 1;
            $SwitchMap$king$james$bible$android$fragment$BaseDailyFragment$FragmentMode[FragmentMode.CHILD.ordinal()] = 2;
        }
    }

    /* access modifiers changed from: protected */
    public void setToolbarTitle(int i) {
        this.titleTextView.setText(i);
    }

    /* access modifiers changed from: protected */
    public void showProgress() {
        this.progressBar.setVisibility(0);
    }

    /* access modifiers changed from: protected */
    public void hideProgress() {
        this.progressBar.setVisibility(8);
    }

    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.backImageButton) {
            onBackClick();
        } else if (id == R.id.menuImageButton) {
            onMenuClick();
        }
    }

    /* access modifiers changed from: protected */
    public void onMenuClick() {
        ((MainFragmentActivity) getActivity()).showHideSideMenu();
    }

    /* access modifiers changed from: protected */
    public void onBackClick() {
        ScreenUtil.getInstance().hideKeyboard(getActivity());
        getActivity().onBackPressed();
    }
}
