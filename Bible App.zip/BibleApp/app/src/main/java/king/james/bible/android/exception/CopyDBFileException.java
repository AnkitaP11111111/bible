package king.james.bible.android.exception;

public class CopyDBFileException extends Exception {
}
