package king.james.bible.android.activity;

import king.james.bible.android.view.holder.PagesSwipeHintHolder;

/* renamed from: king.james.bible.android.activity.-$$Lambda$MainFragmentActivity$aM7FOr4-_7t8fcqsDrhO160v8Ow  reason: invalid class name */
/* compiled from: lambda */
public final /* synthetic */ class $$Lambda$MainFragmentActivity$aM7FOr4_7t8fcqsDrhO160v8Ow implements PagesSwipeHintHolder.HideHintListener {
    public static final /* synthetic */ $$Lambda$MainFragmentActivity$aM7FOr4_7t8fcqsDrhO160v8Ow INSTANCE = new $$Lambda$MainFragmentActivity$aM7FOr4_7t8fcqsDrhO160v8Ow();

    private /* synthetic */ $$Lambda$MainFragmentActivity$aM7FOr4_7t8fcqsDrhO160v8Ow() {
    }

    @Override // king.james.bible.android.view.holder.PagesSwipeHintHolder.HideHintListener
    public final void onHide() {
        MainFragmentActivity.lambda$showScrollHint$0();
    }
}
