package king.james.bible.android.service.notifications.work;

import android.app.AlarmManager;
import android.app.PendingIntent;

/* access modifiers changed from: package-private */
public abstract class ISetAlarmStrategy {
    /* access modifiers changed from: package-private */
    public abstract void setRTCAlarm(AlarmManager alarmManager, long j, PendingIntent pendingIntent);

    ISetAlarmStrategy() {
    }

    /* access modifiers changed from: package-private */
    public void setInexactAlarm(AlarmManager alarmManager, long j, PendingIntent pendingIntent) {
        setRTCAlarm(alarmManager, j, pendingIntent);
    }
}
