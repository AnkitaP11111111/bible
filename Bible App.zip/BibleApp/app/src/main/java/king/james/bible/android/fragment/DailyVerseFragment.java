package king.james.bible.android.fragment;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import king.james.bible.android.R;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import king.james.bible.android.activity.base.NavigationActivity;
import king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter;
import king.james.bible.android.adapter.recycler.DailyVerseRecyclerViewAdapter;
import king.james.bible.android.db.BibleDataBase;
import king.james.bible.android.db.service.DailyVerseDataService;
import king.james.bible.android.dialog.DeleteDialog;
import king.james.bible.android.dialog.DialogUtil;
import king.james.bible.android.model.DailyVerse;
import king.james.bible.android.model.DailyVerseAction;
import king.james.bible.android.model.chapter.ChapterSubChapterCursorResult;
import king.james.bible.android.model.comparator.DailyVerseComparator;
import king.james.bible.android.service.DailyVerseService;
import king.james.bible.android.service.notifications.NotificationDataService;
import king.james.bible.android.service.notifications.NotificationMode;
import king.james.bible.android.service.notifications.NotificationsReadingForegroundUtil;
import king.james.bible.android.service.observable.DeleteListenerObservable;
import king.james.bible.android.service.observable.FragmentCallbackObservable;
import king.james.bible.android.utils.BiblePreferences;
import king.james.bible.android.utils.BibleToast;

public class DailyVerseFragment extends BaseDailyFragment implements View.OnClickListener, BaseRecyclerViewAdapter.OnItemClickListener, DailyVerseRecyclerViewAdapter.DailyVerseActionListener, DeleteDialog.DeleteListener {
    private  int r3;
    private  ChapterSubChapterCursorResult r22;
    private  int r2;
    private DailyVerseRecyclerViewAdapter adapter;
    private BibleDataBase bibleDataBase;
    private RecyclerView dailyVerseRecyclerView;
    private DailyVerseDataService dailyVerseService;
    private List<DailyVerse> dailyVerses;

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.fragment.BaseDailyFragment
    public int getViewResId() {
        return R.layout.fragment_daily_verse;
    }

    @Override // king.james.bible.android.dialog.DeleteDialog.DeleteListener
    public void selectNo() {
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.fragment.BaseDailyFragment
    public void mapViews(View view) {
        setToolbarTitle(R.string.daily_verses);
        view.findViewById(R.id.addDailyVerseImageView).setOnClickListener(this);
        RecyclerView recyclerView = (RecyclerView) view.findViewById(R.id.dailyVerseRecyclerView);
        this.dailyVerseRecyclerView = recyclerView;
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), 1, false));
        this.dailyVerseRecyclerView.addItemDecoration(new BaseRecyclerViewAdapter.ActionBottomSpaceDecoration(getResources().getDimensionPixelSize(R.dimen.buttonactionsize) + getResources().getDimensionPixelSize(R.dimen.indent_xlarge)));
        view.findViewById(R.id.rootRelativeLayout).setBackgroundResource(BiblePreferences.getInstance().isNightMode() ? R.color.daily_versebackground_n : R.color.daily_versebackground);
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.fragment.BaseDailyFragment
    public void initActions() {
        this.dailyVerseService = new DailyVerseDataService();
        this.bibleDataBase = BibleDataBase.getInstance();
        NotificationsReadingForegroundUtil.cancelNotifications(getActivity(), NotificationMode.VERSE);
    }

    @Override // androidx.fragment.app.Fragment
    public void onStart() {
        super.onStart();
        DeleteListenerObservable.getInstance().subscribe(this);
    }

    @Override // androidx.fragment.app.Fragment
    public void onResume() {
        super.onResume();
        initLoadData();
    }

    @Override // androidx.fragment.app.Fragment
    public void onStop() {
        DeleteListenerObservable.getInstance().remove(this);
        super.onStop();
    }

    private void initLoadData() {
        showProgress();
        new Thread(new Runnable() {
            /* class king.james.bible.android.fragment.DailyVerseFragment.AnonymousClass1 */

            public void run() {
                DailyVerseFragment dailyVerseFragment = DailyVerseFragment.this;
                dailyVerseFragment.dailyVerses = dailyVerseFragment.getModels();
                Collections.sort(DailyVerseFragment.this.dailyVerses, new DailyVerseComparator());
                if (DailyVerseFragment.this.getActivity() != null) {
                    DailyVerseFragment dailyVerseFragment2 = DailyVerseFragment.this;
                    List list = dailyVerseFragment2.dailyVerses;
                    DailyVerseFragment dailyVerseFragment3 = DailyVerseFragment.this;
                    dailyVerseFragment2.adapter = new DailyVerseRecyclerViewAdapter(list, dailyVerseFragment3, dailyVerseFragment3);
                    if (DailyVerseFragment.this.getActivity() != null) {
                        DailyVerseFragment.this.getActivity().runOnUiThread(new Runnable() {
                            /* class king.james.bible.android.fragment.DailyVerseFragment.AnonymousClass1.AnonymousClass1 */

                            public void run() {
                                if (DailyVerseFragment.this.getActivity() != null) {
                                    DailyVerseFragment.this.initRecycler();
                                }
                            }
                        });
                    }
                }
            }
        }).start();
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void initRecycler() {
        this.dailyVerseRecyclerView.setAdapter(this.adapter);
        int dailyVersePosition = DailyVerseService.getInstance().getDailyVersePosition();
        if (getArguments() != null) {
            long j = getArguments().getLong("paramId", 0);
            if (j > 0) {
                dailyVersePosition = getVersePosition(Long.valueOf(j));
            }
        }
        this.dailyVerseRecyclerView.scrollToPosition(dailyVersePosition);
        DailyVerseService.getInstance().clearDailyVerseBackStack();
        hideProgress();
    }

    @Override // king.james.bible.android.fragment.BaseDailyFragment
    public void onClick(View view) {
        super.onClick(view);
        if (view.getId() == R.id.addDailyVerseImageView) {
            onAddClick();
        }
    }

    private void onAddClick() {
        if (getActivity() instanceof NavigationActivity) {
            ((NavigationActivity) getActivity()).openFragment(new EditDailyVerseFragment(), (Bundle) null);
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private List<DailyVerse> getModels() {
        return this.dailyVerseService.getDailyVerses();
    }

    @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter.OnItemClickListener
    public void onClick(int i) {
        if (i >= 0 && i < this.dailyVerses.size()) {
            new Thread(new Runnable() {
                /* class king.james.bible.android.fragment.$$Lambda$DailyVerseFragment$bFND6Rg1lG0P93EVCDLj7UXHs4E */
                private final /* synthetic */ int f$1;

                {
                    this.f$1 = r2;
                }

                public final void run() {
                    try {
                        DailyVerseFragment.this.lambda$onClick$0$DailyVerseFragment(this.f$1);
                    } catch (Throwable e) {
                        throw new RuntimeException(e);
                    }
                }
            }).start();
        }
    }

    public /* synthetic */ void lambda$onClick$0$DailyVerseFragment(int i) throws Throwable {
        DailyVerseService.getInstance().setDailyVersePosition(i);
        DailyVerseService.getInstance().setDailyVerseBackStack(true);
        ChapterSubChapterCursorResult allStuffById = this.bibleDataBase.getAllStuffById(this.dailyVerses.get(i).getVerseId());
        if (allStuffById != null) {
            moveToReadingScreen(allStuffById, this.bibleDataBase.getRankByChapter(allStuffById.getChapter(), allStuffById.getSubChapter() + 1, allStuffById.getPosition()));
        }
    }

    private void moveToReadingScreen(ChapterSubChapterCursorResult chapterSubChapterCursorResult, int i) {
        if (getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() {
                /* class king.james.bible.android.fragment.$$Lambda$DailyVerseFragment$s5DNVwr7LgT_fW3Fa7Clmt7zo3w */
                private final /* synthetic */ ChapterSubChapterCursorResult f$1;
                private final /* synthetic */ int f$2;

                {
                    this.f$1 = r22;
                    this.f$2 = r3;
                }

                public final void run() {
                    DailyVerseFragment.this.lambda$moveToReadingScreen$1$DailyVerseFragment(this.f$1, this.f$2);
                }
            });
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: moveToReadingScreenUI */
    public void lambda$moveToReadingScreen$1$DailyVerseFragment(ChapterSubChapterCursorResult chapterSubChapterCursorResult, int i) {
        if (getActivity() != null) {
            getActivity().onBackPressed();
            FragmentCallbackObservable.getInstance().onFragmentResultOk(chapterSubChapterCursorResult.getChapter(), chapterSubChapterCursorResult.getSubChapter(), chapterSubChapterCursorResult.getPosition() - 1, i, this);
        }
    }

    /* renamed from: king.james.bible.android.fragment.DailyVerseFragment$2  reason: invalid class name */
    static /* synthetic */ class AnonymousClass2 {
        static final /* synthetic */ int[] $SwitchMap$king$james$bible$android$model$DailyVerseAction;

        /* JADX WARNING: Can't wrap try/catch for region: R(12:0|1|2|3|4|5|6|7|8|9|10|12) */
        /* JADX WARNING: Code restructure failed: missing block: B:13:?, code lost:
            return;
         */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x001d */
        /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x0028 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:9:0x0033 */
        static {
            int[] iArr = new int[DailyVerseAction.values().length];
            $SwitchMap$king$james$bible$android$model$DailyVerseAction = iArr;
            iArr[DailyVerseAction.SHARE.ordinal()] = 1;
            $SwitchMap$king$james$bible$android$model$DailyVerseAction[DailyVerseAction.COPY.ordinal()] = 2;
            $SwitchMap$king$james$bible$android$model$DailyVerseAction[DailyVerseAction.EDIT.ordinal()] = 3;
            $SwitchMap$king$james$bible$android$model$DailyVerseAction[DailyVerseAction.UPDATE.ordinal()] = 4;
            $SwitchMap$king$james$bible$android$model$DailyVerseAction[DailyVerseAction.DELETE.ordinal()] = 5;
        }
    }

    @Override // king.james.bible.android.adapter.recycler.DailyVerseRecyclerViewAdapter.DailyVerseActionListener
    public void onDailyVerseAction(DailyVerse dailyVerse, DailyVerseAction dailyVerseAction, int i) {
        int i2 = AnonymousClass2.$SwitchMap$king$james$bible$android$model$DailyVerseAction[dailyVerseAction.ordinal()];
        if (i2 == 1) {
            shareString(dailyVerse);
        } else if (i2 == 2) {
            copyString(dailyVerse);
        } else if (i2 == 3) {
            onEditClick(dailyVerse);
        } else if (i2 == 4) {
            onUpdateClick(dailyVerse.getId(), dailyVerse.getChapters(), dailyVerse.getTitle(), i);
        } else if (i2 == 5) {
            onDeleteItem(dailyVerse, i);
        }
    }

    private void shareString(DailyVerse dailyVerse) {
        if (getActivity() != null) {
            try {
                Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("text/plain");
                intent.putExtra("android.intent.extra.TEXT", getResources().getString(R.string.app_name) + getString(R.string.space) + dailyVerse.getChapter() + "\n" + Html.fromHtml(dailyVerse.getText()).toString());
                startActivity(Intent.createChooser(intent, getResources().getString(R.string.share_text)));
            } catch (Exception unused) {
            }
        }
    }

    private void copyString(DailyVerse dailyVerse) {
        if (getActivity() != null) {
            ((ClipboardManager) getActivity().getSystemService("clipboard")).setPrimaryClip(ClipData.newPlainText("text", dailyVerse.getChapter() + "\n" + Html.fromHtml(dailyVerse.getText()).toString()));
            BibleToast.showLongDurationToast(getActivity(), (int) R.string.copied);
        }
    }

    private void onDeleteItem(DailyVerse dailyVerse, int i) {
        DialogUtil.showDeleteDialog(getActivity().getSupportFragmentManager(), dailyVerse.getId(), R.string.daily_versedelete_text, i);
    }

    private void onEditClick(DailyVerse dailyVerse) {
        EditDailyVerseFragment editDailyVerseFragment = new EditDailyVerseFragment();
        Bundle bundle = new Bundle();
        bundle.putSerializable("DailyVerse", dailyVerse);
        if (getActivity() instanceof NavigationActivity) {
            ((NavigationActivity) getActivity()).openFragment(editDailyVerseFragment, bundle);
        }
    }

    private void onUpdateClick(long j, Set<Long> set, String str, int i) {
        long j2;
        boolean z;
        boolean z2;
        if (j >= 1) {
            DailyVerse dailyVersesById = getDailyVersesById(j);
            if (dailyVersesById != null) {
                boolean isNotify = dailyVersesById.isNotify();
                long notifyTime = dailyVersesById.getNotifyTime();
                z2 = dailyVersesById.isUserCreate();
                z = isNotify;
                j2 = notifyTime;
            } else {
                j2 = 0;
                z2 = false;
                z = false;
            }
            DailyVerse updateDailyVerse = this.dailyVerseService.updateDailyVerse(j, set, str, z2, z, j2);
            if (updateDailyVerse != null) {
                this.dailyVerses.set(i, updateDailyVerse);
            }
            this.adapter.notifyItemChanged(i);
        }
    }

    @Override // king.james.bible.android.dialog.DeleteDialog.DeleteListener
    public void selectYes(long j, int i) {
        if (i >= 0 && i < this.dailyVerses.size()) {
            this.dailyVerseService.delete(j);
            NotificationDataService.getInstance().removeVerse(j, getActivity());
            this.dailyVerses.remove(i);
            this.adapter.notifyItemRemoved(i);
        }
    }

    private DailyVerse getDailyVersesById(long j) {
        for (DailyVerse dailyVerse : this.dailyVerses) {
            if (j == dailyVerse.getId()) {
                return dailyVerse;
            }
        }
        return null;
    }

    private int getVersePosition(Long l) {
        for (int i = 0; i < this.dailyVerses.size(); i++) {
            if (l.longValue() == this.dailyVerses.get(i).getId()) {
                return i;
            }
        }
        return -1;
    }

    @Override // king.james.bible.android.fragment.BaseFragment
    public void onResumeFromBackStack() {
        initLoadData();
    }
}
