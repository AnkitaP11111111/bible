package king.james.bible.android.utils;

import android.text.Html;
import com.karumi.dexter.BuildConfig;
import java.util.List;
import java.util.TreeSet;
import king.james.bible.android.db.BibleDataBase;
import king.james.bible.android.model.ShareDBModel;

public class ShareTextUtil {
    public static String prepareText(TreeSet<Integer> treeSet, int i, int i2) {
        return prepareText(treeSet, i, i2, true);
    }

    public static String prepareText(TreeSet<Integer> treeSet, int i, int i2, boolean z) {
        try {
            Integer[] numArr = (Integer[]) treeSet.toArray(new Integer[]{0});
            int[] iArr = new int[numArr.length];
            for (int i3 = 0; i3 < numArr.length; i3++) {
                iArr[i3] = numArr[i3].intValue();
            }
            return prepareText(BibleDataBase.getInstance().getShareDBModel(i, i2, iArr), i, i2, z);
        } catch (Exception unused) {
            return BuildConfig.FLAVOR;
        }
    }

    public static String prepareText(List<ShareDBModel> list, int i, int i2, boolean z) {
        BibleDataBase instance = BibleDataBase.getInstance();
        StringBuilder sb = new StringBuilder();
        boolean isEmpty = list.isEmpty();
        String str = BuildConfig.FLAVOR;
        sb.append(!isEmpty ? str + getPosition(list, 0) : str);
        boolean z2 = false;
        for (int i3 = 1; i3 < list.size(); i3++) {
            int i4 = i3 - 1;
            if (list.get(i4).getPosition() + 1 != list.get(i3).getPosition()) {
                if (z2) {
                    sb.append("-");
                    sb.append(getPosition(list, i4));
                    sb.append(",");
                    sb.append(getPosition(list, i3));
                    z2 = false;
                } else {
                    sb.append(",");
                    sb.append(getPosition(list, i3));
                }
            } else if (i3 + 1 == list.size()) {
                sb.append("-");
                sb.append(getPosition(list, i3));
            } else {
                z2 = true;
            }
        }
        StringBuilder sb2 = new StringBuilder();
        sb2.append(instance.getChapterNameById((long) i));
        sb2.append(" ");
        sb2.append(i2);
        if (!list.isEmpty()) {
            str = ":" + sb.toString();
        }
        sb2.append(str);
        if (!z) {
            return sb2.toString();
        }
        for (ShareDBModel shareDBModel : list) {
            sb2.append("\n[");
            sb2.append(shareDBModel.getPosition());
            sb2.append("]");
            sb2.append((CharSequence) Html.fromHtml(shareDBModel.getText()));
        }
        return sb2.toString();
    }

    private static String getPosition(List<ShareDBModel> list, int i) {
        return Integer.toString(list.get(i).getPosition());
    }
}
