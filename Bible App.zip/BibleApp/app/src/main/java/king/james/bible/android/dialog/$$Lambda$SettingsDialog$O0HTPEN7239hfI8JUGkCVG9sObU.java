package king.james.bible.android.dialog;

import android.content.DialogInterface;

/* renamed from: king.james.bible.android.dialog.-$$Lambda$SettingsDialog$O0HTPEN7239hfI8JUGkCVG9sObU  reason: invalid class name */
/* compiled from: lambda */
public final /* synthetic */ class $$Lambda$SettingsDialog$O0HTPEN7239hfI8JUGkCVG9sObU implements DialogInterface.OnClickListener {
    public static final /* synthetic */ $$Lambda$SettingsDialog$O0HTPEN7239hfI8JUGkCVG9sObU INSTANCE = new $$Lambda$SettingsDialog$O0HTPEN7239hfI8JUGkCVG9sObU();

    private /* synthetic */ $$Lambda$SettingsDialog$O0HTPEN7239hfI8JUGkCVG9sObU() {
    }

    public final void onClick(DialogInterface dialogInterface, int i) {
        dialogInterface.cancel();
    }
}
