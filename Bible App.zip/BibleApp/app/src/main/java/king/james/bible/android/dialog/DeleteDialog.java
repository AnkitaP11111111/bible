package king.james.bible.android.dialog;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import king.james.bible.android.R;
import king.james.bible.android.service.PowerManagerService;
import king.james.bible.android.service.observable.DeleteListenerObservable;
import king.james.bible.android.utils.BiblePreferences;

public class DeleteDialog extends BaseForegroundDialog implements View.OnClickListener {
    private long modelId;
    private int position;
    private int textResId;
    private TextView textTextView;

    public interface DeleteListener {
        void selectNo();

        void selectYes(long j, int i);
    }

    @Override // androidx.fragment.app.DialogFragment
    public Dialog onCreateDialog(Bundle bundle) {
        if (bundle != null) {
            this.modelId = bundle.getLong("modelId", -1);
            this.position = bundle.getInt("position", -1);
            this.textResId = bundle.getInt("textResId", -1);
        }
        Dialog onCreateDialog = super.onCreateDialog(bundle);
        onCreateDialog.getWindow().requestFeature(1);
        return onCreateDialog;
    }

    @Override // androidx.fragment.app.Fragment, androidx.fragment.app.DialogFragment
    public void onSaveInstanceState(Bundle bundle) {
        if (bundle == null) {
            bundle = new Bundle();
        }
        bundle.putLong("modelId", this.modelId);
        bundle.putInt("position", this.position);
        bundle.putInt("textResId", this.textResId);
        super.onSaveInstanceState(bundle);
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.BaseDialogFragment
    public int getLayoutResourceId() {
        return BiblePreferences.getInstance().isNightMode() ? R.layout.delete_dialog_n : R.layout.delete_dialog;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.BaseDialogFragment
    public void mapViews(View view) {
        view.findViewById(R.id.yesButton).setOnClickListener(this);
        view.findViewById(R.id.noButton).setOnClickListener(this);
        this.textTextView = (TextView) view.findViewById(R.id.textTextView);
        PowerManagerService.getInstance().start();
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.BaseDialogFragment
    public void initActions() {
        this.textTextView.setText(this.textResId);
    }

    public void setParameters(long j, int i, int i2) {
        this.modelId = j;
        this.position = i2;
        this.textResId = i;
    }

    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.noButton) {
            selectNo();
        } else if (id == R.id.yesButton) {
            selectYes();
        }
    }

    private void selectYes() {
        dismiss();
        DeleteListenerObservable.getInstance().selectYes(this.modelId, this.position);
    }

    private void selectNo() {
        dismiss();
        DeleteListenerObservable.getInstance().selectNo();
    }
}
