package king.james.bible.android.adapter.recycler.span;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.text.Html;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.UnderlineSpan;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.karumi.dexter.BuildConfig;
import king.james.bible.android.R;
import java.util.ArrayList;
import java.util.Map;
import king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter;
import king.james.bible.android.adapter.recycler.OnItemSpanClickListener;
import king.james.bible.android.adapter.recycler.span.HighlightsItemAdapter;
import king.james.bible.android.db.BibleDataBase;
import king.james.bible.android.model.SpanType;
import king.james.bible.android.model.span.SpanItem;
import king.james.bible.android.utils.AppUtils;
import king.james.bible.android.utils.BiblePreferences;
import king.james.bible.android.utils.SettingsTextUtil;
import king.james.bible.android.view.MarkerTextView;
@SuppressLint({"NewApi", "WrongConstant"})

public class HighlightsItemAdapter extends BaseRecyclerViewAdapter<HighlightsItemAdapter.HighlightsViewHolder> {
    private  HighlightsViewHolder r2;
    private int layoutResId;
    private float lineSpacing;
    private Map<Integer, String> mChapterNameMap;
    private Map<Integer, String> mChapterNameMapN;
    private ArrayList<SpanItem> models;
    private OnItemSpanClickListener onItemSpanClickListener;
    private int screenWidth;
    private String searchText;
    private int textSizeSp;
    private int widthRadio;

    public static HighlightsItemAdapter create(OnItemSpanClickListener onItemSpanClickListener2) {
        int i = BiblePreferences.getInstance().isNightMode() ? R.layout.highlights_item_layout_n : R.layout.highlights_item_layout;
        HighlightsItemAdapter highlightsItemAdapter = new HighlightsItemAdapter(null);
        highlightsItemAdapter.layoutResId = i;
        BibleDataBase instance = BibleDataBase.getInstance();
        instance.initColumSearchName();
        highlightsItemAdapter.mChapterNameMap = instance.getChapterNameMap();
        highlightsItemAdapter.mChapterNameMapN = instance.getChapterNameMapN();
        highlightsItemAdapter.onItemSpanClickListener = onItemSpanClickListener2;
        highlightsItemAdapter.models = new ArrayList<>();
        BiblePreferences instance2 = BiblePreferences.getInstance();
        instance2.lambda$restoreAsync$0$BiblePreferences();
        highlightsItemAdapter.textSizeSp = (int) instance2.getTextSize();
        highlightsItemAdapter.lineSpacing = instance2.getSpacing();
        return highlightsItemAdapter;
    }

    public void setSearchText(String str) {
        this.searchText = str;
    }

    public void initWidth(Activity activity) {
        if (activity != null) {
            DisplayMetrics displayMetrics = new DisplayMetrics();
            activity.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
            int i = displayMetrics.widthPixels;
            this.screenWidth = i;
            this.widthRadio = i / displayMetrics.heightPixels > 0 ? activity.getResources().getDimensionPixelOffset(R.dimen.highlights_bar_width) : 0;
        }
    }

    public void updateModels(ArrayList<SpanItem> arrayList) {
        this.models = arrayList;
        notifyDataSetChanged();
    }

    private HighlightsItemAdapter(OnItemClickListener onItemClickListener) {
        super(onItemClickListener);
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter
    public HighlightsViewHolder doCreateViewHolder(ViewGroup viewGroup, int i) {
        return new HighlightsViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(this.layoutResId, viewGroup, false));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter, king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter, king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter
    public HighlightsViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        HighlightsViewHolder highlightsViewHolder = (HighlightsViewHolder) super.onCreateViewHolder(viewGroup, i);
        highlightsViewHolder.itemView.setOnClickListener(new View.OnClickListener(highlightsViewHolder) {
            /* class king.james.bible.android.adapter.recycler.span.$$Lambda$HighlightsItemAdapter$m00n566raHm3WmzXwoNgoaE2zP0 */
            private final /* synthetic */ HighlightsViewHolder f$1;

            {
                this.f$1 = r2;
            }

            public final void onClick(View view) {
                HighlightsItemAdapter.this.lambda$onCreateViewHolder$0$HighlightsItemAdapter(this.f$1, view);
            }
        });
        highlightsViewHolder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            /* class king.james.bible.android.adapter.recycler.span.$$Lambda$HighlightsItemAdapter$NJfx69OToOFPUBG6Kklh0AQj54 */
            private final /* synthetic */ HighlightsViewHolder f$1;

            {
                this.f$1 = r2;
            }

            public final boolean onLongClick(View view) {
                return HighlightsItemAdapter.this.lambda$onCreateViewHolder$1$HighlightsItemAdapter(this.f$1, view);
            }
        });
        return highlightsViewHolder;
    }

    public /* synthetic */ void lambda$onCreateViewHolder$0$HighlightsItemAdapter(HighlightsViewHolder highlightsViewHolder, View view) {
        OnItemSpanClickListener onItemSpanClickListener2 = this.onItemSpanClickListener;
        if (onItemSpanClickListener2 != null) {
            onItemSpanClickListener2.onClick(highlightsViewHolder.getAdapterPosition(), highlightsViewHolder.itemView, false);
        }
    }

    public /* synthetic */ boolean lambda$onCreateViewHolder$1$HighlightsItemAdapter(HighlightsViewHolder highlightsViewHolder, View view) {
        OnItemSpanClickListener onItemSpanClickListener2 = this.onItemSpanClickListener;
        if (onItemSpanClickListener2 == null) {
            return false;
        }
        onItemSpanClickListener2.onClick(highlightsViewHolder.getAdapterPosition(), highlightsViewHolder.itemView, true);
        return false;
    }

    @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter
    public SpanItem getModel(int i) {
        return this.models.get(i);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.models.size();
    }

    public class HighlightsViewHolder extends BaseViewHolder {
        private LinearLayout delLayout;
        private MarkerTextView text1TextView;
        private TextView timeTextView;
        private TextView titleTextView;

        HighlightsViewHolder(View view) {
            super(view);
        }

        /* access modifiers changed from: protected */
        @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter.BaseViewHolder
        public void mapViews(View view) {
            this.text1TextView = (MarkerTextView) view.findViewById(R.id.highlight_item_text);
            this.titleTextView = (TextView) view.findViewById(R.id.highlight_item_title);
            this.timeTextView = (TextView) view.findViewById(R.id.highlight_item_time);
            RelativeLayout relativeLayout = (RelativeLayout) view.findViewById(R.id.highlight_item_layout);
            relativeLayout.measure(0, 0);
            SettingsTextUtil.setupTextViewSettings(this.text1TextView);
            SettingsTextUtil.setupTextViewSettings(this.titleTextView);
            SettingsTextUtil.setupTextViewSettings(this.timeTextView);
            SettingsTextUtil.prepareTimeTextView(this.timeTextView);
            SettingsTextUtil.prepareTitleTextView(this.titleTextView);
            LinearLayout linearLayout = (LinearLayout) view.findViewById(R.id.highlight_item_del_layout);
            this.delLayout = linearLayout;
            linearLayout.getLayoutParams().height = relativeLayout.getMeasuredHeight();
        }

        @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter.BaseViewHolder
        public void updateView(Object obj) {
            String str;
            if (obj != null) {
                SpanItem spanItem = (SpanItem) obj;
                this.delLayout.setVisibility(8);
                SpanType spanType = SpanType.getSpanType(spanItem.colorSpanType);
                SpannableString spannableString = new SpannableString(Html.fromHtml(SettingsTextUtil.prepareText(spanItem.text)));
                int i = (int) (((float) 64) / (((float) HighlightsItemAdapter.this.textSizeSp) * HighlightsItemAdapter.this.lineSpacing));
                if (i == 0) {
                    i = 1;
                }
                float measureText = this.text1TextView.getPaint().measureText(spannableString, 0, 0);
                this.text1TextView.setupTransparent(i);
                if (spanType.isUnderline()) {
                    spannableString.setSpan(new UnderlineSpan(), 0, spannableString.length(), 18);
                } else if (spanType.isColor()) {
                    this.text1TextView.setup(spanType, measureText, i);
                }
                boolean containsKey = HighlightsItemAdapter.this.mChapterNameMap.containsKey(Integer.valueOf(spanItem.chapterId));
                String str2 = BuildConfig.FLAVOR;
                if (containsKey) {
                    str2 = (String) HighlightsItemAdapter.this.mChapterNameMap.get(Integer.valueOf(spanItem.chapterId));
                    str = (String) HighlightsItemAdapter.this.mChapterNameMapN.get(Integer.valueOf(spanItem.chapterId));
                } else {
                    str = str2;
                }
                String str3 = str2 + " " + spanItem.chapterNum + ":" + spanItem.columnPosition;
                String str4 = str + " " + spanItem.chapterNum + ":" + spanItem.columnPosition;
                if (!TextUtils.isEmpty(HighlightsItemAdapter.this.searchText)) {
                    this.titleTextView.setText(Html.fromHtml(AppUtils.replaceOnBoldSearch(str3, str4, HighlightsItemAdapter.this.searchText, "<b>" + HighlightsItemAdapter.this.searchText + "</b>")));
                } else {
                    this.titleTextView.setText(str3);
                }
                if (!spanItem.date.isEmpty()) {
                    this.timeTextView.setText(spanItem.date);
                    this.timeTextView.setVisibility(0);
                } else {
                    this.timeTextView.setVisibility(4);
                }
                this.text1TextView.setText(spannableString);
                this.text1TextView.setTag(Long.valueOf(spanItem.id));
                this.titleTextView.measure(0, 0);
                this.timeTextView.measure(0, 0);
                if ((HighlightsItemAdapter.this.screenWidth - (this.itemView.getContext().getResources().getDimensionPixelSize(R.dimen.padding_element_nhb) * 2)) - HighlightsItemAdapter.this.widthRadio <= this.titleTextView.getMeasuredWidth() + this.timeTextView.getMeasuredWidth()) {
                    RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) this.titleTextView.getLayoutParams();
                    layoutParams.addRule(10, 0);
                    layoutParams.addRule(3, R.id.highlight_item_time);
                    layoutParams.addRule(9, -1);
                    this.titleTextView.setLayoutParams(layoutParams);
                    return;
                }
                RelativeLayout.LayoutParams layoutParams2 = (RelativeLayout.LayoutParams) this.titleTextView.getLayoutParams();
                layoutParams2.addRule(3, 0);
                layoutParams2.addRule(10, -1);
                layoutParams2.addRule(9, -1);
                this.titleTextView.setLayoutParams(layoutParams2);
            }
        }
    }
}
