package king.james.bible.android.db.listener;

public interface ChangeBookmarkListener {
    void changeBookmark(long j);

    void onChangeComplete();
}
