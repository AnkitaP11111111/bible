package king.james.bible.android.model.chapter;

public class ChapterSubChapterPosition {
    private int chapter;
    private int position;
    private int subChapter;

    public ChapterSubChapterPosition(int i, int i2, int i3) {
        this.chapter = i;
        this.subChapter = i2;
        this.position = i3;
    }

    public int getPosition() {
        return this.position;
    }

    public int getChapter() {
        return this.chapter;
    }

    public int getSubChapter() {
        return this.subChapter;
    }
}
