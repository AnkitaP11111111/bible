package king.james.bible.android.model.span;

public class SpanItem {
    public int chapterId;
    public int chapterNum;
    public int colorSpanType;
    public int columnPosition;
    public String date;
    public long id;
    public String text;
}
