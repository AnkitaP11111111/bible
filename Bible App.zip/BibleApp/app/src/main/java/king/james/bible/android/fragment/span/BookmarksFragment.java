package king.james.bible.android.fragment.span;

import android.annotation.SuppressLint;
import android.os.Handler;
import android.view.View;
import android.widget.LinearLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import king.james.bible.android.R;
import java.util.ArrayList;
import king.james.bible.android.adapter.recycler.OnItemSpanClickListener;
import king.james.bible.android.adapter.recycler.span.BookmarksItemAdapter;
import king.james.bible.android.db.BibleDataBase;
import king.james.bible.android.db.listener.ChangeBookmarkListener;
import king.james.bible.android.dialog.DialogUtil;
import king.james.bible.android.model.span.SpanItem;
import king.james.bible.android.service.PowerManagerService;
@SuppressLint({"NewApi", "WrongConstant"})

public class BookmarksFragment extends BaseSpanFragment implements OnItemSpanClickListener {
    private  ArrayList r2;
    private BookmarksItemAdapter adapter;
    private LinearLayout noEntries;

    @Override // king.james.bible.android.fragment.span.BaseSpanFragment
    public int getRootViewId() {
        return this.preferences.isNightMode() ? R.layout.activity_bookmarks_n : R.layout.activity_bookmarks;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.fragment.span.BaseSpanFragment
    public void mapViews(View view) {
        this.noEntries = (LinearLayout) view.findViewById(R.id.no_entries_bookmarks);
        RecyclerView recyclerView = (RecyclerView) view.findViewById(R.id.lv_bookmarks_result);
        this.adapter = BookmarksItemAdapter.create(this);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), 1, false));
        recyclerView.setAdapter(this.adapter);
        new Handler().postDelayed(new Runnable() {
            /* class king.james.bible.android.fragment.span.$$Lambda$BookmarksFragment$KVB9iloWkM9jymh7tPS5LIrRhQs */

            public final void run() {
                BookmarksFragment.this.lambda$mapViews$1$BookmarksFragment();
            }
        }, 200);
    }

    public /* synthetic */ void lambda$mapViews$1$BookmarksFragment() {
        new Thread(new Runnable() {
            /* class king.james.bible.android.fragment.span.$$Lambda$BookmarksFragment$PLpTvSZ87juJVGgzgpp714rPJY */

            public final void run() {
                BookmarksFragment.this.lambda$null$0$BookmarksFragment();
            }
        }).start();
    }

    public /* synthetic */ void lambda$null$0$BookmarksFragment() {
        try {
            loadModels();
        } catch (Exception unused) {
            DialogUtil.hideProgressDialog();
        }
    }

    private void onLoadFinished(ArrayList<SpanItem> arrayList) {
        if (getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() {
                /* class king.james.bible.android.fragment.span.$$Lambda$BookmarksFragment$tGPlVMTvUsPObU46QHSb9Bhlrc */
                private final /* synthetic */ ArrayList f$1;

                {
                    this.f$1 = r2;
                }

                public final void run() {
                    BookmarksFragment.this.lambda$onLoadFinished$2$BookmarksFragment(this.f$1);
                }
            });
        }
    }

    public /* synthetic */ void lambda$onLoadFinished$2$BookmarksFragment(ArrayList arrayList) {
        if (!getActivity().isFinishing()) {
            PowerManagerService.getInstance().start();
            try {
                if (arrayList.isEmpty()) {
                    this.noEntries.setVisibility(0);
                    this.adapter.updateModels(arrayList);
                    DialogUtil.hideProgressDialog();
                    return;
                }
                this.noEntries.setVisibility(4);
                this.adapter.setSearchText(this.searchText);
                this.adapter.updateModels(arrayList);
                DialogUtil.hideProgressDialog();
            } catch (Exception unused) {
            }
        }
    }

    private void loadModels() {
        DialogUtil.showProgressDialog();
        new Thread(new Runnable() {
            /* class king.james.bible.android.fragment.span.$$Lambda$BookmarksFragment$79183quSUDhvtZqq5wKoX1EkLwI */

            public final void run() {
                BookmarksFragment.this.lambda$loadModels$3$BookmarksFragment();
            }
        }).start();
    }

    public /* synthetic */ void lambda$loadModels$3$BookmarksFragment() {
        onLoadFinished(BibleDataBase.getInstance().getBookmarksCursor(this.searchText));
    }

    @Override // king.james.bible.android.fragment.span.BaseSpanFragment
    public void makeSearch() {
        loadModels();
    }

    /* access modifiers changed from: protected */
//    @Override // king.james.bible.android.fragment.span.BaseSpanFragment
//    public void removeItem(long j) {
//        this.bibleDB.changeBookmark(j, new ChangeBookmarkListener() {
//            /* class king.james.bible.android.fragment.span.BookmarksFragment.AnonymousClass1 */
//
//            @Override // king.james.bible.android.db.listener.ChangeBookmarkListener
//            public void changeBookmark(long j) {
//            }
//
//            @Override // king.james.bible.android.db.listener.ChangeBookmarkListener
//            public void onChangeComplete() {
//                BookmarksFragment.this.makeSearch();
//                BookmarksFragment.this.postDelete();
//            }
//        });
//    }

    @Override // king.james.bible.android.fragment.span.BaseSpanFragment
    public void notifyDataSetChanged() {
        BookmarksItemAdapter bookmarksItemAdapter = this.adapter;
        if (bookmarksItemAdapter != null) {
            bookmarksItemAdapter.notifyDataSetChanged();
        }
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.fragment.span.BaseSpanFragment
    public void updateWidth() {
        this.adapter.initWidth(getActivity());
    }

    @Override // king.james.bible.android.adapter.recycler.OnItemSpanClickListener
    public void onClick(int i, View view, boolean z) {
        if (!executeAction()) {
            return;
        }
        if (z) {
            showItemDeleteView(view);
        } else {
            moveToReadingScreen(view);
        }
    }
}
