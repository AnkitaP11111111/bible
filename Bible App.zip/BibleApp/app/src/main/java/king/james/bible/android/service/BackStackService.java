package king.james.bible.android.service;

import king.james.bible.android.utils.SearchCache;

public class BackStackService {

    /* access modifiers changed from: private */
    public static class SingletonHelper {
        private static final BackStackService INSTANCE = new BackStackService();
    }

    private BackStackService() {
    }

    public static BackStackService getInstance() {
        return SingletonHelper.INSTANCE;
    }

    public void clear() {
        SearchCache.getInstance().clearBackStack();
    }
}
