package king.james.bible.android.adapter.recycler;

import android.graphics.Rect;
import android.view.View;
import android.view.ViewGroup;
import androidx.recyclerview.widget.RecyclerView;
import king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter.BaseViewHolder;

public abstract class BaseRecyclerViewAdapter<H extends BaseViewHolder> extends RecyclerView.Adapter<H> {
    protected OnItemClickListener mOnItemClickListener;

    public interface OnItemClickListener {
        void onClick(int i);
    }

    /* access modifiers changed from: protected */
    public abstract H doCreateViewHolder(ViewGroup viewGroup, int i);

    public abstract Object getModel(int i);

    /* access modifiers changed from: protected */
    public OnItemClickListener getOnItemClickListener() {
        return null;
    }

    public BaseRecyclerViewAdapter(OnItemClickListener onItemClickListener) {
        this.mOnItemClickListener = onItemClickListener;
        if (onItemClickListener == null) {
            this.mOnItemClickListener = getOnItemClickListener();
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public H onCreateViewHolder(ViewGroup viewGroup, int i) {
        final H doCreateViewHolder = doCreateViewHolder(viewGroup, i);
        doCreateViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            /* class king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter.AnonymousClass1 */

            public void onClick(View view) {
                OnItemClickListener onItemClickListener = BaseRecyclerViewAdapter.this.mOnItemClickListener;
                if (onItemClickListener != null) {
                    onItemClickListener.onClick(doCreateViewHolder.getAdapterPosition());
                }
            }
        });
        return doCreateViewHolder;
    }

    public void onBindViewHolder(H h, int i) {
        h.updateView(getModel(i));
    }

    public static abstract class BaseViewHolder extends RecyclerView.ViewHolder {
        /* access modifiers changed from: protected */
        public abstract void mapViews(View view);

        public abstract void updateView(Object obj);

        public BaseViewHolder(View view) {
            super(view);
            mapViews(view);
        }
    }

    public static ActionBottomSpaceDecoration addBottomSpaceDecoration(RecyclerView recyclerView, int i) {
        ActionBottomSpaceDecoration actionBottomSpaceDecoration = new ActionBottomSpaceDecoration(i);
        recyclerView.addItemDecoration(actionBottomSpaceDecoration);
        return actionBottomSpaceDecoration;
    }

    public static class ActionBottomSpaceDecoration extends RecyclerView.ItemDecoration {
        protected int mBottomSpace;

        public ActionBottomSpaceDecoration(int i) {
            this.mBottomSpace = i;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.ItemDecoration
        public void getItemOffsets(Rect rect, View view, RecyclerView recyclerView, RecyclerView.State state) {
            super.getItemOffsets(rect, view, recyclerView, state);
            int childAdapterPosition = recyclerView.getChildAdapterPosition(view);
            if (childAdapterPosition != -1 && childAdapterPosition == state.getItemCount() - 1) {
                rect.bottom += this.mBottomSpace;
            }
        }
    }
}
