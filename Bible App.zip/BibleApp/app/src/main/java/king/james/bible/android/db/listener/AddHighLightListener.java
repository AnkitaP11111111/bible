package king.james.bible.android.db.listener;

import king.james.bible.android.model.SpanType;

public interface AddHighLightListener {
    void addToAdapter(int i, SpanType spanType);

    void onAddComplete();
}
