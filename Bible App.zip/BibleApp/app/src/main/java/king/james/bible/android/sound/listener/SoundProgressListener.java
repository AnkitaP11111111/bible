package king.james.bible.android.sound.listener;

public interface SoundProgressListener {
    void onDone(String str) throws Throwable;

    void onError(String str);

    void onStart(String str);
}
