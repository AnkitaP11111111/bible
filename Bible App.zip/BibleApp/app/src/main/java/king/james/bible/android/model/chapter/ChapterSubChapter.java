package king.james.bible.android.model.chapter;

public class ChapterSubChapter {
    private int chapter;
    private int subChapter;

    public ChapterSubChapter(int i, int i2) {
        this.chapter = i;
        this.subChapter = i2;
    }

    public int getChapter() {
        return this.chapter;
    }

    public int getSubChapter() {
        return this.subChapter;
    }
}
