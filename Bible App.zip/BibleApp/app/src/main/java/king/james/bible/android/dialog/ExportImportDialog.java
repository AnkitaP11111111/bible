package king.james.bible.android.dialog;

import android.app.Dialog;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;
import king.james.bible.android.R;
import java.io.File;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import king.james.bible.android.db.BibleDataBase;
import king.james.bible.android.dialog.FileChooser;
import king.james.bible.android.event.ClickOpenExportEvent;
import king.james.bible.android.model.UpdateRecord;
import king.james.bible.android.service.observable.ExportImportObservable;
import king.james.bible.android.task.ImportTask;
import king.james.bible.android.utils.AppUtils;
import king.james.bible.android.utils.BiblePreferences;
import king.james.bible.android.utils.BibleToast;
import king.james.bible.android.utils.ExportImportUtil;
import org.greenrobot.eventbus.EventBus;
import org.json.JSONArray;
import org.json.JSONObject;

public class ExportImportDialog extends BaseForegroundDialog implements View.OnClickListener, ImportFileListener {
    private Button btnShare;
    private File file;
    private CheckBox importCheckBox;
    private boolean isShowDate;
    private LinearLayout llFile;
    private FileChooser mChooser = null;
    private View progressShadow;
    private CheckBox settingCheckBox;
    private TextView txtFileName;
    private TextView txtFileSize;

    public interface ImportListener {
        void onErrorImport();

        void onSuccessImport();
    }

    public void setParameters(boolean z) {
        this.isShowDate = z;
    }

    @Override // androidx.fragment.app.DialogFragment
    public Dialog onCreateDialog(Bundle bundle) {
        String string;
        if (!(bundle == null || (string = bundle.getString("filePath")) == null || string.isEmpty())) {
            this.file = new File(string);
        }
        Dialog onCreateDialog = super.onCreateDialog(bundle);
        onCreateDialog.getWindow().requestFeature(1);
        return onCreateDialog;
    }

    @Override // androidx.fragment.app.Fragment, androidx.fragment.app.DialogFragment
    public void onSaveInstanceState(Bundle bundle) {
        File file2 = this.file;
        if (file2 != null) {
            bundle.putString("filePath", file2.getAbsolutePath());
        }
        super.onSaveInstanceState(bundle);
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.BaseDialogFragment
    public int getLayoutResourceId() {
        return BiblePreferences.getInstance().isNightMode() ? R.layout.export_import_dialog_n : R.layout.export_import_dialog;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.BaseDialogFragment
    public void mapViews(View view) {
        view.findViewById(R.id.btnImport).setOnClickListener(this);
        this.importCheckBox = (CheckBox) view.findViewById(R.id.importCheckBox);
        this.settingCheckBox = (CheckBox) view.findViewById(R.id.settingCheckBox);
        this.llFile = (LinearLayout) view.findViewById(R.id.llFile);
        this.txtFileName = (TextView) view.findViewById(R.id.txtFileName);
        this.txtFileSize = (TextView) view.findViewById(R.id.txtFileSize);
        this.progressShadow = view.findViewById(R.id.progressShadow);
        Button button = (Button) view.findViewById(R.id.btnShare);
        this.btnShare = button;
        button.setOnClickListener(this);
        view.findViewById(R.id.btnExport).setOnClickListener(this);
        view.findViewById(R.id.btnCancel).setOnClickListener(this);
        this.llFile.setVisibility(8);
        this.btnShare.setVisibility(8);
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.BaseDialogFragment
    public void initActions() {
        if (this.isShowDate) {
            File isFile = ExportImportUtil.getInstance().isFile();
            this.file = isFile;
            if (isFile != null) {
                TextView textView = this.txtFileName;
                textView.setText(Html.fromHtml("<u>" + this.file.getAbsolutePath() + "</u>"));
                this.txtFileSize.setText(readableFileSize(this.file.length()));
                this.llFile.setVisibility(0);
                this.btnShare.setVisibility(0);
            } else {
                this.llFile.setVisibility(8);
                this.btnShare.setVisibility(8);
            }
        } else {
            this.llFile.setVisibility(8);
            this.btnShare.setVisibility(8);
        }
        setCancelable(true);
        if (this.file != null) {
            updateFileView();
        }
    }

    private static String readableFileSize(long j) {
        if (j <= 0) {
            return "0";
        }
        double d = (double) j;
        int log10 = (int) (Math.log10(d) / Math.log10(1024.0d));
        StringBuilder sb = new StringBuilder();
        DecimalFormat decimalFormat = new DecimalFormat("#,##0.#");
        double pow = Math.pow(1024.0d, (double) log10);
        Double.isNaN(d);
        sb.append(decimalFormat.format(d / pow));
        sb.append(" ");
        sb.append(new String[]{"b", "Kb", "Mb", "Gb", "Tb"}[log10]);
        return sb.toString();
    }

    private void showShadow() {
        this.progressShadow.setVisibility(0);
        setCancelable(false);
    }

    private void hideShadow() {
        this.progressShadow.setVisibility(8);
        setCancelable(true);
    }

    public void onClick(View view) {
        int id = view.getId();
        if (id != R.id.txtFileName) {
            switch (id) {
                case R.id.btnCancel:
                    dismiss();
                    return;
                case R.id.btnExport:
                    exportData();
                    return;
                case R.id.btnImport:
                    importData();
                    return;
                case R.id.btnShare:
                    sendFeedback();
                    return;
                default:
                    return;
            }
        } else {
            EventBus.getDefault().post(new ClickOpenExportEvent());
        }
    }

    private void sendFeedback() {
        if (this.file != null) {
            AppUtils.shareFile(getContext(), this.file);
            return;
        }
        this.llFile.setVisibility(8);
        this.btnShare.setVisibility(8);
    }

    private void exportData() {
        List<UpdateRecord> updateRecords = BibleDataBase.getInstance().getUpdateRecords();
        ArrayList arrayList = new ArrayList();
        for (UpdateRecord updateRecord : updateRecords) {
            String str = "{'id':'" + updateRecord.getId() + "',";
            ArrayList arrayList2 = new ArrayList();
            if (updateRecord.getBookmark() != null) {
                arrayList2.add("'bookmark':'" + updateRecord.getBookmark() + "','" + "bookmarkDate" + "':'" + updateRecord.getBookmarkDate() + "'");
            }
            if (updateRecord.getHighlight() != null) {
                arrayList2.add("'highlight':'" + updateRecord.getHighlight() + "','" + "highlightDate" + "':'" + updateRecord.getHighlightDate() + "'");
            }
            if (updateRecord.getNote() != null) {
                arrayList2.add("'note':'" + updateRecord.getNote() + "','" + "noteDate" + "':'" + updateRecord.getNoteDate() + "'");
            }
            int size = arrayList2.size();
            if (size == 1) {
                str = str + ((String) arrayList2.get(0)) + "}";
            } else if (size == 2) {
                str = (str + ((String) arrayList2.get(0)) + ", ") + ((String) arrayList2.get(1)) + "}";
            } else if (size == 3) {
                str = ((str + ((String) arrayList2.get(0)) + ", ") + ((String) arrayList2.get(1)) + ", ") + ((String) arrayList2.get(2)) + "}";
            }
            try {
                arrayList.add(new JSONObject(str));
            } catch (Exception unused) {
            }
        }
        this.file = ExportImportUtil.getInstance().writeArray(new JSONArray((Collection) arrayList));
        updateFileView();
        BibleToast.showShortDurationToast(getContext(), R.string.setting_export_complete);
    }

    private void updateFileView() {
        File file2 = this.file;
        if (file2 != null) {
            this.txtFileName.setText(Html.fromHtml(file2.getAbsolutePath()));
            this.txtFileSize.setText(readableFileSize(this.file.length()));
            this.llFile.setVisibility(0);
            this.btnShare.setVisibility(0);
            return;
        }
        this.llFile.setVisibility(8);
        this.btnShare.setVisibility(8);
    }

    @Override // king.james.bible.android.dialog.ImportFileListener
    public void importData(File file2) {
        if (file2 != null) {
            boolean isChecked = this.importCheckBox.isChecked();
            boolean isChecked2 = this.settingCheckBox.isChecked();
            showShadow();
            new ImportTask(getContext(), file2, isChecked2, isChecked, new ImportTask.OnCallbackHandler() {
                /* class king.james.bible.android.dialog.ExportImportDialog.AnonymousClass1 */

                public void onSuccess(Boolean bool) {
                    if (bool == null || !bool.booleanValue()) {
                        ExportImportDialog.this.error();
                    } else {
                        ExportImportDialog.this.result();
                    }
                }

                @Override // king.james.bible.android.task.BaseTask.OnCallbackHandler
                public void onError(Exception exc) {
                    ExportImportDialog.this.error();
                }
            }).executeAsyncTask(new String[0]);
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void result() {
        hideDialog();
        ExportImportObservable.getInstance().onSuccessImport();
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void error() {
        hideDialog();
        ExportImportObservable.getInstance().onErrorImport();
    }

    private void hideDialog() {
        try {
            hideShadow();
            dismiss();
        } catch (Exception unused) {
        }
    }

    private void importData() {
        if (this.mChooser == null) {
            FileChooser fileChooser = new FileChooser(getActivity());
            fileChooser.setFileListener(new FileChooser.FileSelectedListener() {
                /* class king.james.bible.android.dialog.$$Lambda$ExportImportDialog$ziTgZWu_up3oIheB2550yJfJXGo */

                @Override // king.james.bible.android.dialog.FileChooser.FileSelectedListener
                public final void fileSelected(File file) {
                    ExportImportDialog.this.lambda$importData$0$ExportImportDialog(file);
                }
            });
            this.mChooser = fileChooser;
        }
        this.mChooser.showDialog();
    }

    public /* synthetic */ void lambda$importData$0$ExportImportDialog(File file2) {
        this.mChooser.closeDialog();
        importData(file2);
    }

    @Override // androidx.fragment.app.Fragment
    public void onResume() {
        super.onResume();
        ExportImportObservable.getInstance().subscribe(this);
    }

    @Override // androidx.fragment.app.Fragment
    public void onPause() {
        ExportImportObservable.getInstance().remove(this);
        super.onPause();
    }
}
