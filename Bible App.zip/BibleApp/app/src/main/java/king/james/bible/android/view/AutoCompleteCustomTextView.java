package king.james.bible.android.view;

import android.content.Context;
import android.content.res.Resources;
import android.util.AttributeSet;
import android.widget.AutoCompleteTextView;

public class AutoCompleteCustomTextView extends AutoCompleteTextView {
    public AutoCompleteCustomTextView(Context context) {
        super(context);
    }

    public AutoCompleteCustomTextView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public AutoCompleteCustomTextView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    public AutoCompleteCustomTextView(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
    }

    public AutoCompleteCustomTextView(Context context, AttributeSet attributeSet, int i, int i2, Resources.Theme theme) {
        super(context, attributeSet, i, i2, theme);
    }

    public void showDropDown() {
        try {
            super.showDropDown();
        } catch (Exception unused) {
        }
    }

    public void dismissDropDown() {
        try {
            super.dismissDropDown();
        } catch (Exception unused) {
        }
    }
}
