//package king.james.bible.android.ad;
//
//public enum AdMode {
//    MODE1,
//    MODE2,
//    MODE3,
//    MODE4;
//
//    public static AdMode getMode(int i) {
//        try {
//            return values()[i];
//        } catch (Exception unused) {
//            return MODE1;
//        }
//    }
//}
