package king.james.bible.android.service.observable.listener;

import king.james.bible.android.model.Plan;

public interface DailyPlanListener {
    void loadDailyPlanComplete(Plan plan);
}
