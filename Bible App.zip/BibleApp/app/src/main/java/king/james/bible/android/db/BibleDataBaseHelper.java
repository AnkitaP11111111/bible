package king.james.bible.android.db;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.io.File;
import king.james.bible.android.exception.CopyDBException;
import king.james.bible.android.utils.BiblePreferences;

public class BibleDataBaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = getNameDB();
    private static Context mContext;
    private CopyDataBaseUtil copyDBUtil;
    private SQLiteDatabase mDataBase;
    private boolean tryCheck = true;

    private static String getNameDB() {
        return "bible_eng_tag.sqlite";
    }

    public void onCreate(SQLiteDatabase sQLiteDatabase) {
    }

    public void onDowngrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
    }

    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
    }

    public BibleDataBaseHelper() {
        super(mContext, DB_NAME, (SQLiteDatabase.CursorFactory) null, 1);
        CopyDataBaseUtil instance = CopyDataBaseUtil.getInstance();
        this.copyDBUtil = instance;
        instance.initPath(false);
    }

    public static void init(Context context) {
        mContext = context;
        CopyDataBaseUtil.getInstance().init(context, getNameDB());
    }

    public void setNewPatch() throws Throwable {
        CopyDataBaseUtil.getInstance().setNewPatch();
        createOrUpdateDataBase();
    }

    public void createOrUpdateDataBase() throws Throwable {
        try {
            boolean checkFileDataBase = checkFileDataBase();
            if (!checkFileDataBase) {
                this.copyDBUtil.copyDataBase();
                updateDbVersion();
            }
            if (isNewVersion()) {
                if (checkFileDataBase) {
                    MigrationUserDataUtil.getInstance().readUserData(true);
                    close();
                    deleteJournal();
                    BibleDataBase.getInstance().close();
                    BibleDataBase.getInstance().clearDbLink();
                    this.mDataBase = null;
                    this.copyDBUtil.copyDataBase();
                    openDataBase();
                    MigrationUserDataUtil.getInstance().writeUserData(true);
                }
                updateDbVersion();
            }
        } catch (Exception unused) {
            throw new CopyDBException();
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:21:0x002f  */
    /* JADX WARNING: Removed duplicated region for block: B:25:0x0035  */
    /* JADX WARNING: Removed duplicated region for block: B:31:? A[RETURN, SYNTHETIC] */
    private void deleteJournal() throws Throwable {
        SQLiteDatabase sQLiteDatabase;
        Throwable th;
        SQLiteDatabase sQLiteDatabase2 = null;
        try {
            sQLiteDatabase = this.mDataBase;
            if (sQLiteDatabase != null) {
                try {
                    if (!sQLiteDatabase.isOpen()) {
                        openDataBase();
                    }
                    Cursor rawQuery = sQLiteDatabase.rawQuery("PRAGMA journal_mode=DELETE", null);
                    if (rawQuery != null) {
                        rawQuery.close();
                    }
                    if (sQLiteDatabase != null) {
                        sQLiteDatabase.close();
                    }
                } catch (Exception unused) {
                    sQLiteDatabase2 = sQLiteDatabase;
                    if (sQLiteDatabase2 == null) {
                    }
                } catch (Throwable th2) {
                    th = th2;
                    if (sQLiteDatabase != null) {
                    }
                    throw th;
                }
            } else if (sQLiteDatabase != null) {
                sQLiteDatabase.close();
            }
        } catch (Exception unused2) {
            if (sQLiteDatabase2 == null) {
                sQLiteDatabase2.close();
            }
        } catch (Throwable th3) {
            sQLiteDatabase = null;
            th = th3;
            if (sQLiteDatabase != null) {
                sQLiteDatabase.close();
            }
            throw th;
        }
    }

    private void updateDbVersion() {
        BiblePreferences.getInstance().setDbVersion(49);
        BiblePreferences.getInstance().lambda$saveBg$1$BiblePreferences();
    }

    private boolean isNewVersion() {
        int dbVersion = BiblePreferences.getInstance().getDbVersion();
        if (dbVersion < 1) {
            dbVersion = getVersionFromDB();
        }
        if (49 > dbVersion) {
            return true;
        }
        return false;
    }

    private int getVersionFromDB() {
        try {
            return BibleDataBase.getDbVersion(getReadableDatabase());
        } catch (Exception unused) {
            return 0;
        }
    }

    private boolean checkFileDataBase() {
        return checkFileDataBase(this.copyDBUtil.getDBAbsolutePath());
    }

    public static boolean checkFileDataBase(String str) {
        File file = new File(str);
        return file.exists() && file.length() > 0;
    }

    public boolean isNewDataBase() {
        boolean checkFileDataBase = checkFileDataBase();
        BiblePreferences.getInstance().setFirstStart(!checkFileDataBase);
        if (!checkFileDataBase) {
            return true;
        }
        return isNewVersion();
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(5:9|10|(1:14)|15|16) */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:15:0x0031 */
    @SuppressLint("WrongConstant")
    public boolean openDataBase() throws Throwable {
        if (this.tryCheck && isNewDataBase()) {
            try {
                this.tryCheck = false;
                createOrUpdateDataBase();
            } catch (Exception unused) {
            }
        }
        if (this.mDataBase == null) {
            File file = new File(this.copyDBUtil.getDBAbsolutePath());
            if (file.exists() && !file.isDirectory()) {
                file.setWritable(true);
            }
            this.mDataBase = SQLiteDatabase.openDatabase(this.copyDBUtil.getDBAbsolutePath(), null, 268435472);
        }
        if (this.mDataBase != null) {
            return true;
        }
        return false;
    }

    @Override // java.lang.AutoCloseable
    public synchronized void close() {
        if (this.mDataBase != null) {
            this.mDataBase.close();
        }
        super.close();
    }

    @SuppressLint("WrongConstant")
    public SQLiteDatabase getReadableDatabase() {
        return SQLiteDatabase.openDatabase(this.copyDBUtil.getDBAbsolutePath(), null, 17);
    }

    @SuppressLint("WrongConstant")
    public SQLiteDatabase getWritableDatabase() {
        return SQLiteDatabase.openDatabase(this.copyDBUtil.getDBAbsolutePath(), null, 16);
    }
}
