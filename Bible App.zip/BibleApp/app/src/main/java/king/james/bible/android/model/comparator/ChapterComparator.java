package king.james.bible.android.model.comparator;

import java.util.Comparator;
import king.james.bible.android.model.chapter.Chapter;

public class ChapterComparator implements Comparator<Chapter> {
    public int compare(Chapter chapter, Chapter chapter2) {
        if (chapter.getId() < chapter2.getId()) {
            return -1;
        }
        return chapter.getId() > chapter2.getId() ? 1 : 0;
    }
}
