package king.james.bible.android.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import com.karumi.dexter.BuildConfig;
import king.james.bible.android.R;
import java.util.List;
import king.james.bible.android.db.BibleDataBase;
import king.james.bible.android.model.PlanChapterDay;
import king.james.bible.android.model.PlanDay;
import king.james.bible.android.model.chapter.ChapterShortNameAndMode;
import king.james.bible.android.utils.BiblePreferences;
import king.james.bible.android.view.NumberPickerObservable;

public class SelectPlanDialogView extends RelativeLayout {
    private View cancelButton;
    private FlowLayout chaptersFlowLayout;
    private View closeImageButton;
    private NumberPicker dayPicker;
    private View doneButton;
    private List<PlanDay> models;
    private NumberPickerObservable numberPickerObservable;

    public SelectPlanDialogView(Context context) {
        super(context);
    }

    public SelectPlanDialogView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public SelectPlanDialogView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    /* access modifiers changed from: protected */
    public void onFinishInflate() {
        super.onFinishInflate();
        this.dayPicker = (NumberPicker) findViewById(R.id.dayPicker);
        this.chaptersFlowLayout = (FlowLayout) findViewById(R.id.chaptersFlowLayout);
        this.cancelButton = findViewById(R.id.cancelButton);
        this.doneButton = findViewById(R.id.doneButton);
        this.closeImageButton = findViewById(R.id.closeImageButton);
    }

    public void setOnDoneListener(OnClickListener onClickListener) {
        this.doneButton.setOnClickListener(onClickListener);
    }

    public void setOnCancelListener(OnClickListener onClickListener) {
        this.cancelButton.setOnClickListener(onClickListener);
        this.closeImageButton.setOnClickListener(onClickListener);
    }

    public void init(int i) {
        this.dayPicker.setMinValue(1);
        this.dayPicker.setMaxValue(i);
    }

    private void startObservable() {
        this.numberPickerObservable = new NumberPickerObservable(this.dayPicker, 600, new NumberPickerObservable.NumberPickerChangeListener() {
            /* class king.james.bible.android.view.SelectPlanDialogView.AnonymousClass1 */

            @Override // king.james.bible.android.view.NumberPickerObservable.NumberPickerChangeListener
            public void onChange(int i) {
                SelectPlanDialogView.this.updateChapterList(i - 1);
            }
        });
    }

    public void stopObservable() {
        NumberPickerObservable numberPickerObservable2 = this.numberPickerObservable;
        if (numberPickerObservable2 != null) {
            numberPickerObservable2.stop();
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void updateChapterList(int i) {
        List<PlanDay> list = this.models;
        if (list != null && !list.isEmpty() && this.models.size() > i && i >= 0) {
            prepareChaptersFlowLayout(this.models.get(i));
        }
    }

    public List<PlanDay> getModels() {
        return this.models;
    }

    public void setModels(List<PlanDay> list) {
        this.models = list;
        startObservable();
        updateChapterList(getValue() - 1);
    }

    public int getValue() {
        return this.dayPicker.getValue();
    }

    private void hideChaptersFlowViews() {
        for (int i = 0; i < this.chaptersFlowLayout.getChildCount(); i++) {
            this.chaptersFlowLayout.getChildAt(i).setVisibility(8);
        }
    }

    private void prepareChaptersFlowLayout(PlanDay planDay) {
        hideChaptersFlowViews();
        if (!(planDay.getPlanChapterDays() == null || planDay.getPlanChapterDays().isEmpty())) {
            addChaptersFlowViews(planDay);
            List<ChapterShortNameAndMode> chaptersList = BibleDataBase.getInstance().getChaptersList();
            for (int i = 0; i < planDay.getPlanChapterDays().size(); i++) {
                PlanChapterDay planChapterDay = planDay.getPlanChapterDays().get(i);
                ItemDailyChapterView itemDailyChapterView = (ItemDailyChapterView) this.chaptersFlowLayout.getChildAt(i);
                itemDailyChapterView.setVisibility(0);
                prepareView(planDay, chaptersList, planChapterDay, itemDailyChapterView, i);
            }
        }
    }

    private void prepareView(PlanDay planDay, List<ChapterShortNameAndMode> list, PlanChapterDay planChapterDay, ItemDailyChapterView itemDailyChapterView, int i) {
        String str;
        int chapterOrder = planChapterDay.getChapterOrder() - 1;
        int i2 = BiblePreferences.getInstance().isDayMode() ? R.color.f46daily_readingplan_text : R.color.f47daily_readingplan_text_n;
        if (chapterOrder < 0 || chapterOrder > list.size() - 1) {
            str = BuildConfig.FLAVOR;
        } else {
            str = list.get(chapterOrder).getLongName();
            itemDailyChapterView.setChapterMode(list.get(chapterOrder).getMode());
            if (list.get(chapterOrder).getMode() == 2) {
                i2 = R.color.red_text;
            }
        }
        String str2 = str + " " + planChapterDay.getChapterNum();
        if (i < planDay.getPlanChapterDays().size() - 1) {
            str2 = str2 + ",";
        }
        setColorItem(itemDailyChapterView, i2);
        itemDailyChapterView.setNameText(str2);
    }

    private void addChaptersFlowViews(PlanDay planDay) {
        for (int childCount = this.chaptersFlowLayout.getChildCount(); childCount < planDay.getPlanChapterDays().size(); childCount++) {
            ItemDailyChapterView itemDailyChapterView = (ItemDailyChapterView) LayoutInflater.from(this.chaptersFlowLayout.getContext()).inflate(R.layout.item_daily_chapter, (ViewGroup) this.chaptersFlowLayout, false);
            itemDailyChapterView.setVisibility(8);
            this.chaptersFlowLayout.addView(itemDailyChapterView);
        }
    }

    private void setColorItem(ItemDailyChapterView itemDailyChapterView, int i) {
        if (i > 0) {
            itemDailyChapterView.setModeColor(i);
        } else {
            itemDailyChapterView.setModeColor(R.color.title_text);
        }
    }
}
