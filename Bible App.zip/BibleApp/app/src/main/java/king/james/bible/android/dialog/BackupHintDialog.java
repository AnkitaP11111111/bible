package king.james.bible.android.dialog;

import king.james.bible.android.R;

public class BackupHintDialog extends EvaluationDialog {
    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.EvaluationDialog
    public void closeClick() {
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.EvaluationDialog
    public int getActionTextResId() {
        return R.string.hint_backup_button;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.EvaluationDialog
    public int getTextResId() {
        return R.string.hint_backup_text;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.EvaluationDialog
    public int getTitleResId() {
        return R.string.hint_backup_title;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.EvaluationDialog
    public boolean showLaterButton() {
        return false;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.EvaluationDialog
    public boolean showNoButton() {
        return false;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.EvaluationDialog
    public void selectAction() {
        dismiss();
    }
}
