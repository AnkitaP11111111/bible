package king.james.bible.android.service.net;

import com.karumi.dexter.BuildConfig;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class NetworkRequestService {
    public static String requestGet(String str) {
        StringBuffer stringBuffer = new StringBuffer();
        try {
            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(str).openConnection();
            httpURLConnection.setDoInput(true);
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));
            for (String readLine = bufferedReader.readLine(); readLine != null; readLine = bufferedReader.readLine()) {
                stringBuffer.append(readLine);
            }
            return stringBuffer.toString();
        } catch (Exception unused) {
            return BuildConfig.FLAVOR;
        }
    }
}
