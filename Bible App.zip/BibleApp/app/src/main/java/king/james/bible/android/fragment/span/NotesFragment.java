package king.james.bible.android.fragment.span;

import android.annotation.SuppressLint;
import android.os.Handler;
import android.view.View;
import android.widget.LinearLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import king.james.bible.android.R;
import java.util.ArrayList;
import king.james.bible.android.adapter.recycler.OnItemSpanClickListener;
import king.james.bible.android.adapter.recycler.span.NotesItemAdapter;
import king.james.bible.android.db.BibleDataBase;
import king.james.bible.android.db.listener.AddRemoveNoteListener;
import king.james.bible.android.dialog.DialogUtil;
import king.james.bible.android.model.chapter.ChapterSubChapterCursorResult;
import king.james.bible.android.model.span.SpanItem;
import king.james.bible.android.service.PowerManagerService;
@SuppressLint({"NewApi", "WrongConstant"})

public class NotesFragment extends BaseSpanFragment implements OnItemSpanClickListener {
    private  ArrayList r2;
    private NotesItemAdapter adapter;
    private LinearLayout noEntries;

    @Override // king.james.bible.android.fragment.span.BaseSpanFragment
    public int getRootViewId() {
        return this.preferences.isNightMode() ? R.layout.activity_notes_n : R.layout.activity_notes;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.fragment.span.BaseSpanFragment
    public void mapViews(View view) {
        this.noEntries = (LinearLayout) view.findViewById(R.id.no_entries_notes);
        RecyclerView recyclerView = (RecyclerView) view.findViewById(R.id.lv_notes_result);
        this.adapter = NotesItemAdapter.create(this);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), 1, false));
        recyclerView.setAdapter(this.adapter);
        new Handler().postDelayed(new Runnable() {
            /* class king.james.bible.android.fragment.span.$$Lambda$NotesFragment$TyXfnMjhSbJUeTwyfQmwvCnpW84 */

            public final void run() {
                NotesFragment.this.lambda$mapViews$1$NotesFragment();
            }
        }, 200);
    }

    public /* synthetic */ void lambda$mapViews$1$NotesFragment() {
        new Thread(new Runnable() {
            /* class king.james.bible.android.fragment.span.$$Lambda$NotesFragment$Z9r4th1eBSFhmCCEmbJq72PHBoc */

            public final void run() {
                NotesFragment.this.lambda$null$0$NotesFragment();
            }
        }).start();
    }

    public /* synthetic */ void lambda$null$0$NotesFragment() {
        try {
            loadModels();
        } catch (Exception unused) {
            DialogUtil.hideProgressDialog();
        }
    }

    private void onLoadFinished(ArrayList<SpanItem> arrayList) {
        if (getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() {
                /* class king.james.bible.android.fragment.span.$$Lambda$NotesFragment$1NR37JJvfyqmyqpNvi9Hi4yfgY */
                private final /* synthetic */ ArrayList f$1;

                {
                    this.f$1 = r2;
                }

                public final void run() {
                    NotesFragment.this.lambda$onLoadFinished$2$NotesFragment(this.f$1);
                }
            });
        }
    }

    public /* synthetic */ void lambda$onLoadFinished$2$NotesFragment(ArrayList arrayList) {
        if (getActivity() != null && !getActivity().isFinishing()) {
            PowerManagerService.getInstance().start();
            try {
                if (arrayList.isEmpty()) {
                    this.noEntries.setVisibility(0);
                    this.adapter.updateModels(arrayList);
                    DialogUtil.hideProgressDialog();
                    return;
                }
                this.noEntries.setVisibility(4);
                this.adapter.setSearchText(this.searchText);
                this.adapter.updateModels(arrayList);
                DialogUtil.hideProgressDialog();
            } catch (Exception unused) {
            }
        }
    }

    private void loadModels() {
        DialogUtil.showProgressDialog();
        new Thread(new Runnable() {
            /* class king.james.bible.android.fragment.span.$$Lambda$NotesFragment$x_TAEFDIrtcXXEoHDYRQq0QePOw */

            public final void run() {
                NotesFragment.this.lambda$loadModels$3$NotesFragment();
            }
        }).start();
    }

    public /* synthetic */ void lambda$loadModels$3$NotesFragment() {
        onLoadFinished(BibleDataBase.getInstance().getNotesCursor(this.searchText));
    }

    @Override // king.james.bible.android.fragment.span.BaseSpanFragment
    public void makeSearch() {
        loadModels();
    }

    @Override // king.james.bible.android.adapter.recycler.OnItemSpanClickListener
    public void onClick(int i, View view, boolean z) {
        if (!executeAction()) {
            return;
        }
        if (z) {
            showItemDeleteView(view);
        } else {
            moveToReadingScreen(view);
        }
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.fragment.span.BaseSpanFragment
    public void moveToReadingScreenFromUI(ChapterSubChapterCursorResult chapterSubChapterCursorResult, int i) {
        this.fragmentListener.onFragmentResultOk(chapterSubChapterCursorResult.getChapter(), chapterSubChapterCursorResult.getSubChapter() + 1, chapterSubChapterCursorResult.getPosition(), i, this);
    }

    /* access modifiers changed from: protected */
//    @Override // king.james.bible.android.fragment.span.BaseSpanFragment
//    public void removeItem(long j) {
//        this.bibleDB.removeNote(j, new AddRemoveNoteListener() {
//            /* class king.james.bible.android.fragment.span.$$Lambda$NotesFragment$H9HjA77gi5RzbakFasb9BtLxis */
//
//            @Override // king.james.bible.android.db.listener.AddRemoveNoteListener
//            public final void onComplete(long j) {
//                NotesFragment.this.lambda$removeItem$4$NotesFragment(j);
//            }
//        });
//    }

    public /* synthetic */ void lambda$removeItem$4$NotesFragment(long j) {
        makeSearch();
        postDelete();
    }

    @Override // king.james.bible.android.fragment.span.BaseSpanFragment
    public void notifyDataSetChanged() {
        NotesItemAdapter notesItemAdapter = this.adapter;
        if (notesItemAdapter != null) {
            notesItemAdapter.notifyDataSetChanged();
        }
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.fragment.span.BaseSpanFragment
    public void updateWidth() {
        this.adapter.initWidth(getActivity());
    }
}
