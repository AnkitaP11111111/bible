package king.james.bible.android.adapter.recycler;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import com.karumi.dexter.BuildConfig;
import king.james.bible.android.R;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import king.james.bible.android.adapter.holder.EditDailyVerseViewHolder;
import king.james.bible.android.adapter.holder.HeaderEditDailyVerseViewHolder;
import king.james.bible.android.adapter.holder.SelectChapterHolder$ChapterHolderListener;
import king.james.bible.android.adapter.holder.ViewEditDailyVerseViewHolder;
import king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter;
import king.james.bible.android.model.DailyVerse;
import king.james.bible.android.model.EditDailyVerse;
import king.james.bible.android.model.SelectChapter;

public class EditDailyVerseRecyclerViewAdapter extends BaseRecyclerViewAdapter<EditDailyVerseViewHolder> {
    private SelectChapterHolder$ChapterHolderListener chapterHolderListener;
    private DailyVerse dailyVerse;
    private HeaderEditDailyVerseViewHolder headerHolder;
    private List<SelectChapter> models;
    private boolean selectAllGlobal = true;
    private String selectCountStr = BuildConfig.FLAVOR;

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemViewType(int i) {
        return i == 0 ? R.layout.fragment_edit_daily_verse_header : R.layout.item_edit_daily_verse;
    }

    public EditDailyVerseRecyclerViewAdapter(List<SelectChapter> list, DailyVerse dailyVerse2, boolean z) {
        super(null);
        this.models = list;
        this.dailyVerse = dailyVerse2;
        this.selectAllGlobal = z;
        createChapterHolderListener();
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter
    public EditDailyVerseViewHolder doCreateViewHolder(ViewGroup viewGroup, int i) {
        View inflate = LayoutInflater.from(viewGroup.getContext()).inflate(i, viewGroup, false);
        if (i != R.layout.fragment_edit_daily_verse_header) {
            return new ViewEditDailyVerseViewHolder(inflate, this.chapterHolderListener);
        }
        if (this.headerHolder == null) {
            this.headerHolder = new HeaderEditDailyVerseViewHolder(inflate, this.selectAllGlobal, this.dailyVerse.getTitle(), this.dailyVerse.isNotify(), this.dailyVerse.getNotifyTime());
            setSelectAllListener();
        }
        return this.headerHolder;
    }

    public void onBindViewHolder(EditDailyVerseViewHolder editDailyVerseViewHolder, int i) {
        super.onBindViewHolder( editDailyVerseViewHolder, i);
        if (editDailyVerseViewHolder instanceof HeaderEditDailyVerseViewHolder) {
            notifyHeader();
        }
    }

    @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter
    public SelectChapter getModel(int i) {
        if (i == 0) {
            return null;
        }
        return this.models.get(i - 1);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.models.size() + 1;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter
    public OnItemClickListener getOnItemClickListener() {
        return new OnItemClickListener() {
            /* class king.james.bible.android.adapter.recycler.EditDailyVerseRecyclerViewAdapter.AnonymousClass1 */

            @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter.OnItemClickListener
            public void onClick(int i) {
                if (i >= 1 && i <= EditDailyVerseRecyclerViewAdapter.this.models.size()) {
                    int i2 = i - 1;
                    boolean isSelected = true ^ ((SelectChapter) EditDailyVerseRecyclerViewAdapter.this.models.get(i2)).isSelected();
                    if (!isSelected) {
                        EditDailyVerseRecyclerViewAdapter.this.clearSelectAllChecked();
                    }
                    ((SelectChapter) EditDailyVerseRecyclerViewAdapter.this.models.get(i2)).setSelected(isSelected);
                    if (isSelected) {
                        EditDailyVerseRecyclerViewAdapter.this.setSelectAllChecked();
                    }
                    EditDailyVerseRecyclerViewAdapter.this.notifyItemChanged(i);
                    EditDailyVerseRecyclerViewAdapter.this.setCount();
                }
            }
        };
    }

    private void createChapterHolderListener() {
        this.chapterHolderListener = new SelectChapterHolder$ChapterHolderListener() {
            /* class king.james.bible.android.adapter.recycler.EditDailyVerseRecyclerViewAdapter.AnonymousClass2 */

            @Override // king.james.bible.android.adapter.holder.SelectChapterHolder$ChapterHolderListener
            public void setSelected(boolean z) {
                if (!z) {
                    EditDailyVerseRecyclerViewAdapter.this.clearSelectAllChecked();
                }
                if (z) {
                    EditDailyVerseRecyclerViewAdapter.this.setSelectAllChecked();
                }
                EditDailyVerseRecyclerViewAdapter.this.setCount();
            }
        };
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void clearSelectAllChecked() {
        clearSelectAllListener();
        this.selectAllGlobal = false;
        notifyHeader();
        setSelectAllListener();
    }

    private void setSelectAllListener() {
        HeaderEditDailyVerseViewHolder headerEditDailyVerseViewHolder = this.headerHolder;
        if (headerEditDailyVerseViewHolder != null) {
            headerEditDailyVerseViewHolder.setSelectAllCheckBoxListener(new CompoundButton.OnCheckedChangeListener() {
                /* class king.james.bible.android.adapter.recycler.EditDailyVerseRecyclerViewAdapter.AnonymousClass3 */

                public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                    for (int i = 0; i < EditDailyVerseRecyclerViewAdapter.this.models.size(); i++) {
                        if (((SelectChapter) EditDailyVerseRecyclerViewAdapter.this.models.get(i)).isSelected() != z) {
                            ((SelectChapter) EditDailyVerseRecyclerViewAdapter.this.models.get(i)).setSelected(z);
                            try {
                                EditDailyVerseRecyclerViewAdapter.this.notifyItemChanged(i + 1);
                            } catch (Exception unused) {
                            }
                        }
                    }
                }
            });
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void setSelectAllChecked() {
        boolean z;
        Iterator<SelectChapter> it = this.models.iterator();
        while (true) {
            z = false;
            if (it.hasNext()) {
                if (!it.next().isSelected()) {
                    this.selectAllGlobal = false;
                    break;
                }
            } else {
                z = true;
                break;
            }
        }
        if (z) {
            this.selectAllGlobal = true;
            notifyHeader();
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void setCount() {
        int i = 0;
        for (SelectChapter selectChapter : this.models) {
            if (selectChapter.isSelected()) {
                i++;
            }
        }
        this.selectCountStr = i + "/" + this.models.size();
        notifyHeader();
    }

    private void clearSelectAllListener() {
        HeaderEditDailyVerseViewHolder headerEditDailyVerseViewHolder = this.headerHolder;
        if (headerEditDailyVerseViewHolder != null) {
            headerEditDailyVerseViewHolder.setSelectAllCheckBoxListener(null);
        }
    }

    private void notifyHeader() {
        HeaderEditDailyVerseViewHolder headerEditDailyVerseViewHolder = this.headerHolder;
        if (headerEditDailyVerseViewHolder != null) {
            headerEditDailyVerseViewHolder.updateView(this.selectAllGlobal, this.selectCountStr);
        }
    }

    public EditDailyVerse getEditModel() {
        EditDailyVerse editDailyVerse = null;
        try {
            EditDailyVerse editDailyVerse2 = new EditDailyVerse();
            try {
                editDailyVerse2.setTitle(this.headerHolder.getTitle());
                editDailyVerse2.setNotify(this.headerHolder.isNotify());
                editDailyVerse2.setNotifyTime(this.headerHolder.getNotifyTime());
                editDailyVerse2.setSelectChapters(getSelectChapters());
                return editDailyVerse2;
            } catch (Exception unused) {
                editDailyVerse = editDailyVerse2;
            }
        } catch (Exception unused2) {
            return editDailyVerse;
        }
    }

    private HashSet<Long> getSelectChapters() {
        HashSet<Long> hashSet = new HashSet<>();
        for (SelectChapter selectChapter : this.models) {
            if (selectChapter.isSelected()) {
                hashSet.add(selectChapter.getId());
            }
        }
        return hashSet;
    }
}
