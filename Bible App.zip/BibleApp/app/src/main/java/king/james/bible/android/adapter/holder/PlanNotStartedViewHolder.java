package king.james.bible.android.adapter.holder;

import android.annotation.SuppressLint;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import king.james.bible.android.R;
import java.util.HashMap;
import java.util.Map;
import king.james.bible.android.model.Plan;
import king.james.bible.android.model.PlanModeColor;
import king.james.bible.android.service.observable.DailyReadingActionObservable;
import king.james.bible.android.utils.BiblePreferences;
@SuppressLint({"NewApi", "WrongConstant"})

public class PlanNotStartedViewHolder extends DailyReadingBaseViewHolder implements View.OnClickListener {
    private TextView descriptionTextView;
    private LinearLayout modeLevel1LinearLayout;
    private LinearLayout modeLevel2LinearLayout;
    private Map<Integer, TextView> modeViewMap;
    private Plan plan;
    private BiblePreferences preferences = BiblePreferences.getInstance();
    private TextView titleTextView;

    public PlanNotStartedViewHolder(View view) {
        super(view);
    }

    /* JADX DEBUG: Multi-variable search result rejected for r0v13, resolved type: java.util.Map<java.lang.Integer, android.widget.TextView> */
    /* JADX DEBUG: Multi-variable search result rejected for r0v14, resolved type: java.util.Map<java.lang.Integer, android.widget.TextView> */
    /* JADX DEBUG: Multi-variable search result rejected for r0v15, resolved type: java.util.Map<java.lang.Integer, android.widget.TextView> */
    /* JADX DEBUG: Multi-variable search result rejected for r0v16, resolved type: java.util.Map<java.lang.Integer, android.widget.TextView> */
    /* JADX DEBUG: Multi-variable search result rejected for r0v17, resolved type: java.util.Map<java.lang.Integer, android.widget.TextView> */
    /* JADX WARN: Multi-variable type inference failed */
    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter.BaseViewHolder
    public void mapViews(View view) {
        this.titleTextView = (TextView) view.findViewById(R.id.titleTextView);
        this.descriptionTextView = (TextView) view.findViewById(R.id.descriptionTextView);
        this.modeLevel1LinearLayout = (LinearLayout) view.findViewById(R.id.modeLevel1LinearLayout);
        this.modeLevel2LinearLayout = (LinearLayout) view.findViewById(R.id.modeLevel2LinearLayout);
        HashMap hashMap = new HashMap();
        this.modeViewMap = hashMap;
        hashMap.put(1, view.findViewById(R.id.mode1TextView));
        this.modeViewMap.put(2, view.findViewById(R.id.mode2TextView));
        this.modeViewMap.put(3, view.findViewById(R.id.mode3TextView));
        this.modeViewMap.put(4, view.findViewById(R.id.mode4TextView));
        this.modeViewMap.put(5, view.findViewById(R.id.mode5TextView));
        this.modeViewMap.put(6, view.findViewById(R.id.mode6TextView));
        for (Map.Entry<Integer, TextView> entry : this.modeViewMap.entrySet()) {
            entry.getValue().setOnClickListener(this);
        }
    }

    @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter.BaseViewHolder
    public void updateView(Object obj) {
        Plan plan2 = (Plan) obj;
        this.plan = plan2;
        this.titleTextView.setText(plan2.getTitle());
        this.descriptionTextView.setText(this.plan.getDescription());
        this.descriptionTextView.setTextColor(getDescriptionTextColor());
        hideAllModeView();
        prepareLevelView();
        for (int i = 1; i <= this.plan.getPlanModes().size(); i++) {
            this.modeViewMap.get(Integer.valueOf(i)).setVisibility(0);
            int i2 = i - 1;
            this.modeViewMap.get(Integer.valueOf(i)).setText(this.plan.getPlanModes().get(i2).getNameString());
            this.modeViewMap.get(Integer.valueOf(i)).setTextColor(getButtonTextColor());
            this.modeViewMap.get(Integer.valueOf(i)).setBackgroundResource(getBackgroundResId(this.plan.getPlanModes().get(i2).getPlanModeColor()));
        }
    }

    private int getDescriptionTextColor() {
        return this.itemView.getContext().getResources().getColor(this.preferences.isNightMode() ? R.color.daily_readingplan_text_n : R.color.f46daily_readingplan_text);
    }

    private int getButtonTextColor() {
        return this.itemView.getContext().getResources().getColor(this.preferences.isNightMode() ? R.color.daily_readingtoolbar_n : R.color.title_text);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: king.james.bible.android.adapter.holder.PlanNotStartedViewHolder$1  reason: invalid class name */
    public static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] $SwitchMap$king$james$bible$android$model$PlanModeColor;

        /* JADX WARNING: Can't wrap try/catch for region: R(6:0|1|2|3|4|(3:5|6|8)) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x001d */
        static {
            int[] iArr = new int[PlanModeColor.values().length];
            $SwitchMap$king$james$bible$android$model$PlanModeColor = iArr;
            iArr[PlanModeColor.GREEN.ordinal()] = 1;
            $SwitchMap$king$james$bible$android$model$PlanModeColor[PlanModeColor.YELLOW.ordinal()] = 2;
            try {
                $SwitchMap$king$james$bible$android$model$PlanModeColor[PlanModeColor.RED.ordinal()] = 3;
            } catch (NoSuchFieldError unused) {
            }
        }
    }

    private int getBackgroundResId(PlanModeColor planModeColor) {
        boolean isNightMode = this.preferences.isNightMode();
        int i = AnonymousClass1.$SwitchMap$king$james$bible$android$model$PlanModeColor[planModeColor.ordinal()];
        if (i == 1) {
            return isNightMode ? R.drawable.ic_green_button_n : R.drawable.ic_green_button;
        }
        if (i == 2) {
            return isNightMode ? R.drawable.ic_yellow_button_n : R.drawable.ic_yellow_button;
        }
        if (i != 3) {
            return 0;
        }
        return isNightMode ? R.drawable.ic_red_button_n : R.drawable.ic_red_button;
    }

    private void prepareLevelView() {
        if (!this.plan.getPlanModes().isEmpty()) {
            this.modeLevel1LinearLayout.setVisibility(0);
        }
        if (this.plan.getPlanModes().size() > 3) {
            this.modeLevel2LinearLayout.setVisibility(0);
        }
    }

    private void hideAllModeView() {
        for (Map.Entry<Integer, TextView> entry : this.modeViewMap.entrySet()) {
            entry.getValue().setVisibility(4);
        }
        this.modeLevel1LinearLayout.setVisibility(8);
        this.modeLevel2LinearLayout.setVisibility(8);
    }

    public void onClick(View view) {
        int i;
        switch (view.getId()) {
            case R.id.mode1TextView:
                i = 0;
                break;
            case R.id.mode2TextView:
                i = 1;
                break;
            case R.id.mode3TextView:
                i = 2;
                break;
            case R.id.mode4TextView:
                i = 3;
                break;
            case R.id.mode5TextView:
                i = 4;
                break;
            case R.id.mode6TextView:
                i = 5;
                break;
            default:
                i = -1;
                break;
        }
        if (i >= 0) {
            DailyReadingActionObservable.getInstance().onSelectPlan(this.plan, getLayoutPosition(), this.plan.getPlanModes().get(i));
        }
    }
}
