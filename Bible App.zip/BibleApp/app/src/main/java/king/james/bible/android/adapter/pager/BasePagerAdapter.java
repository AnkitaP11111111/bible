package king.james.bible.android.adapter.pager;

import android.content.Context;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.viewpager.widget.PagerAdapter;
import java.util.ArrayList;
import java.util.List;

public abstract class BasePagerAdapter<T, V extends View> extends PagerAdapter {
    protected SparseArray<V> bindedViews = new SparseArray<>();
    protected Context context;
    protected List<V> discardedViews = new ArrayList();
    protected List<T> items;

    public abstract T getItem(int i);

    /* access modifiers changed from: protected */
    public abstract int getResViewId(int i);

    /* access modifiers changed from: protected */
    public abstract void prepareView(int i, V v, T t);

    public BasePagerAdapter(Context context2, List<T> list) {
        this.items = list;
        this.context = context2;
    }

    @Override // androidx.viewpager.widget.PagerAdapter
    public Object instantiateItem(ViewGroup viewGroup, int i) {
        V view = this.discardedViews.isEmpty() ? getView(viewGroup, i) : this.discardedViews.remove(0);
        T item = getItem(i);
        prepareView(i, view, item);
        this.bindedViews.append(i, view);
        viewGroup.addView(view, 0, new ViewGroup.LayoutParams(-2, -2));
        return item;
    }

    public V getBindedView(int i) {
        return this.bindedViews.get(i);
    }

    public void setItems(List<T> list) {
        this.items = list;
    }

    @Override // androidx.viewpager.widget.PagerAdapter
    public boolean isViewFromObject(View view, Object obj) {
        return view == this.bindedViews.get(this.items.indexOf(obj));
    }

    /* access modifiers changed from: protected */
    public V getView(ViewGroup viewGroup, int i) {
        return (V) LayoutInflater.from(this.context).inflate(getResViewId(i), viewGroup, false);
    }

    @Override // androidx.viewpager.widget.PagerAdapter
    public void destroyItem(ViewGroup viewGroup, int i, Object obj) {
        V v = this.bindedViews.get(i);
        if (v != null) {
            this.discardedViews.add(v);
            this.bindedViews.remove(i);
            viewGroup.removeView(v);
        }
    }
}
