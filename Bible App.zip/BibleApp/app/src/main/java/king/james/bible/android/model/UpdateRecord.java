package king.james.bible.android.model;

public class UpdateRecord {
    private Integer bookmark;
    private Long bookmarkDate;
    private Integer highlight;
    private Long highlightDate;
    private int id;
    private String note;
    private Long noteDate;

    public UpdateRecord(int i, Integer num, Integer num2, String str, Long l, Long l2, Long l3) {
        this.id = i;
        this.bookmark = num;
        this.highlight = num2;
        this.note = str;
        this.bookmarkDate = l;
        this.highlightDate = l2;
        this.noteDate = l3;
    }

    public Long getBookmarkDate() {
        return this.bookmarkDate;
    }

    public Long getHighlightDate() {
        return this.highlightDate;
    }

    public Long getNoteDate() {
        return this.noteDate;
    }

    public int getId() {
        return this.id;
    }

    public Integer getBookmark() {
        return this.bookmark;
    }

    public Integer getHighlight() {
        return this.highlight;
    }

    public String getNote() {
        return this.note;
    }
}
