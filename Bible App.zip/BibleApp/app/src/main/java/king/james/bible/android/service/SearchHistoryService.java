package king.james.bible.android.service;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.karumi.dexter.BuildConfig;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import king.james.bible.android.model.SearchText;
import king.james.bible.android.model.comparator.SearchHistoryComparator;

public class SearchHistoryService {
    private static SearchHistoryService INSTANCE;
    private Context mContext;
    private List<SearchText> mSearchHistory;
    private boolean showSearch = false;

    private SearchHistoryService() {
    }

    public static SearchHistoryService getInstance() {
        if (INSTANCE == null) {
            synchronized (SearchHistoryService.class) {
                if (INSTANCE == null) {
                    INSTANCE = new SearchHistoryService();
                }
            }
        }
        return INSTANCE;
    }

    public void init(Context context) {
        this.mContext = context;
        new Thread(new Runnable() {
            /* class king.james.bible.android.service.SearchHistoryService.AnonymousClass1 */

            public void run() {
                try {
                    SearchHistoryService.this.restore();
                } catch (Exception unused) {
                }
            }
        }).start();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.util.List] */
    /* JADX WARNING: Unknown variable types count: 1 */
    public void restore() {
        SharedPreferences sharedPreferences;
        Context context = this.mContext;
        if (!(context == null || (sharedPreferences = context.getSharedPreferences("king.james.bible.android.service.SearchHistoryService_preference", 0)) == null)) {
            ArrayList<SearchText> arrayList = null;
            try {
                arrayList = (List) new Gson().fromJson(sharedPreferences.getString("SearchHistoryJson", "[]"), new TypeToken<List<SearchText>>(this) {
                    /* class king.james.bible.android.service.SearchHistoryService.AnonymousClass2 */
                }.getType());
            } catch (Exception unused) {
            }
            if (arrayList == null) {
                arrayList = new ArrayList();
            }
            this.mSearchHistory = new ArrayList();
            for (SearchText searchText : arrayList) {
                if (!(searchText == null || searchText.getText() == null)) {
                    this.mSearchHistory.add(searchText);
                }
            }
            save();
        }
    }

    public void save() {
        new Thread(new Runnable() {
            /* class king.james.bible.android.service.SearchHistoryService.AnonymousClass3 */

            public void run() {
                SharedPreferences.Editor edit;
                try {
                    SharedPreferences sharedPreferences = SearchHistoryService.this.mContext.getSharedPreferences("king.james.bible.android.service.SearchHistoryService_preference", 0);
                    if (sharedPreferences != null && (edit = sharedPreferences.edit()) != null) {
                        SearchHistoryService.this.checkHistory();
                        edit.putString("SearchHistoryJson", new Gson().toJson(SearchHistoryService.this.mSearchHistory));
                        edit.apply();
                    }
                } catch (Exception unused) {
                }
            }
        }).start();
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void checkHistory() {
        if (this.mSearchHistory.size() > 300) {
            prepareToSave();
        }
    }

    private void sortHistory() {
        Collections.sort(this.mSearchHistory, new SearchHistoryComparator());
    }

    private void prepareToSave() {
        sortHistory();
        int size = this.mSearchHistory.size() - 300;
        for (int i = 0; i < size; i++) {
            this.mSearchHistory.remove(300);
        }
    }

    public synchronized List<SearchText> search(String str) {
        ArrayList arrayList;
        arrayList = new ArrayList();
        for (SearchText searchText : this.mSearchHistory) {
            if (searchText != null) {
                if (searchText.getText() != null) {
                    if (searchText.getText().toLowerCase().contains(str.toLowerCase())) {
                        arrayList.add(new SearchText(searchText.getTime(), searchText.getText()));
                    }
                }
            }
        }
        return arrayList;
    }

    public void addSearch(String str) {
        this.showSearch = true;
        for (SearchText searchText : this.mSearchHistory) {
            if (!(searchText == null || searchText.getText() == null || !searchText.getText().toLowerCase().equals(str.toLowerCase()))) {
                searchText.setTime(System.currentTimeMillis());
                save();
                return;
            }
        }
        this.mSearchHistory.add(new SearchText(System.currentTimeMillis(), str));
    }

    public String getLastSearch() {
        if (!this.showSearch || this.mSearchHistory.size() < 1) {
            return BuildConfig.FLAVOR;
        }
        sortHistory();
        return this.mSearchHistory.get(0).getText();
    }
}
