package king.james.bible.android.adapter.holder;

import android.view.View;
import king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter;

public abstract class ContentsTabletBaseHolder extends BaseRecyclerViewAdapter.BaseViewHolder {
    public ContentsTabletBaseHolder(View view) {
        super(view);
    }
}
