package king.james.bible.android.service.notifications;

public enum NotificationMode {
    PLAN,
    VERSE
}
