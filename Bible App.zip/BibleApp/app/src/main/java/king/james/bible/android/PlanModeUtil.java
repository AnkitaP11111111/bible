package king.james.bible.android;

import java.util.HashMap;
import java.util.Map;
import king.james.bible.android.model.PlanMode;
import king.james.bible.android.model.PlanModeColor;

public class PlanModeUtil {
    public static final Map<Integer, PlanMode> plansMode;

    static {
        HashMap hashMap = new HashMap();
        plansMode = hashMap;
        hashMap.put(1, new PlanMode(1, 365, "1 Year", PlanModeColor.GREEN));
        plansMode.put(2, new PlanMode(2, 180, "180 Days", PlanModeColor.YELLOW));
        plansMode.put(3, new PlanMode(3, 90, "90 Days", PlanModeColor.RED));
    }
}
