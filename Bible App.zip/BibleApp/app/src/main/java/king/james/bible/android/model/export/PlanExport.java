package king.james.bible.android.model.export;

import java.util.Map;

public class PlanExport {
    private long id;
    private int modeId;
    private boolean notify;
    private long notifyTime;
    private Map<Integer, PlanDayExport> planDays;
    private long startDate;

    public PlanExport(long j, long j2, int i, boolean z, long j3) {
        this.id = j;
        this.startDate = j2;
        this.modeId = i;
        this.notify = z;
        this.notifyTime = j3;
    }

    public long getId() {
        return this.id;
    }

    public long getStartDate() {
        return this.startDate;
    }

    public int getModeId() {
        return this.modeId;
    }

    public boolean isNotify() {
        return this.notify;
    }

    public long getNotifyTime() {
        return this.notifyTime;
    }

    public Map<Integer, PlanDayExport> getPlanDays() {
        return this.planDays;
    }

    public void setPlanDays(Map<Integer, PlanDayExport> map) {
        this.planDays = map;
    }
}
