package king.james.bible.android.activity;

/* renamed from: king.james.bible.android.activity.-$$Lambda$LaunchActivity$bkGfLmoY4zMTpTsI0HYF0KyGil4  reason: invalid class name */
/* compiled from: lambda */
public final /* synthetic */ class $$Lambda$LaunchActivity$bkGfLmoY4zMTpTsI0HYF0KyGil4 implements Runnable {
    public static final /* synthetic */ $$Lambda$LaunchActivity$bkGfLmoY4zMTpTsI0HYF0KyGil4 INSTANCE = new $$Lambda$LaunchActivity$bkGfLmoY4zMTpTsI0HYF0KyGil4();

    private /* synthetic */ $$Lambda$LaunchActivity$bkGfLmoY4zMTpTsI0HYF0KyGil4() {
    }

    public final void run() {
        LaunchActivity.lambda$checkData$0();
    }
}
