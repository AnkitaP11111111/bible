package king.james.bible.android.adapter.holder;

import android.annotation.SuppressLint;
import android.view.View;
import android.widget.TextView;
import king.james.bible.android.R;
import king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter;
import king.james.bible.android.model.SearchTextResult;
import king.james.bible.android.utils.BiblePreferences;
@SuppressLint({"NewApi", "WrongConstant"})

public class SearchItemViewHolder extends BaseRecyclerViewAdapter.BaseViewHolder {
    View dividerView;
    private BiblePreferences preferences = BiblePreferences.getInstance();
    TextView text1;

    public SearchItemViewHolder(View view) {
        super(view);
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter.BaseViewHolder
    public void mapViews(View view) {
        this.text1 = (TextView) view.findViewById(R.id.search_item_text1);
        this.dividerView = view.findViewById(R.id.dividerView);
    }

    @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter.BaseViewHolder
    public void updateView(Object obj) {
        this.dividerView.setVisibility(8);
        setupTextSettings(this.text1);
        if (obj instanceof SearchTextResult) {
            this.dividerView.setVisibility(0);
            this.text1.setText(((SearchTextResult) obj).getText());
        }
    }

    private void setupTextSettings(TextView textView) {
        textView.setTypeface(this.preferences.getTypeface());
        textView.setTextSize(2, (float) ((int) this.preferences.getTextSize()));
        textView.setLineSpacing(0.0f, this.preferences.getSpacing());
    }
}
