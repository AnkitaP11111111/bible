package king.james.bible.android.event;

public class WaitDialogEvent {
    private boolean showDialog;

    public WaitDialogEvent(boolean z) {
        this.showDialog = z;
    }

    public boolean isShowDialog() {
        return this.showDialog;
    }
}
