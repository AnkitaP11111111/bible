package king.james.bible.android.sound.holder;

import android.view.View;
import com.karumi.dexter.BuildConfig;
import king.james.bible.android.sound.SoundHelper;

public class SettingsSoundButtonHolder extends SoundButtonHolder {
    private String text;

    public static SettingsSoundButtonHolder create(View view) {
        return new SettingsSoundButtonHolder(view);
    }

    private SettingsSoundButtonHolder(View view) {
        super(view, null, null, null);
        clearText();
    }

    public void clearText() {
        this.text = BuildConfig.FLAVOR;
    }

    public void addText(String str) {
        this.text += " " + str;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.sound.holder.SoundButtonHolder
    public void onSoundClick() {
        if (SoundHelper.getInstance().isPlayItem(-14, -1)) {
            pause();
        } else {
            play();
        }
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.sound.holder.SoundButtonHolder
    public void play() {
        showButton();
        preparePlayBackground();
        SoundHelper.getInstance().play(-14, -1, this.text);
    }
}
