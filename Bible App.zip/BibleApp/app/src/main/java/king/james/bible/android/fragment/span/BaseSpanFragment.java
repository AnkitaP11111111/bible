package king.james.bible.android.fragment.span;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import com.karumi.dexter.BuildConfig;
import king.james.bible.android.R;
import king.james.bible.android.db.BibleDataBase;
import king.james.bible.android.dialog.DialogUtil;
import king.james.bible.android.event.UpdatePageEvent;
import king.james.bible.android.fragment.FragmentCallbackListener;
import king.james.bible.android.model.chapter.ChapterSubChapterCursorResult;
import king.james.bible.android.service.PowerManagerService;
import king.james.bible.android.utils.BiblePreferences;
import king.james.bible.android.utils.ScreenUtil;
import org.greenrobot.eventbus.EventBus;
@SuppressLint({"NewApi", "WrongConstant"})

public abstract class BaseSpanFragment extends Fragment implements View.OnClickListener, TextView.OnEditorActionListener, AdapterView.OnItemLongClickListener {
     static  LinearLayout r1;
    private  long r222;
    private  LinearLayout r22;
    private  Handler r21;
      Long r3;
    private LinearLayout.LayoutParams r2;
    protected long DEBOUNCE_INTERVAL_MILLISECONDS = 600;
    protected BibleDataBase bibleDB;
    FragmentCallbackListener fragmentListener;
    protected long lastActionTime = 0;
    protected BiblePreferences preferences;
    private EditText searchEdit;
    protected String searchText = BuildConfig.FLAVOR;
    private LinearLayout slider;

    /* access modifiers changed from: protected */
    public abstract int getRootViewId();

    /* access modifiers changed from: protected */
    public abstract void makeSearch();

    /* access modifiers changed from: protected */
    public abstract void mapViews(View view);

    /* access modifiers changed from: protected */
    public abstract void notifyDataSetChanged();

    /* access modifiers changed from: protected */
    public static void removeItem(long j) {
    }

    /* access modifiers changed from: protected */
    public abstract void updateWidth();

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Context context) {
        super.onAttach(context);
        try {
            this.fragmentListener = (FragmentCallbackListener) getActivity();
        } catch (ClassCastException unused) {
            throw new ClassCastException(getActivity().toString() + " must implement OnHeadlineSelectedListener");
        }
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        BiblePreferences instance = BiblePreferences.getInstance();
        this.preferences = instance;
        instance.lambda$restoreAsync$0$BiblePreferences();
        BibleDataBase instance2 = BibleDataBase.getInstance();
        this.bibleDB = instance2;
        instance2.initColumSearchName();
        View inflate = layoutInflater.inflate(getRootViewId(), (ViewGroup) null);
        initToolBar(inflate);
        mapViews(inflate);
        PowerManagerService.getInstance().start();
        return inflate;
    }

    private void initToolBar(View view) {
        view.findViewById(R.id.span_page_back_btn).setOnClickListener(this);
        view.findViewById(R.id.span_page_search_btn).setOnClickListener(this);
        this.slider = (LinearLayout) view.findViewById(R.id.span_search_slider);
        EditText editText = (EditText) view.findViewById(R.id.span_page_search_text);
        this.searchEdit = editText;
        editText.setOnEditorActionListener(this);
        this.searchEdit.addTextChangedListener(new TextWatcher() {
            /* class king.james.bible.android.fragment.span.BaseSpanFragment.AnonymousClass1 */

            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void afterTextChanged(Editable editable) {
                try {
                    BaseSpanFragment.this.searchText = editable.toString();
                    if (BaseSpanFragment.this.searchText.length() < 1) {
                        BaseSpanFragment.this.searchText = BuildConfig.FLAVOR;
                    }
                    BaseSpanFragment.this.makeSearch();
                } catch (Exception unused) {
                }
            }
        });
        if (!this.searchText.isEmpty()) {
            this.searchEdit.setText(this.searchText);
            this.searchEdit.requestFocus();
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.slider.getLayoutParams();
            layoutParams.rightMargin = 5;
            this.slider.setLayoutParams(layoutParams);
            this.slider.requestLayout();
        }
    }

    public void onClick(View view) {
        PowerManagerService.getInstance().start();
        switch (view.getId()) {
            case R.id.span_page_back_btn:
                ScreenUtil.getInstance().hideKeyboard(getActivity());
                if (getActivity() != null) {
                    getActivity().onBackPressed();
                    break;
                }
                break;
            case R.id.span_page_search_btn:
                LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.slider.getLayoutParams();
                ValueAnimator ofInt = ValueAnimator.ofInt(layoutParams.rightMargin, 5);
                ofInt.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                    /* class king.james.bible.android.fragment.span.$$Lambda$BaseSpanFragment$m1T2E5Zh30B45UOwFwTcrWTgCs */
                    private final /* synthetic */ LinearLayout.LayoutParams f$1;

                    {
                        this.f$1 = r2;
                    }

                    public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                        BaseSpanFragment.this.lambda$onClick$0$BaseSpanFragment(this.f$1, valueAnimator);
                    }
                });
                ofInt.addListener(new Animator.AnimatorListener() {
                    /* class king.james.bible.android.fragment.span.BaseSpanFragment.AnonymousClass2 */

                    public void onAnimationCancel(Animator animator) {
                    }

                    public void onAnimationRepeat(Animator animator) {
                    }

                    public void onAnimationStart(Animator animator) {
                    }

                    public void onAnimationEnd(Animator animator) {
                        if (BaseSpanFragment.this.searchEdit != null) {
                            BaseSpanFragment.this.searchEdit.requestFocus();
                            ScreenUtil.getInstance().showKeyboard(BaseSpanFragment.this.searchEdit);
                        }
                    }
                });
                ofInt.setDuration(500L);
                ofInt.start();
                break;
        }
        PowerManagerService.getInstance().start();
    }

    public /* synthetic */ void lambda$onClick$0$BaseSpanFragment(LinearLayout.LayoutParams layoutParams, ValueAnimator valueAnimator) {
        layoutParams.rightMargin = ((Integer) valueAnimator.getAnimatedValue()).intValue();
        this.slider.requestLayout();
    }

    public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
        if (i == 3) {
            try {
                runSearch();
                return true;
            } catch (Exception unused) {
            }
        }
        return false;
    }

    @Override // androidx.fragment.app.Fragment
    public void onPause() {
        ScreenUtil.getInstance().hideKeyboard(this.searchEdit);
        super.onPause();
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroy() {
        DialogUtil.hideProgressDialog();
        super.onDestroy();
    }

    private void runSearch() {
        DialogUtil.showProgressDialog();
        new Thread(new Runnable() {
            /* class king.james.bible.android.fragment.span.$$Lambda$BaseSpanFragment$U2mEgcHXVGw1342gKrG8FoaXa1A */
            private final /* synthetic */ Handler f$1;

            {
                this.f$1 = r21;
            }

            public final void run() {
                BaseSpanFragment.this.lambda$runSearch$1$BaseSpanFragment(this.f$1);
            }
        }).start();
    }

    public /* synthetic */ void lambda$runSearch$1$BaseSpanFragment(Handler handler) {
        handler.postDelayed(new Runnable() {
            /* class king.james.bible.android.fragment.span.$$Lambda$6bz1SwOw_wVfM1Y56zAR6HMd06M */

            public final void run() {
                BaseSpanFragment.this.makeSearch();
            }
        }, 200);
    }

    @Override // android.widget.AdapterView.OnItemLongClickListener
    public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long j) {
        showItemDeleteView(view);
        return true;
    }

    /* access modifiers changed from: package-private */
    public static void showItemDeleteView(View view) {
        PowerManagerService.getInstance().start();
        RelativeLayout relativeLayout = (RelativeLayout) view;
        LinearLayout linearLayout = (LinearLayout) relativeLayout.getChildAt(1);
        linearLayout.setVisibility(0);
        linearLayout.getLayoutParams().height = view.getMeasuredHeight();
        ((Button) linearLayout.findViewById(R.id.span_item_delete)).setOnClickListener(new View.OnClickListener(linearLayout, (Long) ((RelativeLayout) relativeLayout.getChildAt(0)).getChildAt(2).getTag()) {
            /* class king.james.bible.android.fragment.span.$$Lambda$BaseSpanFragment$p5tdg_R9X4lbItsTzG5VpRungVs */
            private final /* synthetic */ LinearLayout f$1;
            private final /* synthetic */ Long f$2;

            {
                this.f$1 = r22;
                this.f$2 = r3;
            }

            public final void onClick(View view) {
               lambda$showItemDeleteView$2$BaseSpanFragment(this.f$1, this.f$2, view);
            }
        });
        linearLayout.findViewById(R.id.span_item_cancel).setOnClickListener(new View.OnClickListener(linearLayout) {
            /* class king.james.bible.android.fragment.span.$$Lambda$BaseSpanFragment$FX2ZwJ5mzc50gFce5v8GPGaCu88 */
            private final /* synthetic */ LinearLayout f$0;

            {
                this.f$0 = r1;
            }

            public final void onClick(View view) {
                BaseSpanFragment.showItemDeleteView( view);
            }
        });
        PowerManagerService.getInstance().start();
    }

    public static /* synthetic */ void lambda$showItemDeleteView$2$BaseSpanFragment(LinearLayout linearLayout, Long l, View view) {
        linearLayout.setVisibility(8);
        DialogUtil.showProgressDialog();
        removeItem(l.longValue());
    }

    @Override // androidx.fragment.app.Fragment
    public void onConfigurationChanged(Configuration configuration) {
        DialogUtil.hideProgressDialog();
        super.onConfigurationChanged(configuration);
        updateWidth();
        notifyDataSetChanged();
    }

    /* access modifiers changed from: package-private */
    public Long getTag(View view) {
        return (Long) ((RelativeLayout) ((RelativeLayout) view).getChildAt(0)).getChildAt(2).getTag();
    }

    /* access modifiers changed from: package-private */
    public boolean executeAction() {
        long elapsedRealtime = SystemClock.elapsedRealtime();
        boolean z = elapsedRealtime - this.lastActionTime > this.DEBOUNCE_INTERVAL_MILLISECONDS;
        this.lastActionTime = elapsedRealtime;
        if (z) {
            PowerManagerService.getInstance().start();
        }
        return z;
    }

    /* access modifiers changed from: package-private */
    public void moveToReadingScreen(View view) {
        Long tag = getTag(view);
        if (tag != null) {
            moveToReadingScreen(tag.longValue());
        } else if (getActivity() != null) {
            getActivity().onBackPressed();
        }
    }

    private void moveToReadingScreen(long j) {
        new Thread(new Runnable() {
            /* class king.james.bible.android.fragment.span.$$Lambda$BaseSpanFragment$5FTJ9au9hkHIy3sr4uhT6QSDN0Q */
            private final /* synthetic */ long f$1;

            {
                this.f$1 = r222;
            }

            public final void run() {
                BaseSpanFragment.this.lambda$moveToReadingScreen$4$BaseSpanFragment(this.f$1);
            }
        }).start();
    }

    public /* synthetic */ void lambda$moveToReadingScreen$4$BaseSpanFragment(long j) throws Throwable {
        ChapterSubChapterCursorResult allStuffById = this.bibleDB.getAllStuffById(j);
        moveToReadingScreen(allStuffById, this.bibleDB.getRankByChapter(allStuffById.getChapter(), allStuffById.getSubChapter() + 1, allStuffById.getPosition()));
    }

    private void moveToReadingScreen(final ChapterSubChapterCursorResult chapterSubChapterCursorResult, final int i) {
        if (getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() {
                /* class king.james.bible.android.fragment.span.BaseSpanFragment.AnonymousClass3 */

                public void run() {
                    if (BaseSpanFragment.this.getActivity() != null) {
                        BaseSpanFragment.this.getActivity().onBackPressed();
                    }
                    BaseSpanFragment baseSpanFragment = BaseSpanFragment.this;
                    if (baseSpanFragment.fragmentListener != null) {
                        baseSpanFragment.moveToReadingScreenFromUI(chapterSubChapterCursorResult, i);
                    }
                }
            });
        }
    }

    /* access modifiers changed from: protected */
    public void moveToReadingScreenFromUI(ChapterSubChapterCursorResult chapterSubChapterCursorResult, int i) {
        this.fragmentListener.onFragmentResultOk(chapterSubChapterCursorResult.getChapter(), chapterSubChapterCursorResult.getSubChapter(), chapterSubChapterCursorResult.getPosition() - 1, i, this);
    }

    /* access modifiers changed from: protected */
    public void postDelete() {
        EventBus.getDefault().post(new UpdatePageEvent());
    }
}
