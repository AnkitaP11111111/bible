package king.james.bible.android.appad;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import king.james.bible.android.R;
import king.james.bible.android.utils.BiblePreferences;

public class AppDialog {
    public static void show(final Context context, final AppAd appAd) {
        if (context != null) {
            try {
                View inflate = LayoutInflater.from(context).inflate(BiblePreferences.getInstance().isNightMode() ? R.layout.fragment_app_ad_dialog_n : R.layout.fragment_app_ad_dialog, (ViewGroup) null, false);
                AlertDialog.Builder builder = new AlertDialog.Builder(context, 2131821102);
                builder.setView(inflate);
                builder.setCancelable(true);
                final AlertDialog create = builder.create();
                ((TextView) inflate.findViewById(R.id.titleTextView)).setText(Html.fromHtml(appAd.getName()));
                ((TextView) inflate.findViewById(R.id.textTextView)).setText(Html.fromHtml(appAd.getText()));
                inflate.findViewById(R.id.closeImageButton).setOnClickListener(new View.OnClickListener() {
                    /* class king.james.bible.android.appad.AppDialog.AnonymousClass1 */

                    public void onClick(View view) {
                        AppAdStorage.getInstance().restoreStartCount(appAd.getId());
                        AppDialog.dismiss(create);
                    }
                });
                inflate.findViewById(R.id.neverRemindButton).setOnClickListener(new View.OnClickListener() {
                    /* class king.james.bible.android.appad.AppDialog.AnonymousClass2 */

                    public void onClick(View view) {
                        AppAdStorage.getInstance().clearStartCount(appAd.getId());
                        AppDialog.dismiss(create);
                    }
                });
                inflate.findViewById(R.id.laterButton).setOnClickListener(new View.OnClickListener() {
                    /* class king.james.bible.android.appad.AppDialog.AnonymousClass3 */

                    public void onClick(View view) {
                        AppAdStorage.getInstance().restoreStartCount(appAd.getId());
                        AppDialog.dismiss(create);
                    }
                });
                inflate.findViewById(R.id.downloadButton).setOnClickListener(new View.OnClickListener() {
                    /* class king.james.bible.android.appad.AppDialog.AnonymousClass4 */

                    public void onClick(View view) {
                        AppAdStorage.getInstance().clearStartCount(appAd.getId());
                        AppDialog.dismiss(create);
                        AppDialog.openMarketPage(context, appAd.getUrl());
                    }
                });
                create.setOnCancelListener(new DialogInterface.OnCancelListener() {
                    /* class king.james.bible.android.appad.AppDialog.AnonymousClass5 */

                    public void onCancel(DialogInterface dialogInterface) {
                        AppAdStorage.getInstance().restoreStartCount(appAd.getId());
                    }
                });
                create.show();
            } catch (Exception unused) {
            }
        }
    }

    /* access modifiers changed from: private */
    public static void dismiss(AlertDialog alertDialog) {
        try {
            alertDialog.dismiss();
        } catch (Exception unused) {
        }
    }

    /* access modifiers changed from: private */
    public static void openMarketPage(Context context, String str) {
        if (context != null) {
            try {
                context.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(str)));
            } catch (Exception unused) {
            }
        }
    }
}
