package king.james.bible.android.sound.holder;

import android.annotation.SuppressLint;
import android.os.Build;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import king.james.bible.android.R;
import java.util.Set;
import king.james.bible.android.sound.SoundHelper;
import king.james.bible.android.sound.listener.page.SoundInitListener;
import king.james.bible.android.sound.listener.page.SoundPlayListener;
import king.james.bible.android.sound.model.SoundButtonModel;
import king.james.bible.android.sound.util.DrawableUtil;
import king.james.bible.android.sound.util.SoundAction;
@SuppressLint({"NewApi", "WrongConstant"})

public class SoundButtonHolder {
    private int pagePosition;
    private ProgressBar playProgressBar;
    private int rank;
    private ProgressBar repeatProgressBar;
    private Button soundButton;
    private SoundButtonHolderListener soundButtonHolderListener;
    private SoundInitListener soundInitListener;
    private View.OnClickListener soundOnclickListener = new View.OnClickListener() {
        /* class king.james.bible.android.sound.holder.SoundButtonHolder.AnonymousClass1 */

        public void onClick(View view) {
            SoundButtonHolder.this.onSoundClick();
        }
    };
    private SoundPlayListener soundPlayListener;
    private Button soundRepeatButton;
    private View.OnClickListener soundRepeatOnclickListener = new View.OnClickListener() {
        /* class king.james.bible.android.sound.holder.SoundButtonHolder.AnonymousClass2 */

        public void onClick(View view) {
            SoundButtonHolder.this.onSoundRepeatClick();
        }
    };
    private View soundRootContainer;

    public interface SoundButtonHolderListener {
        void setSoundViewAlpha(int i);
    }

    public void showButton() {
    }

    public static SoundButtonHolder create(View view, SoundButtonModel soundButtonModel, SoundInitListener soundInitListener2, SoundButtonHolderListener soundButtonHolderListener2) {
        return new SoundButtonHolder(view, soundButtonModel, soundInitListener2, soundButtonHolderListener2);
    }

    protected SoundButtonHolder(View view, SoundButtonModel soundButtonModel, SoundInitListener soundInitListener2, SoundButtonHolderListener soundButtonHolderListener2) {
        this.soundInitListener = soundInitListener2;
        this.soundButtonHolderListener = soundButtonHolderListener2;
        this.soundRootContainer = view;
        init(view, soundButtonModel);
    }

    private void init(View view, SoundButtonModel soundButtonModel) {
        if (view != null) {
            this.soundButton = (Button) view.findViewById(R.id.sound_item_button);
            this.soundRepeatButton = (Button) view.findViewById(R.id.sound_repeat_item_button);
            this.playProgressBar = (ProgressBar) view.findViewById(R.id.playProgressBar);
            this.repeatProgressBar = (ProgressBar) view.findViewById(R.id.repeatProgressBar);
            if (soundButtonModel != null) {
                this.pagePosition = soundButtonModel.getPagePosition();
                this.rank = soundButtonModel.getRank();
            }
            this.soundButton.setOnClickListener(this.soundOnclickListener);
            Button button = this.soundRepeatButton;
            if (button != null) {
                button.setOnClickListener(this.soundRepeatOnclickListener);
            }
            preparePauseBackground();
            prepareRepeatPauseBackground();
            updateButtonsAlpha();
        }
    }

    public void setModels(int i, int i2) {
        this.pagePosition = i;
        this.rank = i2;
    }

    public int getRank() {
        return this.rank;
    }

    public void setRank(int i) {
        this.rank = i;
    }

    /* access modifiers changed from: protected */
    public void onSoundRepeatClick() {
        if (SoundHelper.getInstance().isPlayRepeatItem(this.pagePosition, this.rank)) {
            pauseRepeat();
        } else {
            playRepeat();
        }
    }

    public boolean isPlay() {
        return SoundHelper.getInstance().isPlayItem(this.pagePosition, this.rank);
    }

    public boolean isPlayRepeat() {
        return SoundHelper.getInstance().isPlayRepeatItem(this.pagePosition, this.rank);
    }

    /* access modifiers changed from: protected */
    public void onSoundClick() {
        if (SoundHelper.getInstance().isPlayItem(this.pagePosition, this.rank)) {
            pause();
        } else {
            play();
        }
    }

    /* access modifiers changed from: protected */
    public void play() {
        prepareRepeatPauseBackground();
        this.soundButton.setVisibility(0);
        SoundHelper.getInstance().play(this.pagePosition, this.rank, this.soundInitListener);
        preparePlayBackground();
        SoundPlayListener soundPlayListener2 = this.soundPlayListener;
        if (soundPlayListener2 != null) {
            soundPlayListener2.onSoundPlay(this.rank);
        }
    }

    public void pause() {
        SoundHelper.getInstance().pause();
        preparePauseBackground();
    }

    /* access modifiers changed from: protected */
    public void playRepeat() {
        preparePauseBackground();
        Button button = this.soundRepeatButton;
        if (button != null) {
            button.setVisibility(0);
        }
        Set<Integer> set = null;
        SoundPlayListener soundPlayListener2 = this.soundPlayListener;
        if (soundPlayListener2 != null) {
            set = soundPlayListener2.getSelectedSoundRepeatSet();
        }
        SoundHelper.getInstance().playRepeat(this.pagePosition, this.rank, set, this.soundInitListener);
        prepareRepeatPlayBackground();
    }

    public void pauseRepeat() {
        SoundHelper.getInstance().pause();
        prepareRepeatPauseBackground();
    }

    public void hideButton() {
        preparePauseBackground();
        prepareRepeatPauseBackground();
        hidePlayProgressBar();
        hideRepeatProgressBar();
        this.soundRootContainer.setVisibility(8);
        this.soundButton.setVisibility(8);
        Button button = this.soundRepeatButton;
        if (button != null) {
            button.setVisibility(8);
        }
    }

    public void preparePlayBackground() {
        if (Build.VERSION.SDK_INT >= 16) {
            this.soundButton.setBackground(DrawableUtil.getInstance().getDrawable(SoundAction.PAUSE_ACTION));
        } else {
            this.soundButton.setBackgroundResource(DrawableUtil.getInstance().getResourceByAction(SoundAction.PAUSE_ACTION));
        }
        updateButtonsAlpha();
    }

    public void prepareRepeatPlayBackground() {
        Button button = this.soundRepeatButton;
        if (button != null) {
            if (Build.VERSION.SDK_INT >= 16) {
                button.setBackground(DrawableUtil.getInstance().getDrawable(SoundAction.PAUSE_REPEAT_ACTION));
            } else {
                button.setBackgroundResource(DrawableUtil.getInstance().getResourceByAction(SoundAction.PAUSE_REPEAT_ACTION));
            }
            updateButtonsAlpha();
        }
    }

    public void preparePauseBackground() {
        if (Build.VERSION.SDK_INT >= 16) {
            this.soundButton.setBackground(DrawableUtil.getInstance().getDrawable(SoundAction.PLAY_ACTION));
        } else {
            this.soundButton.setBackgroundResource(DrawableUtil.getInstance().getResourceByAction(SoundAction.PLAY_ACTION));
        }
        updateButtonsAlpha();
    }

    public void prepareRepeatPauseBackground() {
        Button button = this.soundRepeatButton;
        if (button != null) {
            if (Build.VERSION.SDK_INT >= 16) {
                button.setBackground(DrawableUtil.getInstance().getDrawable(SoundAction.PLAY_REPEAT_ACTION));
            } else {
                button.setBackgroundResource(DrawableUtil.getInstance().getResourceByAction(SoundAction.PLAY_REPEAT_ACTION));
            }
            updateButtonsAlpha();
        }
    }

    public Button getSoundButton() {
        return this.soundButton;
    }

    public Button getSoundRepeatButton() {
        return this.soundRepeatButton;
    }

    public void clearBitmap() {
        if (Build.VERSION.SDK_INT >= 16) {
            this.soundButton.setBackground(null);
            Button button = this.soundRepeatButton;
            if (button != null) {
                button.setBackground(null);
                return;
            }
            return;
        }
        this.soundButton.setBackgroundResource(17170445);
        Button button2 = this.soundRepeatButton;
        if (button2 != null) {
            button2.setBackgroundResource(17170445);
        }
    }

    public void setSoundPlayListener(SoundPlayListener soundPlayListener2) {
        this.soundPlayListener = soundPlayListener2;
    }

    public void showProgress() {
        if (SoundHelper.getInstance().isPlayItem(this.pagePosition, this.rank)) {
            showPlayProgressBar();
        }
        if (SoundHelper.getInstance().isPlayRepeatItem(this.pagePosition, this.rank)) {
            showRepeatProgressBar();
        }
    }

    public void hideProgress() {
        hidePlayProgressBar();
        hideRepeatProgressBar();
        this.soundButton.setVisibility(0);
        Button button = this.soundRepeatButton;
        if (button != null) {
            button.setVisibility(0);
        }
    }

    private void showPlayProgressBar() {
        ProgressBar progressBar = this.playProgressBar;
        if (progressBar != null) {
            progressBar.setVisibility(0);
        }
    }

    private void hidePlayProgressBar() {
        ProgressBar progressBar = this.playProgressBar;
        if (progressBar != null) {
            progressBar.setVisibility(8);
        }
    }

    private void showRepeatProgressBar() {
        ProgressBar progressBar = this.repeatProgressBar;
        if (progressBar != null) {
            progressBar.setVisibility(0);
        }
    }

    private void hideRepeatProgressBar() {
        ProgressBar progressBar = this.repeatProgressBar;
        if (progressBar != null) {
            progressBar.setVisibility(8);
        }
    }

    private void updateButtonsAlpha() {
        updateButtonsAlpha(isPlay() || isPlayRepeat());
    }

    private void updateButtonsAlpha(boolean z) {
        int i = z ? 100 : 255;
        SoundButtonHolderListener soundButtonHolderListener2 = this.soundButtonHolderListener;
        if (soundButtonHolderListener2 != null) {
            soundButtonHolderListener2.setSoundViewAlpha(i);
        }
        if (this.soundButton.getVisibility() == 0) {
            Button button = this.soundButton;
            if (!(button == null || button.getBackground() == null)) {
                try {
                    this.soundButton.getBackground().setAlpha(i);
                    this.soundButton.invalidate();
                } catch (Exception unused) {
                }
            }
            Button button2 = this.soundRepeatButton;
            if (button2 != null && button2.getBackground() != null) {
                try {
                    this.soundRepeatButton.getBackground().setAlpha(i);
                    this.soundRepeatButton.invalidate();
                } catch (Exception unused2) {
                }
            }
        }
    }
}
