package king.james.bible.android.dialog;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.app.AlertDialog;
import king.james.bible.android.R;
import java.util.List;
import king.james.bible.android.db.service.DailyReadingDataService;
import king.james.bible.android.model.PlanDay;
import king.james.bible.android.model.PlanMode;
import king.james.bible.android.utils.BiblePreferences;
import king.james.bible.android.view.SelectPlanDialogView;

public class StartPlanDialog {
    private static long lastOpen;

    public interface StartPlanListener {
        void onSelectStartDay(int i);
    }

    public static void show(Context context, final StartPlanListener startPlanListener, final long j, final PlanMode planMode) {
        if (lastOpen + 500 <= System.currentTimeMillis()) {
            lastOpen = System.currentTimeMillis();
            final SelectPlanDialogView selectPlanDialogView = (SelectPlanDialogView) LayoutInflater.from(context).inflate(BiblePreferences.getInstance().isDayMode() ? R.layout.start_plan_dialog : R.layout.start_plan_dialog_n, (ViewGroup) null, false);
            try {
                selectPlanDialogView.init(planMode.getDayCount());
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setView(selectPlanDialogView);
                builder.setCancelable(false);
                final AlertDialog create = builder.create();
                create.show();
                selectPlanDialogView.setOnDoneListener(new View.OnClickListener() {
                    /* class king.james.bible.android.dialog.StartPlanDialog.AnonymousClass1 */

                    public void onClick(View view) {
                        selectPlanDialogView.stopObservable();
                        try {
                            create.dismiss();
                        } catch (Exception unused) {
                        }
//                        StartPlanListener startPlanListener = startPlanListener;
                        if (startPlanListener != null) {
                            startPlanListener.onSelectStartDay(selectPlanDialogView.getValue());
                        }
                    }
                });
                selectPlanDialogView.setOnCancelListener(new View.OnClickListener() {
                    /* class king.james.bible.android.dialog.StartPlanDialog.AnonymousClass2 */

                    public void onClick(View view) {
                        selectPlanDialogView.stopObservable();
                        try {
                            create.dismiss();
                        } catch (Exception unused) {
                        }
                    }
                });
                new Thread(new Runnable() {
                    /* class king.james.bible.android.dialog.StartPlanDialog.AnonymousClass3 */

                    public void run() {
                        final List<PlanDay> daysStartPlan = new DailyReadingDataService().getDaysStartPlan(j, planMode.getId());
//                        SelectPlanDialogView selectPlanDialogView = selectPlanDialogView;
                        if (selectPlanDialogView != null && daysStartPlan != null) {
                            selectPlanDialogView.post(new Runnable() {
                                /* class king.james.bible.android.dialog.StartPlanDialog.AnonymousClass3.AnonymousClass1 */

                                public void run() {
                                    selectPlanDialogView.setModels(daysStartPlan);
                                }
                            });
                        }
                    }
                }).start();
            } catch (Exception unused) {
            }
        }
    }
}
