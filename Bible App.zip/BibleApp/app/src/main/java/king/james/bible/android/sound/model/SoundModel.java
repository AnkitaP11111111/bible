package king.james.bible.android.sound.model;

import java.util.List;
import king.james.bible.android.model.Text;

public class SoundModel {
    private String chapter;
    private int pagePosition;
    private int rank;
    private int subChapter;
    private List<Text> textList;

    public SoundModel(int i, int i2) {
        this.pagePosition = i;
        this.rank = i2;
    }

    public int getPagePosition() {
        return this.pagePosition;
    }

    public int getRank() {
        return this.rank;
    }

    public void setRank(int i) {
        this.rank = i;
    }

    public String getChapter() {
        return this.chapter;
    }

    public void setChapter(String str) {
        this.chapter = str;
    }

    public int getSubChapter() {
        return this.subChapter;
    }

    public void setSubChapter(int i) {
        this.subChapter = i;
    }

    public List<Text> getTextList() {
        return this.textList;
    }

    public void setTextList(List<Text> list) {
        this.textList = list;
    }
}
