package king.james.bible.android.adapter.array;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import king.james.bible.android.R;
import java.util.List;
import king.james.bible.android.utils.BiblePreferences;

public abstract class BaseSpinnerAdapter<T> extends ArrayAdapter<T> {
    private BiblePreferences prefs = BiblePreferences.getInstance();

    public long getItemId(int i) {
        return (long) i;
    }

    /* access modifiers changed from: protected */
    public abstract String getViewText(int i);

    protected static int layoutResource() {
        return BiblePreferences.getInstance().isNightMode() ? R.layout.font_spinner_item_layout_n : R.layout.font_spinner_item_layout;
    }

    public BaseSpinnerAdapter(Context context, int i, T[] tArr) {
        super(context, i, tArr);
    }

    public BaseSpinnerAdapter(Context context, int i, List<T> list) {
        super(context, i, list);
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater from = LayoutInflater.from(viewGroup.getContext());
        this.prefs.lambda$restoreAsync$0$BiblePreferences();
        View inflate = from.inflate(this.prefs.isNightMode() ? R.layout.font_spinner_item_layout_n : R.layout.font_spinner_item_layout, viewGroup, false);
        ((TextView) inflate.findViewById(R.id.font_spinner_text1)).setText(getViewText(i));
        return inflate;
    }

    public View getDropDownView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater from = LayoutInflater.from(viewGroup.getContext());
        this.prefs.lambda$restoreAsync$0$BiblePreferences();
        View inflate = from.inflate(this.prefs.isNightMode() ? R.layout.font_spinner_row_layout_n : R.layout.font_spinner_row_layout, viewGroup, false);
        ((TextView) inflate.findViewById(R.id.font_spinner_row_text1)).setText(getViewText(i));
        return inflate;
    }
}
