package king.james.bible.android.appad;

import android.content.Context;
import king.james.bible.android.R;
import java.util.List;
import king.james.bible.android.task.BaseTask;
import king.james.bible.android.utils.AppUtils;
import king.james.bible.android.utils.BibleToast;

public class AppAdService {
    public static void loadDialogs(final Context context) {
        if (AppUtils.isNetworkAvailable(context)) {
            new GetAppAdTask(context, new BaseTask.OnCallbackHandler<List<AppAd>>() {
                /* class king.james.bible.android.appad.AppAdService.AnonymousClass1 */

                public void onSuccess(List<AppAd> list) {
                }

                @Override // king.james.bible.android.task.BaseTask.OnCallbackHandler
                public void onError(Exception exc) {
                    BibleToast.showShortDurationToast(context, R.string.error);
                }
            }).executeAsyncTask(new Void[0]);
        }
    }

    public static void showDialog(Context context) {
        AppAd appAdModel;
        if (context != null && AppUtils.isNetworkAvailable(context) && (appAdModel = AppAdStorage.getInstance().getAppAdModel()) != null) {
            AppDialog.show(context, appAdModel);
        }
    }
}
