package king.james.bible.android.view;

import java.util.Timer;
import java.util.TimerTask;
import king.james.bible.android.view.NumberPicker;

public class NumberPickerObservable {
    private long delay;
    private int lastValue;
    private NumberPickerChangeListener listener;
    private boolean newValue;
    private NumberPicker numberPicker;
    private Timer timer;

    public interface NumberPickerChangeListener {
        void onChange(int i);
    }

    public NumberPickerObservable(NumberPicker numberPicker2, long j, NumberPickerChangeListener numberPickerChangeListener) {
        this.numberPicker = numberPicker2;
        this.delay = j;
        this.listener = numberPickerChangeListener;
        numberPicker2.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            /* class king.james.bible.android.view.NumberPickerObservable.AnonymousClass1 */

            @Override // king.james.bible.android.view.NumberPicker.OnValueChangeListener
            public void onValueChange(NumberPicker numberPicker, int i, int i2) {
                if (i2 != NumberPickerObservable.this.lastValue) {
                    NumberPickerObservable.this.newValue = true;
                    NumberPickerObservable.this.lastValue = i2;
                }
            }
        });
        startTimer();
    }

    private void startTimer() {
        Timer timer2 = new Timer();
        this.timer = timer2;
        timer2.schedule(new TimerTask() {
            /* class king.james.bible.android.view.NumberPickerObservable.AnonymousClass2 */

            public void run() {
                if (NumberPickerObservable.this.numberPicker == null) {
                    NumberPickerObservable.this.timer.cancel();
                } else if (NumberPickerObservable.this.listener != null && NumberPickerObservable.this.newValue) {
                    NumberPickerObservable.this.newValue = false;
                    NumberPickerObservable.this.numberPicker.post(new Runnable() {
                        /* class king.james.bible.android.view.NumberPickerObservable.AnonymousClass2.AnonymousClass1 */

                        public void run() {
                            NumberPickerObservable.this.listener.onChange(NumberPickerObservable.this.lastValue);
                        }
                    });
                }
            }
        }, 1000, this.delay);
    }

    public void stop() {
        Timer timer2 = this.timer;
        if (timer2 != null) {
            timer2.cancel();
        }
    }
}
