package king.james.bible.android.service.observable;

import java.util.HashSet;
import java.util.Set;
import king.james.bible.android.dialog.DeleteDialog;

public class DeleteListenerObservable implements DeleteDialog.DeleteListener {
    private static DeleteListenerObservable instance;
    private Set<DeleteDialog.DeleteListener> listeners;

    private DeleteListenerObservable() {
    }

    public static DeleteListenerObservable getInstance() {
        if (instance == null) {
            synchronized (DeleteListenerObservable.class) {
                if (instance == null) {
                    instance = new DeleteListenerObservable();
                }
            }
        }
        return instance;
    }

    public void subscribe(DeleteDialog.DeleteListener deleteListener) {
        checkList();
        this.listeners.add(deleteListener);
    }

    public void remove(DeleteDialog.DeleteListener deleteListener) {
        checkList();
        this.listeners.remove(deleteListener);
    }

    private void checkList() {
        if (this.listeners == null) {
            this.listeners = new HashSet();
        }
    }

    @Override // king.james.bible.android.dialog.DeleteDialog.DeleteListener
    public void selectYes(long j, int i) {
        checkList();
        for (DeleteDialog.DeleteListener deleteListener : this.listeners) {
            if (deleteListener != null) {
                deleteListener.selectYes(j, i);
            }
        }
    }

    @Override // king.james.bible.android.dialog.DeleteDialog.DeleteListener
    public void selectNo() {
        checkList();
        for (DeleteDialog.DeleteListener deleteListener : this.listeners) {
            if (deleteListener != null) {
                deleteListener.selectNo();
            }
        }
    }
}
