package king.james.bible.android.utils;

import android.os.Environment;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import king.james.bible.android.model.UpdateRecord;
import king.james.bible.android.utils.builder.DailyReadingBuilder;
import king.james.bible.android.utils.builder.DailyVerseModelsBuilder;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ExportImportUtil {
    private static ExportImportUtil instance;

    private ExportImportUtil() {
    }

    public static ExportImportUtil getInstance() {
        if (instance == null) {
            synchronized (ExportImportUtil.class) {
                if (instance == null) {
                    instance = new ExportImportUtil();
                }
            }
        }
        return instance;
    }

    private File getFile(String str) {
        File file = new File((Environment.getExternalStorageDirectory().getAbsolutePath() + "/Bible/") + str);
        if (!file.exists()) {
            file.getParentFile().mkdir();
            try {
                file.createNewFile();
            } catch (IOException unused) {
            }
        }
        return file;
    }

    public File isFile() {
        File file = new File((Environment.getExternalStorageDirectory().getAbsolutePath() + "/Bible/") + "bible_" + ".setting");
        if (file.exists()) {
            return file;
        }
        return null;
    }

    private void addField(PrintWriter printWriter, String str) {
        printWriter.write(str);
        printWriter.write("\r\n");
    }

    private PrintWriter getPrintWriter(File file) throws IOException {
        return new PrintWriter(new BufferedWriter(new FileWriter(file, true)));
    }

    public File writeArray(JSONArray jSONArray) {
        File file = null;
        try {
            String format = new SimpleDateFormat("M-d_H_m").format(Calendar.getInstance().getTime());
            file = getFile("bible_" + format + ".setting");
            PrintWriter printWriter = getPrintWriter(file);
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("DataList", jSONArray);
            jSONObject.put("DailyVerses", DailyVerseModelsBuilder.getDailyVerses());
            jSONObject.put("DailyReading", DailyReadingBuilder.getDailyReading());
            BiblePreferences instance2 = BiblePreferences.getInstance();
            instance2.lambda$restoreAsync$0$BiblePreferences();
            JSONObject jSONObject2 = new JSONObject();
            jSONObject2.put("Font", instance2.getFontType());
            jSONObject2.put("NightMode", instance2.isNightMode());
            jSONObject2.put("Size", (double) instance2.getTextSize());
            jSONObject2.put("Spacing", (double) instance2.getSpacing());
            jSONObject2.put("italic_words", instance2.isItalicWords());
            jSONObject2.put("redletters_mode", instance2.isRedLettersMode());
            jSONObject2.put("screen_stay", instance2.isScreenStay());
            jSONObject.put("SettingList", jSONObject2);
            addField(printWriter, jSONObject.toString());
            printWriter.close();
            return file;
        } catch (Exception unused) {
            return file;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:18:0x0037, code lost:
        if (r1 != null) goto L_0x0026;
     */
    /* JADX WARNING: Removed duplicated region for block: B:12:0x0032 A[SYNTHETIC, Splitter:B:12:0x0032] */
    public List<UpdateRecord> readArray(File file, boolean z) {
        FileInputStream fileInputStream;
        Throwable th;
        FileInputStream fileInputStream2 = null;
        r0 = null;
        List<UpdateRecord> list = null;
        try {
            fileInputStream = new FileInputStream(file);
            try {
                FileChannel channel = fileInputStream.getChannel();
                list = readArray(Charset.defaultCharset().decode(channel.map(FileChannel.MapMode.READ_ONLY, 0, channel.size())).toString(), z);
            } catch (IOException unused) {
            } catch (Throwable th2) {
                th = th2;
                fileInputStream2 = fileInputStream;
                if (fileInputStream2 != null) {
                }
                throw th;
            }
        } catch (IOException unused2) {
            fileInputStream = null;
        } catch (Throwable th3) {
            th = th3;
            if (fileInputStream2 != null) {
                try {
                    fileInputStream2.close();
                } catch (Exception unused3) {
                }
            }
            throw th;
        }
        try {
            fileInputStream.close();
        } catch (Exception unused4) {
        }
        return list;
    }

    private List<UpdateRecord> readArray(String str, boolean z) {
        Long l;
        Integer num;
        Long l2;
        Integer num2;
        Long l3;
        String str2;
        ArrayList arrayList = null;
        try {
            JSONObject jSONObject = new JSONObject(str);
            writeDailyVerses(jSONObject);
            writeDailyReading(jSONObject);
            JSONArray jSONArray = jSONObject.getJSONArray("DataList");
            ArrayList arrayList2 = new ArrayList();
            for (int i = 0; i < jSONArray.length(); i++) {
                try {
                    JSONObject jSONObject2 = jSONArray.getJSONObject(i);
                    int i2 = jSONObject2.getInt("id");
                    if (!jSONObject2.isNull("bookmark")) {
                        num = Integer.valueOf(jSONObject2.getInt("bookmark"));
                        l = Long.valueOf(jSONObject2.getLong("bookmarkDate"));
                    } else {
                        num = null;
                        l = null;
                    }
                    if (!jSONObject2.isNull("highlight")) {
                        num2 = Integer.valueOf(jSONObject2.getInt("highlight"));
                        l2 = Long.valueOf(jSONObject2.getLong("highlightDate"));
                    } else {
                        num2 = null;
                        l2 = null;
                    }
                    if (!jSONObject2.isNull("note")) {
                        String string = jSONObject2.getString("note");
                        l3 = Long.valueOf(jSONObject2.getLong("noteDate"));
                        str2 = string;
                    } else {
                        str2 = null;
                        l3 = null;
                    }
                    arrayList2.add(new UpdateRecord(i2, num, num2, str2, l, l2, l3));
                } catch (JSONException unused) {
                    arrayList = arrayList2;
                    return arrayList;
                }
            }
            if (!z) {
                return arrayList2;
            }
            readSettings(jSONObject.getJSONObject("SettingList"));
            return arrayList2;
        } catch (JSONException unused2) {
            return arrayList;
        }
    }

    private void writeDailyVerses(JSONObject jSONObject) {
        try {
            DailyVerseModelsBuilder.writeDailyVerses(jSONObject.getJSONArray("DailyVerses"));
        } catch (Exception unused) {
        }
    }

    public static void writeDailyReading(JSONObject jSONObject) {
        try {
            DailyReadingBuilder.writeDailyReading(jSONObject.getJSONArray("DailyReading"));
        } catch (Exception unused) {
        }
    }

    private void readSettings(JSONObject jSONObject) throws JSONException {
        BiblePreferences instance2 = BiblePreferences.getInstance();
        instance2.lambda$restoreAsync$0$BiblePreferences();
        instance2.setTextSize((float) jSONObject.getDouble("Size"));
        instance2.setSpacing((float) jSONObject.getDouble("Spacing"));
        instance2.setFontType(jSONObject.getString("Font"));
        if (!jSONObject.isNull("italic_words")) {
            instance2.setItalicWords(jSONObject.getBoolean("italic_words"));
        }
        if (!jSONObject.isNull("redletters_mode")) {
            instance2.setRedLettersMode(jSONObject.getBoolean("redletters_mode"));
        }
        if (!jSONObject.isNull("screen_stay")) {
            instance2.setScreenStay(jSONObject.getBoolean("screen_stay"));
        }
        if (!jSONObject.isNull("NightMode")) {
            instance2.setNightMode(jSONObject.getBoolean("NightMode"));
        }
        instance2.lambda$saveBg$1$BiblePreferences();
    }
}
