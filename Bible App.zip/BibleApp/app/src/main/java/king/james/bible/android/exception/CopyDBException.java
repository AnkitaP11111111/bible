package king.james.bible.android.exception;

public class CopyDBException extends Exception {
}
