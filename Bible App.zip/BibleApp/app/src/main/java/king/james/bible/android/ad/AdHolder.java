//package king.james.bible.android.ad;
//
//import android.content.Context;
//
//public interface AdHolder {
//    void createAd(Context context);
//
//    void destroyAd();
//
//    void hideAdView();
//
//    void initAD(AdHolderListener adHolderListener);
//
//    void pauseAd();
//
//    void rebuildRequest();
//
//    void resumeAd();
//
//    void showAdView();
//}
