package king.james.bible.android.view;

import android.content.Context;
import android.text.format.DateFormat;
import android.util.AttributeSet;
import android.widget.LinearLayout;
import king.james.bible.android.R;
import java.util.concurrent.TimeUnit;
import king.james.bible.android.utils.DateUtil;

public class InputTimeView extends LinearLayout {
    private int MAX_HOUR_VALUE = 23;
    private int MIN_HOUR_VALUE = 0;
    private NumberPicker hoursPicker;
    private NumberPicker minutesPicker;
    private NumberPicker partPicker;

    private int get12AMHours(int i) {
        return i == 0 ? i + 12 : i;
    }

    private int get12PMHours(int i) {
        return i != 12 ? i - 12 : i;
    }

    private int getAMHours(int i) {
        return i == 12 ? i - 12 : i;
    }

    private int getPMHours(int i) {
        return i != 12 ? i + 12 : i;
    }

    public InputTimeView(Context context) {
        super(context);
    }

    public InputTimeView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public InputTimeView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    /* access modifiers changed from: protected */
    public void onFinishInflate() {
        super.onFinishInflate();
        if (!isInEditMode()) {
            this.hoursPicker = (NumberPicker) findViewById(R.id.hoursPicker);
            this.minutesPicker = (NumberPicker) findViewById(R.id.minutesPicker);
            this.partPicker = (NumberPicker) findViewById(R.id.partPicker);
            if (is24Mode()) {
                this.MIN_HOUR_VALUE = 0;
                this.MAX_HOUR_VALUE = 23;
                this.partPicker.setVisibility(8);
            } else {
                this.MIN_HOUR_VALUE = 1;
                this.MAX_HOUR_VALUE = 12;
                this.partPicker.setVisibility(0);
                initNumberPicker(this.partPicker, 1, 2);
                NumberPicker numberPicker = this.partPicker;
                numberPicker.setDisplayedValues(new String[]{DateUtil.getInstance().getDayPart(1) + "   ", DateUtil.getInstance().getDayPart(2) + "   "});
            }
            initNumberPicker(this.hoursPicker, this.MIN_HOUR_VALUE, this.MAX_HOUR_VALUE);
            initNumberPicker(this.minutesPicker, 0, 59);
        }
    }

    private void initNumberPicker(NumberPicker numberPicker, int i, int i2) {
        numberPicker.setMinValue(i);
        numberPicker.setMaxValue(i2);
        numberPicker.setDescendantFocusability(393216);
    }

    public long getValue() {
        int value = this.hoursPicker.getValue();
        int value2 = this.minutesPicker.getValue();
        if (is24Mode()) {
            return getTime24(value, value2);
        }
        return getTime24(this.partPicker.getValue() == 1 ? getAMHours(value) : getPMHours(value), value2);
    }

    private long getTime24(int i, int i2) {
        return TimeUnit.HOURS.toMillis((long) i) + TimeUnit.MINUTES.toMillis((long) i2);
    }

    private void setValue(int i, int i2, int i3) {
        setValue(i, i2);
        this.partPicker.setValue(i3);
    }

    private void setValue(int i, int i2) {
        if (i < this.MIN_HOUR_VALUE || i > this.MAX_HOUR_VALUE) {
            this.hoursPicker.setValue(this.MIN_HOUR_VALUE);
        } else {
            this.hoursPicker.setValue(i);
        }
        if (i2 < 0 || i2 > 59) {
            this.minutesPicker.setValue(0);
        } else {
            this.minutesPicker.setValue(i2);
        }
    }

    public void setValue(long j) {
        int hours = (int) TimeUnit.MILLISECONDS.toHours(j);
        int minutes = (int) (TimeUnit.MILLISECONDS.toMinutes(j) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(j)));
        if (is24Mode()) {
            setValue(hours, minutes);
            return;
        }
        int i = hours < 12 ? 1 : 2;
        setValue(i == 1 ? get12AMHours(hours) : get12PMHours(hours), minutes, i);
    }

    private boolean is24Mode() {
        return DateFormat.is24HourFormat(getContext());
    }
}
