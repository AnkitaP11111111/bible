package king.james.bible.android.utils;

import android.content.Context;
import android.os.Build;
import android.os.Environment;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class ExternalStorage {
    private static List<String> allPathsGlobal = null;

    static {
        Pattern.compile("/");
    }

    public static List<String> getAllPaths(Context context) {
        int lastIndexOf;
        List<String> list = allPathsGlobal;
        if (!(list == null || list.isEmpty())) {
            return allPathsGlobal;
        }
        ArrayList arrayList = new ArrayList();
        try {
            if (Build.VERSION.SDK_INT >= 17) {
                arrayList.add(context.getApplicationInfo().dataDir);
            } else {
                arrayList.add("/data/data/" + context.getPackageName());
            }
        } catch (Exception unused) {
        }
        if (Build.VERSION.SDK_INT < 19) {
            allPathsGlobal = arrayList;
            return arrayList;
        }
        File[] fileArr = null;
        try {
            fileArr = context.getExternalFilesDirs("external");
        } catch (Exception unused2) {
        }
        if (fileArr != null) {
            for (File file : fileArr) {
                if (file != null && (lastIndexOf = file.getAbsolutePath().lastIndexOf("/Android/data")) > 0) {
                    String substring = file.getAbsolutePath().substring(0, lastIndexOf);
                    try {
                        substring = new File(substring).getCanonicalPath() + "/Android/data/" + context.getPackageName() + "/files";
                    } catch (Exception unused3) {
                    }
                    arrayList.add(substring);
                }
            }
        }
        if (arrayList.isEmpty()) {
            try {
                arrayList.add(Environment.getExternalStorageDirectory().getAbsolutePath() + "/Android/data/" + context.getPackageName() + "/files");
            } catch (Exception unused4) {
            }
        }
        allPathsGlobal = arrayList;
        return arrayList;
    }

    public static boolean copyFileDB(String str, String str2) {
        try {
            copyDirectory(str, str2);
            cleanFolder(str);
            return true;
        } catch (Exception unused) {
            return false;
        }
    }

    private static void cleanFolder(String str) {
        File file = new File(str);
        if (file.listFiles() != null && file.listFiles().length >= 1) {
            File[] listFiles = file.listFiles();
            for (File file2 : listFiles) {
                if (!file2.isDirectory()) {
                    file2.delete();
                }
            }
        }
    }

    private static void copyDirectory(String str, String str2) throws IOException {
        File file = new File(str);
        File file2 = new File(str2);
        if (file.exists()) {
            if (!file.isDirectory()) {
                copyFile(file, file2);
                return;
            }
            if (!file2.exists()) {
                file2.mkdirs();
            }
            for (File file3 : file.listFiles()) {
                String name = file3.getName();
                copyDirectory(new File(file, name).getCanonicalPath(), new File(file2, name).getCanonicalPath());
            }
        }
    }

    /* JADX DEBUG: Failed to insert an additional move for type inference into block B:20:? */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v2, types: [java.io.OutputStream] */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r2v10 */
    /* JADX WARNING: Removed duplicated region for block: B:33:0x0056  */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x005e  */
    /* JADX WARNING: Removed duplicated region for block: B:37:0x0063  */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x0068  */
    /* JADX WARNING: Removed duplicated region for block: B:44:0x0071  */
    /* JADX WARNING: Removed duplicated region for block: B:46:0x0079  */
    /* JADX WARNING: Removed duplicated region for block: B:48:0x007e  */
    /* JADX WARNING: Removed duplicated region for block: B:53:? A[RETURN, SYNTHETIC] */
    private static void copyFile(File file, File file2) throws IOException {
        FileInputStream fileInputStream;
        BufferedInputStream bufferedInputStream;
        FileOutputStream fileOutputStream;
        BufferedOutputStream bufferedOutputStream;
        FileOutputStream fileOutputStream2;
        Throwable th;
        Throwable th2;
        BufferedInputStream bufferedInputStream2;
        BufferedOutputStream bufferedOutputStream2 = null;
        try {
            fileInputStream = new FileInputStream(file);
            try {
                bufferedInputStream = new BufferedInputStream(fileInputStream);
            } catch (Exception unused) {
                bufferedInputStream = null;
                fileOutputStream = null;
                if (bufferedOutputStream2 != null) {
                }
                if (fileOutputStream != null) {
                }
                if (bufferedInputStream != null) {
                }
                if (fileInputStream == null) {
                }
                fileInputStream.close();
            } catch (Throwable th3) {
                th2 = th3;
                bufferedOutputStream = null;
                bufferedInputStream2 = null;
                th = th2;
                bufferedInputStream = bufferedInputStream2;
                fileOutputStream2 = bufferedInputStream2;
                if (bufferedOutputStream != null) {
                }
                if (fileOutputStream2 != 0) {
                }
                if (bufferedInputStream != null) {
                }
                if (fileInputStream != null) {
                }
                throw th;
            }
            try {
                fileOutputStream = new FileOutputStream(file2);
            } catch (Exception unused2) {
                fileOutputStream = null;
                if (bufferedOutputStream2 != null) {
                    bufferedOutputStream2.flush();
                    bufferedOutputStream2.close();
                }
                if (fileOutputStream != null) {
                    fileOutputStream.close();
                }
                if (bufferedInputStream != null) {
                    bufferedInputStream.close();
                }
                if (fileInputStream == null) {
                    return;
                }
                fileInputStream.close();
            } catch (Throwable th4) {
                fileOutputStream2 = 0;
                th = th4;
                bufferedOutputStream = null;
                if (bufferedOutputStream != null) {
                    bufferedOutputStream.flush();
                    bufferedOutputStream.close();
                }
                if (fileOutputStream2 != 0) {
                    fileOutputStream2.close();
                }
                if (bufferedInputStream != null) {
                    bufferedInputStream.close();
                }
                if (fileInputStream != null) {
                    fileInputStream.close();
                }
                throw th;
            }
            try {
                bufferedOutputStream = new BufferedOutputStream(fileOutputStream);
                try {
                    byte[] bArr = new byte[1024];
                    for (int read = bufferedInputStream.read(bArr); read > 0; read = bufferedInputStream.read(bArr)) {
                        bufferedOutputStream.write(bArr);
                    }
                    bufferedOutputStream.flush();
                    bufferedOutputStream.close();
                    fileOutputStream.close();
                    bufferedInputStream.close();
                } catch (Exception unused3) {
                    bufferedOutputStream2 = bufferedOutputStream;
                    if (bufferedOutputStream2 != null) {
                    }
                    if (fileOutputStream != null) {
                    }
                    if (bufferedInputStream != null) {
                    }
                    if (fileInputStream == null) {
                    }
                    fileInputStream.close();
                } catch (Throwable th5) {
                    th = th5;
                    fileOutputStream2 = fileOutputStream;
                    if (bufferedOutputStream != null) {
                    }
                    if (fileOutputStream2 != 0) {
                    }
                    if (bufferedInputStream != null) {
                    }
                    if (fileInputStream != null) {
                    }
                    throw th;
                }
            } catch (Exception unused4) {
                if (bufferedOutputStream2 != null) {
                }
                if (fileOutputStream != null) {
                }
                if (bufferedInputStream != null) {
                }
                if (fileInputStream == null) {
                }
                fileInputStream.close();
            } catch (Throwable th6) {
                th = th6;
                bufferedOutputStream = null;
                fileOutputStream2 = fileOutputStream;
                if (bufferedOutputStream != null) {
                }
                if (fileOutputStream2 != 0) {
                }
                if (bufferedInputStream != null) {
                }
                if (fileInputStream != null) {
                }
                throw th;
            }
        } catch (Exception unused5) {
            bufferedInputStream = null;
            fileInputStream = null;
            fileOutputStream = null;
            if (bufferedOutputStream2 != null) {
            }
            if (fileOutputStream != null) {
            }
            if (bufferedInputStream != null) {
            }
            if (fileInputStream == null) {
            }
            fileInputStream.close();
        } catch (Throwable th7) {
            th2 = th7;
            bufferedOutputStream = null;
            fileInputStream = null;
            bufferedInputStream2 = null;
            th = th2;
            bufferedInputStream = bufferedInputStream2;
            fileOutputStream2 = bufferedInputStream2;
            if (bufferedOutputStream != null) {
            }
            if (fileOutputStream2 != 0) {
            }
            if (bufferedInputStream != null) {
            }
            if (fileInputStream != null) {
            }
            throw th;
        }
        fileInputStream.close();
    }
}
