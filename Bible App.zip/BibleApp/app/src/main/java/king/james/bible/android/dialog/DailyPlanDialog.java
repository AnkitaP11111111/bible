package king.james.bible.android.dialog;

import android.app.Dialog;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.bignerdranch.expandablerecyclerview.Model.ParentListItem;
import king.james.bible.android.R;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import king.james.bible.android.adapter.recycler.PlanExpandableAdapter;
import king.james.bible.android.model.DailyPlanMonth;
import king.james.bible.android.model.Plan;
import king.james.bible.android.model.PlanDay;
import king.james.bible.android.model.PlanMode;
import king.james.bible.android.model.comparator.DailyPlanMonthComparator;
import king.james.bible.android.service.DailyReadingService;
import king.james.bible.android.service.PowerManagerService;
import king.james.bible.android.service.observable.DailyPlanObservable;
import king.james.bible.android.service.observable.DailyReadingActionObservable;
import king.james.bible.android.service.observable.listener.DailyPlanListener;
import king.james.bible.android.utils.BiblePreferences;
import king.james.bible.android.utils.CalendarUtil;

public class DailyPlanDialog extends BaseForegroundDialog implements DailyPlanListener {
    private RelativeLayout chapterListRelativeLayout;
    private DailyPlanDialogListener dailyPlanDialogListener;
    private TextView dateTextView;
    private View divider;
    private LinearLayoutManager layoutManager;
    private Parcelable layoutManagerState;
    private TextView modeNameTextView;
    private HashSet<String> openItems;
    private Plan plan;
    private PlanExpandableAdapter planExpandableAdapter;
    private RecyclerView planRecyclerView;
    private BiblePreferences preferences;
    private ProgressBar progressBar;
    private TextView titleTextView;

    public interface DailyPlanDialogListener {
        void closeDialog();
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.BaseDialogFragment
    public int getLayoutResourceId() {
        return R.layout.daily_plan_dialog;
    }

    @Override // androidx.fragment.app.DialogFragment
    public Dialog onCreateDialog(Bundle bundle) {
        if (bundle != null && bundle.containsKey("plan")) {
            this.plan = (Plan) bundle.getSerializable("plan");
            this.openItems = (HashSet) bundle.getSerializable("openMonth");
            this.layoutManagerState = bundle.getParcelable("layoutManagerState");
        }
        this.dailyPlanDialogListener = new DailyPlanDialogListener() {
            /* class king.james.bible.android.dialog.DailyPlanDialog.AnonymousClass1 */

            @Override // king.james.bible.android.dialog.DailyPlanDialog.DailyPlanDialogListener
            public void closeDialog() {
                DailyPlanDialog.this.dismiss();
            }
        };
        DailyPlanObservable.getInstance().subscribe(this);
        return super.onCreateDialog(bundle);
    }

    @Override // androidx.fragment.app.Fragment, androidx.fragment.app.DialogFragment
    public void onSaveInstanceState(Bundle bundle) {
        if (bundle == null) {
            bundle = new Bundle();
        }
        bundle.putSerializable("plan", this.plan);
        bundle.putSerializable("openMonth", this.planExpandableAdapter.getOpenItems());
        bundle.putParcelable("layoutManagerState", this.layoutManager.onSaveInstanceState());
        super.onSaveInstanceState(bundle);
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.BaseDialogFragment
    public void mapViews(View view) {
        BiblePreferences instance = BiblePreferences.getInstance();
        this.preferences = instance;
        instance.lambda$restoreAsync$0$BiblePreferences();
        this.planRecyclerView = (RecyclerView) view.findViewById(R.id.planRecyclerView);
        this.modeNameTextView = (TextView) view.findViewById(R.id.modeNameTextView);
        this.dateTextView = (TextView) view.findViewById(R.id.dateTextView);
        this.titleTextView = (TextView) view.findViewById(R.id.titleTextView);
        this.progressBar = (ProgressBar) view.findViewById(R.id.progressBar);
        this.chapterListRelativeLayout = (RelativeLayout) view.findViewById(R.id.chapterListRelativeLayout);
        this.divider = view.findViewById(R.id.divider);
        PowerManagerService.getInstance().start();
    }

    public void setPlan(Plan plan2) {
        this.plan = plan2;
    }

    @Override // king.james.bible.android.dialog.BaseDialogFragment
    public void initActions() {
        PlanMode planMode = this.plan.getPlanMode();
        prepareModeView();
        if (planMode != null) {
            TextView textView = this.modeNameTextView;
            textView.setText(" (" + planMode.getNameString() + ")");
            this.modeNameTextView.setTextColor(DailyReadingService.getModeTextColorResId(planMode.getPlanModeColor(), getActivity()));
        }
        this.dateTextView.setText(getDate(this.plan));
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        this.layoutManager = linearLayoutManager;
        this.planRecyclerView.setLayoutManager(linearLayoutManager);
        PlanExpandableAdapter planExpandableAdapter2 = new PlanExpandableAdapter(getModels(), this.plan.getStartDate(), this.plan.getModeId(), this.dailyPlanDialogListener);
        this.planExpandableAdapter = planExpandableAdapter2;
        this.planRecyclerView.setAdapter(planExpandableAdapter2);
        Parcelable parcelable = this.layoutManagerState;
        if (parcelable != null) {
            this.layoutManager.onRestoreInstanceState(parcelable);
        }
    }

    private void prepareModeView() {
        int i;
        int i2;
        int i3;
        if (this.preferences.isNightMode()) {
            i3 = R.color.f49daily_readingtoolbar_n;
            i2 = R.color.f31daily_readingbutton_text_n;
            i = R.color.f34daily_readingdivider_n;
        } else {
            i3 = R.color.white;
            i2 = R.color.title_text;
            i = R.color.f33daily_readingdivider;
        }
        this.chapterListRelativeLayout.setBackgroundResource(i3);
        this.titleTextView.setTextColor(getActivity().getResources().getColor(i2));
        this.dateTextView.setTextColor(getActivity().getResources().getColor(i2));
        this.divider.setBackgroundResource(i);
    }

    private String getDate(Plan plan2) {
        return getDateFormat(plan2.getStartDate()) + " - " + getDateFormat(plan2.getStartDate() + (((long) (plan2.getPlanDays().size() - 1)) * 86400000));
    }

    private String getDateFormat(long j) {
        return new SimpleDateFormat("M/dd/yyyy").format(new Date(j));
    }

    private List<? extends ParentListItem> getModels() {
        hideProgress();
        HashMap hashMap = new HashMap();
        long startDate = this.plan.getStartDate();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/yy");
        if (this.plan.getPlanDays().size() != this.plan.getPlanMode().getDayCount()) {
            showProgress();
        }
        for (int i = 0; i < this.plan.getPlanDays().size(); i++) {
            PlanDay planDay = this.plan.getPlanDays().get(i);
            long day = (((long) (planDay.getDay() - 1)) * 86400000) + startDate;
            String format = simpleDateFormat.format(new Date(day));
            if (!hashMap.containsKey(format)) {
                DailyPlanMonth dailyPlanMonth = new DailyPlanMonth();
                dailyPlanMonth.setName(getMonthName(day));
                dailyPlanMonth.setPlanDays(new ArrayList());
                dailyPlanMonth.setTime(day);
                hashMap.put(format, dailyPlanMonth);
            }
            if (planDay.getId() > 0) {
                ((DailyPlanMonth) hashMap.get(format)).getPlanDays().add(planDay);
            }
        }
        ArrayList<DailyPlanMonth> arrayList = new ArrayList();
        arrayList.addAll(hashMap.values());
        Collections.sort(arrayList, new DailyPlanMonthComparator());
        if (this.openItems != null) {
            for (DailyPlanMonth dailyPlanMonth2 : arrayList) {
                if (this.openItems.contains(dailyPlanMonth2.getName())) {
                    dailyPlanMonth2.setInitiallyExpanded(true);
                } else {
                    dailyPlanMonth2.setInitiallyExpanded(false);
                }
            }
        }
        return arrayList;
    }

    private String getMonthName(long j) {
        Calendar instance = Calendar.getInstance();
        instance.setTime(new Date(j));
        int i = instance.get(2);
        int i2 = instance.get(1);
        return CalendarUtil.getInstance().getMonthName(getActivity(), i) + ", " + i2;
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroy() {
        super.onDestroy();
        DailyReadingActionObservable.getInstance().onDestroyDailyPlanDialog();
        DailyPlanObservable.getInstance().remove(this);
    }

    private void showProgress() {
        this.progressBar.setVisibility(0);
    }

    private void hideProgress() {
        this.progressBar.setVisibility(8);
    }

    @Override // king.james.bible.android.service.observable.listener.DailyPlanListener
    public void loadDailyPlanComplete(Plan plan2) {
        if (plan2 != null) {
            setPlan(plan2);
            this.openItems = this.planExpandableAdapter.getOpenItems();
            PlanExpandableAdapter planExpandableAdapter2 = new PlanExpandableAdapter(getModels(), this.plan.getStartDate(), this.plan.getModeId(), this.dailyPlanDialogListener);
            this.planExpandableAdapter = planExpandableAdapter2;
            this.planRecyclerView.setAdapter(planExpandableAdapter2);
            this.planExpandableAdapter.notifyDataSetChanged();
            hideProgress();
        }
    }
}
