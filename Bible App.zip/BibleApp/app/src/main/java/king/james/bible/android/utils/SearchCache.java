package king.james.bible.android.utils;

import java.util.ArrayList;
import java.util.List;
import king.james.bible.android.model.SearchTextResult;
import king.james.bible.android.model.SearchType;

public class SearchCache {
    private boolean backStack;
    private int chapter;
    private int listPosition;
    private List<SearchTextResult> models;
    private SearchType searchType;

    /* access modifiers changed from: private */
    public static class SingletonHelper {
        private static final SearchCache INSTANCE = new SearchCache();
    }

    private SearchCache() {
        this.searchType = SearchType.ALL;
        this.backStack = false;
    }

    public static SearchCache getInstance() {
        return SingletonHelper.INSTANCE;
    }

    public List<SearchTextResult> getModels() {
        return this.models;
    }

    private void checkList() {
        if (this.models == null) {
            this.models = new ArrayList();
        }
    }

    public void addModels(List<SearchTextResult> list) {
        checkList();
        this.models.addAll(list);
    }

    public SearchType getSearchType() {
        return this.searchType;
    }

    public void setSearchType(SearchType searchType2) {
        this.searchType = searchType2;
    }

    public int getListPosition() {
        return this.listPosition;
    }

    public void setListPosition(int i) {
        this.listPosition = i;
    }

    public int getChapter() {
        return this.chapter;
    }

    public void setChapter(int i) {
        this.chapter = i;
    }

    public void clear() {
        List<SearchTextResult> list = this.models;
        if (list != null) {
            list.clear();
        }
        this.models = new ArrayList();
        this.searchType = SearchType.ALL;
        this.listPosition = -1;
        this.chapter = 0;
    }

    public boolean isEmptyModelsList() {
        checkList();
        return this.models.isEmpty();
    }

    public void clearBackStack() {
        this.backStack = false;
    }

    public boolean isBackStack() {
        return this.backStack;
    }

    public void setBackStack(boolean z) {
        this.backStack = z;
    }
}
