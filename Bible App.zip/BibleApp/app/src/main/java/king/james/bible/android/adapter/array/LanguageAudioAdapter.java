package king.james.bible.android.adapter.array;

import android.content.Context;
import com.karumi.dexter.BuildConfig;
import java.util.List;
import king.james.bible.android.sound.model.LanguageModel;
import king.james.bible.android.sound.util.SoundLanguageService;

public class LanguageAudioAdapter extends BaseSpinnerAdapter<LanguageModel> {
    private List<LanguageModel> models;

    public static LanguageAudioAdapter getModeAdapter(Context context) {
        return new LanguageAudioAdapter(context, BaseSpinnerAdapter.layoutResource(), SoundLanguageService.getInstance().getLanguageModelList());
    }

    public LanguageAudioAdapter(Context context, int i, List<LanguageModel> list) {
        super(context, i, list);
        this.models = list;
    }

    public int getCount() {
        return this.models.size();
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.adapter.array.BaseSpinnerAdapter
    public String getViewText(int i) {
        return (i < 0 || i >= this.models.size()) ? BuildConfig.FLAVOR : this.models.get(i).getName();
    }

    @Override // android.widget.ArrayAdapter
    public LanguageModel getItem(int i) {
        return this.models.get(i);
    }
}
