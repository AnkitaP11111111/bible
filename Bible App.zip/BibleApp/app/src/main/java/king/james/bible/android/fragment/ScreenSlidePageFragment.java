package king.james.bible.android.fragment;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import king.james.bible.android.R;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;
import king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter;
import king.james.bible.android.adapter.recycler.MainFragmentRecyclerViewAdapter;
import king.james.bible.android.db.BibleDataBase;
import king.james.bible.android.db.listener.AddHighLightListener;
import king.james.bible.android.db.listener.AddRemoveNoteListener;
import king.james.bible.android.db.listener.ChangeBookmarkListener;
import king.james.bible.android.db.listener.RemoveHighLightListener;
import king.james.bible.android.db.listener.UpdateViewHolderListener;
import king.james.bible.android.db.service.TextDataService;
import king.james.bible.android.dialog.DialogUtil;
import king.james.bible.android.dialog.NoteDialog;
import king.james.bible.android.dialog.SelectActionDialog;
import king.james.bible.android.event.ClickAddEvent;
import king.james.bible.android.event.ClickHeaderEvent;
import king.james.bible.android.event.HidePageSelectionEvent;
import king.james.bible.android.event.UpdatePageBySettingsChangeEvent;
import king.james.bible.android.event.UpdatePageEvent;
import king.james.bible.android.model.DialogDataBookmark;
import king.james.bible.android.model.SpanType;
import king.james.bible.android.model.Text;
import king.james.bible.android.model.chapter.ChapterSubChapterResult;
import king.james.bible.android.service.BackStackService;
import king.james.bible.android.service.DailyReadingService;
import king.james.bible.android.service.DailyVerseService;
import king.james.bible.android.service.PowerManagerService;
import king.james.bible.android.service.observable.NoteDialogListenerObservable;
import king.james.bible.android.service.observable.SelectActionDialogListenerObservable;
import king.james.bible.android.sound.SoundHelper;
import king.james.bible.android.sound.listener.page.SoundPlayListener;
import king.james.bible.android.utils.BiblePreferences;
import king.james.bible.android.utils.BibleToast;
import king.james.bible.android.utils.EmailUtils;
import king.james.bible.android.utils.ShareTextUtil;
import king.james.bible.android.view.HeaderTextList;
import king.james.bible.android.view.MarkerTextView;
import king.james.bible.android.view.WrapperLinearLayoutManager;
import king.james.bible.android.view.animator.ScreenSlidePageBackgroundAnimator;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

public class ScreenSlidePageFragment extends Fragment implements AdapterView.OnItemClickListener, View.OnClickListener, SelectActionDialog.SelectActionDialogListener, BaseRecyclerViewAdapter.OnItemClickListener, UpdateViewHolderListener, MarkerTextView.OnSelectionListener, SoundPlayListener, NoteDialog.NoteDialogListener {
    private  List r266;
    private  boolean r333;
    private  List r2222;
    private  int r233;
    private  boolean r23;
    private int r5;
    private  int r4;
    private int r3;
    private boolean r2;
    private MainFragmentRecyclerViewAdapter adapter;
    private int chapter;
    private boolean delayLoading = false;
    private LinearLayoutManager layoutManager;
    private int pagePosition;
    private int startPosition = 0;
    private int subChapter;
    private RecyclerView textRecyclerView;
    private int unicId;

    @Override // androidx.fragment.app.Fragment
    public void onSaveInstanceState(Bundle bundle) {
    }

    public static ScreenSlidePageFragment create(int i, int i2, int i3, boolean z) {
        ScreenSlidePageFragment screenSlidePageFragment = new ScreenSlidePageFragment();
        Bundle bundle = new Bundle();
        bundle.putInt("page_position", i);
        bundle.putInt("sub_chapter", i3);
        bundle.putInt("chapter", i2);
        bundle.putBoolean("delayLoading", z);
        screenSlidePageFragment.setArguments(bundle);
        return screenSlidePageFragment;
    }

    @Override // androidx.fragment.app.Fragment
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (getArguments() != null) {
            int i = getArguments().getInt("page_position");
            this.pagePosition = i;
            this.unicId = i;
            this.subChapter = getArguments().getInt("sub_chapter");
            this.chapter = getArguments().getInt("chapter");
            this.delayLoading = getArguments().getBoolean("delayLoading");
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void onStart() {
        super.onStart();
        EventBus.getDefault().register(this);
    }

    @Override // androidx.fragment.app.Fragment
    public void onResume() {
        super.onResume();
        NoteDialogListenerObservable.getInstance().subscribe(this.pagePosition, this);
        SelectActionDialogListenerObservable.getInstance().subscribe(this.pagePosition, this);
    }

    @Override // androidx.fragment.app.Fragment
    public void onPause() {
        NoteDialogListenerObservable.getInstance().remove(this.pagePosition);
        SelectActionDialogListenerObservable.getInstance().remove(this.pagePosition);
        super.onPause();
    }

    @Override // androidx.fragment.app.Fragment
    public void onStop() {
        EventBus.getDefault().unregister(this);
        super.onStop();
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        ViewGroup viewGroup2 = (ViewGroup) layoutInflater.inflate(BiblePreferences.getInstance().isDayMode() ? R.layout.fragment_screen_slide_page : R.layout.fragment_screen_slide_page_n, (ViewGroup) null);
        this.textRecyclerView = (RecyclerView) viewGroup2.findViewById(R.id.textRecyclerView);
        WrapperLinearLayoutManager wrapperLinearLayoutManager = new WrapperLinearLayoutManager(getActivity(), 1, false);
        this.layoutManager = wrapperLinearLayoutManager;
        this.textRecyclerView.setLayoutManager(wrapperLinearLayoutManager);
        BaseRecyclerViewAdapter.addBottomSpaceDecoration(this.textRecyclerView, getResources().getDimensionPixelSize(R.dimen.indent_xmedium));
        MainFragmentRecyclerViewAdapter mainFragmentRecyclerViewAdapter = new MainFragmentRecyclerViewAdapter(getActivity(), this.pagePosition, this.unicId, this, this, this, this);
        this.adapter = mainFragmentRecyclerViewAdapter;
        mainFragmentRecyclerViewAdapter.setSoundPlayListener(this);
        this.textRecyclerView.setAdapter(this.adapter);
        if (Build.VERSION.SDK_INT > 18) {
            try {
                this.textRecyclerView.setScrollBarSize(0);
            } catch (Throwable unused) {
            }
            this.textRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
                /* class king.james.bible.android.fragment.ScreenSlidePageFragment.AnonymousClass1 */

                @Override // androidx.recyclerview.widget.RecyclerView.OnScrollListener
                public void onScrollStateChanged(RecyclerView recyclerView, int i) {
                    try {
                        super.onScrollStateChanged(recyclerView, i);
                        recyclerView.setScrollBarSize(10);
                        if (i == 0) {
                            recyclerView.setScrollBarSize(0);
                        }
                    } catch (Throwable unused) {
                    }
                }
            });
        }
        new Handler().postDelayed(new Runnable() {
            /* class king.james.bible.android.fragment.$$Lambda$ScreenSlidePageFragment$sm63n8ssnFHHAI7AH4nPgmmll5g */

            public final void run() {
                ScreenSlidePageFragment.this.lambda$onCreateView$0$ScreenSlidePageFragment();
            }
        }, this.delayLoading ? 2500 : 0);
        return viewGroup2;
    }

    public /* synthetic */ void lambda$onCreateView$0$ScreenSlidePageFragment() {
        loadModels(true);
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroy() {
        this.adapter.clearSubscription();
        this.adapter.getSelectedSet().clear();
        this.adapter.setMenuItem(null);
        this.adapter.notifyDataSetChanged();
        this.adapter.clear();
        this.adapter.notifyDataSetChanged();
        this.textRecyclerView.setAdapter(null);
        this.textRecyclerView.destroyDrawingCache();
        this.textRecyclerView = null;
        this.adapter = null;
        super.onDestroy();
    }

    /* access modifiers changed from: package-private */
    public boolean isMenuButtonShow() {
        MainFragmentRecyclerViewAdapter mainFragmentRecyclerViewAdapter = this.adapter;
        return (mainFragmentRecyclerViewAdapter == null || mainFragmentRecyclerViewAdapter.getSelectedSet() == null || this.adapter.getSelectedSet().isEmpty()) ? false : true;
    }

    /* access modifiers changed from: package-private */
    public void hideMenuButton() {
        this.adapter.getSelectedSet().clear();
        if (getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() {
                /* class king.james.bible.android.fragment.$$Lambda$ScreenSlidePageFragment$_nK8sgAsSIVxU1_C4hNTM9AIFs8 */

                public final void run() {
                    ScreenSlidePageFragment.this.lambda$hideMenuButton$1$ScreenSlidePageFragment();
                }
            });
        }
    }

    public /* synthetic */ void lambda$hideMenuButton$1$ScreenSlidePageFragment() {
        MainFragmentRecyclerViewAdapter mainFragmentRecyclerViewAdapter;
        if (!getActivity().isFinishing() && (mainFragmentRecyclerViewAdapter = this.adapter) != null) {
            try {
                mainFragmentRecyclerViewAdapter.getSelectedSet().clear();
                this.adapter.setMenuItem(null);
                this.adapter.notifyDataSetChanged();
                this.adapter.getHeaderHolder().setMenuItem(this.adapter.getMenuItem().intValue());
                this.adapter.getHeaderHolder().setSelectedSet(this.adapter.getSelectedSet());
                this.adapter.getHeaderHolder().returnHeaderItem();
                SoundHelper.getInstance().pause();
            } catch (Exception unused) {
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void scrollListTo(int i) {
        RecyclerView recyclerView = this.textRecyclerView;
        if (recyclerView != null && i >= 0) {
            recyclerView.postDelayed(new ScrollRunnable(i), 600);
        }
    }

    /* access modifiers changed from: package-private */
    public void scrollListToNote(int i, int i2, int i3, int i4) {
        RecyclerView recyclerView = this.textRecyclerView;
        if (recyclerView != null) {
            recyclerView.postDelayed(new ScrollRunnable(i3), 600);
            new Thread(new Runnable() {
                /* class king.james.bible.android.fragment.$$Lambda$ScreenSlidePageFragment$_hwD14jPGizyOgivNf7bOwS4Atw */
                private final /* synthetic */ int f$1;
                private final /* synthetic */ int f$2;
                private final /* synthetic */ int f$3;
                private final /* synthetic */ int f$4;

                {
                    this.f$1 = r233;
                    this.f$2 = r3;
                    this.f$3 = r4;
                    this.f$4 = r5;
                }

                public final void run() {
                    ScreenSlidePageFragment.this.lambda$scrollListToNote$2$ScreenSlidePageFragment(this.f$1, this.f$2, this.f$3, this.f$4);
                }
            }).start();
        }
    }

    public /* synthetic */ void lambda$scrollListToNote$2$ScreenSlidePageFragment(int i, int i2, int i3, int i4) {
        this.adapter.setMenuItem(Integer.valueOf(BibleDataBase.getInstance().getPositionByChapter(i, i2, i3)));
        showNoteDialog(i4);
    }

    private void showNoteDialog(int i) {
        if (getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() {
                private int r2w3;
                /* class king.james.bible.android.fragment.$$Lambda$ScreenSlidePageFragment$SRydwxs8_pSvazcP8QlsAo7eo0M */




                public final void run() {
                    ScreenSlidePageFragment.this.lambda$showNoteDialog$3$ScreenSlidePageFragment(r2w3);
                }
            });
        }
    }

    public /* synthetic */ void lambda$showNoteDialog$3$ScreenSlidePageFragment(int i) {
        DialogUtil.showAddANoteDialog(getChildFragmentManager(), this.pagePosition, this.chapter, this.subChapter, i);
    }

    /* access modifiers changed from: package-private */
    public void stopAllVerses() {
        if (getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() {
                /* class king.james.bible.android.fragment.$$Lambda$ScreenSlidePageFragment$Km_hsyMbwJAwHOGhkpLB143Yyw8 */

                public final void run() {
                    ScreenSlidePageFragment.this.lambda$stopAllVerses$5$ScreenSlidePageFragment();
                }
            });
        }
    }

    public /* synthetic */ void lambda$stopAllVerses$5$ScreenSlidePageFragment() {
        MainFragmentRecyclerViewAdapter mainFragmentRecyclerViewAdapter;
        if (getActivity() != null && (mainFragmentRecyclerViewAdapter = this.adapter) != null) {
            mainFragmentRecyclerViewAdapter.getSelectedSet().clear();
            this.adapter.setMenuItem(null);
            this.adapter.notifyDataSetChanged();
            if (this.adapter.getHeaderHolder() != null) {
                this.adapter.getHeaderHolder().setMenuItem(this.adapter.getMenuItem().intValue());
                this.adapter.getHeaderHolder().setSelectedSet(this.adapter.getSelectedSet());
                this.adapter.getHeaderHolder().updateButtons();
            }
            this.textRecyclerView.postDelayed(new Runnable() {
                /* class king.james.bible.android.fragment.$$Lambda$ScreenSlidePageFragment$mctPpa3LjGlzUzUnNMsfbahpq3g */

                public final void run() {
                    ScreenSlidePageFragment.this.lambda$null$4$ScreenSlidePageFragment();
                }
            }, 300);
        }
    }

    public /* synthetic */ void lambda$null$4$ScreenSlidePageFragment() {
        if (getActivity() != null) {
            this.adapter.notifyDataSetChanged();
        }
    }

    /* access modifiers changed from: package-private */
    public void nextVerse(int i, boolean z) {
        if (getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() {
                /* class king.james.bible.android.fragment.$$Lambda$ScreenSlidePageFragment$SHQ7rjksQFEBOh9KMLSfdTbpGjM */
                private final /* synthetic */ boolean f$1;
                private final /* synthetic */ int f$2;

                {
                    this.f$1 = r23;
                    this.f$2 = r3;
                }

                public final void run() {
                    ScreenSlidePageFragment.this.lambda$nextVerse$7$ScreenSlidePageFragment(this.f$1, this.f$2);
                }
            });
        }
    }

    public /* synthetic */ void lambda$nextVerse$7$ScreenSlidePageFragment(boolean z, int i) {
        if (getActivity() != null) {
            if (z) {
                try {
                    this.textRecyclerView.postDelayed(new Runnable() {
                        /* class king.james.bible.android.fragment.$$Lambda$ScreenSlidePageFragment$eY09VwPilFVaJJ59Pz8aJNz2GnY */

                        public final void run() {
                            ScreenSlidePageFragment.this.lambda$null$6$ScreenSlidePageFragment();
                        }
                    }, 600);
                } catch (Exception unused) {
                    return;
                }
            }
            this.adapter.getSelectedSet().clear();
            this.adapter.setMenuItem(null);
            this.adapter.getSelectedSet().add(Integer.valueOf(i));
            this.adapter.setMenuItem(Integer.valueOf(i));
            this.adapter.notifyDataSetChanged();
            this.adapter.getHeaderHolder().setMenuItem(this.adapter.getMenuItem().intValue());
            this.adapter.getHeaderHolder().setSelectedSet(this.adapter.getSelectedSet());
            this.adapter.getHeaderHolder().returnHeaderItem();
            if (i > this.adapter.getHeaderHolder().getPositionView()) {
                this.adapter.onNextVerse(this.pagePosition, i);
                int findLastVisibleItemPosition = this.layoutManager.findLastVisibleItemPosition();
                int findFirstVisibleItemPosition = this.layoutManager.findFirstVisibleItemPosition();
                if (i > findLastVisibleItemPosition || findFirstVisibleItemPosition > i) {
                    this.textRecyclerView.scrollToPosition(Math.max(this.adapter.getAdapterPosition(i), 0) - ((findFirstVisibleItemPosition - findLastVisibleItemPosition) / 2));
                }
            }
        }
    }

    public /* synthetic */ void lambda$null$6$ScreenSlidePageFragment() {
        RecyclerView recyclerView;
        if (getActivity() != null && (recyclerView = this.textRecyclerView) != null) {
            recyclerView.scrollToPosition(0);
            this.textRecyclerView.setScrollY(0);
        }
    }

    /* access modifiers changed from: package-private */
    public void prepareSoundHeaderPauseBackground() {
        if (getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() {
                /* class king.james.bible.android.fragment.$$Lambda$ScreenSlidePageFragment$z7IcdgG5sOTEZJ7z23SdkSJDtMs */

                public final void run() {
                    ScreenSlidePageFragment.this.lambda$prepareSoundHeaderPauseBackground$8$ScreenSlidePageFragment();
                }
            });
        }
    }

    public /* synthetic */ void lambda$prepareSoundHeaderPauseBackground$8$ScreenSlidePageFragment() {
        MainFragmentRecyclerViewAdapter mainFragmentRecyclerViewAdapter;
        if (getActivity() != null && (mainFragmentRecyclerViewAdapter = this.adapter) != null && mainFragmentRecyclerViewAdapter.getHeaderHolder() != null) {
            this.adapter.getHeaderHolder().prepareSoundPauseBackground();
        }
    }

    @Override // king.james.bible.android.view.MarkerTextView.OnSelectionListener
    public void onTextViewClick(View view, int i) {
        onItemClick(view, i, false);
    }

    /* access modifiers changed from: private */
    public class ScrollRunnable implements Runnable {
        private int rank;

        ScrollRunnable(int i) {
            this.rank = i;
        }

        public void run() {
            if (ScreenSlidePageFragment.this.getActivity() != null && ScreenSlidePageFragment.this.layoutManager != null && ScreenSlidePageFragment.this.textRecyclerView != null && ScreenSlidePageFragment.this.adapter != null && ScreenSlidePageFragment.this.adapter.getHeaderHolder() != null) {
                int i = this.rank;
                if (i < 0) {
                    i = 1;
                }
                this.rank = i;
                ScreenSlidePageFragment.this.layoutManager.scrollToPositionWithOffset(ScreenSlidePageFragment.this.adapter.getAdapterPosition(this.rank), 0);
                if (ScreenSlidePageFragment.this.textRecyclerView != null) {
                    ScreenSlidePageFragment.this.textRecyclerView.postDelayed(new ScrollAnimatorRunnable(this.rank), 400);
                }
            }
        }
    }

    /* access modifiers changed from: private */
    public class ScrollAnimatorRunnable implements Runnable {
        private int rank;

        ScrollAnimatorRunnable(int i) {
            this.rank = i;
        }

        public void run() {
            if (ScreenSlidePageFragment.this.getActivity() != null) {
                if (ScreenSlidePageFragment.this.adapter.getHeaderHolder().getPositionView() >= this.rank) {
                    ScreenSlidePageFragment.this.adapter.getHeaderHolder().animItem(this.rank);
                    return;
                }
                if (ScreenSlidePageFragment.this.textRecyclerView.getChildAt(ScreenSlidePageFragment.this.adapter.getAdapterPosition(this.rank) - ScreenSlidePageFragment.this.layoutManager.findFirstVisibleItemPosition()) != null) {
                    animateItem();
                } else {
                    ScreenSlidePageFragment.this.textRecyclerView.postDelayed(new Runnable() {
                        /* class king.james.bible.android.fragment.$$Lambda$ScreenSlidePageFragment$ScrollAnimatorRunnable$y5augxSP5uPDK9SIM1v1yuXypE */

                        public final void run() {
                            ScrollAnimatorRunnable.this.animateItem();
                        }
                    }, 1000);
                }
            }
        }

        /* access modifiers changed from: private */
        public void animateItem() {
            if (ScreenSlidePageFragment.this.adapter != null) {
                int adapterPosition = ScreenSlidePageFragment.this.adapter.getAdapterPosition(this.rank);
                final int findFirstVisibleItemPosition = ScreenSlidePageFragment.this.layoutManager.findFirstVisibleItemPosition();
                View childAt = ScreenSlidePageFragment.this.layoutManager.getChildAt(adapterPosition - findFirstVisibleItemPosition);
                if (childAt != null) {
                    final ScreenSlidePageBackgroundAnimator screenSlidePageBackgroundAnimator = new ScreenSlidePageBackgroundAnimator(childAt);
                    screenSlidePageBackgroundAnimator.start();
                    ScreenSlidePageFragment.this.textRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
                        /* class king.james.bible.android.fragment.ScreenSlidePageFragment.ScrollAnimatorRunnable.AnonymousClass1 */

                        @Override // androidx.recyclerview.widget.RecyclerView.OnScrollListener
                        public void onScrolled(RecyclerView recyclerView, int i, int i2) {
                            ScreenSlidePageFragment.this.textRecyclerView.removeOnScrollListener(this);
                            if (findFirstVisibleItemPosition != ScreenSlidePageFragment.this.layoutManager.findFirstVisibleItemPosition()) {
                                screenSlidePageBackgroundAnimator.cancel();
                            }
                        }
                    });
                }
            }
        }
    }

    private void loadModels(boolean z) {
        loadModels(z, 0);
    }

    private void loadModels(boolean z, int i) {
        new Thread(new Runnable() {
            /* class king.james.bible.android.fragment.$$Lambda$ScreenSlidePageFragment$owI9yDeMibmk3mWZmlIVi4Bi3p4 */
            private final /* synthetic */ boolean f$1;
            private final /* synthetic */ int f$2;

            {
                this.f$1 = r2;
                this.f$2 = r3;
            }

            public final void run() {
                ScreenSlidePageFragment.this.lambda$loadModels$10$ScreenSlidePageFragment(this.f$1, this.f$2);
            }
        }).start();
    }

    public /* synthetic */ void lambda$loadModels$10$ScreenSlidePageFragment(boolean z, int i) throws Throwable {
        if (this.chapter == 0) {
            try {
                ChapterSubChapterResult chapterByPosition = BibleDataBase.getInstance().getChapterByPosition(this.pagePosition + 1);
                if (chapterByPosition != null) {
                    this.chapter = chapterByPosition.getChapter();
                    this.subChapter = chapterByPosition.getSubChapter();
                }
            } catch (Exception unused) {
            }
        }
        List<Text> firstTextModels = TextDataService.getFirstTextModels(this.subChapter, this.chapter);
        if (getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() {
                /* class king.james.bible.android.fragment.$$Lambda$ScreenSlidePageFragment$Q1gaJxydBPWSsCiM6GrPEmlXp8o */
                private final /* synthetic */ List f$1;
                private final /* synthetic */ boolean f$2;
                private final /* synthetic */ int f$3;

                {
                    this.f$1 = r2222;
                    this.f$2 = r333;
                    this.f$3 = r4;
                }

                public final void run() {
                    ScreenSlidePageFragment.this.lambda$null$9$ScreenSlidePageFragment(this.f$1, this.f$2, this.f$3);
                }
            });
        }
    }

    public /* synthetic */ void lambda$null$9$ScreenSlidePageFragment(List list, boolean z, int i) {
        try {
            this.adapter.getHeaderHolder().setModel(list, this.adapter.getSelectedSet(), z, i);
            this.adapter.getHeaderHolder().setSoundPlayListener(this);
        } catch (Exception unused) {
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(UpdatePageBySettingsChangeEvent updatePageBySettingsChangeEvent) {
        this.adapter.getHeaderHolder().updateBySettingsChange();
        this.adapter.notifyDataSetChanged();
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(ClickHeaderEvent clickHeaderEvent) {
        if (getActivity() != null && clickHeaderEvent.getUnicId() == this.unicId) {
            updateList(1, false);
            clickPosition(clickHeaderEvent.getRank(), true);
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(ClickAddEvent clickAddEvent) {
        if (clickAddEvent.getUnicId() == this.unicId) {
            DialogUtil.showSelectActionDialog(getChildFragmentManager(), this.pagePosition, new DialogDataBookmark(this.adapter.getSelectedSet(), this.chapter, this.subChapter, this.unicId, this.adapter.getMenuItem().intValue()));
        }
    }

    private void updateList(int i, boolean z) {
        if (getActivity() != null) {
            MainFragmentRecyclerViewAdapter mainFragmentRecyclerViewAdapter = this.adapter;
            mainFragmentRecyclerViewAdapter.setStartPosition(mainFragmentRecyclerViewAdapter.getHeaderHolder().getPositionView());
            if (i == 2) {
                getActivity().runOnUiThread(new Runnable() {
                    /* class king.james.bible.android.fragment.$$Lambda$ScreenSlidePageFragment$SlyzOGmDnyAccf_O_EH1ecjKfA */

                    public final void run() {
                        ScreenSlidePageFragment.this.lambda$updateList$11$ScreenSlidePageFragment();
                    }
                });
            }
            if (z) {
                updateHeader();
            }
        }
    }

    public /* synthetic */ void lambda$updateList$11$ScreenSlidePageFragment() {
        this.adapter.notifyDataSetChanged();
    }

    @Override // king.james.bible.android.db.listener.UpdateViewHolderListener
    public void onCompleteDrawHeader(int i, int i2) {
        RecyclerView recyclerView;
        if (getActivity() != null && (recyclerView = this.textRecyclerView) != null && recyclerView.getLayoutManager() != null) {
            new Thread(new Runnable(i) {
                /* class king.james.bible.android.fragment.$$Lambda$ScreenSlidePageFragment$jXwPcJRZds0byJOmbg7J8SfwxYs */
                private final /* synthetic */ int f$1;

                {
                    this.f$1 = r2;
                }

                public final void run() {
                    ScreenSlidePageFragment.this.lambda$onCompleteDrawHeader$12$ScreenSlidePageFragment(this.f$1);
                }
            }).start();
        }
    }

    public /* synthetic */ void lambda$onCompleteDrawHeader$12$ScreenSlidePageFragment(int i) {
        try {
            onLoadModels(TextDataService.getTextList(this.subChapter, this.chapter), i);
        } catch (Exception unused) {
        }
    }

    private void onLoadModels(List<Text> list, int i) {
        if (getActivity() != null) {
            getActivity().runOnUiThread(new Runnable(list, i) {
                /* class king.james.bible.android.fragment.$$Lambda$ScreenSlidePageFragment$sRhAl_Q1HBKRnlXqNhMzIRxhIyM */
                private final /* synthetic */ List f$1;
                private final /* synthetic */ int f$2;

                {
                    this.f$1 = r266;
                    this.f$2 = r3;
                }

                public final void run() {
                    ScreenSlidePageFragment.this.lambda$onLoadModels$13$ScreenSlidePageFragment(this.f$1, this.f$2);
                }
            });
        }
    }

    public /* synthetic */ void lambda$onLoadModels$13$ScreenSlidePageFragment(List list, int i) {
        try {
            this.adapter.setModels(list);
            this.adapter.setStartPosition(i);
            this.adapter.notifyDataSetChanged();
        } catch (Exception unused) {
        }
    }

    private void updateHeader() {
        loadModels(true);
    }

    private int getRankByPosition(int i) {
        MainFragmentRecyclerViewAdapter mainFragmentRecyclerViewAdapter = this.adapter;
        if (mainFragmentRecyclerViewAdapter == null || mainFragmentRecyclerViewAdapter.getModel(i) == null) {
            return -1;
        }
        return this.adapter.getModel(i).getRank();
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
        onItemClick(view, i, true);
    }

    private void onItemClick(View view, int i, boolean z) {
        DailyVerseService.getInstance().clearDailyVerseBackStack();
        DailyReadingService.getInstance().clearDailyReadingBackStack();
        BackStackService.getInstance().clear();
        if (SoundHelper.getInstance().isPlay()) {
            this.adapter.getSelectedSet().clear();
        }
        SoundHelper.getInstance().pause();
        if (!z || (!((Boolean) view.getTag()).booleanValue() && !view.getClass().equals(HeaderTextList.class))) {
            clickPosition(i, false);
            PowerManagerService.getInstance().start();
        }
    }

    private void clickPosition(int i, boolean z) {
        if (!z) {
            i = getRankByPosition(i);
        }
        if (i >= 0) {
            if (this.adapter.getSelectedSet().contains(Integer.valueOf(i))) {
                this.adapter.getSelectedSet().remove(Integer.valueOf(i));
                if (this.adapter.getSelectedSet().isEmpty()) {
                    this.adapter.setMenuItem(null);
                } else {
                    SortedSet<Integer> tailSet = this.adapter.getSelectedSet().tailSet(Integer.valueOf(i + this.startPosition));
                    if (tailSet.isEmpty()) {
                        MainFragmentRecyclerViewAdapter mainFragmentRecyclerViewAdapter = this.adapter;
                        mainFragmentRecyclerViewAdapter.setMenuItem(mainFragmentRecyclerViewAdapter.getSelectedSet().last());
                    } else {
                        this.adapter.setMenuItem(tailSet.first());
                    }
                }
            } else {
                this.adapter.getSelectedSet().add(Integer.valueOf(i));
                this.adapter.setMenuItem(Integer.valueOf(i));
            }
            updateHeaderSelectedSet();
            if (!z) {
                MainFragmentRecyclerViewAdapter mainFragmentRecyclerViewAdapter2 = this.adapter;
                mainFragmentRecyclerViewAdapter2.setStartPosition(mainFragmentRecyclerViewAdapter2.getHeaderHolder().getPositionView());
            }
            this.adapter.notifyDataSetChanged();
        }
    }

    @Override // king.james.bible.android.sound.listener.page.SoundPlayListener
    public void onSoundPlay(int i) {
        MainFragmentRecyclerViewAdapter mainFragmentRecyclerViewAdapter;
        if (getActivity() != null && (mainFragmentRecyclerViewAdapter = this.adapter) != null) {
            mainFragmentRecyclerViewAdapter.setMenuItem(Integer.valueOf(i));
            this.adapter.getSelectedSet().clear();
            this.adapter.getSelectedSet().add(Integer.valueOf(i));
            updateHeaderSelectedSet();
            this.adapter.notifyDataSetChanged();
        }
    }

    @Override // king.james.bible.android.sound.listener.page.SoundPlayListener
    public Set<Integer> getSelectedSoundRepeatSet() {
        return this.adapter.getSelectedSet();
    }

    private void updateHeaderSelectedSet() {
        this.adapter.getHeaderHolder().setSelectedSet(this.adapter.getSelectedSet());
        this.adapter.getHeaderHolder().setMenuItem(this.adapter.getMenuItem().intValue());
        this.adapter.getHeaderHolder().returnHeaderItem();
    }

    @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter.OnItemClickListener
    public void onClick(int i) {
        DailyVerseService.getInstance().clearDailyVerseBackStack();
        DailyReadingService.getInstance().clearDailyReadingBackStack();
        BackStackService.getInstance().clear();
        if (SoundHelper.getInstance().isPlay()) {
            this.adapter.getSelectedSet().clear();
        }
        SoundHelper.getInstance().pause();
        if (i != 0) {
            clickPosition(i, false);
            PowerManagerService.getInstance().start();
        }
    }

    public void onClick(View view) {
        PowerManagerService.getInstance().start();
        if (view.getId() == R.id.text_item_menu_button) {
            try {
                DialogUtil.showSelectActionDialog(getChildFragmentManager(), this.pagePosition, new DialogDataBookmark(this.adapter.getSelectedSet(), this.chapter, this.subChapter, this.unicId, this.adapter.getMenuItem().intValue()));
                SoundHelper.getInstance().pause();
            } catch (Exception unused) {
            }
        }
    }

    @Override // king.james.bible.android.dialog.SelectActionDialog.SelectActionDialogListener
    public void onActionSelected(int i, SelectActionDialog.DialogActions dialogActions, DialogDataBookmark dialogDataBookmark) {
        if (this.pagePosition == i && this.adapter != null && getActivity() != null && dialogDataBookmark != null) {
            BibleDataBase instance = BibleDataBase.getInstance();
            switch (AnonymousClass5.$SwitchMap$king$james$bible$android$dialog$SelectActionDialog$DialogActions[dialogActions.ordinal()]) {
                case 1:
                    changeBookmark(instance, dialogDataBookmark);
                    break;
                case 2:
                    DialogUtil.showAddANoteDialog(getChildFragmentManager(), i, this.chapter, this.subChapter, dialogDataBookmark.getMenuItem());
                    break;
                case 3:
                    setColor(instance, SpanType.UNDERLINE, dialogDataBookmark);
                    break;
                case 4:
                    setColor(instance, SpanType.COLOR_1, dialogDataBookmark);
                    break;
                case 5:
                    setColor(instance, SpanType.COLOR_2, dialogDataBookmark);
                    break;
                case 6:
                    setColor(instance, SpanType.COLOR_3, dialogDataBookmark);
                    break;
                case 7:
                    setColor(instance, SpanType.COLOR_4, dialogDataBookmark);
                    break;
                case 8:
                    setColor(instance, SpanType.COLOR_5, dialogDataBookmark);
                    break;
                case 9:
                    setColor(instance, SpanType.COLOR_6, dialogDataBookmark);
                    break;
                case 10:
                    setColor(instance, SpanType.COLOR_7, dialogDataBookmark);
                    break;
                case 11:
                    setColor(instance, SpanType.COLOR_8, dialogDataBookmark);
                    break;
                case 12:
                    removeHighLight(instance, dialogDataBookmark);
                    break;
                case 13:
                    postCopyShareEvent(dialogDataBookmark, true);
                    break;
                case 14:
                    postCopyShareEvent(dialogDataBookmark, false);
                    break;
            }
            PowerManagerService.getInstance().start();
        }
    }

    /* renamed from: king.james.bible.android.fragment.ScreenSlidePageFragment$5  reason: invalid class name */
    static /* synthetic */ class AnonymousClass5 {
        static final /* synthetic */ int[] $SwitchMap$king$james$bible$android$dialog$SelectActionDialog$DialogActions;

        /* JADX WARNING: Can't wrap try/catch for region: R(28:0|1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26|(3:27|28|30)) */
        /* JADX WARNING: Can't wrap try/catch for region: R(30:0|1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26|27|28|30) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:11:0x003e */
        /* JADX WARNING: Missing exception handler attribute for start block: B:13:0x0049 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:15:0x0054 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:17:0x0060 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:19:0x006c */
        /* JADX WARNING: Missing exception handler attribute for start block: B:21:0x0078 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:23:0x0084 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:25:0x0090 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:27:0x009c */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x001d */
        /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x0028 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:9:0x0033 */
        static {
            int[] iArr = new int[SelectActionDialog.DialogActions.values().length];
            $SwitchMap$king$james$bible$android$dialog$SelectActionDialog$DialogActions = iArr;
            iArr[SelectActionDialog.DialogActions.bookmark.ordinal()] = 1;
            $SwitchMap$king$james$bible$android$dialog$SelectActionDialog$DialogActions[SelectActionDialog.DialogActions.note.ordinal()] = 2;
            $SwitchMap$king$james$bible$android$dialog$SelectActionDialog$DialogActions[SelectActionDialog.DialogActions.uline.ordinal()] = 3;
            $SwitchMap$king$james$bible$android$dialog$SelectActionDialog$DialogActions[SelectActionDialog.DialogActions.color_1.ordinal()] = 4;
            $SwitchMap$king$james$bible$android$dialog$SelectActionDialog$DialogActions[SelectActionDialog.DialogActions.color_2.ordinal()] = 5;
            $SwitchMap$king$james$bible$android$dialog$SelectActionDialog$DialogActions[SelectActionDialog.DialogActions.color_3.ordinal()] = 6;
            $SwitchMap$king$james$bible$android$dialog$SelectActionDialog$DialogActions[SelectActionDialog.DialogActions.color_4.ordinal()] = 7;
            $SwitchMap$king$james$bible$android$dialog$SelectActionDialog$DialogActions[SelectActionDialog.DialogActions.color_5.ordinal()] = 8;
            $SwitchMap$king$james$bible$android$dialog$SelectActionDialog$DialogActions[SelectActionDialog.DialogActions.color_6.ordinal()] = 9;
            $SwitchMap$king$james$bible$android$dialog$SelectActionDialog$DialogActions[SelectActionDialog.DialogActions.color_7.ordinal()] = 10;
            $SwitchMap$king$james$bible$android$dialog$SelectActionDialog$DialogActions[SelectActionDialog.DialogActions.color_8.ordinal()] = 11;
            $SwitchMap$king$james$bible$android$dialog$SelectActionDialog$DialogActions[SelectActionDialog.DialogActions.off.ordinal()] = 12;
            $SwitchMap$king$james$bible$android$dialog$SelectActionDialog$DialogActions[SelectActionDialog.DialogActions.copy.ordinal()] = 13;
            try {
                $SwitchMap$king$james$bible$android$dialog$SelectActionDialog$DialogActions[SelectActionDialog.DialogActions.share.ordinal()] = 14;
            } catch (NoSuchFieldError unused) {
            }
        }
    }

    private void changeBookmark(BibleDataBase bibleDataBase, final DialogDataBookmark dialogDataBookmark) {
        bibleDataBase.changeBookmark(this.chapter, this.subChapter, dialogDataBookmark, new ChangeBookmarkListener() {
            /* class king.james.bible.android.fragment.ScreenSlidePageFragment.AnonymousClass2 */

            @Override // king.james.bible.android.db.listener.ChangeBookmarkListener
            public void changeBookmark(long j) {
                ScreenSlidePageFragment.this.adapter.changeBookmark((int) j);
            }

            @Override // king.james.bible.android.db.listener.ChangeBookmarkListener
            public void onChangeComplete() {
                ScreenSlidePageFragment.this.postUpdateListEvent(dialogDataBookmark);
            }
        });
    }

    private void removeHighLight(BibleDataBase bibleDataBase, final DialogDataBookmark dialogDataBookmark) {
        bibleDataBase.removeHighLight(this.chapter, this.subChapter, dialogDataBookmark, new RemoveHighLightListener() {
            /* class king.james.bible.android.fragment.ScreenSlidePageFragment.AnonymousClass3 */

            @Override // king.james.bible.android.db.listener.RemoveHighLightListener
            public void removeFromAdapter(int i) {
                ScreenSlidePageFragment.this.adapter.clearColor(i);
            }

            @Override // king.james.bible.android.db.listener.RemoveHighLightListener
            public void onComplete() {
                ScreenSlidePageFragment.this.postUpdateListEvent(dialogDataBookmark);
            }
        });
    }

    @Override // king.james.bible.android.dialog.NoteDialog.NoteDialogListener
    public void onSaveNoteSelect(int i, String str, int i2) {
        if (this.pagePosition == i && this.adapter != null && getActivity() != null) {
            if (this.adapter.getMenuItem() == null) {
                this.adapter.setMenuItem(Integer.valueOf(i2));
            }
            BibleDataBase.getInstance().addNote(this.chapter, this.subChapter, i2, str, new AddRemoveNoteListener(i2, str) {
                /* class king.james.bible.android.fragment.$$Lambda$ScreenSlidePageFragment$JvMcu8RvGhDhJDZV7Z3y7xEcm8A */
                private final /* synthetic */ int f$1;
                private final /* synthetic */ String f$2;

                {
                    this.f$1 = r2;
                    this.f$2 = r3;
                }

                @Override // king.james.bible.android.db.listener.AddRemoveNoteListener
                public final void onComplete(long j) {
                    ScreenSlidePageFragment.this.lambda$onSaveNoteSelect$14$ScreenSlidePageFragment(this.f$1, this.f$2, j);
                }
            });
        }
    }

    public /* synthetic */ void lambda$onSaveNoteSelect$14$ScreenSlidePageFragment(int i, String str, long j) {
        this.adapter.setNote(i, str);
        postUpdateListEvent();
    }

    @Override // king.james.bible.android.dialog.NoteDialog.NoteDialogListener
    public void onDeleteNoteSelect(int i, int i2, int i3, int i4) {
        if (this.pagePosition == i && this.adapter != null && getActivity() != null) {
            BibleDataBase.getInstance().removeNote(i2, i3, i4, new AddRemoveNoteListener() {
                /* class king.james.bible.android.fragment.$$Lambda$ScreenSlidePageFragment$roXpWvRFxlXO7Ujaz79FSmUd1k */

                @Override // king.james.bible.android.db.listener.AddRemoveNoteListener
                public final void onComplete(long j) {
                    ScreenSlidePageFragment.this.lambda$onDeleteNoteSelect$15$ScreenSlidePageFragment(j);
                }
            });
        }
    }

    public /* synthetic */ void lambda$onDeleteNoteSelect$15$ScreenSlidePageFragment(long j) {
        this.adapter.removeNote(j);
        postUpdateListEvent();
    }

    private void postUpdateListEvent() {
        postUpdateListEvent(null);
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void postUpdateListEvent(DialogDataBookmark dialogDataBookmark) {
        boolean z = dialogDataBookmark != null && isRefreshFragment(dialogDataBookmark);
        if (getActivity() != null && !z) {
            getActivity().runOnUiThread(new Runnable() {
                /* class king.james.bible.android.fragment.$$Lambda$ScreenSlidePageFragment$ymrkkrE8Hsn6OiQklrWYozHdb8g */

                public final void run() {
                    ScreenSlidePageFragment.this.lambda$postUpdateListEvent$16$ScreenSlidePageFragment();
                }
            });
            updateList();
        }
    }

    public /* synthetic */ void lambda$postUpdateListEvent$16$ScreenSlidePageFragment() {
        this.adapter.notifyDataSetChanged();
    }

    private void postCopyShareEvent(DialogDataBookmark dialogDataBookmark, boolean z) {
        new Thread(new Runnable(dialogDataBookmark, z) {
            /* class king.james.bible.android.fragment.$$Lambda$ScreenSlidePageFragment$x36djvTe6RVUtaYHsF3fefF5A */
            private final /* synthetic */ DialogDataBookmark f$1;
            private final /* synthetic */ boolean f$2;

            {
                this.f$1 = r2;
                this.f$2 = r3;
            }

            public final void run() {
                ScreenSlidePageFragment.this.lambda$postCopyShareEvent$18$ScreenSlidePageFragment(this.f$1, this.f$2);
            }
        }).start();
    }

    public /* synthetic */ void lambda$postCopyShareEvent$18$ScreenSlidePageFragment(DialogDataBookmark dialogDataBookmark, boolean z) {
        String prepareText = ShareTextUtil.prepareText(dialogDataBookmark.getSelectedSet(), this.chapter, this.subChapter);
        if (getActivity() != null) {
            getActivity().runOnUiThread(new Runnable(z, prepareText) {
                /* class king.james.bible.android.fragment.$$Lambda$ScreenSlidePageFragment$UywswtJSn_Np9ogY0IUbe6WvFb8 */
                private final /* synthetic */ boolean f$1;
                private final /* synthetic */ String f$2;

                {
                    this.f$1 = r2;
                    this.f$2 = r3;
                }

                public final void run() {
                    ScreenSlidePageFragment.this.lambda$null$17$ScreenSlidePageFragment(this.f$1, this.f$2);
                }
            });
        }
    }

    public /* synthetic */ void lambda$null$17$ScreenSlidePageFragment(boolean z, String str) {
        if (z) {
            copyString(str);
        } else {
            sendFeedback(str);
        }
    }

    private void copyString(String str) {
        if (getActivity() != null) {
            ((ClipboardManager) getActivity().getSystemService("clipboard")).setPrimaryClip(ClipData.newPlainText("text", str));
            BibleToast.showLongDurationToast(getActivity(), (int) R.string.copied);
        }
    }

    private void sendFeedback(String str) {
        if (getActivity() != null) {
            FragmentActivity activity = getActivity();
            String[] strArr = {getResources().getString(R.string.feedback_email)};
            String string = getResources().getString(R.string.feedback_subject);
            EmailUtils.sentShare(activity, strArr, string, getString(R.string.app_name) + getString(R.string.point) + getString(R.string.space) + str);
        }
    }

    private void setColor(BibleDataBase bibleDataBase, SpanType spanType, final DialogDataBookmark dialogDataBookmark) {
        if (this.adapter != null) {
            bibleDataBase.addHighLight(this.chapter, this.subChapter, spanType, dialogDataBookmark, new AddHighLightListener() {
                /* class king.james.bible.android.fragment.ScreenSlidePageFragment.AnonymousClass4 */

                @Override // king.james.bible.android.db.listener.AddHighLightListener
                public void addToAdapter(int i, SpanType spanType) {
                    ScreenSlidePageFragment.this.adapter.addColor(i, spanType);
                }

                @Override // king.james.bible.android.db.listener.AddHighLightListener
                public void onAddComplete() {
                    ScreenSlidePageFragment.this.postUpdateListEvent(dialogDataBookmark);
                }
            });
        }
    }

    private boolean isRefreshFragment(DialogDataBookmark dialogDataBookmark) {
        return dialogDataBookmark.getNameChapter() == this.chapter && dialogDataBookmark.getIntNumberChapter() == this.subChapter && this.unicId != dialogDataBookmark.getUnicId();
    }

    private void updateList() {
        try {
            this.adapter.getSelectedSet().clear();
            this.adapter.setMenuItem(null);
            this.adapter.getHeaderHolder().setMenuItem(this.adapter.getMenuItem().intValue());
            this.adapter.getHeaderHolder().setSelectedSet(this.adapter.getSelectedSet());
            getActivity().runOnUiThread(new Runnable() {
                /* class king.james.bible.android.fragment.$$Lambda$ScreenSlidePageFragment$hY7JY9WftkJq5bNxLw22cQeNAo4 */

                public final void run() {
                    ScreenSlidePageFragment.this.lambda$updateList$19$ScreenSlidePageFragment();
                }
            });
            updateList(2, true);
        } catch (Exception unused) {
        }
    }

    public /* synthetic */ void lambda$updateList$19$ScreenSlidePageFragment() {
        this.adapter.getHeaderHolder().returnHeaderItem();
    }

    /* access modifiers changed from: package-private */
    public void reloadFragment() {
        loadModels(true);
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(UpdatePageEvent updatePageEvent) {
        reloadFragment();
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(HidePageSelectionEvent hidePageSelectionEvent) {
        if (hidePageSelectionEvent != null && hidePageSelectionEvent.getPagePosition() != this.pagePosition && this.adapter != null && getActivity() != null && !this.adapter.getSelectedSet().isEmpty()) {
            this.adapter.getSelectedSet().clear();
            this.adapter.setMenuItem(null);
            this.adapter.notifyDataSetChanged();
            this.adapter.getHeaderHolder().setMenuItem(this.adapter.getMenuItem().intValue());
            this.adapter.getHeaderHolder().setSelectedSet(this.adapter.getSelectedSet());
            this.adapter.getHeaderHolder().returnHeaderItem();
        }
    }
}
