package king.james.bible.android;

public final class Constants {
    public static final Long AD_DISABLE_ADS_TIMEOUT = 259200000L;
    public static final String[] PUBLISHER_IDS = {"pub-9489298482310064"};
}
