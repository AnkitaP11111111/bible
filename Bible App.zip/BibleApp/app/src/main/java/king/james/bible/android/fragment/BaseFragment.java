package king.james.bible.android.fragment;

import androidx.fragment.app.Fragment;

public abstract class BaseFragment extends Fragment {
    public void onResumeFromBackStack() {
    }

    public void updateToolbar() {
    }
}
