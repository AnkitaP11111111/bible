package king.james.bible.android.sound.model;

public class SoundButtonModel {
    private int pagePosition;
    private int rank;

    public SoundButtonModel(int i, int i2) {
        this.pagePosition = i;
        this.rank = i2;
    }

    public int getPagePosition() {
        return this.pagePosition;
    }

    public int getRank() {
        return this.rank;
    }
}
