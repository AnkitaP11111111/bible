package king.james.bible.android.service.notifications;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.os.Build;
import android.provider.Settings;
import android.widget.RemoteViews;
import androidx.core.app.NotificationCompat;
import king.james.bible.android.R;
import king.james.bible.android.activity.MainFragmentActivity;
import king.james.bible.android.utils.DateUtil;

public class NotificationsReadingForegroundUtil {
    private static String title;

    public static void startForeground(Context context, NotificationMode notificationMode, String str, long j, long j2) {
        Intent intent = new Intent(context, MainFragmentActivity.class);
        intent.setAction("ACTION.MAIN_ACTION");
        intent.setFlags(603979776);
        intent.putExtra("mode", notificationMode.name());
        intent.putExtra("itemId", j2);
        int i = (int) j2;
        int i2 = notificationMode == NotificationMode.PLAN ? i + 10000 : i + 11000;
        PendingIntent activity = PendingIntent.getActivity(context, i2, intent, Build.VERSION.SDK_INT >= 23 ? 1140850688 : 1073741824);
        RemoteViews remoteViews = new RemoteViews(context.getPackageName(), (int) R.layout.notification_reading);
        String str2 = title;
        if (str2 == null || str2.isEmpty()) {
            title = context.getResources().getString(R.string.app_name);
        }
        remoteViews.setTextViewText(R.id.notification_text_title, title);
        remoteViews.setTextViewText(R.id.notification_text_subtitle, getModePrefix(context, notificationMode, str));
        remoteViews.setTextViewText(R.id.notification_time, DateUtil.getInstance().getNotificationsTime(j, context));
        Bitmap decodeResource = BitmapFactory.decodeResource(context.getResources(), R.drawable.ic_launcher);
        Notification notification = new Notification();
        notification.defaults |= 2;
        NotificationManager notificationManager = (NotificationManager) context.getSystemService("notification");
        createChanel(notificationManager);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, "bible_reading_notification_channel");
        builder.setDefaults(notification.defaults);
        builder.setContentTitle(title);
        builder.setContentIntent(activity);
        builder.setContentText(getModePrefix(context, notificationMode, str));
        builder.setSmallIcon(R.drawable.ic_launcher);
        builder.setLargeIcon(Bitmap.createScaledBitmap(decodeResource, 128, 128, false));
        builder.setAutoCancel(true);
        builder.setSound(Settings.System.DEFAULT_NOTIFICATION_URI);
        if (notificationManager != null) {
            notificationManager.notify(i2, builder.build());
        }
    }

    private static void createChanel(NotificationManager notificationManager) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel notificationChannel = new NotificationChannel("bible_reading_notification_channel", "BibleReading Notifications", 3);
            notificationChannel.setDescription("Channel description");
            notificationChannel.setSound(RingtoneManager.getDefaultUri(2), new AudioAttributes.Builder().setContentType(4).setUsage(6).build());
            notificationChannel.enableLights(true);
            notificationChannel.enableVibration(false);
            notificationChannel.enableLights(false);
            notificationChannel.setVibrationPattern(new long[]{0});
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(notificationChannel);
            }
        }
    }

    private static String getModePrefix(Context context, NotificationMode notificationMode, String str) {
        if (notificationMode == NotificationMode.PLAN) {
            return context.getResources().getString(R.string.update_day, str);
        } else if (notificationMode != NotificationMode.VERSE) {
            return str;
        } else {
            return context.getResources().getString(R.string.update_verse, str);
        }
    }

    public static void cancelNotifications(final Context context, final NotificationMode notificationMode) {
        new Thread(new Runnable() {
            /* class king.james.bible.android.service.notifications.NotificationsReadingForegroundUtil.AnonymousClass1 */

            public void run() {
                @SuppressLint("WrongConstant") NotificationManager notificationManager = (NotificationManager) context.getSystemService("notification");
                int i = notificationMode == NotificationMode.PLAN ? 10000 : 11000;
                for (int i2 = i; i2 <= i + 1000; i2++) {
                    notificationManager.cancel(i2);
                }
            }
        }).start();
    }
}
