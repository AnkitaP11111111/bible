package king.james.bible.android.utils.builder;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import king.james.bible.android.db.service.DailyVerseDataService;
import king.james.bible.android.model.DailyVerse;
import king.james.bible.android.model.comparator.DailyVerseComparator;
import king.james.bible.android.model.export.DailyVerseSimple;
import org.json.JSONArray;
import org.json.JSONException;

public class DailyVerseModelsBuilder {
    public static JSONArray getDailyVerses() {
        List<DailyVerse> dailyVerses = new DailyVerseDataService().getDailyVerses();
        Collections.sort(dailyVerses, new DailyVerseComparator());
        try {
            return new JSONArray(new Gson().toJson(getExportModels(dailyVerses)));
        } catch (JSONException unused) {
            return new JSONArray();
        }
    }

    public static List<DailyVerseSimple> getExportModels() {
        DailyVerseDataService dailyVerseDataService = new DailyVerseDataService();
        List<DailyVerse> arrayList = new ArrayList<>();
        try {
            arrayList = dailyVerseDataService.getDailyVersesSimple();
        } catch (Exception unused) {
        }
        Collections.sort(arrayList, new DailyVerseComparator());
        return getExportModels(arrayList);
    }

    public static List<DailyVerseSimple> getExportModels(List<DailyVerse> list) {
        ArrayList arrayList = new ArrayList();
        if (list != null && !list.isEmpty()) {
            for (DailyVerse dailyVerse : list) {
                if (dailyVerse.isUserCreate()) {
                    arrayList.add(new DailyVerseSimple(dailyVerse));
                }
            }
        }
        return arrayList;
    }

    public static void writeDailyVerses(JSONArray jSONArray) {
        writeDailyVerses((List) new GsonBuilder().create().fromJson(jSONArray.toString(), new TypeToken<List<DailyVerseSimple>>() {
            /* class king.james.bible.android.utils.builder.DailyVerseModelsBuilder.AnonymousClass1 */
        }.getType()));
    }

    public static void writeDailyVerses(List<DailyVerseSimple> list) {
        new DailyVerseDataService().save(getImportModels(list));
    }

    public static List<DailyVerse> getImportModels(List<DailyVerseSimple> list) {
        ArrayList arrayList = new ArrayList();
        if (list != null && !list.isEmpty()) {
            for (DailyVerseSimple dailyVerseSimple : list) {
                arrayList.add(new DailyVerse(dailyVerseSimple));
            }
        }
        return arrayList;
    }
}
