package king.james.bible.android.event;

public class SettingUpdateEvent {
    public boolean isCancel() {
        throw null;
    }
}
