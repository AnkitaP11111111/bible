package king.james.bible.android.task;

import java.util.List;
import king.james.bible.android.db.service.SearchService;
import king.james.bible.android.model.SearchTextResult;
import king.james.bible.android.model.SearchType;

public class SearchPartsTask extends BaseTask<String, Void, Integer> {
    private int chapter;
    private boolean exactPhrase;
    private boolean partial;
    private SearchListener searchListener;
    private String searchText;
    private SearchType searchType;

    public interface SearchListener {
        void onCount(int i, boolean z);

        void onError();

        void onParseComplete(int i, int i2);

        void onPartLoad(int i, List<SearchTextResult> list);
    }

    public SearchPartsTask(SearchType searchType2, String str, int i, boolean z, boolean z2) {
        super(null, null);
        this.searchType = searchType2;
        this.searchText = str;
        this.chapter = i;
        this.exactPhrase = z;
        this.partial = z2;
    }

    /* access modifiers changed from: protected */
    public Integer doExecute(String... strArr) throws Exception {
        SearchService.searchTextModels(this.searchType, this.searchText, this.chapter, this.exactPhrase, this.partial);
        SearchService.setSearchListener(null);
        return 0;
    }

    /* access modifiers changed from: protected */
    public void onPostExecute(Integer num) {
        if (this.searchListener != null && !isCancelled() && this.mException != null) {
            this.searchListener.onError();
        }
    }

    public void setSearchListener(SearchListener searchListener2) {
        SearchService.setSearchListener(searchListener2);
        this.searchListener = searchListener2;
    }
}
