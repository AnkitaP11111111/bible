package king.james.bible.android.event;

public class HidePageSelectionEvent {
    private int pagePosition;

    public HidePageSelectionEvent(int i) {
        this.pagePosition = i;
    }

    public int getPagePosition() {
        return this.pagePosition;
    }
}
