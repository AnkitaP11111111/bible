package king.james.bible.android.fragment.listener;

import android.view.View;
import androidx.drawerlayout.widget.DrawerLayout;

public abstract class DrawerActionListener implements DrawerLayout.DrawerListener {
    @Override // androidx.drawerlayout.widget.DrawerLayout.DrawerListener
    public void onDrawerClosed(View view) {
    }

    @Override // androidx.drawerlayout.widget.DrawerLayout.DrawerListener
    public void onDrawerSlide(View view, float f) {
    }

    @Override // androidx.drawerlayout.widget.DrawerLayout.DrawerListener
    public void onDrawerStateChanged(int i) {
    }
}
