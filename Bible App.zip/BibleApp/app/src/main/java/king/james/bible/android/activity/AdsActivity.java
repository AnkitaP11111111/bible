package king.james.bible.android.activity;

import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Looper;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;

import com.karumi.dexter.BuildConfig;
import king.james.bible.android.R;
import java.util.Iterator;
import java.util.Timer;
import java.util.TimerTask;
import king.james.bible.android.Constants;
import king.james.bible.android.activity.base.NavigationActivity;

import king.james.bible.android.event.NetworkOnEvent;
import king.james.bible.android.service.net.NetworkService;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

public abstract class AdsActivity extends NavigationActivity {
    private RelativeLayout adContainer;
    private FrameLayout adPlaceholder;
    private boolean initAd = false;
    private Timer mTimer;
    private TimerTask mTimerTask;
    private boolean readyToPurchase = false;


    /* access modifiers changed from: protected */
    public abstract void hideAdvertisingButton();


    /* access modifiers changed from: protected */
    public abstract void updateAdvertisingButton();

    /* access modifiers changed from: protected */
    @Override // androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, androidx.fragment.app.FragmentActivity, king.james.bible.android.activity.base.NavigationActivity, king.james.bible.android.activity.base.BaseActivity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
//        this.adContainer = (RelativeLayout) findViewById(R.id.adContainer);
//        this.adPlaceholder = (FrameLayout) findViewById(R.id.fl_adplaceholder);
        postInit();
    }

    private void postInit() {
//        if (!((NavigationActivity) this).preferences.isNoAdvertising()) {
//            new Thread(new Runnable() {
//                /* class king.james.bible.android.activity.$$Lambda$AdsActivity$1QgOSpQ03Dx8GNVKs3NCwcC8aI */
//
//                public final void run() {
//                    AdsActivity.this.lambda$postInit$0$AdsActivity();
//                }
//            }).start();
//            this.adHolder = AdHolderCreator.createAdHolder(this);
//        }
//        checkAD();
//        if (!NetworkService.isConnect() && this.adHolder != null) {
//            hideAD(1);
//        }
        startTimer();
    }

//    public /* synthetic */ void lambda$postInit$0$AdsActivity() {
//        try {
//            BillingProcessor billingProcessor = new BillingProcessor(this, "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAn5vdUL6L/iPDb5CZHb2zMqREi7aDbsZ5Z/3JnAAJsMWaLJ/hlfkHBIiZpSf1JkLk2LSfKqMvNbIJCEg39CsjkLIPtXSCtShr4mGsHnc/ePLhhn9HAKbX4dZ7ZmeQ7Lme3MEubOCn5gtdDb2bjSYK8X6accGs+bUXi/wgMaiw5IDz8yclC0qKNn89xvYU0cCtgCw8GA3XGtnf0xe9lyG1r5SiIclf/VG2tds4b6WOJpPbBJi9mX/O3NkASSp/aIeWs21L3s8Gx5fcXMnSWHGI6pSdl0ya/H4/r2MsfCzedFh4FBxUNOfl1aHOKT3NxPE2NoVMkDTVCG45tFqNsVgpDwIDAQAB", this);
//            this.mBillingProcessor = billingProcessor;
//            billingProcessor.initialize();
//        } catch (Exception unused) {
//        }
//    }

    /* access modifiers changed from: protected */
//    public void checkRequestLocationInEeaOrUnknown() {
//        if (NetworkService.isConnect() && !((NavigationActivity) this).preferences.isNoAdvertising()) {
//            ConsentInformation.getInstance(this).requestConsentInfoUpdate(Constants.PUBLISHER_IDS, new ConsentInfoUpdateListener() {
//                /* class king.james.bible.android.activity.AdsActivity.AnonymousClass1 */
//
//                @Override // com.google.ads.consent.ConsentInfoUpdateListener
//                public void onConsentInfoUpdated(ConsentStatus consentStatus) {
//                    boolean isRequestLocationInEeaOrUnknown = ConsentInformation.getInstance(AdsActivity.this).isRequestLocationInEeaOrUnknown();
//                    if (isRequestLocationInEeaOrUnknown != ((NavigationActivity) AdsActivity.this).preferences.getNonPersonalizedAds()) {
//                        ((NavigationActivity) AdsActivity.this).preferences.setNonPersonalizedAds(isRequestLocationInEeaOrUnknown ? 1 : 0);
//                    }
//                    AdsActivity.this.rebuildAdRequest();
//                }
//
//                @Override // com.google.ads.consent.ConsentInfoUpdateListener
//                public void onFailedToUpdateConsentInfo(String str) {
//                    AdsActivity.this.rebuildAdRequest();
//                }
//            });
//        }
////    }
//
//    /* access modifiers changed from: private */
//    /* access modifiers changed from: public */
//    private void rebuildAdRequest() {
//        startTimer();
//        AdHolder adHolder2 = this.adHolder;
//        if (adHolder2 != null) {
//            adHolder2.rebuildRequest();
////            initAD();
//        }
//    }

//    private void hideNativeAdView(int i) {
//        if (!isFinishing() && this.nativeAdsUnified != null) {
//            runOnUiThread(new Runnable(i) {
//                /* class king.james.bible.android.activity.$$Lambda$AdsActivity$IVwDO18JJm07wUBFq6eYZmNZ5Z4 */
//                private final /* synthetic */ int f$1;
//
//                {
//                    this.f$1 = r2;
//                }
//
//                public final void run() {
//                    AdsActivity.this.lambda$hideNativeAdView$1$AdsActivity(this.f$1);
//                }
//            });
//        }
//    }

//    public /* synthetic */ void lambda$hideNativeAdView$1$AdsActivity(int i) {
//        NativeAdsUnifiedImpl nativeAdsUnifiedImpl;
//        if (!isFinishing() && (nativeAdsUnifiedImpl = this.nativeAdsUnified) != null) {
//            nativeAdsUnifiedImpl.hideView(i);
//            throw null;
//        }
//    }

    private void startTimer() {
//        ((NavigationActivity) this).preferences.isNoAdvertising();
//        if (this.nativeAdsUnified != null) {
//            if (((NavigationActivity) this).preferences.isNoAdvertising()) {
////                hideNativeAdView(2);
//            }
//            if (!NetworkService.isConnect()) {
////                hideNativeAdView(1);
//            }
////            hideNativeAdView(4);
//        }
        stopTimer();
    }

//    private void loadReward() {
//        if (!((NavigationActivity) this).preferences.isNoAdvertising()) {
//            showRewardAdsDialog(true);
//            RewardedAd.load(this, BuildConfig.FLAVOR, new AdRequest.Builder().build(), new RewardedAdLoadCallback() {
//                /* class king.james.bible.android.activity.AdsActivity.AnonymousClass3 */
//
//                @Override // com.google.android.gms.ads.AdLoadCallback
//                public void onAdFailedToLoad(LoadAdError loadAdError) {
//                    RewardAdsDialog.hideDialog();
//                    AdsActivity.this.showEmptyRewardDialog();
//                }
//
//                public void onAdLoaded(RewardedAd rewardedAd) {
//                    AdsActivity.this.rewardedAd = rewardedAd;
//                    RewardAdsDialog.hideDialog();
//                    AdsActivity.this.showReward();
//                }
//            });
//        }
//    }

    private void stopTimer() {
        try {
            this.mTimerTask.cancel();
            this.mTimer.cancel();
            this.mTimer.purge();
            this.mTimer = null;
            this.mTimerTask = null;
        } catch (Exception unused) {
        }
    }
//
//    @Override // com.anjlab.android.iab.v3.BillingProcessor.IBillingHandler
//    public void onProductPurchased(String str, PurchaseInfo purchaseInfo) {
//        hideAdvertisingButton();
//        ((NavigationActivity) this).preferences.setNoAdvertising(true);
//        ((NavigationActivity) this).preferences.lambda$saveBg$1$BiblePreferences();
//        hideAD(2);
//    }
//
//    @Override // com.anjlab.android.iab.v3.BillingProcessor.IBillingHandler
//    public void onPurchaseHistoryRestored() {
//        boolean z;
//        BillingProcessor billingProcessor = this.mBillingProcessor;
//        if (billingProcessor == null || billingProcessor.listOwnedProducts() == null || this.mBillingProcessor.listOwnedProducts().isEmpty()) {
//            showAD();
//            return;
//        }
//        Iterator<String> it = this.mBillingProcessor.listOwnedProducts().iterator();
//        while (true) {
//            z = true;
//            if (it.hasNext()) {
//                if (it.next().equals("english_tagalog.no_ads")) {
//                    ((NavigationActivity) this).preferences.setNoAdvertising(true);
//                    ((NavigationActivity) this).preferences.lambda$saveBg$1$BiblePreferences();
//                    hideAD(2);
//                    z = false;
//                    hideAdvertisingButton();
//                    break;
//                }
//            } else {
//                break;
//            }
//        }
//        if (z) {
//            showAD();
//        }
//    }
//
//    @Override // com.anjlab.android.iab.v3.BillingProcessor.IBillingHandler
//    public void onBillingError(int i, Throwable th) {
//        showAD();
//    }
//
//    @Override // com.anjlab.android.iab.v3.BillingProcessor.IBillingHandler
//    public void onBillingInitialized() {
//        this.readyToPurchase = true;
//    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, king.james.bible.android.activity.base.BaseActivity
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        updateDayNightMode();
    }

    private void updateDayNightMode() {
//        ((NavigationActivity) this).preferences.isNoAdvertising();
    }

    /* access modifiers changed from: protected */
    @Override // androidx.fragment.app.FragmentActivity
    public void onResume() {
        super.onResume();
        resumeAds();
    }

    /* access modifiers changed from: protected */
    public void resumeAds() {
        updateDayNightMode();
        updateAdMenu();
//        checkAD();
//        AdHolder adHolder2 = this.adHolder;
//        if (adHolder2 != null) {
//            adHolder2.resumeAd();
//        }
    }

    /* access modifiers changed from: protected */
//    @Override // androidx.fragment.app.FragmentActivity
//    public void onPause() {
//        AdHolder adHolder2;
//        if (!((NavigationActivity) this).preferences.isNoAdvertising() && (adHolder2 = this.adHolder) != null) {
//            adHolder2.pauseAd();
//        }
//        stopTimer();
//        super.onPause();
//    }

    /* access modifiers changed from: protected */
    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, king.james.bible.android.activity.base.NavigationActivity, king.james.bible.android.activity.base.BaseActivity
    public void onDestroy() {
//        AdHolder adHolder2;
        stopTimer();
//        RewardAdsDialog.hideDialog();
//        BillingProcessor billingProcessor = this.mBillingProcessor;
//        if (billingProcessor != null) {
//            billingProcessor.release();
//        }
//        this.mBillingProcessor = null;
//        if (((NavigationActivity) this).preferences.isNoAdvertising() && (adHolder2 = this.adHolder) != null) {
//            adHolder2.destroyAd();
//        }
        System.gc();
        super.onDestroy();
    }

    /* access modifiers changed from: protected */
//    public void onPurchaseNoAdClick() {
//        closeDrawerLeft();
//        if (((NavigationActivity) this).preferences.getAdMode() == AdMode.MODE4) {
//            loadReward();
//        } else {
//            onPurchase();
//        }
//    }

    /* access modifiers changed from: protected */
//    public void onPurchase() {
//        checkAD();
//        if (!((NavigationActivity) this).preferences.isNoAdvertising() && this.readyToPurchase) {
//            try {
//                this.mBillingProcessor.purchase(this, "english_tagalog.no_ads");
//            } catch (Exception unused) {
//            }
//        }
//    }

    /* access modifiers changed from: protected */
//    public void checkAD() {
//        if (((NavigationActivity) this).preferences.isNoAdvertising()) {
//            hideAD(2);
//        } else {
//            showAD();
//        }
//        updateAdMenu();
//    }

    private void updateAdMenu() {
        updateAdvertisingButton();
    }

//    public void hideAD(int i) {
//        if (!isFinishing()) {
//            AdHolder adHolder2 = this.adHolder;
//            if (adHolder2 != null) {
//                adHolder2.hideAdView();
//            }
//            RelativeLayout relativeLayout = this.adContainer;
//            if (relativeLayout != null) {
//                relativeLayout.setVisibility(8);
//            }
//        }
//    }
//


//    private void showRewardAdsDialog(boolean z) {
//        RewardAdsDialog.show(getSupportFragmentManager(), z);
//    }
//
//    /* access modifiers changed from: private */
//    /* access modifiers changed from: public */
//    private void showEmptyRewardDialog() {
//        RewardAdsDialog.showEmptyReward(getSupportFragmentManager());
//    }

    /* access modifiers changed from: protected */
//    public void initAD() {
//        if (((NavigationActivity) this).preferences.isNoAdvertising()) {
//            RelativeLayout relativeLayout = this.adContainer;
//            if (relativeLayout != null) {
//                relativeLayout.setVisibility(8);
//            }
//            FrameLayout frameLayout = this.adPlaceholder;
//            if (frameLayout != null) {
//                frameLayout.setVisibility(8);
//            }
//        } else if (this.adHolder != null) {
//            if (Looper.myLooper() == Looper.getMainLooper()) {
//                adHolderInitAD();
//            } else {
//                runOnUiThread(new Runnable() {
//                    /* class king.james.bible.android.activity.$$Lambda$AdsActivity$I_ZcN2b9ab7qEfrCi3_7O47pYio */
//
//                    public final void run() {
//                        AdsActivity.this.adHolderInitAD();
//                    }
//                });
//            }
//        }
//    }

    /* access modifiers changed from: private */
//    public void adHolderInitAD() {
//        this.adHolder.initAD(new AdHolderListener() {
//            /* class king.james.bible.android.activity.AdsActivity.AnonymousClass4 */
//
//            @Override // king.james.bible.android.ad.AdHolderListener
//            public void onAdLoaded() {
//                AdsActivity.this.showAD();
//            }
//
//            @Override // king.james.bible.android.ad.AdHolderListener
//            public void onAdFailedToLoad(boolean z) {
//                AdsActivity.this.hideAD(3);
//                if (NetworkService.isConnect()) {
//                    AdsActivity.this.onAdReLoad(z);
//                }
//            }
//
//            @Override // king.james.bible.android.ad.AdHolderListener
//            public void addView(View view) {
//                if (AdsActivity.this.adContainer != null) {
//                    for (int i = 0; i < AdsActivity.this.adContainer.getChildCount(); i++) {
//                        if (AdsActivity.this.adContainer.getChildAt(i).getTag().toString().equals(view.getTag().toString())) {
//                            return;
//                        }
//                    }
//                    AdsActivity.this.adContainer.addView(view);
//                }
//            }
//        });
//        this.initAd = true;
//    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
//    private void onAdReLoad(boolean z) {
//        RelativeLayout relativeLayout;
//        if (!((NavigationActivity) this).preferences.isNoAdvertising() && !isFinishing() && (relativeLayout = this.adContainer) != null) {
//            if (z) {
//                initAD();
//            } else {
//                relativeLayout.postDelayed(new Runnable() {
//                    /* class king.james.bible.android.activity.$$Lambda$AdsActivity$Nr1vjszsTJFqzmEm07S3GBes9nw */
//
//                    public final void run() {
//                        AdsActivity.this.lambda$onAdReLoad$3$AdsActivity();
//                    }
//                }, 10000);
//            }
//        }
//    }

//    public /* synthetic */ void lambda$onAdReLoad$3$AdsActivity() {
//        if (!isFinishing() && this.adContainer != null) {
//            initAD();
//        }
//    }

//    @Subscribe(threadMode = ThreadMode.MAIN)
//    public void onEvent(NetworkOnEvent networkOnEvent) {
//        try {
//            if (this.nativeAdsUnified != null) {
//                this.nativeAdsUnified.clearLastTimerUpdate();
//                throw null;
//            } else if (((NavigationActivity) this).preferences.getNonPersonalizedAds() == 1) {
//                checkRequestLocationInEeaOrUnknown();
//            } else {
//                rebuildAdRequest();
//            }
//        } catch (Exception unused) {
//        }
//    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity
    public void onStart() {
        super.onStart();
//        RewardAdsListenerObservable.getInstance().subscribe(this);
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity
    public void onStop() {
//        RewardAdsListenerObservable.getInstance().remove(this);
        super.onStop();
    }

//    @Override/ctShowRewardAds() {
//        showReward();
//    }
}
