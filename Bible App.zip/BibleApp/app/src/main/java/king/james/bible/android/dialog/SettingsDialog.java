package king.james.bible.android.dialog;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import king.james.bible.android.R;
import king.james.bible.android.utils.AppUtils;

public class SettingsDialog {
    private  Activity r1;

    public static void showSettingsDialog(Activity activity) {
        try {
            new AlertDialog.Builder(activity).setTitle(R.string.settings_dialogtitle).setMessage(R.string.settings_dialogmessage).setPositiveButton(R.string.f175settings_dialogbutton_ok, new DialogInterface.OnClickListener(activity) {
                /* class king.james.bible.android.dialog.$$Lambda$SettingsDialog$_8kXDBEWyyW13z7cb5mgQsWl68 */
                private final /* synthetic */ Activity f$0;

                {
                    this.f$0 = r1;
                }

                public final void onClick(DialogInterface dialogInterface, int i) {
                    SettingsDialog.lambda$showSettingsDialog$0(this.f$0, dialogInterface, i);
                }
            }).setNegativeButton(R.string.cancel, $$Lambda$SettingsDialog$O0HTPEN7239hfI8JUGkCVG9sObU.INSTANCE).show();
        } catch (Exception unused) {
        }
    }

    static /* synthetic */ void lambda$showSettingsDialog$0(Activity activity, DialogInterface dialogInterface, int i) {
        dialogInterface.cancel();
        AppUtils.openSettings(activity);
    }
}
