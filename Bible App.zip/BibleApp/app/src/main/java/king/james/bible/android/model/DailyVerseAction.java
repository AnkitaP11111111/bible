package king.james.bible.android.model;

public enum DailyVerseAction {
    SHARE,
    COPY,
    EDIT,
    UPDATE,
    DELETE,
    EMPTY
}
