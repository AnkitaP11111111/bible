package king.james.bible.android.adapter.holder;

import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.bignerdranch.expandablerecyclerview.ChildViewHolder;

import com.bignerdranch.expandablerecyclerview.ParentViewHolder;
import king.james.bible.android.R;
import king.james.bible.android.model.DailyPlanMonth;
import king.james.bible.android.utils.BiblePreferences;

public class PlanMonthViewHolder extends ParentViewHolder {
    private ImageView arrowImageView;
    private TextView nameTextView;
    private RelativeLayout planMonthRelativeLayout;

    public PlanMonthViewHolder(View view) {
        super(view);
        mapViews(view);
    }

    private void mapViews(View view) {
        this.planMonthRelativeLayout = (RelativeLayout) view.findViewById(R.id.planMonthRelativeLayout);
        this.nameTextView = (TextView) view.findViewById(R.id.nameTextView);
        this.arrowImageView = (ImageView) view.findViewById(R.id.arrowImageView);
    }

    public void updateView(DailyPlanMonth dailyPlanMonth, boolean z) {
        int i;
        int i2;
        this.nameTextView.setText(dailyPlanMonth.getName());
        boolean isNightMode = BiblePreferences.getInstance().isNightMode();
        int i3 = R.color.title_text;
        if (z) {
            i = isNightMode ? R.drawable.arrow_up_n : R.drawable.arrow_up;
            i2 = isNightMode ? R.drawable.plan_month_open_bg_n : R.drawable.plan_month_open_bg;
            if (isNightMode) {
                i3 = R.color.daily_readingplan_monthtext_open_n;
            }
        } else {
            i = isNightMode ? R.drawable.arrow_down_n : R.drawable.arrow_down;
            i2 = isNightMode ? R.drawable.plan_month_close_bg_n : R.drawable.plan_month_close_bg;
            if (isNightMode) {
                i3 = R.color.daily_readingplan_monthtext_close_n;
            }
        }
        this.nameTextView.setTextColor(this.itemView.getContext().getResources().getColor(i3));
        this.arrowImageView.setImageResource(i);
        this.planMonthRelativeLayout.setBackgroundResource(i2);
    }
}
