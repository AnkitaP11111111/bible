package king.james.bible.android.service.notifications.work;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.PendingIntent;
@SuppressLint({"NewApi", "WrongConstant"})

/* access modifiers changed from: package-private */
public class IceCreamSetter extends ISetAlarmStrategy {
    IceCreamSetter() {
    }

    /* access modifiers changed from: package-private */
    @Override // king.james.bible.android.service.notifications.work.ISetAlarmStrategy
    public void setRTCAlarm(AlarmManager alarmManager, long j, PendingIntent pendingIntent) {
        alarmManager.set(0, j, pendingIntent);
    }

    /* access modifiers changed from: package-private */
    @Override // king.james.bible.android.service.notifications.work.ISetAlarmStrategy
    public void setInexactAlarm(AlarmManager alarmManager, long j, PendingIntent pendingIntent) {
        alarmManager.set(0, j, pendingIntent);
    }
}
