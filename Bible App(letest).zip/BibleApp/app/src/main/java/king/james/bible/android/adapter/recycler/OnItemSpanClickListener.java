package king.james.bible.android.adapter.recycler;

import android.view.View;

public interface OnItemSpanClickListener {
    void onClick(int i, View view, boolean z);
}
