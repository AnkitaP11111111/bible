package king.james.bible.android.fragment;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.karumi.dexter.BuildConfig;
import king.james.bible.android.R;
import java.util.List;
import king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter;
import king.james.bible.android.adapter.recycler.SearchRecycleViewAdapter;
import king.james.bible.android.db.BibleDataBase;
import king.james.bible.android.dialog.DialogUtil;
import king.james.bible.android.holder.SearchItemSelectHandler;
import king.james.bible.android.holder.SearchTextViewHolder;
import king.james.bible.android.model.SearchTextResult;
import king.james.bible.android.model.SearchType;
import king.james.bible.android.model.chapter.ChapterSubChapterCursorResult;
import king.james.bible.android.service.PowerManagerService;
import king.james.bible.android.service.SearchHistoryService;
import king.james.bible.android.task.SearchPartsTask;
import king.james.bible.android.utils.BiblePreferences;
import king.james.bible.android.utils.ScreenUtil;
import king.james.bible.android.utils.SearchCache;
import king.james.bible.android.view.AutoCompleteCustomTextView;
@SuppressLint({"NewApi", "WrongConstant","NonConstantResourceId"})


public class SearchFragment extends Fragment implements View.OnClickListener, TextView.OnEditorActionListener, CompoundButton.OnCheckedChangeListener, SearchItemSelectHandler, SearchPartsTask.SearchListener, BaseRecyclerViewAdapter.OnItemClickListener {
    private  SearchTextResult r2;
    private SearchRecycleViewAdapter adapter;
    private BibleDataBase bibleDB;
    private int chapter;
    private CheckBox exactPhraseCheckBox;
    private FragmentCallbackListener fragmentListener;
    private TextView headerText;
    private LinearLayoutManager linearLayoutManager;
    private CheckBox partialCheckBox;
    private BiblePreferences preferences;
    private RadioGroup radioGroup;
    private AutoCompleteCustomTextView searchEdit;
    private RecyclerView searchRecyclerView;
    private SearchPartsTask task;

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        if (getArguments() != null) {
            this.chapter = getArguments().getInt("chapterId", 0);
        }
        if (this.chapter < 1) {
            this.chapter = SearchCache.getInstance().getChapter();
        }
        SearchHistoryService.getInstance().restore();
        BiblePreferences instance = BiblePreferences.getInstance();
        this.preferences = instance;
        instance.lambda$restoreAsync$0$BiblePreferences();
        this.preferences.setNeedToBackMode(false);
        this.preferences.lambda$saveBg$1$BiblePreferences();
        View inflate = layoutInflater.inflate(this.preferences.isNightMode() ? R.layout.activity_search_n : R.layout.activity_search, (ViewGroup) null);
        BibleDataBase instance2 = BibleDataBase.getInstance();
        this.bibleDB = instance2;
        instance2.initColumSearchName();
        inflate.findViewById(R.id.search_page_back_btn).setOnClickListener(this);
        inflate.findViewById(R.id.search_cancel_btn).setOnClickListener(this);
        this.searchEdit = (AutoCompleteCustomTextView) inflate.findViewById(R.id.search_page_search_text);
        this.exactPhraseCheckBox = (CheckBox) inflate.findViewById(R.id.exactPhraseCheckBox);
        this.partialCheckBox = (CheckBox) inflate.findViewById(R.id.partialCheckBox);
        this.radioGroup = (RadioGroup) inflate.findViewById(R.id.search_radio_group);
        RadioButton radioButton = (RadioButton) inflate.findViewById(R.id.search_radio_current);
        RadioButton radioButton2 = (RadioButton) inflate.findViewById(R.id.search_radio_all);
        RadioButton radioButton3 = (RadioButton) inflate.findViewById(R.id.search_radio_ot);
        RadioButton radioButton4 = (RadioButton) inflate.findViewById(R.id.search_radio_nt);
        RadioButton radioButton5 = (RadioButton) inflate.findViewById(R.id.search_radio_ap);
        int i = AnonymousClass8.$SwitchMap$king$james$bible$android$model$SearchType[SearchCache.getInstance().getSearchType().ordinal()];
        if (i == 1) {
            radioButton5.setChecked(true);
        } else if (i == 2) {
            radioButton4.setChecked(true);
        } else if (i == 3) {
            radioButton3.setChecked(true);
        } else if (i != 4) {
            radioButton2.setChecked(true);
        } else {
            this.chapter = SearchCache.getInstance().getChapter();
            radioButton.setChecked(true);
        }
        this.searchEdit.setOnEditorActionListener(this);
        radioButton.setText(this.bibleDB.getChapterNameById((long) this.chapter));
        this.headerText = (TextView) inflate.findViewById(R.id.search_result_header_text);
        this.searchRecyclerView = (RecyclerView) inflate.findViewById(R.id.lv_search_result);
        LinearLayoutManager linearLayoutManager2 = new LinearLayoutManager(getActivity(), 1, false);
        this.linearLayoutManager = linearLayoutManager2;
        this.searchRecyclerView.setLayoutManager(linearLayoutManager2);
        if (!SearchCache.getInstance().isEmptyModelsList()) {
            int size = SearchCache.getInstance().getModels().size();
            initRecycler(size);
            this.adapter.setModels(SearchCache.getInstance().getModels());
            this.adapter.notifyDataSetChanged();
            showResultPanel(size);
            this.searchRecyclerView.postDelayed(new Runnable() {
                /* class king.james.bible.android.fragment.SearchFragment.AnonymousClass1 */

                public void run() {
                    if (SearchFragment.this.getActivity() != null) {
                        ScreenUtil.getInstance().hideKeyboard(SearchFragment.this.getActivity());
                        SearchFragment.this.linearLayoutManager.scrollToPositionWithOffset(SearchCache.getInstance().getListPosition(), 0);
                    }
                }
            }, 600);
        } else {
            ScreenUtil.getInstance().showKeyboard(this.searchEdit);
        }
        radioButton5.setVisibility(8);
        radioButton.setOnClickListener(this);
        radioButton2.setOnClickListener(this);
        radioButton3.setOnClickListener(this);
        radioButton4.setOnClickListener(this);
        radioButton5.setOnClickListener(this);
        PowerManagerService.getInstance().start();
        this.exactPhraseCheckBox.setChecked(this.preferences.isExactPhrase());
        this.exactPhraseCheckBox.setOnCheckedChangeListener(this);
        this.partialCheckBox.setChecked(this.preferences.isPartialSearch());
        this.partialCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            /* class king.james.bible.android.fragment.SearchFragment.AnonymousClass2 */

            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                SearchFragment.this.preferences.setPartialSearch(z);
                SearchFragment.this.preferences.lambda$saveBg$1$BiblePreferences();
                SearchFragment.this.makeSearch();
            }
        });
        this.searchEdit.setText(SearchHistoryService.getInstance().getLastSearch());
        AutoCompleteCustomTextView autoCompleteCustomTextView = this.searchEdit;
        autoCompleteCustomTextView.setSelection(autoCompleteCustomTextView.length());
        new SearchTextViewHolder(this.searchEdit, this);
        return inflate;
    }

    /* renamed from: king.james.bible.android.fragment.SearchFragment$8  reason: invalid class name */
    static /* synthetic */ class AnonymousClass8 {
        static final /* synthetic */ int[] $SwitchMap$king$james$bible$android$model$SearchType;

        /* JADX WARNING: Can't wrap try/catch for region: R(12:0|1|2|3|4|5|6|7|8|9|10|12) */
        /* JADX WARNING: Code restructure failed: missing block: B:13:?, code lost:
            return;
         */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x001d */
        /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x0028 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:9:0x0033 */
        static {
            int[] iArr = new int[SearchType.values().length];
            $SwitchMap$king$james$bible$android$model$SearchType = iArr;
            iArr[SearchType.AP.ordinal()] = 1;
            $SwitchMap$king$james$bible$android$model$SearchType[SearchType.NT.ordinal()] = 2;
            $SwitchMap$king$james$bible$android$model$SearchType[SearchType.OT.ordinal()] = 3;
            $SwitchMap$king$james$bible$android$model$SearchType[SearchType.CURRENT.ordinal()] = 4;
            $SwitchMap$king$james$bible$android$model$SearchType[SearchType.ALL.ordinal()] = 5;
        }
    }

    public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
        this.preferences.setExactPhrase(z);
        this.preferences.lambda$saveBg$1$BiblePreferences();
        makeSearch();
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.search_cancel_btn:
                this.searchEdit.setText(BuildConfig.FLAVOR);
                this.headerText.setVisibility(4);
                onCount(0, false);
                break;
            case R.id.search_page_back_btn:
                ScreenUtil.getInstance().hideKeyboard(getActivity());
                SearchHistoryService.getInstance().save();
                savePosition();
                getActivity().onBackPressed();
                break;
            case R.id.search_radio_all:
            case R.id.search_radio_ap:
            case R.id.search_radio_current:
            case R.id.search_radio_nt:
            case R.id.search_radio_ot:
                makeSearch();
                break;
        }
        PowerManagerService.getInstance().start();
    }

    @Override // androidx.fragment.app.Fragment
    public void onResume() {
        super.onResume();
        if (getActivity() != null) {
            this.searchEdit.postDelayed(new Runnable() {
                /* class king.james.bible.android.fragment.SearchFragment.AnonymousClass3 */

                public void run() {
                    if (SearchFragment.this.getActivity() != null && SearchFragment.this.searchEdit != null && SearchCache.getInstance().isEmptyModelsList()) {
                        ScreenUtil.getInstance().showKeyboard(SearchFragment.this.searchEdit);
                    }
                }
            }, 300);
            PowerManagerService.getInstance().start();
        }
    }

    private boolean isPartial() {
        return this.partialCheckBox.isChecked();
    }

    private SearchType getSearchType() {
        switch (this.radioGroup.getCheckedRadioButtonId()) {
            case R.id.search_radio_ap:
                return SearchType.AP;
            case R.id.search_radio_current:
                return SearchType.CURRENT;
            case R.id.search_radio_group:
            default:
                return SearchType.ALL;
            case R.id.search_radio_nt:
                return SearchType.NT;
            case R.id.search_radio_ot:
                return SearchType.OT;
        }
    }

    private String getSearchText() {
        String obj = this.searchEdit.getText().toString();
        if (obj != null) {
            return obj.trim().replace("(", BuildConfig.FLAVOR).replace(")", BuildConfig.FLAVOR);
        }
        return BuildConfig.FLAVOR;
    }

    @Override // king.james.bible.android.holder.SearchItemSelectHandler
    public void makeSearchBySelectItem() {
        makeSearch();
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void makeSearch() {
        String searchText = getSearchText();
        if (getActivity() != null && searchText != null && !searchText.isEmpty()) {
            SearchPartsTask searchPartsTask = this.task;
            if (searchPartsTask != null) {
                searchPartsTask.setSearchListener(null);
            }
            stopParse();
            SearchCache.getInstance().clear();
            ScreenUtil.getInstance().hideKeyboard(getActivity());
            SearchHistoryService.getInstance().addSearch(searchText);
            SearchHistoryService.getInstance().save();
            clearAdapter();
            DialogUtil.showProgressDialog();
            SearchPartsTask searchPartsTask2 = new SearchPartsTask(getSearchType(), getSearchText(), this.chapter, this.exactPhraseCheckBox.isChecked(), isPartial());
            this.task = searchPartsTask2;
            searchPartsTask2.setSearchListener(this);
            this.task.executeAsyncTask(new String[0]);
        }
    }

    public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
        if (i != 3) {
            return false;
        }
        makeSearch();
        return true;
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            this.fragmentListener = (FragmentCallbackListener) activity;
        } catch (ClassCastException unused) {
            throw new ClassCastException(activity.toString() + " must implement OnHeadlineSelectedListener");
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroy() {
        SearchHistoryService.getInstance().save();
        stopParse();
        savePosition();
        super.onDestroy();
    }

    @Override // king.james.bible.android.task.SearchPartsTask.SearchListener
    public void onCount(final int i, final boolean z) {
        if (getActivity() != null) {
            if (i < 1 && !z) {
                stopParse();
            }
            getActivity().runOnUiThread(new Runnable() {
                /* class king.james.bible.android.fragment.SearchFragment.AnonymousClass4 */

                public void run() {
                    if (i >= 1 || z) {
                        SearchFragment.this.initRecycler(i);
                        SearchFragment.this.showResultPanel(i);
                        return;
                    }
                    SearchFragment.this.clearAdapter();
                    SearchFragment.this.showResultPanel(0);
                    DialogUtil.hideProgressDialog();
                }
            });
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void showResultPanel(int i) {
        try {
            this.headerText.setVisibility(0);
            TextView textView = this.headerText;
            textView.setText(getActivity().getResources().getString(R.string.search_showing) + " " + i + " " + getActivity().getResources().getString(R.string.search_results));
        } catch (Exception unused) {
        }
    }

    @Override // king.james.bible.android.task.SearchPartsTask.SearchListener
    public void onError() {
        onCount(0, false);
    }

    @Override // king.james.bible.android.task.SearchPartsTask.SearchListener
    public void onPartLoad(final int i, final List<SearchTextResult> list) {
        if (getActivity() != null) {
            SearchCache.getInstance().addModels(list);
            getActivity().runOnUiThread(new Runnable() {
                /* class king.james.bible.android.fragment.SearchFragment.AnonymousClass5 */

                public void run() {
                    if (SearchFragment.this.getActivity() != null) {
                        if (SearchFragment.this.adapter != null) {
                            SearchFragment.this.adapter.checkAllCount(i);
                        }
                        if (SearchFragment.this.adapter == null) {
                            SearchFragment.this.initRecycler(i);
                        }
                        SearchFragment.this.showResultPanel(i);
                        SearchFragment.this.addPartWords(list);
                        DialogUtil.hideProgressDialog();
                    }
                }
            });
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void initRecycler(int i) {
        checkAdapter();
        this.adapter.setAllCount(i);
        this.adapter.notifyDataSetChanged();
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void addPartWords(List<SearchTextResult> list) {
        int realItemCount = this.adapter.getRealItemCount();
        this.adapter.addModels(list);
        this.adapter.notifyItemRangeChanged(realItemCount, list.size());
    }

    private void checkAdapter() {
        if (this.adapter == null) {
            this.adapter = new SearchRecycleViewAdapter(this);
        }
        if (this.searchRecyclerView.getAdapter() == null) {
            this.searchRecyclerView.setAdapter(this.adapter);
        }
    }

    @Override // king.james.bible.android.task.SearchPartsTask.SearchListener
    public void onParseComplete(int i, int i2) {
        if (getActivity() != null) {
            stopParse();
            if (i < 1) {
                clearAdapter();
                showResultPanel(0);
                DialogUtil.hideProgressDialog();
            }
        }
    }

    public void stopParse() {
        SearchPartsTask searchPartsTask = this.task;
        if (searchPartsTask != null) {
            searchPartsTask.setSearchListener(null);
            this.task.cancel(true);
        }
        this.task = null;
    }

    /* access modifiers changed from: protected */
    public void clearAdapter() {
        if (this.adapter != null && getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() {
                /* class king.james.bible.android.fragment.SearchFragment.AnonymousClass6 */

                public void run() {
                    if (SearchFragment.this.adapter != null && SearchFragment.this.getActivity() != null) {
                        SearchFragment.this.adapter.clearModels();
                        SearchFragment.this.adapter.notifyDataSetChanged();
                        SearchFragment.this.showResultPanel(0);
                    }
                }
            });
        }
    }

    @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter.OnItemClickListener
    public void onClick(int i) {
        SearchRecycleViewAdapter searchRecycleViewAdapter;
        SearchTextResult model;
        if (getActivity() != null && (searchRecycleViewAdapter = this.adapter) != null && (model = searchRecycleViewAdapter.getModel(i)) != null) {
            new Thread(new Runnable() {
                /* class king.james.bible.android.fragment.$$Lambda$SearchFragment$JBZW16aGXTNyySBcbf1_P2vmHg */
                private final /* synthetic */ SearchTextResult f$1;

                {
                    this.f$1 = r2;
                }

                public final void run() {
                    SearchFragment.this.lambda$onClick$0$SearchFragment(this.f$1);
                }
            }).start();
        }
    }

    public /* synthetic */ void lambda$onClick$0$SearchFragment(SearchTextResult searchTextResult) throws Throwable {
        try {
            ChapterSubChapterCursorResult allStuffById = this.bibleDB.getAllStuffById(searchTextResult.getId());
            int rankByChapter = this.bibleDB.getRankByChapter(allStuffById.getChapter(), allStuffById.getSubChapter() + 1, allStuffById.getPosition());
            savePosition();
            openResultScreen(allStuffById, rankByChapter);
        } catch (Exception unused) {
        }
    }

    private void savePosition() {
        SearchCache.getInstance().setListPosition(this.linearLayoutManager.findFirstVisibleItemPosition());
        SearchCache.getInstance().setChapter(this.chapter);
    }

    private void openResultScreen(final ChapterSubChapterCursorResult chapterSubChapterCursorResult, final int i) {
        if (getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() {
                /* class king.james.bible.android.fragment.SearchFragment.AnonymousClass7 */

                public void run() {
                    try {
                        SearchFragment.this.getActivity().onBackPressed();
                        if (SearchFragment.this.fragmentListener != null) {
                            SearchFragment.this.fragmentListener.onFragmentResultOk(chapterSubChapterCursorResult.getChapter(), chapterSubChapterCursorResult.getSubChapter(), chapterSubChapterCursorResult.getPosition() - 1, i, this);
                        }
                        SearchCache.getInstance().setBackStack(true);
                        PowerManagerService.getInstance().start();
                    } catch (Exception unused) {
                    }
                }
            });
        }
    }
}
