package king.james.bible.android.task;

import android.content.Context;
import java.util.List;
import king.james.bible.android.model.SearchText;
import king.james.bible.android.service.SearchHistoryService;
import king.james.bible.android.task.BaseTask;

public class SearchTask extends BaseTask<String, Void, List<SearchText>> {

    public interface OnCallbackHandler extends BaseTask.OnCallbackHandler<List<SearchText>> {
    }

    public SearchTask(Context context, BaseTask.OnCallbackHandler<List<SearchText>> onCallbackHandler) {
        super(context, onCallbackHandler);
    }

    /* access modifiers changed from: protected */
    public List<SearchText> doExecute(String... strArr) throws Exception {
        return SearchHistoryService.getInstance().search(strArr[0]);
    }
}
