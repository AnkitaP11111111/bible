package king.james.bible.android.utils.builder;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import king.james.bible.android.db.service.DailyReadingDataImportService;
import king.james.bible.android.db.service.DailyReadingDataService;
import king.james.bible.android.model.Plan;
import king.james.bible.android.model.PlanChapterDay;
import king.james.bible.android.model.PlanDay;
import king.james.bible.android.model.export.PlanChapterDayExport;
import king.james.bible.android.model.export.PlanDayExport;
import king.james.bible.android.model.export.PlanExport;
import org.json.JSONArray;
import org.json.JSONException;

public class DailyReadingBuilder {
    public static JSONArray getDailyReading() {
        try {
            return new JSONArray(new Gson().toJson(getExportModels()));
        } catch (JSONException unused) {
            return new JSONArray();
        }
    }

    public static List<PlanExport> getExportModels() {
        ArrayList arrayList = new ArrayList();
        List<Plan> planList = new DailyReadingDataService().getPlanList();
        if (planList != null && !planList.isEmpty()) {
            for (Plan plan : planList) {
                if (plan.isStarted()) {
                    arrayList.add(getPlanExportModel(plan));
                }
            }
        }
        return arrayList;
    }

    private static PlanExport getPlanExportModel(Plan plan) {
        PlanExport planExport = new PlanExport(plan.getId(), plan.getStartDate(), plan.getModeId(), plan.isNotify(), plan.getNotifyTime());
        planExport.setPlanDays(new HashMap());
        for (PlanDay planDay : plan.getPlanDays()) {
            PlanDayExport planDayExportModel = getPlanDayExportModel(planDay);
            if (planDayExportModel != null) {
                planExport.getPlanDays().put(Integer.valueOf(planDay.getDay()), planDayExportModel);
            }
        }
        return planExport;
    }

    private static PlanDayExport getPlanDayExportModel(PlanDay planDay) {
        if (!planDay.isReaded()) {
            return getPlanDayExportModelNotReaded(planDay);
        }
        PlanDayExport planDayExport = new PlanDayExport();
        planDayExport.setReaded(true);
        planDayExport.setPlanChapterDays(new ArrayList());
        return planDayExport;
    }

    private static PlanDayExport getPlanDayExportModelNotReaded(PlanDay planDay) {
        boolean z;
        Iterator<PlanChapterDay> it = planDay.getPlanChapterDays().iterator();
        while (true) {
            if (it.hasNext()) {
                if (it.next().isViewed()) {
                    z = true;
                    break;
                }
            } else {
                z = false;
                break;
            }
        }
        if (!z) {
            return null;
        }
        PlanDayExport planDayExport = new PlanDayExport();
        planDayExport.setReaded(false);
        planDayExport.setPlanChapterDays(new ArrayList());
        for (PlanChapterDay planChapterDay : planDay.getPlanChapterDays()) {
            if (planChapterDay.isViewed()) {
                planDayExport.getPlanChapterDays().add(new PlanChapterDayExport(planChapterDay.getChapterOrder(), planChapterDay.getChapterNum()));
            }
        }
        return planDayExport;
    }

    public static void writeDailyReading(JSONArray jSONArray) {
        writeDailyReading((List) new GsonBuilder().create().fromJson(jSONArray.toString(), new TypeToken<List<PlanExport>>() {
            /* class king.james.bible.android.utils.builder.DailyReadingBuilder.AnonymousClass1 */
        }.getType()));
    }

    public static void writeDailyReading(List<PlanExport> list) {
        new DailyReadingDataImportService().importData(list);
    }
}
