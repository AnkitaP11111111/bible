package king.james.bible.android.service.net;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import java.util.Timer;
import java.util.TimerTask;

import king.james.bible.android.MyApplication;
import king.james.bible.android.event.NetworkOnEvent;
import org.greenrobot.eventbus.EventBus;

public class NetworkService {
    private NetworkStatus currentStatus;
    private Timer timer;
    private TimerTask timerTask;

    public enum NetworkStatus {
        WIFI,
        MOBILE,
        NOT_CONNECTED
    }

    /* access modifiers changed from: private */
    public static class SingletonHelper {
        private static final NetworkService INSTANCE = new NetworkService();
    }

    private NetworkService() {
        this.currentStatus = NetworkStatus.NOT_CONNECTED;
    }

    public static NetworkService getInstance() {
        return SingletonHelper.INSTANCE;
    }

    public void startObservable() {
        if (this.timer == null) {
            this.timerTask = new TimerTask() {
                /* class king.james.bible.android.service.net.NetworkService.AnonymousClass1 */

                public void run() {
                    Context context = MyApplication.getContext();
                    NetworkStatus networkStatus = NetworkStatus.NOT_CONNECTED;
                    if (context != null) {
                        networkStatus = NetworkService.this.getNetworkStatus(context);
                    }
                    if (networkStatus != NetworkService.this.currentStatus) {
                        NetworkService.this.onNewStatus(networkStatus);
                    }
                }
            };
            Timer timer2 = new Timer();
            this.timer = timer2;
            try {
                timer2.schedule(this.timerTask, 0, 30);
            } catch (Exception unused) {
            }
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void onNewStatus(NetworkStatus networkStatus) {
        if (networkStatus != this.currentStatus) {
            this.currentStatus = networkStatus;
            EventBus.getDefault().post(new NetworkOnEvent());
        }
    }

    public void stopObservable() {
        this.currentStatus = null;
        Timer timer2 = this.timer;
        if (timer2 != null) {
            timer2.cancel();
        }
        this.timer = null;
        TimerTask timerTask2 = this.timerTask;
        if (timerTask2 != null) {
            timerTask2.cancel();
        }
        this.timerTask = null;
    }

    @SuppressLint({"MissingPermission", "WrongConstant"})
    private int getConnectivityStatus(Context context) {
        NetworkInfo networkInfo;
        try {
            networkInfo = ((ConnectivityManager) context.getSystemService("connectivity")).getActiveNetworkInfo();
        } catch (Exception unused) {
            networkInfo = null;
        }
        if (networkInfo == null) {
            return 0;
        }
        if (networkInfo.getType() == 1) {
            return 1;
        }
        if (networkInfo.getType() == 0) {
            return 2;
        }
        return 0;
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private NetworkStatus getNetworkStatus(Context context) {
        int connectivityStatus = getConnectivityStatus(context);
        NetworkStatus networkStatus = NetworkStatus.NOT_CONNECTED;
        if (connectivityStatus == 1) {
            return NetworkStatus.WIFI;
        }
        return connectivityStatus == 2 ? NetworkStatus.MOBILE : networkStatus;
    }

    private void checkActive() {
        onNewStatus(getNetworkStatus(MyApplication.getContext()));
        if (this.timer == null) {
            startObservable();
        }
    }

    public boolean isConnectNetwork() {
        checkActive();
        return this.currentStatus != NetworkStatus.NOT_CONNECTED;
    }

    public static boolean isConnect() {
        return getInstance().isConnectNetwork();
    }
}
