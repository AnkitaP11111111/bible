package king.james.bible.android.adapter.holder;

import android.view.View;
import java.util.List;
import java.util.Set;
import king.james.bible.android.db.listener.UpdateViewHolderListener;
import king.james.bible.android.model.Text;
import king.james.bible.android.sound.listener.page.SoundPlayListener;
import king.james.bible.android.view.HeaderTextList;
import king.james.bible.android.view.MarkerTextView;

public class MainHeaderViewHolder extends MainFragmentViewHolder {
    private HeaderTextList headerTextList;
    private MarkerTextView.OnSelectionListener onSelectionListener;
    private UpdateViewHolderListener updateViewHolderListener;

    public MainHeaderViewHolder(View view, UpdateViewHolderListener updateViewHolderListener2, MarkerTextView.OnSelectionListener onSelectionListener2) {
        super(view);
        this.updateViewHolderListener = updateViewHolderListener2;
        this.onSelectionListener = onSelectionListener2;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter.BaseViewHolder
    public void mapViews(View view) {
        this.headerTextList = (HeaderTextList) view;
    }

    @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter.BaseViewHolder
    public void updateView(Object obj) {
        this.headerTextList.setUpdateViewHolderListener(this.updateViewHolderListener);
        this.headerTextList.setOnSelectionListener(this.onSelectionListener);
    }

    public void setModel(List<Text> list, Set<Integer> set, boolean z, int i) {
        this.headerTextList.setModel(list, set, z, i);
    }

    public void updateBySettingsChange() {
        this.headerTextList.updateBySettingsChange();
    }

    public void setPagePosition(int i) {
        this.headerTextList.setPagePosition(i);
    }

    public void setTag(Object obj) {
        this.headerTextList.setTag(obj);
    }

    public void setUnicId(int i) {
        this.headerTextList.setUnicId(i);
    }

    public void setMenuItem(int i) {
        this.headerTextList.setMenuItem(i);
    }

    public void setSelectedSet(Set<Integer> set) {
        this.headerTextList.setSelectedSet(set);
    }

    public void returnHeaderItem() {
        this.headerTextList.returnHeaderItem();
    }

    public void setSoundPlayListener(SoundPlayListener soundPlayListener) {
        this.headerTextList.setSoundPlayListener(soundPlayListener);
    }

    public void updateButtons() {
        this.headerTextList.updateButtons();
    }

    public int getPositionView() {
        return this.headerTextList.getPositionView();
    }

    public void prepareSoundPauseBackground() {
        this.headerTextList.prepareSoundPauseBackground();
    }

    public void animItem(int i) {
        this.headerTextList.animItem(i);
    }
}
