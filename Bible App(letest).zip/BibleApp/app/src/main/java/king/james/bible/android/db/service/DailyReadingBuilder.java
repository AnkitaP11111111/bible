package king.james.bible.android.db.service;

import android.content.ContentValues;
import android.database.Cursor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import king.james.bible.android.PlanModeUtil;
import king.james.bible.android.model.Plan;
import king.james.bible.android.model.PlanChapterDay;
import king.james.bible.android.model.PlanDay;

public class DailyReadingBuilder {
    public static List<Plan> createModels(Cursor cursor, boolean z) {
        ArrayList arrayList = new ArrayList();
        if (cursor.moveToFirst()) {
            do {
                arrayList.add(createModel(cursor, z));
            } while (cursor.moveToNext());
        }
        return arrayList;
    }

    public static Plan createModel(Cursor cursor) {
        return createModel(cursor, false);
    }

    public static Plan createModel(Cursor cursor, boolean z) {
        Plan plan = new Plan();
        plan.setId(cursor.getLong(cursor.getColumnIndexOrThrow("_id")));
        plan.setTitle(cursor.getString(cursor.getColumnIndexOrThrow("title")));
        if (z) {
            return plan;
        }
        boolean z2 = true;
        long j = 0;
        int i = 0;
        try {
            plan.setNotify(Boolean.valueOf(cursor.getInt(cursor.getColumnIndexOrThrow("notify")) > 0).booleanValue());
            Long valueOf = Long.valueOf(cursor.getLong(cursor.getColumnIndexOrThrow("notify_time")));
            plan.setNotifyTime(valueOf != null ? valueOf.longValue() : 0);
        } catch (Exception unused) {
            plan.setNotify(false);
            plan.setNotifyTime(0);
        }
        plan.setDescription(cursor.getString(cursor.getColumnIndexOrThrow("description")));
        plan.setOrder(cursor.getInt(cursor.getColumnIndexOrThrow("order_val")));
        Long valueOf2 = Long.valueOf(cursor.getLong(cursor.getColumnIndexOrThrow("start_date")));
        plan.setStartDate(valueOf2 != null ? valueOf2.longValue() : 0);
        Long valueOf3 = Long.valueOf(cursor.getLong(cursor.getColumnIndexOrThrow("end_date")));
        if (valueOf3 != null) {
            j = valueOf3.longValue();
        }
        plan.setEndDate(j);
        if (cursor.getInt(cursor.getColumnIndexOrThrow("started")) <= 0) {
            z2 = false;
        }
        plan.setStarted(Boolean.valueOf(z2).booleanValue());
        Integer valueOf4 = Integer.valueOf(cursor.getInt(cursor.getColumnIndexOrThrow("mode_id")));
        if (valueOf4 != null) {
            i = valueOf4.intValue();
        }
        plan.setModeId(i);
        plan.setModeIds(cursor.getString(cursor.getColumnIndexOrThrow("mode_ids")));
        addModeModels(plan);
        return plan;
    }

    private static void addModeModels(Plan plan) {
        plan.setPlanModes(new ArrayList());
        String[] split = plan.getModeIds().split(",");
        int length = split.length;
        Integer[] numArr = new Integer[length];
        for (int i = 0; i < split.length; i++) {
            numArr[i] = Integer.valueOf(Integer.parseInt(split[i]));
        }
        for (int i2 = 0; i2 < length; i2++) {
            plan.getPlanModes().add(PlanModeUtil.plansMode.get(numArr[i2]));
        }
    }

    public static ContentValues getPlanContentValues(Plan plan) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("title", plan.getTitle());
        contentValues.put("description", plan.getDescription());
        contentValues.put("order_val", Integer.valueOf(plan.getOrder()));
        contentValues.put("start_date", Long.valueOf(plan.getStartDate()));
        contentValues.put("end_date", Long.valueOf(plan.getEndDate()));
        contentValues.put("started", Boolean.valueOf(plan.isStarted()));
        contentValues.put("mode_id", Integer.valueOf(plan.getModeId()));
        contentValues.put("mode_ids", plan.getModeIds());
        contentValues.put("notify", Boolean.valueOf(plan.isNotify()));
        contentValues.put("notify_time", Long.valueOf(plan.getNotifyTime()));
        return contentValues;
    }

    public static ContentValues getPlanDayContentValues(long j, int i, boolean z) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("plan_id", Long.valueOf(j));
        contentValues.put("day", Integer.valueOf(i));
        contentValues.put("readed", Boolean.valueOf(z));
        return contentValues;
    }

    public static ContentValues getPlanDayContentValues(PlanDay planDay) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("plan_id", Long.valueOf(planDay.getPlanId()));
        contentValues.put("day", Integer.valueOf(planDay.getDay()));
        contentValues.put("readed", Boolean.valueOf(planDay.isReaded()));
        return contentValues;
    }

    public static List<PlanDay> cretePlanDays(Cursor cursor) {
        ArrayList arrayList = new ArrayList();
        if (cursor.moveToFirst()) {
            do {
                arrayList.add(createPlanDay(cursor));
            } while (cursor.moveToNext());
        }
        return arrayList;
    }

    public static PlanDay createPlanDay(Cursor cursor) {
        PlanDay planDay = new PlanDay();
        planDay.setId(cursor.getLong(cursor.getColumnIndexOrThrow("_id")));
        planDay.setPlanId(cursor.getLong(cursor.getColumnIndexOrThrow("plan_id")));
        planDay.setDay(cursor.getInt(cursor.getColumnIndexOrThrow("day")));
        planDay.setReaded(cursor.getInt(cursor.getColumnIndexOrThrow("readed")) > 0);
        return planDay;
    }

    public static Map<Integer, List<PlanChapterDay>> createPlanChapterDaysMap(Cursor cursor) {
        HashMap hashMap = new HashMap();
        if (cursor.moveToFirst()) {
            do {
                PlanChapterDay createPlanChapterDay = createPlanChapterDay(cursor);
                if (!hashMap.containsKey(Integer.valueOf(createPlanChapterDay.getDay()))) {
                    hashMap.put(Integer.valueOf(createPlanChapterDay.getDay()), new ArrayList());
                }
                ((List) hashMap.get(Integer.valueOf(createPlanChapterDay.getDay()))).add(createPlanChapterDay);
            } while (cursor.moveToNext());
        }
        return hashMap;
    }

    public static PlanChapterDay createPlanChapterDay(Cursor cursor) {
        PlanChapterDay planChapterDay = new PlanChapterDay();
        planChapterDay.setId(cursor.getLong(cursor.getColumnIndexOrThrow("_id")));
        planChapterDay.setPlanId(cursor.getLong(cursor.getColumnIndexOrThrow("plan_id")));
        planChapterDay.setModeId((long) cursor.getInt(cursor.getColumnIndexOrThrow("mode_id")));
        planChapterDay.setDay(cursor.getInt(cursor.getColumnIndexOrThrow("day")));
        planChapterDay.setChapterOrder(cursor.getInt(cursor.getColumnIndexOrThrow("chapter_order")));
        planChapterDay.setViewed(cursor.getInt(cursor.getColumnIndexOrThrow("viewed")) > 0);
        planChapterDay.setChapterNum(cursor.getInt(cursor.getColumnIndexOrThrow("chapter_num")));
        return planChapterDay;
    }

    public static ContentValues getChapterDayContentValues(PlanChapterDay planChapterDay) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("plan_id", Long.valueOf(planChapterDay.getPlanId()));
        contentValues.put("mode_id", Long.valueOf(planChapterDay.getModeId()));
        contentValues.put("day", Integer.valueOf(planChapterDay.getDay()));
        contentValues.put("chapter_order", Integer.valueOf(planChapterDay.getChapterOrder()));
        contentValues.put("viewed", Boolean.valueOf(planChapterDay.isViewed()));
        contentValues.put("chapter_num", Integer.valueOf(planChapterDay.getChapterNum()));
        return contentValues;
    }
}
