//package king.james.bible.android.ad;
//
//import android.content.Context;
//import king.james.bible.ad.AdHolderImpl;
//
//public class AdHolderCreator {
//    public static AdHolder createAdHolder(Context context) {
//        AdHolderImpl adHolderImpl = new AdHolderImpl();
//        adHolderImpl.createAd(context);
//        return adHolderImpl;
//    }
//}
