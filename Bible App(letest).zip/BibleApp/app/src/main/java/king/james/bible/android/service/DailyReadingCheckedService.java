package king.james.bible.android.service;

import android.widget.CheckBox;
import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

public class DailyReadingCheckedService {
    private static DailyReadingCheckedService instance;
    private Map<Long, CheckBox> checkBoxMap = new HashMap();
    private Map<Long, DailyReadingCheckedHandler> handlerMap = new HashMap();
    private Timer timer;

    public interface DailyReadingCheckedHandler {
        Boolean isCheckedModel();

        void setCheckedModel(boolean z);
    }

    private DailyReadingCheckedService() {
        startTimer();
    }

    public static DailyReadingCheckedService getInstance() {
        if (instance == null) {
            synchronized (DailyReadingCheckedService.class) {
                if (instance == null) {
                    instance = new DailyReadingCheckedService();
                }
            }
        }
        return instance;
    }

    public void clear() {
        this.handlerMap.clear();
        this.handlerMap = new HashMap();
        this.checkBoxMap.clear();
        this.checkBoxMap = new HashMap();
        stopTimer();
    }

    public void remove(long j) {
        if (this.checkBoxMap.containsKey(Long.valueOf(j))) {
            this.checkBoxMap.remove(Long.valueOf(j));
            this.handlerMap.remove(Long.valueOf(j));
        }
    }

    private void stopTimer() {
        Timer timer2 = this.timer;
        if (timer2 != null) {
            timer2.cancel();
        }
        this.timer = null;
    }

    public void add(long j, CheckBox checkBox, DailyReadingCheckedHandler dailyReadingCheckedHandler) {
        if (this.timer == null) {
            startTimer();
        }
        this.checkBoxMap.put(Long.valueOf(j), checkBox);
        this.handlerMap.put(Long.valueOf(j), dailyReadingCheckedHandler);
    }

    private void startTimer() {
        Timer timer2 = new Timer();
        this.timer = timer2;
        timer2.schedule(new TimerTask() {
            /* class king.james.bible.android.service.DailyReadingCheckedService.AnonymousClass1 */

            public void run() {
                try {
                    DailyReadingCheckedService.this.actionTimer();
                } catch (Exception unused) {
                }
            }
        }, 0, 200);
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private synchronized void actionTimer() {
        Boolean isCheckedModel;
        if (!this.handlerMap.isEmpty()) {
            for (Map.Entry<Long, CheckBox> entry : this.checkBoxMap.entrySet()) {
                DailyReadingCheckedHandler dailyReadingCheckedHandler = this.handlerMap.get(entry.getKey());
                if (!(entry.getValue() == null || dailyReadingCheckedHandler == null || (isCheckedModel = dailyReadingCheckedHandler.isCheckedModel()) == null || entry.getValue().isChecked() == isCheckedModel.booleanValue())) {
                    dailyReadingCheckedHandler.setCheckedModel(entry.getValue().isChecked());
                }
            }
        }
    }
}
