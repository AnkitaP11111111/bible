package king.james.bible.android.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import king.james.bible.android.R;
import king.james.bible.android.db.MigrationUserDataUtil;

public class LaunchActivity extends Activity {
    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_load);
        checkData();
        initSplashView();
    }

    private void checkData() {
        new Thread($$Lambda$LaunchActivity$bkGfLmoY4zMTpTsI0HYF0KyGil4.INSTANCE).start();
    }

    static /* synthetic */ void lambda$checkData$0() {
        if (MigrationUserDataUtil.getInstance().isEmptyDBRecords()) {
            MigrationUserDataUtil.getInstance().writeUserData();
        }
    }

    private void initSplashView() {
        findViewById(R.id.name).postDelayed(new Runnable() {
            /* class king.james.bible.android.activity.$$Lambda$LaunchActivity$rBobYGFIqdZYTOrJ0S_dZKs1dM */

            public final void run() {
                LaunchActivity.this.hideSplash();
            }
        }, 500);
    }

    /* access modifiers changed from: private */
    public void hideSplash() {
        if (!isFinishing()) {
            overridePendingTransition(0, 0);
            new Thread(new Runnable() {
                /* class king.james.bible.android.activity.$$Lambda$LaunchActivity$gtxWWDzlwOftR01nFvXmSyUf_g */

                public final void run() {
                    LaunchActivity.this.lambda$hideSplash$1$LaunchActivity();
                }
            }).start();
        }
    }

    public /* synthetic */ void lambda$hideSplash$1$LaunchActivity() {
        try {
            startActivity(new Intent(this, MainFragmentActivity.class));
            overridePendingTransition(0, 0);
            finish();
        } catch (Exception unused) {
        }
    }
}
