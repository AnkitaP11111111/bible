package king.james.bible.android.fragment.span;

import android.annotation.SuppressLint;
import android.os.Handler;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import king.james.bible.android.R;
import java.util.ArrayList;
import king.james.bible.android.adapter.recycler.OnItemSpanClickListener;
import king.james.bible.android.adapter.recycler.span.HighlightsItemAdapter;
import king.james.bible.android.db.BibleDataBase;
import king.james.bible.android.db.listener.RemoveHighLightListener;
import king.james.bible.android.dialog.DialogUtil;
import king.james.bible.android.model.SpanType;
import king.james.bible.android.model.span.SpanItem;
import king.james.bible.android.service.PowerManagerService;
@SuppressLint({"NewApi", "WrongConstant"})

public class HighlightsFragment extends BaseSpanFragment implements View.OnClickListener, OnItemSpanClickListener {
    private HighlightsItemAdapter adapter;
    private LinearLayout noEntries;
    private RadioGroup radioGroup;
    private RadioGroup radioGroup2;
    private SpanType spanType = SpanType.EMPTY_TYPE;

    @Override // king.james.bible.android.fragment.span.BaseSpanFragment
    public int getRootViewId() {
        return this.preferences.isNightMode() ? R.layout.activity_highlights_n : R.layout.activity_highlights;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.fragment.span.BaseSpanFragment
    public void mapViews(View view) {
        this.noEntries = (LinearLayout) view.findViewById(R.id.no_entries_highlights);
        this.radioGroup = (RadioGroup) view.findViewById(R.id.highlights_radio_group);
        this.radioGroup2 = (RadioGroup) view.findViewById(R.id.highlights_radio_group2);
        clearCheckRadioGroup1();
        clearCheckRadioGroup2();
        ((RadioButton) view.findViewById(R.id.highlights_radio_all)).setChecked(true);
        this.spanType = SpanType.EMPTY_TYPE;
        view.findViewById(R.id.highlights_radio_all).setOnClickListener(this);
        view.findViewById(R.id.highlights_radio_color_1).setOnClickListener(this);
        view.findViewById(R.id.highlights_radio_color_2).setOnClickListener(this);
        view.findViewById(R.id.highlights_radio_color_3).setOnClickListener(this);
        view.findViewById(R.id.highlights_radio_color_4).setOnClickListener(this);
        view.findViewById(R.id.highlights_radio_color_5).setOnClickListener(this);
        view.findViewById(R.id.highlights_radio_color_6).setOnClickListener(this);
        view.findViewById(R.id.highlights_radio_color_7).setOnClickListener(this);
        view.findViewById(R.id.highlights_radio_color_8).setOnClickListener(this);
        view.findViewById(R.id.highlights_radio_uline).setOnClickListener(this);
        this.radioGroup.measure(0, 0);
        RecyclerView recyclerView = (RecyclerView) view.findViewById(R.id.lv_highlights_result);
        this.adapter = HighlightsItemAdapter.create(this);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), 1, false));
        recyclerView.setAdapter(this.adapter);
        new Handler().postDelayed(new Runnable() {
            /* class king.james.bible.android.fragment.span.$$Lambda$HighlightsFragment$GAchr3wUSWRBHRytXqWkUrwwAss */

            public final void run() {
                HighlightsFragment.this.lambda$mapViews$1$HighlightsFragment();
            }
        }, 200);
    }

    public /* synthetic */ void lambda$mapViews$1$HighlightsFragment() {
        new Thread(new Runnable() {
            /* class king.james.bible.android.fragment.span.$$Lambda$HighlightsFragment$ybqkfkwJQHxKKQAwg6eABCHMEmk */

            public final void run() {
                HighlightsFragment.this.lambda$null$0$HighlightsFragment();
            }
        }).start();
    }

    public /* synthetic */ void lambda$null$0$HighlightsFragment() {
        try {
            loadModels();
        } catch (Exception unused) {
            DialogUtil.hideProgressDialog();
        }
    }

    private SpanType getSpanType() {
        SpanType spanType2 = this.spanType;
        return spanType2 == null ? SpanType.EMPTY_TYPE : spanType2;
    }

    @Override // king.james.bible.android.fragment.span.BaseSpanFragment
    public void onClick(View view) {
        super.onClick(view);
        if (getActivity() != null) {
            DialogUtil.showProgressDialog();
            switch (view.getId()) {
                case R.id.highlights_radio_all:
                    this.spanType = SpanType.EMPTY_TYPE;
                    clearCheckRadioGroup2();
                    break;
                case R.id.highlights_radio_color_1:
                    this.spanType = SpanType.COLOR_1;
                    clearCheckRadioGroup2();
                    break;
                case R.id.highlights_radio_color_2:
                    this.spanType = SpanType.COLOR_2;
                    clearCheckRadioGroup2();
                    break;
                case R.id.highlights_radio_color_3:
                    this.spanType = SpanType.COLOR_3;
                    clearCheckRadioGroup2();
                    break;
                case R.id.highlights_radio_color_4:
                    this.spanType = SpanType.COLOR_4;
                    clearCheckRadioGroup2();
                    break;
                case R.id.highlights_radio_color_5:
                    this.spanType = SpanType.COLOR_5;
                    clearCheckRadioGroup1();
                    break;
                case R.id.highlights_radio_color_6:
                    this.spanType = SpanType.COLOR_6;
                    clearCheckRadioGroup1();
                    break;
                case R.id.highlights_radio_color_7:
                    this.spanType = SpanType.COLOR_7;
                    clearCheckRadioGroup1();
                    break;
                case R.id.highlights_radio_color_8:
                    this.spanType = SpanType.COLOR_8;
                    clearCheckRadioGroup1();
                    break;
                case R.id.highlights_radio_uline:
                    this.spanType = SpanType.UNDERLINE;
                    clearCheckRadioGroup1();
                    break;
            }
            loadModels();
        }
    }

    private void clearCheckRadioGroup1() {
        clearCheckRadioGroup(this.radioGroup);
    }

    private void clearCheckRadioGroup2() {
        clearCheckRadioGroup(this.radioGroup2);
    }

    private void clearCheckRadioGroup(RadioGroup radioGroup3) {
        try {
            radioGroup3.clearCheck();
        } catch (Exception unused) {
        }
    }

    private void onLoadFinished(ArrayList<SpanItem> arrayList) {
        if (getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() {
                private  ArrayList r2;
                /* class king.james.bible.android.fragment.span.$$Lambda$HighlightsFragment$b8rnmG_mOSU7TNN0Fg8ef5CiKM */
                private final /* synthetic */ ArrayList f$1;

                {
                    this.f$1 = r2;
                }

                public final void run() {
                    HighlightsFragment.this.lambda$onLoadFinished$2$HighlightsFragment(this.f$1);
                }
            });
        }
    }

    public /* synthetic */ void lambda$onLoadFinished$2$HighlightsFragment(ArrayList arrayList) {
        if (getActivity() != null && !getActivity().isFinishing()) {
            PowerManagerService.getInstance().start();
            try {
                if (arrayList.isEmpty()) {
                    this.noEntries.setVisibility(0);
                    this.adapter.updateModels(arrayList);
                    DialogUtil.hideProgressDialog();
                    return;
                }
                this.noEntries.setVisibility(4);
                this.adapter.setSearchText(this.searchText);
                this.adapter.updateModels(arrayList);
                DialogUtil.hideProgressDialog();
            } catch (Exception unused) {
            }
        }
    }

    private void loadModels() {
        DialogUtil.showProgressDialog();
        new Thread(new Runnable() {
            /* class king.james.bible.android.fragment.span.$$Lambda$HighlightsFragment$5lQjCDpwBL9IcDyBW8NXZBdy1go */

            public final void run() {
                HighlightsFragment.this.lambda$loadModels$3$HighlightsFragment();
            }
        }).start();
    }

    public /* synthetic */ void lambda$loadModels$3$HighlightsFragment() {
        onLoadFinished(BibleDataBase.getInstance().getHighlightsCursor(this.searchText, getSpanType()));
    }

    @Override // king.james.bible.android.fragment.span.BaseSpanFragment
    public void makeSearch() {
        loadModels();
    }

//    /* access modifiers changed from: protected */
//    @Override // king.james.bible.android.fragment.span.BaseSpanFragment
//    public void removeItem(long j) {
//        this.bibleDB.removeHighLight(j, new RemoveHighLightListener() {
//            /* class king.james.bible.android.fragment.span.HighlightsFragment.AnonymousClass1 */
//
//            @Override // king.james.bible.android.db.listener.RemoveHighLightListener
//            public void removeFromAdapter(int i) {
//            }
//
//            @Override // king.james.bible.android.db.listener.RemoveHighLightListener
//            public void onComplete() {
//                HighlightsFragment.this.makeSearch();
//                HighlightsFragment.this.postDelete();
//            }
//        });
//    }

    @Override // king.james.bible.android.fragment.span.BaseSpanFragment
    public void notifyDataSetChanged() {
        HighlightsItemAdapter highlightsItemAdapter = this.adapter;
        if (highlightsItemAdapter != null) {
            highlightsItemAdapter.notifyDataSetChanged();
        }
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.fragment.span.BaseSpanFragment
    public void updateWidth() {
        this.adapter.initWidth(getActivity());
    }

    @Override // king.james.bible.android.adapter.recycler.OnItemSpanClickListener
    public void onClick(int i, View view, boolean z) {
        if (!executeAction()) {
            return;
        }
        if (z) {
            showItemDeleteView(view);
        } else {
            moveToReadingScreen(view);
        }
    }
}
