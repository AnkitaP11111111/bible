package king.james.bible.android.utils;

import java.util.HashMap;
import java.util.Map;

public class DailyReadingCache {
    private static Map<Long, Integer> startedPositionMap;

    public static void put(long j, int i) {
        if (startedPositionMap == null) {
            initMap();
        }
        startedPositionMap.put(Long.valueOf(j), Integer.valueOf(i));
    }

    public static int getDayPosition(long j) {
        if (startedPositionMap == null) {
            initMap();
        }
        if (startedPositionMap.containsKey(Long.valueOf(j))) {
            return startedPositionMap.get(Long.valueOf(j)).intValue();
        }
        return 0;
    }

    public static void clear() {
        Map<Long, Integer> map = startedPositionMap;
        if (map != null) {
            map.clear();
        }
        initMap();
    }

    private static void initMap() {
        startedPositionMap = new HashMap();
    }
}
