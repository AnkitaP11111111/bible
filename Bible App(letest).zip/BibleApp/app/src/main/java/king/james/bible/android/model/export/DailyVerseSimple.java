package king.james.bible.android.model.export;

import java.util.Set;
import king.james.bible.android.model.DailyVerse;

public class DailyVerseSimple {
    private Set<Long> chapters;
    private boolean notify;
    private long notifyTime;
    private String title;
    private long verseId;

    public DailyVerseSimple(DailyVerse dailyVerse) {
        this.title = dailyVerse.getTitle();
        this.verseId = dailyVerse.getVerseId();
        this.notify = dailyVerse.isNotify();
        this.notifyTime = dailyVerse.getNotifyTime();
        this.chapters = dailyVerse.getChapters();
    }

    public String getTitle() {
        return this.title;
    }

    public long getVerseId() {
        return this.verseId;
    }

    public boolean isNotify() {
        return this.notify;
    }

    public long getNotifyTime() {
        return this.notifyTime;
    }

    public Set<Long> getChapters() {
        return this.chapters;
    }
}
