package king.james.bible.android.model;

import com.karumi.dexter.BuildConfig;

public class Verse {
    private long chapterId;
    private String chapterName;
    private int chapterNum;
    private int head;
    private long id;
    private int position;
    private String text;

    public long getId() {
        return this.id;
    }

    public void setId(long j) {
        this.id = j;
    }

    public long getChapterId() {
        return this.chapterId;
    }

    public void setChapterId(long j) {
        this.chapterId = j;
    }

    public int getChapterNum() {
        return this.chapterNum;
    }

    public void setChapterNum(int i) {
        this.chapterNum = i;
    }

    public String getChapterName() {
        return this.chapterName;
    }

    public void setChapterName(String str) {
        this.chapterName = str;
    }

    public int getPosition() {
        return this.position;
    }

    public void setPosition(int i) {
        this.position = i;
    }

    public String getText() {
        String str = this.text;
        return str != null ? str : BuildConfig.FLAVOR;
    }

    public void setText(String str) {
        this.text = str;
    }

    public int getHead() {
        return this.head;
    }

    public void setHead(int i) {
        this.head = i;
    }

    public boolean isVerse() {
        return this.head == 0;
    }

    public boolean isHeader() {
        return this.head == 1;
    }

    public boolean isSubHeader() {
        return this.head == 2;
    }
}
