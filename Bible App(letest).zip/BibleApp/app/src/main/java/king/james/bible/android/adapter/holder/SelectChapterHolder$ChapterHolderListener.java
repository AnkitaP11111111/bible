package king.james.bible.android.adapter.holder;

public interface SelectChapterHolder$ChapterHolderListener {
    void setSelected(boolean z);
}
