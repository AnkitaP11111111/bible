package king.james.bible.android.utils;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Build;
import androidx.core.content.FileProvider;
import king.james.bible.android.R;
import java.io.File;

public class AppUtils {
    public static boolean isNetworkAvailable(Context context) {
        if (context == null) {
            return false;
        }
        try {
            ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService("connectivity");
            if (connectivityManager == null || connectivityManager.getActiveNetworkInfo() == null || !connectivityManager.getActiveNetworkInfo().isConnected()) {
                return false;
            }
            return true;
        } catch (Exception unused) {
            return false;
        }
    }

    public static float convertDpToPixel(float f, Context context) {
        return f * (((float) context.getResources().getDisplayMetrics().densityDpi) / 160.0f);
    }

    public static String replaceOnBoldSearch(String str, String str2, String str3, String str4) {
        int indexOf;
        StringBuilder sb = new StringBuilder(str2.toLowerCase());
        StringBuilder sb2 = new StringBuilder(str);
        StringBuilder sb3 = new StringBuilder(str.toLowerCase());
        String lowerCase = str3.toLowerCase();
        int i = 0;
        int i2 = -1;
        while (true) {
            indexOf = sb.indexOf(lowerCase, i);
            if (indexOf == -1) {
                break;
            }
            i2++;
            if (i2 > 0) {
                indexOf += i2 * 7;
            }
            sb2.replace(indexOf, lowerCase.length() + indexOf, "<b>" + sb2.substring(indexOf, str3.length() + indexOf) + "</b>");
            sb3.replace(indexOf, lowerCase.length() + indexOf, "<b>" + sb3.substring(indexOf, str3.length() + indexOf) + "</b>");
            i = indexOf + str4.length();
        }
        if (i2 == -1 && indexOf == -1) {
            int i3 = 0;
            int i4 = -1;
            while (true) {
                i3 = sb3.indexOf(lowerCase, i3);
                if (i3 == -1) {
                    break;
                }
                i4++;
                if (i4 > 0) {
                    i3 += i4 * 7;
                }
                if (lowerCase.length() + i3 < sb2.length()) {
                    sb2.replace(i3, lowerCase.length() + i3, "<b>" + sb2.substring(i3, str3.length() + i3) + "</b>");
                    sb3.replace(i3, lowerCase.length() + i3, "<b>" + sb3.substring(i3, str3.length() + i3) + "</b>");
                    i3 += str4.length();
                }
            }
        }
        sb3.setLength(0);
        sb3.trimToSize();
        return sb2.toString();
    }

    public static double getPercent(int i, int i2, int i3) {
        return round((double) ((((float) i) / ((float) i2)) * 100.0f), i3);
    }

    private static double round(double d, int i) {
        double d2 = (double) i;
        double round = (double) Math.round(d * Math.pow(10.0d, d2));
        double pow = Math.pow(10.0d, d2);
        Double.isNaN(round);
        return round / pow;
    }

    public static void openMarketPage(Activity activity) {
        if (activity != null) {
            Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + activity.getPackageName()));
            intent.addFlags(1208483840);
            try {
                activity.startActivity(intent);
            } catch (ActivityNotFoundException unused) {
                activity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(activity.getString(R.string.KJB_app_url) + activity.getPackageName())));
            }
        }
    }

    public static void shareApp(Context context) {
        String string = context.getResources().getString(R.string.share_app_text_message);
        String string2 = context.getResources().getString(R.string.share_app_text_chooser);
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("text/plain");
        intent.setAction("android.intent.action.SEND");
        intent.putExtra("android.intent.extra.TEXT", string + " \n" + (context.getResources().getString(R.string.KJB_app_url) + context.getPackageName()));
        context.startActivity(Intent.createChooser(intent, string2));
    }

    public static void openPrivatePolicyLink(Activity activity) {
        try {
            activity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(activity.getString(R.string.privacy_policy_link))));
        } catch (Throwable unused) {
        }
    }

    public static void openSettings(Activity activity) {
        Intent intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
        intent.setData(Uri.fromParts("package", activity.getPackageName(), null));
        activity.startActivityForResult(intent, 101);
    }

    public static void shareFile(Context context, File file) {
        Uri uri;
        if (file == null || !file.exists() || !file.canRead()) {
            BibleToast.showShortDurationToast(context, R.string.f152errorfile_not_found);
            return;
        }
        try {
            Intent intent = new Intent("android.intent.action.SEND");
            if (Build.VERSION.SDK_INT >= 24) {
                uri = FileProvider.getUriForFile(context, context.getApplicationContext().getPackageName() + ".share.bible.provider", file);
                intent.addFlags(1);
                intent.setType("application/octet-stream");
            } else {
                uri = Uri.parse("file://" + file);
                intent.setType("text/plain");
            }
            intent.putExtra("android.intent.extra.STREAM", uri);
            context.startActivity(Intent.createChooser(intent, context.getResources().getString(R.string.f138choosershare)));
        } catch (Exception unused) {
            BibleToast.showShortDurationToast(context, R.string.error);
        }
    }

    public static void onOpenTTSDeviceSettingsScreen(Context context) {
        try {
            Intent intent = new Intent();
            intent.setAction("com.android.settings.TTS_SETTINGS");
            intent.setFlags(268435456);
            context.startActivity(intent);
        } catch (Exception unused) {
        }
    }
}
