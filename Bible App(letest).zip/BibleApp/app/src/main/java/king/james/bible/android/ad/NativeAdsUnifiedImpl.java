//package king.james.bible.android.ad;
//
//public class NativeAdsUnifiedImpl {
//    public void clearLastTimerUpdate() {
//        throw null;
//    }
//
//    public void hideView(int i) {
//        throw null;
//    }
//}
