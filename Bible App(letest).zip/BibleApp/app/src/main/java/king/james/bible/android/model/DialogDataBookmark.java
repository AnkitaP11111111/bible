package king.james.bible.android.model;

import java.util.TreeSet;

public class DialogDataBookmark {
    private int menuItem;
    private int nameChapter;
    private int numberChapter;
    private TreeSet<Integer> selectedSet;
    private int unicId;

    public DialogDataBookmark(TreeSet<Integer> treeSet, int i, int i2, int i3, int i4) {
        this.selectedSet = treeSet;
        this.nameChapter = i;
        this.numberChapter = i2;
        this.unicId = i3;
        this.menuItem = i4;
    }

    public TreeSet<Integer> getSelectedSet() {
        return this.selectedSet;
    }

    public int getNameChapter() {
        return this.nameChapter;
    }

    public int getIntNumberChapter() {
        return this.numberChapter;
    }

    public int getUnicId() {
        return this.unicId;
    }

    public int getMenuItem() {
        return this.menuItem;
    }
}
