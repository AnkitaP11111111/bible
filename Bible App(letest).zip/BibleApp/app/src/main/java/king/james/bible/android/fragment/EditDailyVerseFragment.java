package king.james.bible.android.fragment;

import android.os.Bundle;
import android.view.View;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import king.james.bible.android.R;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter;
import king.james.bible.android.adapter.recycler.EditDailyVerseRecyclerViewAdapter;
import king.james.bible.android.db.service.DailyVerseDataService;
import king.james.bible.android.db.service.SelectChapterService;
import king.james.bible.android.model.DailyVerse;
import king.james.bible.android.model.EditDailyVerse;
import king.james.bible.android.model.SelectChapter;
import king.james.bible.android.model.comparator.SelectChapterComparator;
import king.james.bible.android.service.notifications.NotificationDataService;
import king.james.bible.android.utils.BiblePreferences;
import king.james.bible.android.utils.BibleToast;
import king.james.bible.android.view.EditDailyVerseGridLayoutManager;

public class EditDailyVerseFragment extends BaseDailyFragment {
    private EditDailyVerseRecyclerViewAdapter adapter;
    private DailyVerse dailyVerse;
    private DailyVerseDataService dailyVerseService;
    private FloatingActionButton okFloatingActionButton;
    private RecyclerView recyclerView;
    private int rightColumnSize;

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.fragment.BaseDailyFragment
    public int getViewResId() {
        return R.layout.fragment_edit_daily_verse;
    }

    @Override // androidx.fragment.app.Fragment
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (getArguments() != null) {
            this.dailyVerse = (DailyVerse) getArguments().getSerializable("DailyVerse");
        }
        if (this.dailyVerse == null) {
            DailyVerse dailyVerse2 = new DailyVerse();
            this.dailyVerse = dailyVerse2;
            dailyVerse2.setId(0);
            this.dailyVerse.setTitle(getString(R.string.daily_verse));
            this.dailyVerse.setNotify(false);
            this.dailyVerse.setNotifyTime(0);
            this.dailyVerse.setChapters(new HashSet());
        }
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.fragment.BaseDailyFragment
    public void mapViews(View view) {
        setToolbarTitle(R.string.daily_versesedit);
        this.okFloatingActionButton = (FloatingActionButton) view.findViewById(R.id.okFloatingActionButton);
        this.recyclerView = (RecyclerView) view.findViewById(R.id.editDailyVerseRecyclerView);
        view.findViewById(R.id.rootRelativeLayout).setBackgroundResource(BiblePreferences.getInstance().isNightMode() ? R.color.cardview_dark_background : R.color.black_bg);
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.fragment.BaseDailyFragment
    public void initActions() {
        this.dailyVerseService = new DailyVerseDataService();
        List<SelectChapter> models = getModels();
        boolean prepareModels = prepareModels(models);
        this.recyclerView.setLayoutManager(new EditDailyVerseGridLayoutManager(getActivity(), 2, this.rightColumnSize));
        EditDailyVerseRecyclerViewAdapter editDailyVerseRecyclerViewAdapter = new EditDailyVerseRecyclerViewAdapter(models, this.dailyVerse, prepareModels);
        this.adapter = editDailyVerseRecyclerViewAdapter;
        this.recyclerView.setAdapter(editDailyVerseRecyclerViewAdapter);
        this.recyclerView.addItemDecoration(new BaseRecyclerViewAdapter.ActionBottomSpaceDecoration(getResources().getDimensionPixelSize(R.dimen.buttonactionsize) + getResources().getDimensionPixelSize(R.dimen.indent_xlarge)));
        this.okFloatingActionButton.setOnClickListener(this);
    }

    private boolean prepareModels(List<SelectChapter> list) {
        if (this.dailyVerse.getChapters() == null || this.dailyVerse.getChapters().isEmpty()) {
            return true;
        }
        boolean z = true;
        for (SelectChapter selectChapter : list) {
            if (this.dailyVerse.getChapters().contains(selectChapter.getId())) {
                selectChapter.setSelected(true);
            } else {
                selectChapter.setSelected(false);
                z = false;
            }
        }
        return z;
    }

    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r4v5, types: [java.lang.Object] */
    /* JADX WARNING: Unknown variable types count: 2 */
    private List<SelectChapter> getModels() {
        int i;
        List<SelectChapter> allSelectChapter = SelectChapterService.getInstance().getAllSelectChapter();
        Collections.sort(allSelectChapter, new SelectChapterComparator());
        int i2 = 0;
        this.rightColumnSize = 0;
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        for (SelectChapter selectChapter : allSelectChapter) {
            if (selectChapter.getMode() == 2) {
                this.rightColumnSize++;
                arrayList2.add(selectChapter);
            } else {
                arrayList.add(selectChapter);
            }
        }
        if (this.rightColumnSize >= 1 && arrayList.size() >= arrayList2.size()) {
            allSelectChapter = new ArrayList<>();
            while (true) {
                i = this.rightColumnSize;
                if (i2 >= i) {
                    break;
                }
                allSelectChapter.add((SelectChapter) arrayList.get(i2));
                allSelectChapter.add((SelectChapter) arrayList2.get(i2));
                i2++;
            }
            allSelectChapter.addAll(arrayList.subList(i, arrayList.size()));
        }
        return allSelectChapter;
    }

    @Override // king.james.bible.android.fragment.BaseDailyFragment
    public void onClick(View view) {
        super.onClick(view);
        if (view.getId() == R.id.okFloatingActionButton) {
            okClick();
        }
    }

    private void okClick() {
        DailyVerse dailyVerse2;
        EditDailyVerse editModel = this.adapter.getEditModel();
        if (editModel != null) {
            String title = editModel.getTitle();
            if (title == null || title.isEmpty()) {
                BibleToast.showLongDurationToast(getActivity(), (int) R.string.daily_verseinput_error);
            } else if (editModel.getSelectChapters().isEmpty()) {
                BibleToast.showLongDurationToast(getActivity(), (int) R.string.daily_verseempty_select);
            } else {
                if (this.dailyVerse.getId() > 0) {
                    dailyVerse2 = this.dailyVerseService.updateDailyVerse(this.dailyVerse.getId(), editModel.getSelectChapters(), title, this.dailyVerse.isUserCreate(), editModel.isNotify(), editModel.getNotifyTime());
                } else {
                    DailyVerseDataService dailyVerseDataService = this.dailyVerseService;
                    dailyVerse2 = dailyVerseDataService.createModel(editModel.getSelectChapters(), title, editModel.isNotify(), editModel.getNotifyTime());
                    dailyVerseDataService.save(dailyVerse2);
                }
                if (dailyVerse2 != null) {
                    NotificationDataService.getInstance().addOrUpdateVerse(dailyVerse2, getActivity());
                }
                onBackClick();
            }
        }
    }
}
