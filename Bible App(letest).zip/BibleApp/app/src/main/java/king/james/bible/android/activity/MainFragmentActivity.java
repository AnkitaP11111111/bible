package king.james.bible.android.activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentManager;
import king.james.bible.android.R;
import king.james.bible.android.activity.base.NavigationActivity;
import king.james.bible.android.appad.AppAdService;
import king.james.bible.android.appad.AppAdStorage;
import king.james.bible.android.db.BibleDataBase;
import king.james.bible.android.dialog.DialogUtil;
import king.james.bible.android.event.DrawerOpenEvent;
import king.james.bible.android.event.OpenFromContents3Event;
import king.james.bible.android.event.ShowBackupHint;
import king.james.bible.android.fragment.DailyReadingFragment;
import king.james.bible.android.fragment.DailyVerseFragment;
import king.james.bible.android.fragment.FeedbackFragment;
import king.james.bible.android.fragment.FragmentCallbackListener;
import king.james.bible.android.fragment.MainScreenFragment;
import king.james.bible.android.fragment.SearchFragment;
import king.james.bible.android.fragment.SettingsFragment;
import king.james.bible.android.fragment.contents.ContentsMainFragment;
import king.james.bible.android.fragment.listener.DrawerActionListener;
import king.james.bible.android.fragment.span.BookmarksFragment;
import king.james.bible.android.fragment.span.HighlightsFragment;
import king.james.bible.android.fragment.span.NotesFragment;
import king.james.bible.android.service.BackStackService;
import king.james.bible.android.service.DailyReadingService;
import king.james.bible.android.service.DailyVerseService;
import king.james.bible.android.service.LastChaptersService;
import king.james.bible.android.service.PowerManagerService;
import king.james.bible.android.service.notifications.NotificationMode;
import king.james.bible.android.service.notifications.NotificationService;
import king.james.bible.android.service.observable.FragmentCallbackObservable;
import king.james.bible.android.sound.SoundHelper;
import king.james.bible.android.utils.AppUtils;
import king.james.bible.android.utils.BiblePreferences;
import king.james.bible.android.utils.DailyReadingCache;
import king.james.bible.android.utils.ScreenUtil;
import king.james.bible.android.utils.SearchCache;
import king.james.bible.android.view.holder.PagesSwipeHintHolder;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
@SuppressLint({"NewApi", "WrongConstant","NonConstantResourceId"})

public class MainFragmentActivity extends AdsActivity implements View.OnClickListener, FragmentCallbackListener {
    public static boolean firstLoad = true;
    public static boolean showAdDialog = true;
    private  boolean r2;
    private BibleDataBase bibleDB;
    private boolean copyDBError = false;
    private boolean dailyReadingRoot = false;
    private TextView errorTextView;
    private View loadView;
    private boolean lockMenu = false;
    private DrawerLayout mDrawerLayout;
    private LinearLayout mDrawerPane;
    private boolean mLoadActivity = true;
    private ImageView menuImage;
    private LinearLayout menuSettings;
    private boolean needRestart = false;
    private LinearLayout noAdvertisingBtn;
    private View pagesSwipeHintContainer;

    /* access modifiers changed from: protected */
    @Override // androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, androidx.fragment.app.FragmentActivity, king.james.bible.android.activity.base.NavigationActivity, king.james.bible.android.activity.AdsActivity, king.james.bible.android.activity.base.BaseActivity
    public void onCreate(Bundle bundle) {
        AppAdService.loadDialogs(this);
        super.onCreate(bundle);
        boolean z = false;
        if (((NavigationActivity) this).preferences.isLoadScreen()) {
            ((NavigationActivity) this).preferences.setNeedToBackMode(false);
            ((NavigationActivity) this).preferences.saveBg();
        }
        View findViewById = findViewById(R.id.loadView);
        this.loadView = findViewById;
        findViewById.setVisibility(bundle == null ? 0 : 8);
        this.pagesSwipeHintContainer = findViewById(R.id.pagesSwipeHintContainer);
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.drawerPane);
        this.mDrawerPane = linearLayout;
        if (linearLayout == null) {
            finish();
            return;
        }
        this.errorTextView = (TextView) findViewById(R.id.errorTextView);
        this.mDrawerPane.setVisibility(8);
        this.menuImage = (ImageView) findViewById(R.id.menu_image);
        this.bibleDB = BibleDataBase.getInstance();
        FragmentCallbackObservable.getInstance().subscribe(this);
        if (!((NavigationActivity) this).preferences.isLoadScreen()) {
            this.loadView.setVisibility(8);
            showScrollHint();
            loadMainContent();
            if (bundle != null) {
                z = true;
            }
            existDataBase(z);
            return;
        }
        loadMainContent();
        if (!((NavigationActivity) this).preferences.isLoadScreen()) {
            this.loadView.setVisibility(8);
            showScrollHint();
            if (bundle != null) {
                z = true;
            }
            existDataBase(z);
            return;
        }
        if (bundle != null) {
            z = true;
        }
        checkDataBase(z);
    }

    private void checkNotifications() {
        NotificationService.checkAsyncNotifications(this);
    }

    void showScrollHint() {
        if (((NavigationActivity) this).preferences.isHintPagesSwipe()) {
            new PagesSwipeHintHolder(this.pagesSwipeHintContainer, new PagesSwipeHintHolder.HideHintListener() {
                @Override
                public void onHide() {
                    showScrollHint();
                }
            }).show();
            ((NavigationActivity) this).preferences.setHintPagesSwipe(false);
            ((NavigationActivity) this).preferences.saveBg();
        }
    }

    private void checkDataBase(boolean z) {
        new Thread(new Runnable() {
            /* class king.james.bible.android.activity.$$Lambda$MainFragmentActivity$gbCwx7Q6maqSUryRCNbGEcCdxdY */
            private final /* synthetic */ boolean f$1;

            {
                this.f$1 = r2;
            }

            public final void run() {
                MainFragmentActivity.this.lambda$checkDataBase$1$MainFragmentActivity(this.f$1);
            }
        }).start();
    }

    public /* synthetic */ void lambda$checkDataBase$1$MainFragmentActivity(boolean z) {
        try {
            this.bibleDB.openForMigration();
            existDataBase(z);
        } catch (Exception unused) {
            setNewPatch();
        }
    }

    private void setNewPatch() {
        try {
            this.bibleDB.setNewPatch();
            existDataBase(false);
        } catch (Exception unused) {
            showCopyDBError();
        }
    }

    private void showCopyDBError() {
        if (!((NavigationActivity) this).preferences.isLoadScreen()) {
            runOnUiThread(new Runnable() {
                /* class king.james.bible.android.activity.$$Lambda$MainFragmentActivity$k3uFMpgNwoFUqmg5w3CERTOWoPg */

                public final void run() {
                    MainFragmentActivity.this.lambda$showCopyDBError$2$MainFragmentActivity();
                }
            });
        } else {
            runOnUiThread(new Runnable() {
                /* class king.james.bible.android.activity.$$Lambda$MainFragmentActivity$a3tBdfMGQgwN_cz_5tZ4diryz4 */

                public final void run() {
                    MainFragmentActivity.this.lambda$showCopyDBError$3$MainFragmentActivity();
                }
            });
        }
    }

    public /* synthetic */ void lambda$showCopyDBError$2$MainFragmentActivity() {
        this.errorTextView.setVisibility(0);
        this.loadView.setVisibility(0);
        this.copyDBError = true;
    }

    public /* synthetic */ void lambda$showCopyDBError$3$MainFragmentActivity() {
        ((NavigationActivity) this).preferences.setLoadScreen(false);
        ((NavigationActivity) this).preferences.lambda$saveBg$1$BiblePreferences();
        this.copyDBError = true;
        this.errorTextView.setVisibility(0);
    }

    private void existDataBase(boolean z) {
        if (!isFinishing()) {
            try {
                this.bibleDB.open();
                this.bibleDB.initColumSearchName();
                runOnUiThread(new Runnable() {
                    /* class king.james.bible.android.activity.$$Lambda$MainFragmentActivity$4kt7kcSM3CYzB9c57fd5p1T8vc */
                    private final /* synthetic */ boolean f$1;

                    {
                        this.f$1 = r2;
                    }

                    public final void run() {
                        MainFragmentActivity.this.lambda$existDataBase$4$MainFragmentActivity(this.f$1);
                    }
                });
                this.bibleDB.initChapterList();
                this.bibleDB.getTotalPagesCount();
                this.bibleDB.initNameMapAsync();
            } catch (Exception unused) {
                showCopyDBError();
            }
        }
    }

    public /* synthetic */ void lambda$existDataBase$4$MainFragmentActivity(boolean z) {
        if (!z) {
            loadMainFragmentFirst();
        } else {
            this.mLoadActivity = false;
            restoreFragments();
        }
        updateNotificationInstance(getIntent());
    }

    private void loadMainFragmentFirst() {
        try {
            if (this.bibleDB.getTotalPagesCount() < 1) {
                showCopyDBError();
            } else {
                loadMainFragment();
            }
        } catch (Exception unused) {
            showCopyDBError();
        }
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.activity.base.NavigationActivity
    public void loadDBComplete() {
        LinearLayout linearLayout;
        if (!isFinishing() && (linearLayout = this.mDrawerPane) != null) {
            linearLayout.setVisibility(0);
            this.loadView.setVisibility(8);
            showScrollHint();
            this.mLoadActivity = false;
            if (firstLoad) {
                firstLoad = false;
                ((NavigationActivity) this).preferences.incStartAppCount();
                ((NavigationActivity) this).preferences.incStartAppShareCount();
                AppAdStorage.getInstance().incStartCount();
            }
            ((NavigationActivity) this).preferences.setLoadScreen(true);
            ((NavigationActivity) this).preferences.lambda$saveBg$1$BiblePreferences();
            if (!isFinishing() && getFragmentManager() != null && showAdDialog && !isFinishing()) {
                if (AppUtils.isNetworkAvailable(this) && ((NavigationActivity) this).preferences.isShowEvaluationDialog()) {
                    showAdDialog = false;
                    DialogUtil.showEvaluationDialog(getSupportFragmentManager());
                } else if (!AppUtils.isNetworkAvailable(this) || !((NavigationActivity) this).preferences.isShowShareDialog()) {
                    if (showAdDialog) {
                        AppAdService.showDialog(this);
                    }
                    showAdDialog = false;
                } else {
                    showAdDialog = false;
                    DialogUtil.showShareDialog(getSupportFragmentManager());
                }
            }
        }
    }

    private void loadMainContent() {
        this.mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        prepareMenu();
        new Handler().postDelayed(new Runnable() {
            /* class king.james.bible.android.activity.$$Lambda$MainFragmentActivity$tiMEt79GL1s5UjqsZ8DaQMCormo */

            public final void run() {
                MainFragmentActivity.this.lambda$loadMainContent$5$MainFragmentActivity();
            }
        }, 1100);
        this.mDrawerLayout.closeDrawer(this.mDrawerPane);
        PowerManagerService.getInstance().start();
        new Handler().postDelayed(new Runnable() {
            /* class king.james.bible.android.activity.$$Lambda$KaZ3oaDodWBA5Cy10DnPuh2GNs */

            public final void run() {
                MainFragmentActivity.this.customStatusBar();
            }
        }, 1000);
//        checkRequestLocationInEeaOrUnknown();
    }

    public /* synthetic */ void lambda$loadMainContent$5$MainFragmentActivity() {
        DrawerLayout drawerLayout = this.mDrawerLayout;
        if (drawerLayout != null) {
            drawerLayout.addDrawerListener(new DrawerActionListener() {
                /* class king.james.bible.android.activity.MainFragmentActivity.AnonymousClass1 */

                @Override // androidx.drawerlayout.widget.DrawerLayout.DrawerListener
                public void onDrawerOpened(View view) {
                    EventBus.getDefault().post(new DrawerOpenEvent());
                    ScreenUtil.getInstance().hideKeyboard(MainFragmentActivity.this);
                }
            });
            checkNotifications();
        }
    }

    public void prepareMenu() {
        this.menuSettings = (LinearLayout) findViewById(R.id.menu_settings);
        this.noAdvertisingBtn = (LinearLayout) findViewById(R.id.menu_no_advertising);
        View findViewById = findViewById(R.id.menu_bookmarks);
        View findViewById2 = findViewById(R.id.menu_highlights);
        View findViewById3 = findViewById(R.id.menu_notes);
        View findViewById4 = findViewById(R.id.daily_verses);
        View findViewById5 = findViewById(R.id.daily_reading);
        View findViewById6 = findViewById(R.id.menu_feedback);
        View findViewById7 = findViewById(R.id.menu_day_night);
        View findViewById8 = findViewById(R.id.read_bible);
        View findViewById9 = findViewById(R.id.shareMenu);
        int i = 0;
        findViewById9.setVisibility(0);
        findViewById4.setVisibility(0);
        findViewById5.setVisibility(0);
        findViewById8.setVisibility(8);
        findViewById.setVisibility(0);
        findViewById2.setVisibility(0);
        findViewById3.setVisibility(0);
        this.menuSettings.setVisibility(0);
        findViewById.setOnClickListener(this);
        findViewById3.setOnClickListener(this);
        findViewById2.setOnClickListener(this);
        findViewById4.setOnClickListener(this);
        findViewById5.setOnClickListener(this);
        findViewById6.setOnClickListener(this);
        findViewById7.setOnClickListener(this);
        findViewById8.setOnClickListener(this);
        findViewById9.setOnClickListener(this);
        LinearLayout linearLayout = this.noAdvertisingBtn;
        if (((NavigationActivity) this).preferences.isNoAdvertising()) {
            i = 8;
        }
        linearLayout.setVisibility(i);
        this.menuSettings.setOnClickListener(this);
        this.noAdvertisingBtn.setOnClickListener(this);
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, king.james.bible.android.activity.AdsActivity, king.james.bible.android.activity.base.BaseActivity
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        if (!this.mLoadActivity) {
            ((NavigationActivity) this).preferences.lambda$restoreAsync$0$BiblePreferences();
        }
    }

    public void updateDrawerState() {
        if (this.mDrawerLayout != null) {
            this.mDrawerPane.setVisibility(0);
            this.mDrawerLayout.setVisibility(0);
            if (this.mDrawerLayout.isActivated()) {
                this.mDrawerLayout.openDrawer(this.mDrawerPane);
            } else {
                this.mDrawerLayout.closeDrawer(this.mDrawerPane);
            }
        }
    }

    public void showHideSideMenu() {
        if (this.mDrawerLayout.isActivated()) {
            this.mDrawerLayout.closeDrawer(this.mDrawerPane);
        } else {
            this.mDrawerPane.setVisibility(0);
            this.mDrawerLayout.setVisibility(0);
            this.mDrawerLayout.openDrawer(this.mDrawerPane);
            this.mDrawerLayout.postDelayed(new Runnable() {
                /* class king.james.bible.android.activity.MainFragmentActivity.AnonymousClass2 */

                public void run() {
                    if (MainFragmentActivity.this.mDrawerLayout != null && !MainFragmentActivity.this.mDrawerLayout.isActivated()) {
                        MainFragmentActivity.this.mDrawerLayout.openDrawer(MainFragmentActivity.this.mDrawerPane);
                    }
                }
            }, 300);
        }
        ScreenUtil.getInstance().hideKeyboard(this);
    }

    @Override // androidx.fragment.app.FragmentActivity, king.james.bible.android.activity.AdsActivity
    public void onPause() {
        if (this.mLoadActivity) {
            super.onPause();
            return;
        }
        ((NavigationActivity) this).preferences.saveBg();
        ScreenUtil.getInstance().hideKeyboard(this);
        super.onPause();
    }

    @Override // androidx.fragment.app.FragmentActivity, king.james.bible.android.activity.AdsActivity
    public void onResume() {
        super.onResume();
        PowerManagerService.getInstance().start();
        if (!this.mLoadActivity) {
            customStatusBar();
            ((NavigationActivity) this).preferences.restoreAsync();
        }
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, king.james.bible.android.activity.base.NavigationActivity, king.james.bible.android.activity.AdsActivity, king.james.bible.android.activity.base.BaseActivity
    public void onDestroy() {
        SoundHelper.getInstance().pause();
        this.noAdvertisingBtn = null;
        this.menuSettings = null;
        this.noAdvertisingBtn = null;
        this.menuImage.setImageBitmap(null);
        this.menuImage = null;
        this.mDrawerLayout = null;
        this.mDrawerPane = null;
        LastChaptersService.getInstance().clearFirstChapter();
        if (this.mLoadActivity) {
            super.onDestroy();
            return;
        }
        FragmentCallbackObservable.getInstance().remove(this);
        if (!this.needRestart) {
            this.bibleDB.close();
        }
        super.onDestroy();
        if (!this.needRestart) {
            SoundHelper.getInstance().init(null);
        }
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.activity.AdsActivity
    public void hideAdvertisingButton() {
        this.noAdvertisingBtn.setVisibility(8);
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.activity.AdsActivity
    public void updateAdvertisingButton() {
        BiblePreferences biblePreferences;
        LinearLayout linearLayout = this.noAdvertisingBtn;
        if (linearLayout != null && (biblePreferences = ((NavigationActivity) this).preferences) != null) {
            try {
                linearLayout.setVisibility(biblePreferences.isShowAdvertisingMenu() ? 0 : 8);
            } catch (Exception unused) {
            }
        }
    }

    public void onClick(View view) {
        if (!this.lockMenu) {
            lockMenuItem(view);
            DailyVerseService.getInstance().clearDailyVerseBackStack();
            DailyReadingService.getInstance().clearDailyReadingBackStack();
            BackStackService.getInstance().clear();
            switch (view.getId()) {
                case R.id.daily_reading :
                    dailyReadingClick();
                    break;
                case R.id.daily_verses /*{ENCODED_INT: 2131362002}*/:
                    openFragment(DailyVerseFragment.class);
                    break;
                case R.id.menu_bookmarks /*{ENCODED_INT: 2131362219}*/:
                    openFragment(BookmarksFragment.class);
                    break;
                case R.id.menu_day_night /*{ENCODED_INT: 2131362220}*/:
                    dayNightClick();
                    break;
                case R.id.menu_feedback /*{ENCODED_INT: 2131362221}*/:
                    openFragment(FeedbackFragment.class);
                    break;
                case R.id.menu_highlights /*{ENCODED_INT: 2131362222}*/:
                    openFragment(HighlightsFragment.class);
                    break;
                case R.id.menu_no_advertising /*{ENCODED_INT: 2131362224}*/:
                    noAdvertisingClick();
                    break;
                case R.id.menu_notes /*{ENCODED_INT: 2131362225}*/:
                    openFragment(NotesFragment.class);
                    break;
                case R.id.menu_settings /*{ENCODED_INT: 2131362226}*/:
                    openFragment(SettingsFragment.class);
                    break;
                case R.id.read_bible /*{ENCODED_INT: 2131362355}*/:
                    readBibleClick();
                    break;
                case R.id.shareMenu /*{ENCODED_INT: 2131362424}*/:
                    onShareMenuClick();
                    break;
            }
            unlockMenuItem(view);
        }
    }

    private void onShareMenuClick() {
        this.mDrawerLayout.closeDrawer(this.mDrawerPane);
        ((NavigationActivity) this).preferences.clearStartAppShareCount();
        AppUtils.shareApp(this);
    }

    private void dailyReadingClick() {
        DailyReadingCache.clear();
        SoundHelper.getInstance().pause();
        this.mDrawerLayout.closeDrawer(3);
        if (!this.dailyReadingRoot) {
            openFragment(DailyReadingFragment.class);
        }
    }

    private void readBibleClick() {
        SoundHelper.getInstance().pause();
        this.mDrawerLayout.closeDrawer(3);
        if (this.dailyReadingRoot) {
            loadMainFragment();
        }
    }

    private void dayNightClick() {
        SoundHelper.getInstance().pause();
        ((NavigationActivity) this).preferences.changeDayMode();
        ((NavigationActivity) this).preferences.setLoadScreen(false);
        ((NavigationActivity) this).preferences.lambda$saveBg$1$BiblePreferences();
        this.needRestart = true;
        finish();
        startActivity(new Intent(this, MainFragmentActivity.class));
    }

    private void noAdvertisingClick() {
        this.mDrawerLayout.closeDrawer(3);
//        onPurchaseNoAdClick();
    }

    private void lockMenuItem(View view) {
        this.lockMenu = true;
        view.setClickable(false);
    }

    private void unlockMenuItem(final View view) {
        new Handler().postDelayed(new Runnable() {
            /* class king.james.bible.android.activity.MainFragmentActivity.AnonymousClass3 */

            public void run() {
                if (MainFragmentActivity.this != null) {
                    view.setClickable(true);
                    MainFragmentActivity.this.lockMenu = false;
                }
            }
        }, 2000);
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.activity.base.NavigationActivity
    public void closeDrawerLeft() {
        DrawerLayout drawerLayout = this.mDrawerLayout;
        if (drawerLayout != null) {
            drawerLayout.closeDrawer(3);
        }
    }

    @Override // king.james.bible.android.fragment.FragmentCallbackListener
    public void onFragmentResultOk(int i, int i2, int i3, int i4, Object obj) {
        onFragmentResultOk(i, i2, i3, i4, obj, false);
    }

    @Override // king.james.bible.android.fragment.FragmentCallbackListener
    public void onFragmentResultOk(int i, int i2, int i3, int i4, Object obj, boolean z) {
        LastChaptersService.getInstance().clearFirstChapter();
        boolean z2 = obj instanceof NotesFragment;
        if (getSupportFragmentManager().getBackStackEntryCount() < 1) {
            loadMainFragment();
        }
        if (getTopFragment() != null && (getTopFragment() instanceof MainScreenFragment)) {
            ((MainScreenFragment) getTopFragment()).setParameters(i, i2, i4, z2);
        }
        this.dailyReadingRoot = false;
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(final OpenFromContents3Event openFromContents3Event) {
        super.onBackPressed();
        getSupportFragmentManager().popBackStack();
        getSupportFragmentManager().popBackStack();
        loadMainFragment();
        this.mDrawerLayout.postDelayed(new Runnable() {
            /* class king.james.bible.android.activity.MainFragmentActivity.AnonymousClass4 */

            public void run() {
                MainFragmentActivity mainFragmentActivity = MainFragmentActivity.this;
                if (mainFragmentActivity != null) {
                    mainFragmentActivity.onFragmentResultOk(openFromContents3Event.getChapter(), openFromContents3Event.getSubChapter(), openFromContents3Event.getPosition(), openFromContents3Event.getPositionRank(), openFromContents3Event.getObject());
                }
            }
        }, 300);
    }

    @Override // androidx.activity.ComponentActivity, king.james.bible.android.activity.base.NavigationActivity
    public void onBackPressed() {
        SoundHelper.getInstance().pause();
        if (this.copyDBError) {
            finish();
        } else if (!this.mLoadActivity) {
            existBackStack(false);
        }
    }

    public void onContentSelect() {
        existBackStack(true);
    }

    private void existBackStack(boolean z) {
        if (getOpenFragment() instanceof SearchFragment) {
            SearchCache.getInstance().clearBackStack();
        }
        if (getTopFragment() != null && (getTopFragment() instanceof MainScreenFragment) && ((MainScreenFragment) getTopFragment()).hideSelectionsIfNeeded()) {
            return;
        }
        if (!z && (getOpenFragment() instanceof ContentsMainFragment) && ((ContentsMainFragment) getOpenFragment()).onBackClick()) {
            return;
        }
        if (DailyVerseService.getInstance().isDailyVerseBackStack() && (getTopFragment() instanceof MainScreenFragment)) {
            openFragment(DailyVerseFragment.class);
        } else if (DailyReadingService.getInstance().isDailyReadingBackStack() && (getTopFragment() instanceof MainScreenFragment)) {
            openFragment(DailyReadingFragment.class);
        } else if (SearchCache.getInstance().isBackStack() && (getTopFragment() instanceof MainScreenFragment)) {
            openFragment(SearchFragment.class, (Bundle) null);
        } else if (((NavigationActivity) this).preferences.isNeedToBackMode()) {
            EventBus.getDefault().post(new DrawerOpenEvent());
            ((NavigationActivity) this).preferences.setBackMode();
            this.needRestart = true;
            finish();
            startActivity(new Intent(this, MainFragmentActivity.class));
        } else {
            super.onBackPressed();
        }
    }

    public void setDrawerMode(int i) {
        this.mDrawerLayout.setDrawerLockMode(i);
    }

    @Override // king.james.bible.android.activity.base.NavigationActivity, androidx.fragment.app.FragmentManager.OnBackStackChangedListener
    public void onBackStackChanged() {
        if (this.mDrawerLayout != null) {
            if (getSupportFragmentManager().getBackStackEntryCount() > 1) {
                this.mDrawerLayout.setDrawerLockMode(1);
            } else {
                this.mDrawerLayout.setDrawerLockMode(0);
            }
            prepareMenu();
        }
    }

    /* access modifiers changed from: protected */
    @Override // androidx.fragment.app.FragmentActivity
    public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        updateNotificationInstance(intent);
    }

    private void updateNotificationInstance(Intent intent) {
        NotificationMode valueOf;
        String stringExtra = intent.getStringExtra("mode");
        long longExtra = intent.getLongExtra("itemId", 0);
        if (stringExtra != null && !stringExtra.isEmpty() && (valueOf = NotificationMode.valueOf(stringExtra)) != null) {
            if (valueOf == NotificationMode.PLAN) {
                clearStack();
                Bundle bundle = new Bundle();
                bundle.putLong("paramId", longExtra);
                openFragment(DailyReadingFragment.class, bundle);
            } else if (valueOf == NotificationMode.VERSE) {
                DailyVerseFragment dailyVerseFragment = new DailyVerseFragment();
                clearStack();
                Bundle bundle2 = new Bundle();
                bundle2.putLong("paramId", longExtra);
                dailyVerseFragment.setArguments(bundle2);
                openFragment(DailyVerseFragment.class);
            }
        }
    }

    private void clearStack() {
        try {
            FragmentManager supportFragmentManager = getSupportFragmentManager();
            int backStackEntryCount = supportFragmentManager.getBackStackEntryCount();
            if (backStackEntryCount != 0) {
                for (int i = 1; i < backStackEntryCount; i++) {
                    supportFragmentManager.popBackStackImmediate();
                }
            }
        } catch (Exception unused) {
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(ShowBackupHint showBackupHint) {
        if (((NavigationActivity) this).preferences.isShowBackupHint()) {
            new Handler().postDelayed(new Runnable() {
                /* class king.james.bible.android.activity.$$Lambda$MainFragmentActivity$Qf_K0dTnbOESDAG2rreDvaaRsF4 */

                public final void run() {
                    MainFragmentActivity.this.lambda$onEvent$6$MainFragmentActivity();
                }
            }, 1200);
        }
    }

    public /* synthetic */ void lambda$onEvent$6$MainFragmentActivity() {
        if (((NavigationActivity) this).preferences.isShowBackupHint()) {
            DialogUtil.showBackupHintDialog(getSupportFragmentManager());
            ((NavigationActivity) this).preferences.setShowBackupHint(false);
        }
    }
}
