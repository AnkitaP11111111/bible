package king.james.bible.android.model;

public class SearchText {
    private String text;
    private long time;

    public SearchText() {
    }

    public SearchText(long j, String str) {
        this.time = j;
        this.text = str;
    }

    public long getTime() {
        return this.time;
    }

    public void setTime(long j) {
        this.time = j;
    }

    public String getText() {
        return this.text;
    }
}
