package king.james.bible.android.model.export;

import java.util.List;

public class PlanDayExport {
    private List<PlanChapterDayExport> planChapterDays;
    private boolean readed;

    public boolean isReaded() {
        return this.readed;
    }

    public void setReaded(boolean z) {
        this.readed = z;
    }

    public List<PlanChapterDayExport> getPlanChapterDays() {
        return this.planChapterDays;
    }

    public void setPlanChapterDays(List<PlanChapterDayExport> list) {
        this.planChapterDays = list;
    }
}
