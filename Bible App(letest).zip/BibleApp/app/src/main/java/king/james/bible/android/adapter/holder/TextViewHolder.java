package king.james.bible.android.adapter.holder;

import android.annotation.SuppressLint;
import android.text.Html;
import android.text.SpannableString;
import android.text.style.BackgroundColorSpan;
import android.text.style.StyleSpan;
import android.text.style.UnderlineSpan;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.karumi.dexter.BuildConfig;
import king.james.bible.android.R;
import java.util.TreeSet;
import king.james.bible.android.model.Text;
import king.james.bible.android.sound.holder.SoundButtonHolder;
import king.james.bible.android.sound.listener.page.SoundInitListener;
import king.james.bible.android.sound.model.SoundButtonModel;
import king.james.bible.android.utils.BiblePreferences;
import king.james.bible.android.utils.ScreenUtil;
import king.james.bible.android.utils.SettingsTextUtil;
import king.james.bible.android.view.MarkerTextView;
import king.james.bible.android.view.SizeImageLinearLayout;
import king.james.bible.android.view.SizeImageView;
@SuppressLint({"NewApi", "WrongConstant"})

public class TextViewHolder extends MainFragmentViewHolder implements SoundButtonHolder.SoundButtonHolderListener {
    private SizeImageView bookmarkImage;
    private Button menuButton;
    private View.OnClickListener menuListener;
    private Text modelText;
    private SizeImageView noteImage;
    private MarkerTextView.OnSelectionListener onSelectionListener;
    private int pagePosition;
    private BiblePreferences preferences = BiblePreferences.getInstance();
    private SoundButtonHolder soundButtonHolder;
    private View soundContainer;
    private TextView text1;
    private MarkerTextView text2;
    private SizeImageLinearLayout textItemIcons;

    public TextViewHolder(View view, View.OnClickListener onClickListener, int i, MarkerTextView.OnSelectionListener onSelectionListener2) {
        super(view);
        this.menuListener = onClickListener;
        this.pagePosition = i;
        this.onSelectionListener = onSelectionListener2;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter.BaseViewHolder
    public void mapViews(View view) {
        this.textItemIcons = (SizeImageLinearLayout) view.findViewById(R.id.text_item_icons);
        this.bookmarkImage = (SizeImageView) view.findViewById(R.id.text_item_bookmark);
        this.noteImage = (SizeImageView) view.findViewById(R.id.text_item_note);
        this.text2 = (MarkerTextView) view.findViewById(R.id.item_text2);
        this.text1 = (TextView) view.findViewById(R.id.item_text1);
        this.menuButton = (Button) view.findViewById(R.id.text_item_menu_button);
        this.soundContainer = view.findViewById(R.id.soundContainer);
    }

    @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter.BaseViewHolder
    public void updateView(Object obj) {
        this.modelText = (Text) obj;
        this.text2.setOnSelectionViewListener(this.onSelectionListener);
    }

    public SoundButtonHolder updateView(Integer num, TreeSet<Integer> treeSet, int i, SoundInitListener soundInitListener) {
        int i2;
        CharSequence charSequence;
        Text text = this.modelText;
        if (text == null) {
            return null;
        }
        String text3 = text.getText();
        int textSize = (int) this.preferences.getTextSize();
        this.preferences.getSpacing();
        SettingsTextUtil.setupTextViewSettings(this.text2);
        this.bookmarkImage.setTextImageSize();
        this.noteImage.setTextImageSize();
        this.textItemIcons.setImageSize();
        boolean isNightMode = this.preferences.isNightMode();
        this.menuButton.setOnClickListener(this.menuListener);
        updateSizeButton(this.menuButton);
        if (this.soundButtonHolder == null) {
            this.soundButtonHolder = SoundButtonHolder.create(this.soundContainer, new SoundButtonModel(this.pagePosition, this.modelText.getRank()), soundInitListener, this);
        }
        updateSizeButton(this.soundButtonHolder.getSoundButton());
        updateSizeButton(this.soundButtonHolder.getSoundRepeatButton());
        this.bookmarkImage.setVisibility(this.modelText.isBookmark() ? 0 : 8);
        this.noteImage.setVisibility(8);
        if (this.modelText.getNote() != null && !this.modelText.getNote().isEmpty()) {
            this.noteImage.setVisibility(0);
        }
        if (this.noteImage.getVisibility() == 0 && this.bookmarkImage.getVisibility() == 0) {
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.noteImage.getLayoutParams();
            layoutParams.setMargins(0, 5, 0, 0);
            this.noteImage.setLayoutParams(layoutParams);
        }
        if (this.modelText.getPosition() == 1) {
            i2 = 0;
        } else {
            i2 = String.valueOf(this.modelText.getPosition()).length() + 1;
        }
        SpannableString spannableString = new SpannableString(text3);
        this.text2.setupTransparent(0);
        this.bookmarkImage.setTextImageSize();
        if (this.modelText.getHead() == 0) {
            this.itemView.setTag(false);
            this.text2.setGravity(55);
            float f = (float) textSize;
            this.text2.setTextSize(2, f);
            this.modelText.getPosition();
            this.text1.setVisibility(0);
            this.text1.setTextSize(2, 1.0f);
            this.text1.setText(BuildConfig.FLAVOR);
            StringBuilder sb = new StringBuilder();
            sb.append("<b><font color='");
            sb.append(isNightMode ? "#FFBFBFBF" : "#bf360c");
            sb.append("'>");
            sb.append(this.modelText.getPosition());
            sb.append("</font></b>  ");
            sb.append((Object) spannableString);
            spannableString = new SpannableString(Html.fromHtml(sb.toString()));
            RelativeLayout.LayoutParams layoutParams2 = (RelativeLayout.LayoutParams) this.textItemIcons.getLayoutParams();
            layoutParams2.topMargin = (int) (((float) ((int) ((f * 6.0f) / ((float) this.itemView.getContext().getResources().getInteger(R.integer.def_font_size))))) * this.itemView.getContext().getResources().getDisplayMetrics().density);
            this.textItemIcons.setLayoutParams(layoutParams2);
            this.textItemIcons.requestLayout();
        } else {
            if (this.modelText.getHead() == 1) {
                this.itemView.setTag(true);
                this.text1.setVisibility(0);
                this.text1.setText(BuildConfig.FLAVOR);
                this.text1.setTextSize(2, 1.0f);
                this.text2.setGravity(17);
                MarkerTextView markerTextView = this.text2;
                charSequence = BuildConfig.FLAVOR;
                double d = (double) textSize;
                Double.isNaN(d);
                markerTextView.setTextSize(2, (float) ((int) (d * 1.22d)));
                this.text2.setTextColor(this.preferences.isNightMode() ? this.itemView.getContext().getResources().getColor(R.color.main_text_color_n) : this.itemView.getContext().getResources().getColor(R.color.main_text_color));
                spannableString.setSpan(new StyleSpan(1), 0, spannableString.length(), 33);
                this.menuButton.setVisibility(8);
                this.soundButtonHolder.hideButton();
            } else {
                charSequence = BuildConfig.FLAVOR;
            }
            if (this.modelText.getHead() == 2) {
                this.itemView.setTag(true);
                this.text1.setVisibility(0);
                this.text1.setText(charSequence);
                this.text1.setTextSize(2, 1.0f);
                this.text2.setGravity(17);
                MarkerTextView markerTextView2 = this.text2;
                double d2 = (double) textSize;
                Double.isNaN(d2);
                markerTextView2.setTextSize(2, (float) ((int) (d2 * 1.06d)));
                this.text2.setTextColor(this.preferences.isNightMode() ? this.itemView.getContext().getResources().getColor(R.color.main_text_color_n) : this.itemView.getContext().getResources().getColor(R.color.main_text_color));
                spannableString.setSpan(new StyleSpan(2), 0, spannableString.length(), 33);
                this.menuButton.setVisibility(8);
                this.soundButtonHolder.hideButton();
            }
        }
        if (this.modelText.getHead() == 0) {
            spannableString.setSpan(new BackgroundColorSpan(16777215), 0, spannableString.length(), 18);
            float measureText = this.modelText.getPosition() == 1 ? (float) 0 : this.text2.getPaint().measureText(spannableString, 0, i2);
            if (this.modelText.isUnderline()) {
                spannableString.setSpan(new UnderlineSpan(), i2, spannableString.length(), 18);
            } else if (this.modelText.isColor()) {
                this.text2.setup(this.modelText.getHighlight(), measureText, 0);
            }
            if (!treeSet.isEmpty()) {
                if (treeSet.contains(Integer.valueOf(this.modelText.getRank()))) {
                    spannableString.setSpan(new BackgroundColorSpan(this.itemView.getContext().getResources().getColor(isNightMode ? R.color.selected_item_text_n : R.color.selected_item_text)), i2, spannableString.length(), 18);
                }
            }
            if (treeSet.isEmpty() || num == null) {
                this.menuButton.setVisibility(8);
                this.soundButtonHolder.hideButton();
            } else {
                this.soundButtonHolder.setRank(this.modelText.getRank());
                if (num.intValue() == this.modelText.getRank()) {
                    this.menuButton.setVisibility(0);
                    this.soundButtonHolder.showButton();
                } else {
                    this.menuButton.setVisibility(8);
                    this.soundButtonHolder.hideButton();
                }
            }
        }
        this.text2.setText(spannableString, i);
        return this.soundButtonHolder;
    }

    private void updateSizeButton(Button button) {
        double d;
        if (ScreenUtil.getInstance().isTablet()) {
            ViewGroup.LayoutParams layoutParams = button.getLayoutParams();
            double dimensionPixelSize = (double) this.itemView.getContext().getResources().getDimensionPixelSize(R.dimen.button_size);
            int integer = this.itemView.getContext().getResources().getInteger(R.integer.max_font_size);
            int integer2 = (integer - this.itemView.getContext().getResources().getInteger(R.integer.min_font_size)) / 3;
            int textSize = integer - ((int) this.preferences.getTextSize());
            if (textSize > integer2 * 2) {
                d = 1.0d;
                Double.isNaN(dimensionPixelSize);
            } else if (textSize > integer2) {
                d = 1.5d;
                Double.isNaN(dimensionPixelSize);
            } else {
                d = 2.0d;
                Double.isNaN(dimensionPixelSize);
            }
            int i = (int) (dimensionPixelSize * d);
            layoutParams.width = i;
            layoutParams.height = i;
            button.setLayoutParams(layoutParams);
        }
    }

    @Override // king.james.bible.android.sound.holder.SoundButtonHolder.SoundButtonHolderListener
    public void setSoundViewAlpha(int i) {
        Button button = this.menuButton;
        if (button != null && button.getVisibility() == 0 && this.menuButton.getBackground() != null) {
            try {
                this.menuButton.getBackground().setAlpha(i);
                this.menuButton.invalidate();
            } catch (Exception unused) {
            }
        }
    }
}
