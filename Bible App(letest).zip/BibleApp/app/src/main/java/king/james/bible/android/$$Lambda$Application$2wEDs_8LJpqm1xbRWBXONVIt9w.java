package king.james.bible.android;

/* renamed from: king.james.bible.android.-$$Lambda$Application$2wEDs_8LJ-pqm1xbRWBXONVIt9w  reason: invalid class name */
/* compiled from: lambda */
public final /* synthetic */ class $$Lambda$Application$2wEDs_8LJpqm1xbRWBXONVIt9w implements Runnable {
    public static final /* synthetic */ $$Lambda$Application$2wEDs_8LJpqm1xbRWBXONVIt9w INSTANCE = new $$Lambda$Application$2wEDs_8LJpqm1xbRWBXONVIt9w();

    private /* synthetic */ $$Lambda$Application$2wEDs_8LJpqm1xbRWBXONVIt9w() {
    }

    public final void run() {
        MyApplication.lambda$null$2();
    }
}
