package king.james.bible.android.fragment;

import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.Html;
import android.text.SpannableString;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import android.widget.Toast;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import com.karumi.dexter.BuildConfig;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import king.james.bible.android.R;
import com.karumi.dexter.listener.DexterError;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.PermissionRequestErrorListener;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import king.james.bible.android.activity.MainFragmentActivity;
import king.james.bible.android.adapter.array.FontSpinnerAdapter;
import king.james.bible.android.adapter.array.LanguageAudioAdapter;
import king.james.bible.android.db.BibleDataBase;
import king.james.bible.android.dialog.DialogUtil;
import king.james.bible.android.dialog.ExportImportDialog;
import king.james.bible.android.dialog.SettingsDialog;
import king.james.bible.android.event.ClickOpenExportEvent;
import king.james.bible.android.event.ClickOpenImportEvent;
import king.james.bible.android.event.SettingUpdateEvent;
import king.james.bible.android.event.UpdatePageBySettingsChangeEvent;
import king.james.bible.android.model.SettingsSoundModel;
import king.james.bible.android.service.PowerManagerService;
import king.james.bible.android.service.observable.ExportImportObservable;
import king.james.bible.android.sound.SoundHelper;
import king.james.bible.android.sound.holder.SettingsSoundButtonHolder;
import king.james.bible.android.sound.listener.page.SoundVerseListener;
import king.james.bible.android.sound.model.LanguageModel;
import king.james.bible.android.sound.util.SoundLanguageService;
import king.james.bible.android.utils.AppUtils;
import king.james.bible.android.utils.BiblePreferences;
import king.james.bible.android.utils.BibleToast;
import king.james.bible.android.utils.SettingsTextUtil;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
@SuppressLint({"NewApi", "WrongConstant"})

public class SettingsFragment extends Fragment implements View.OnClickListener, SoundVerseListener, ExportImportDialog.ImportListener {
    private float audioPitch = 0.0f;
    private TextView audioPitchTextView;
    private float audioSpeechRate = 0.0f;
    private TextView audioSpeechRateTextView;
    private List<SettingsSoundModel> firstTextList;
    private String[] fontNames;
    private Spinner fontSpinner;
    private String fontType = BuildConfig.FLAVOR;
    private boolean isNightMode;
    private CheckBox italicWordsCheckBox;
    private List<TextView> mTextViews = new ArrayList(3);
    private float maxAudioPitch;
    private float maxAudioSpeechRate;
    private float maxSpacing;
    private int maxTextSize;
    private float minAudioPitch;
    private float minAudioSpeechRate;
    private float minSpacing;
    private int minTextSize;
    private BiblePreferences preferences;
    private CheckBox redLettersModeCheckBox;
    private CheckBox screenStayCheckBox;
    private SettingsSoundButtonHolder settingsSoundButtonHolder;
    private SeekBar sizeSeek;
    private TextView sizeText;
    private float spacing = 0.0f;
    private SeekBar spacingSeek;
    private TextView spacingText;
    private float textSize = 0.0f;
    private CompoundButton.OnCheckedChangeListener r3;

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void initTextView() {
        new Thread(new Runnable() {
            /* class king.james.bible.android.fragment.$$Lambda$SettingsFragment$lxeQpqnNgXK623uCQl9dIT8UU1o */

            public final void run() {
                SettingsFragment.this.lambda$initTextView$1$SettingsFragment();
            }
        }).start();
    }

    public /* synthetic */ void lambda$initTextView$1$SettingsFragment() {
        prepareDBText(BibleDataBase.getInstance().getFirstText(3));
        if (getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() {
                /* class king.james.bible.android.fragment.$$Lambda$SettingsFragment$xC71C5OzJRUNzeakapPm0v8F6zc */

                public final void run() {
                    SettingsFragment.this.lambda$null$0$SettingsFragment();
                }
            });
        }
    }

    public /* synthetic */ void lambda$null$0$SettingsFragment() {
        if (getActivity() != null && !getActivity().isFinishing()) {
            updateTextView();
        }
    }

    private void prepareDBText(List<String> list) {
        if (!(list == null || list.isEmpty())) {
            this.firstTextList = new ArrayList();
            for (int i = 0; i < 3; i++) {
                String str = this.preferences.isNightMode() ? (i + 1) + "  " : "<b><font color='#bf360c'>" + (i + 1) + "</font></b>  ";
                String prepareText = SettingsTextUtil.prepareText(list.get(i));
                this.firstTextList.add(new SettingsSoundModel(Html.fromHtml(prepareText).toString(), new SpannableString(Html.fromHtml(str + prepareText))));
            }
        }
    }

    private void updateTextView() {
        List<SettingsSoundModel> list;
        this.settingsSoundButtonHolder.clearText();
        for (int i = 0; i < 3; i++) {
            List<TextView> list2 = this.mTextViews;
            if (list2 != null && !list2.isEmpty() && i < this.mTextViews.size() && this.mTextViews.get(i) != null && (list = this.firstTextList) != null && !list.isEmpty() && i < this.firstTextList.size() && this.firstTextList.get(i) != null) {
                this.mTextViews.get(i).setText(this.firstTextList.get(i).getSpannableString());
                this.settingsSoundButtonHolder.addText(this.firstTextList.get(i).getText());
            }
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        EventBus.getDefault().register(this);
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroyView() {
        EventBus.getDefault().unregister(this);
        super.onDestroyView();
    }

    @Override // androidx.fragment.app.Fragment
    public void onStart() {
        super.onStart();
        ExportImportObservable.getInstance().subscribe(this);
    }

    @Override // androidx.fragment.app.Fragment
    public void onStop() {
        ExportImportObservable.getInstance().remove(this);
        super.onStop();
    }

    private int getIntegerResource(int i) {
        if (getActivity() == null) {
            return 0;
        }
        return getActivity().getResources().getInteger(i);
    }

    /* JADX DEBUG: Multi-variable search result rejected for r10v1, resolved type: java.util.List<android.widget.TextView> */
    /* JADX DEBUG: Multi-variable search result rejected for r10v2, resolved type: java.util.List<android.widget.TextView> */
    /* JADX DEBUG: Multi-variable search result rejected for r10v3, resolved type: java.util.List<android.widget.TextView> */
    /* JADX WARN: Multi-variable type inference failed */
    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.maxTextSize = getIntegerResource(R.integer.max_font_size);
        this.minTextSize = getIntegerResource(R.integer.min_font_size);
        this.maxSpacing = ((float) getIntegerResource(R.integer.max_font_spacing)) / 100.0f;
        this.minSpacing = ((float) getIntegerResource(R.integer.min_font_spacing)) / 100.0f;
        this.maxAudioSpeechRate = ((float) getIntegerResource(R.integer.max_audio_speech_rate)) / 100.0f;
        this.minAudioSpeechRate = ((float) getIntegerResource(R.integer.min_audio_speech_rate)) / 100.0f;
        this.maxAudioPitch = ((float) getIntegerResource(R.integer.max_audio_pitch)) / 100.0f;
        this.minAudioPitch = ((float) getIntegerResource(R.integer.min_audio_pitch)) / 100.0f;
        this.textSize = (float) getIntegerResource(R.integer.def_font_size);
        BiblePreferences instance = BiblePreferences.getInstance();
        this.preferences = instance;
        instance.lambda$restoreAsync$0$BiblePreferences();
        this.isNightMode = this.preferences.isNightMode();
        View inflate = layoutInflater.cloneInContext(new ContextThemeWrapper(getActivity(), (int) R.style.SettingsMaterialStyle)).inflate(this.preferences.isNightMode() ? R.layout.activity_settings_n : R.layout.activity_settings, viewGroup, false);
        prepareTextStyleSettings(inflate);
        this.mTextViews.add(inflate.findViewById(R.id.settings_text1));
        this.mTextViews.add(inflate.findViewById(R.id.settings_text2));
        this.mTextViews.add(inflate.findViewById(R.id.settings_text3));
        SoundHelper.getInstance().addSoundVerseListener(-14, this);
        SettingsSoundButtonHolder create = SettingsSoundButtonHolder.create(inflate.findViewById(R.id.settingsSoundContainer));
        this.settingsSoundButtonHolder = create;
        create.getSoundButton().setVisibility(8);
        initTextView();
        this.fontNames = getResources().getStringArray(R.array.fonts);
        Spinner spinner = (Spinner) inflate.findViewById(R.id.settings_font_spinner);
        this.fontSpinner = spinner;
        spinner.setAdapter((SpinnerAdapter) FontSpinnerAdapter.getModeAdapter(getActivity(), this.fontNames));
        this.sizeText = (TextView) inflate.findViewById(R.id.settings_size_text);
        this.spacingText = (TextView) inflate.findViewById(R.id.settings_spacing_text);
        RelativeLayout relativeLayout = (RelativeLayout) inflate.findViewById(R.id.importExportLayout);
        relativeLayout.setOnClickListener(this);
        relativeLayout.setVisibility(0);
        TextView textView = (TextView) inflate.findViewById(R.id.importExportTextView);
        textView.setText(Html.fromHtml("<u>" + ((Object) textView.getText()) + "</u>"));
        inflate.findViewById(R.id.languageAudioRelativeLayout).setVisibility(8);
        Spinner spinner2 = (Spinner) inflate.findViewById(R.id.languageAudioSpinner);
        spinner2.setAdapter((SpinnerAdapter) LanguageAudioAdapter.getModeAdapter(getActivity()));
        int i = 0;
        for (LanguageModel languageModel : SoundLanguageService.getInstance().getLanguageModelList()) {
            if (this.preferences.getSoundLanguage() == null || languageModel.getId().equals(this.preferences.getSoundLanguage().getId())) {
                break;
            }
            i++;
        }
        spinner2.setSelection(i);
        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            /* class king.james.bible.android.fragment.SettingsFragment.AnonymousClass1 */

            @Override // android.widget.AdapterView.OnItemSelectedListener
            public void onNothingSelected(AdapterView<?> adapterView) {
            }

            @Override // android.widget.AdapterView.OnItemSelectedListener
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
                SettingsFragment.this.settingsSoundButtonHolder.pause();
                SettingsFragment.this.preferences.setSoundLanguage(SoundLanguageService.getInstance().getLanguageModelList().get(i));
                SettingsFragment.this.preferences.lambda$saveBg$1$BiblePreferences();
            }
        });
        inflate.findViewById(R.id.audioSpeechRateRelativeLayout).setVisibility(8);
        SeekBar seekBar = (SeekBar) inflate.findViewById(R.id.audioSpeechRateSeekBar);
        seekBar.setMax((int) ((this.maxAudioSpeechRate - this.minAudioSpeechRate) * 10.0f));
        seekBar.setProgress((int) ((this.audioSpeechRate - this.minAudioSpeechRate) * 10.0f));
        this.audioSpeechRateTextView = (TextView) inflate.findViewById(R.id.audioSpeechRateTextView);
        float audioSpeechRate2 = this.preferences.getAudioSpeechRate();
        this.audioSpeechRate = audioSpeechRate2;
        seekBar.setProgress((int) ((audioSpeechRate2 - this.minAudioSpeechRate) * 10.0f));
        TextView textView2 = this.audioSpeechRateTextView;
        textView2.setText(BuildConfig.FLAVOR + String.format("%.2f", Float.valueOf(this.audioSpeechRate)));
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            /* class king.james.bible.android.fragment.SettingsFragment.AnonymousClass2 */

            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
                SettingsFragment.this.settingsSoundButtonHolder.pause();
                SettingsFragment.this.preferences.setAudioSpeechRate(SettingsFragment.this.audioSpeechRate);
                SettingsFragment.this.preferences.lambda$saveBg$1$BiblePreferences();
            }

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                SettingsFragment.this.settingsSoundButtonHolder.pause();
                int min = Math.min(i, (int) ((SettingsFragment.this.maxAudioSpeechRate - SettingsFragment.this.minAudioSpeechRate) * 10.0f));
                SettingsFragment settingsFragment = SettingsFragment.this;
                settingsFragment.audioSpeechRate = (((float) min) / 10.0f) + settingsFragment.minAudioSpeechRate;
                TextView textView = SettingsFragment.this.audioSpeechRateTextView;
                textView.setText(BuildConfig.FLAVOR + String.format("%.2f", Float.valueOf(SettingsFragment.this.audioSpeechRate)));
            }
        });
        inflate.findViewById(R.id.audioPitchRelativeLayout).setVisibility(8);
        SeekBar seekBar2 = (SeekBar) inflate.findViewById(R.id.audioPitchSeekBar);
        seekBar2.setMax((int) ((this.maxAudioPitch - this.minAudioPitch) * 10.0f));
        seekBar2.setProgress((int) ((this.audioPitch - this.minAudioPitch) * 10.0f));
        this.audioPitchTextView = (TextView) inflate.findViewById(R.id.audioPitchTextView);
        float audioPitch2 = this.preferences.getAudioPitch();
        this.audioPitch = audioPitch2;
        seekBar2.setProgress((int) ((audioPitch2 - this.minAudioPitch) * 10.0f));
        TextView textView3 = this.audioPitchTextView;
        textView3.setText(BuildConfig.FLAVOR + String.format("%.2f", Float.valueOf(this.audioPitch)));
        seekBar2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            /* class king.james.bible.android.fragment.SettingsFragment.AnonymousClass3 */

            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
                SettingsFragment.this.settingsSoundButtonHolder.pause();
                SettingsFragment.this.preferences.setAudioPitch(SettingsFragment.this.audioPitch);
                SettingsFragment.this.preferences.lambda$saveBg$1$BiblePreferences();
            }

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                SettingsFragment.this.settingsSoundButtonHolder.pause();
                int min = Math.min(i, (int) ((SettingsFragment.this.maxAudioPitch - SettingsFragment.this.minAudioPitch) * 10.0f));
                SettingsFragment settingsFragment = SettingsFragment.this;
                settingsFragment.audioPitch = (((float) min) / 10.0f) + settingsFragment.minAudioPitch;
                TextView textView = SettingsFragment.this.audioPitchTextView;
                textView.setText(BuildConfig.FLAVOR + String.format("%.2f", Float.valueOf(SettingsFragment.this.audioPitch)));
            }
        });
        SeekBar seekBar3 = (SeekBar) inflate.findViewById(R.id.settings_size_seek);
        this.sizeSeek = seekBar3;
        seekBar3.setMax(this.maxTextSize - this.minTextSize);
        SeekBar seekBar4 = (SeekBar) inflate.findViewById(R.id.settings_spacing_seek);
        this.spacingSeek = seekBar4;
        seekBar4.setMax((int) ((this.maxSpacing - this.minSpacing) * 20.0f));
        inflate.findViewById(R.id.back_btn).setOnClickListener(this);
        String fontType2 = this.preferences.getFontType();
        this.fontType = fontType2;
        int i2 = 2;
        if (fontType2.equalsIgnoreCase(this.fontNames[1])) {
            i2 = 1;
        } else if (!this.fontType.equalsIgnoreCase(this.fontNames[2])) {
            i2 = 0;
        }
        this.fontSpinner.setSelection(i2);
        updateFontType(this.fontType);
        this.fontSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            /* class king.james.bible.android.fragment.SettingsFragment.AnonymousClass4 */

            @Override // android.widget.AdapterView.OnItemSelectedListener
            public void onNothingSelected(AdapterView<?> adapterView) {
            }

            @Override // android.widget.AdapterView.OnItemSelectedListener
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
                SettingsFragment settingsFragment = SettingsFragment.this;
                settingsFragment.fontType = settingsFragment.fontNames[i];
                boolean z = !SettingsFragment.this.preferences.getFontType().equalsIgnoreCase(SettingsFragment.this.fontType);
                SettingsFragment.this.preferences.setFontType(SettingsFragment.this.fontType);
                SettingsFragment.this.preferences.lambda$saveBg$1$BiblePreferences();
                SettingsFragment settingsFragment2 = SettingsFragment.this;
                settingsFragment2.updateFontType(settingsFragment2.fontType);
                if (z) {
                    SettingsFragment.this.postUpdateEvent();
                }
            }
        });
        float textSize2 = this.preferences.getTextSize();
        this.textSize = textSize2;
        updateTextSize(textSize2);
        this.sizeSeek.setProgress(((int) this.textSize) - this.minTextSize);
        TextView textView4 = this.sizeText;
        textView4.setText(BuildConfig.FLAVOR + ((int) this.textSize));
        this.sizeSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            /* class king.james.bible.android.fragment.SettingsFragment.AnonymousClass5 */

            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
                SettingsFragment.this.preferences.setTextSize(SettingsFragment.this.textSize);
                SettingsFragment.this.preferences.lambda$saveBg$1$BiblePreferences();
                SettingsFragment.this.postUpdateEvent();
            }

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                int max = Math.max(Math.min(i, SettingsFragment.this.maxTextSize - SettingsFragment.this.minTextSize), 0);
                SettingsFragment settingsFragment = SettingsFragment.this;
                settingsFragment.textSize = (float) (max + settingsFragment.minTextSize);
                TextView textView = SettingsFragment.this.sizeText;
                textView.setText(BuildConfig.FLAVOR + ((int) SettingsFragment.this.textSize));
                SettingsFragment settingsFragment2 = SettingsFragment.this;
                settingsFragment2.updateTextSize(settingsFragment2.textSize);
            }
        });
        float spacing2 = this.preferences.getSpacing();
        this.spacing = spacing2;
        updateSpacing(spacing2);
        this.spacingSeek.setProgress((int) ((this.spacing - this.minSpacing) * 20.0f));
        TextView textView5 = this.spacingText;
        textView5.setText(BuildConfig.FLAVOR + String.format("%.2f", Float.valueOf(this.spacing)));
        this.spacingSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            /* class king.james.bible.android.fragment.SettingsFragment.AnonymousClass6 */

            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
                SettingsFragment.this.preferences.setSpacing(SettingsFragment.this.spacing);
                SettingsFragment.this.preferences.lambda$saveBg$1$BiblePreferences();
                SettingsFragment.this.postUpdateEvent();
            }

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                int max = Math.max(Math.min(i, (int) ((SettingsFragment.this.maxSpacing - SettingsFragment.this.minSpacing) * 20.0f)), 0);
                SettingsFragment settingsFragment = SettingsFragment.this;
                settingsFragment.spacing = (((float) max) / 20.0f) + settingsFragment.minSpacing;
                TextView textView = SettingsFragment.this.spacingText;
                textView.setText(BuildConfig.FLAVOR + String.format("%.2f", Float.valueOf(SettingsFragment.this.spacing)));
                SettingsFragment settingsFragment2 = SettingsFragment.this;
                settingsFragment2.updateSpacing(settingsFragment2.spacing);
            }
        });
        inflate.findViewById(R.id.ttsSettingsButton).setOnClickListener(this);
        PowerManagerService.getInstance().start();
        return inflate;
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(SettingUpdateEvent settingUpdateEvent) {
        if (getActivity() != null) {
            settingUpdateEvent.isCancel();
            throw null;
        }
    }

    /* access modifiers changed from: private */
    public void updateView() {
        int i = 0;
        if (this.preferences.isNightMode() != this.isNightMode) {
            this.isNightMode = this.preferences.isNightMode();
            this.preferences.setLoadScreen(false);
            this.preferences.lambda$saveBg$1$BiblePreferences();
            getActivity().finish();
            Intent intent = new Intent(getActivity(), MainFragmentActivity.class);
            intent.putExtra("start_setting_fragment", true);
            getActivity().startActivity(intent);
            return;
        }
        BibleToast.showShortDurationToast(getActivity(), R.string.setting_import_complete);
        this.preferences.lambda$restoreAsync$0$BiblePreferences();
        this.textSize = this.preferences.getTextSize();
        this.spacing = this.preferences.getSpacing();
        this.sizeSeek.setProgress(((int) this.textSize) - this.minTextSize);
        this.sizeText.setText(Integer.toString((int) this.textSize));
        updateTextSize(this.textSize);
        this.spacingSeek.setProgress((int) ((this.spacing - this.minSpacing) * 20.0f));
        TextView textView = this.spacingText;
        textView.setText(BuildConfig.FLAVOR + String.format("%.2f", Float.valueOf(this.spacing)));
        this.screenStayCheckBox.setChecked(this.preferences.isScreenStay());
        this.redLettersModeCheckBox.setChecked(this.preferences.isRedLettersMode());
        this.italicWordsCheckBox.setChecked(this.preferences.isItalicWords());
        String fontType2 = this.preferences.getFontType();
        this.fontType = fontType2;
        if (fontType2.equalsIgnoreCase(this.fontNames[1])) {
            i = 1;
        } else if (this.fontType.equalsIgnoreCase(this.fontNames[2])) {
            i = 2;
        }
        updateFontType(this.fontType);
        this.fontSpinner.setSelection(i);
        postUpdateEvent();
    }

    private void prepareTextStyleSettings(View view) {
        this.screenStayCheckBox = (CheckBox) view.findViewById(R.id.screenStayCheckBox);
        this.redLettersModeCheckBox = (CheckBox) view.findViewById(R.id.redLettersModeCheckBox);
        this.italicWordsCheckBox = (CheckBox) view.findViewById(R.id.italicWordsCheckBox);
        view.findViewById(R.id.redLettersModeRelativeLayout).setVisibility(0);
        view.findViewById(R.id.italicWordsRelativeLayout).setVisibility(0);
        this.screenStayCheckBox.setChecked(this.preferences.isScreenStay());
        this.redLettersModeCheckBox.setChecked(this.preferences.isRedLettersMode());
        this.italicWordsCheckBox.setChecked(this.preferences.isItalicWords());
      r3 = new CompoundButton.OnCheckedChangeListener() {
            /* class king.james.bible.android.fragment.SettingsFragment.AnonymousClass7 */

            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                int id = compoundButton.getId();
                if (id == R.id.italicWordsCheckBox) {
                    SettingsFragment.this.preferences.setItalicWords(z);
                    SettingsFragment.this.initTextView();
                } else if (id == R.id.redLettersModeCheckBox) {
                    SettingsFragment.this.preferences.setRedLettersMode(z);
                    SettingsFragment.this.initTextView();
                } else if (id == R.id.screenStayCheckBox) {
                    PowerManagerService.getInstance().updateState(z);
                    SettingsFragment.this.preferences.setScreenStay(z);
                }
                SettingsFragment.this.preferences.lambda$saveBg$1$BiblePreferences();
                SettingsFragment.this.postUpdateEvent();
            }
        };
        this.screenStayCheckBox.setOnCheckedChangeListener(r3);
        this.redLettersModeCheckBox.setOnCheckedChangeListener(r3);
        this.italicWordsCheckBox.setOnCheckedChangeListener(r3);
    }

    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.back_btn) {
            try {
                getActivity().onBackPressed();
            } catch (Exception unused) {
            }
        } else if (id == R.id.importExportLayout) {
            onImportExportClick();
        } else if (id == R.id.ttsSettingsButton) {
            onTTSClick();
        }
    }

    private void onImportExportClick() {
        Dexter.withContext(getActivity()).withPermissions("android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE").withListener(new MultiplePermissionsListener() {
            /* class king.james.bible.android.fragment.SettingsFragment.AnonymousClass8 */

            @Override // com.karumi.dexter.listener.multi.MultiplePermissionsListener
            public void onPermissionsChecked(MultiplePermissionsReport multiplePermissionsReport) {
                if (multiplePermissionsReport.areAllPermissionsGranted()) {
                    try {
                        DialogUtil.showImportExportDialog(SettingsFragment.this.getChildFragmentManager());
                    } catch (Exception unused) {
                    }
                } else if (multiplePermissionsReport.isAnyPermissionPermanentlyDenied()) {
                    SettingsDialog.showSettingsDialog(SettingsFragment.this.getActivity());
                }
            }

            @Override // com.karumi.dexter.listener.multi.MultiplePermissionsListener
            public void onPermissionRationaleShouldBeShown(List<PermissionRequest> list, PermissionToken permissionToken) {
                permissionToken.continuePermissionRequest();
            }
        }).withErrorListener(new PermissionRequestErrorListener() {
            /* class king.james.bible.android.fragment.$$Lambda$SettingsFragment$pjZHyuzIPK_OWROjNRwEBfHk20I */

            @Override // com.karumi.dexter.listener.PermissionRequestErrorListener
            public final void onError(DexterError dexterError) {
                SettingsFragment.this.lambda$onImportExportClick$3$SettingsFragment(dexterError);
            }
        }).onSameThread().check();
    }

    public /* synthetic */ void lambda$onImportExportClick$3$SettingsFragment(DexterError dexterError) {
        FragmentActivity activity = getActivity();
        Toast.makeText(activity, getActivity().getString(R.string.error) + " " + dexterError.toString(), 0).show();
    }

    private void onTTSClick() {
        AppUtils.onOpenTTSDeviceSettingsScreen(getContext());
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(ClickOpenImportEvent clickOpenImportEvent) {
        openFolder();
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(ClickOpenExportEvent clickOpenExportEvent) {
        openFolderView();
    }

    private void openFolder() {
        Intent intent = new Intent("android.intent.action.GET_CONTENT");
        Uri parse = Uri.parse(Environment.getDownloadCacheDirectory().getPath());
        intent.addCategory("android.intent.category.OPENABLE");
        intent.setDataAndType(parse, "*/*");
        try {
            startActivityForResult(intent, 300);
        } catch (ActivityNotFoundException unused) {
            BibleToast.showShortDurationToast(getActivity(), R.string.errorfilemanager);
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i2 == -1 && intent != null) {
            if (Build.VERSION.SDK_INT >= 21) {
                String realPath = getRealPath(intent);
                if (realPath.length() > 0) {
                    ExportImportObservable.getInstance().importData(new File(realPath));
                    return;
                }
                BibleToast.showShortDurationToast(getActivity(), R.string.errorfile);
                return;
            }
            ExportImportObservable.getInstance().importData(new File(intent.getData().getPath()));
        }
    }

    @SuppressLint("Range")
    private String getRealPath(Intent intent) {
        String str;
        String str2;
        Cursor query = getActivity().getContentResolver().query(intent.getData(), null, null, null, null);
        if (query == null) {
            return intent.getData().getPath();
        }
        boolean moveToFirst = query.moveToFirst();
        String str3 = null;
        String str4 = BuildConfig.FLAVOR;
        if (moveToFirst) {
            do {
                try {
                    str = query.getString(query.getColumnIndex("document_id"));
                } catch (IllegalStateException unused) {
                    str = query.getString(query.getColumnIndex("_data"));
                }
                str3 = query.getString(query.getColumnIndex("mime_type"));
                str2 = query.getString(query.getColumnIndex("_display_name"));
            } while (query.moveToNext());
        } else {
            str2 = null;
            str = str4;
        }
        query.close();
        if (str.indexOf("/") == 0) {
            return str;
        }
        Cursor query2 = getActivity().getContentResolver().query(MediaStore.Files.getContentUri("external"), null, "mime_type=? OR _data LIKE ?", new String[]{str3, "%" + str2 + "%"}, null);
        if (query2 == null) {
            return str4;
        }
        if (query2.moveToFirst()) {
            do {
                str = query2.getString(query2.getColumnIndex("_data"));
            } while (query2.moveToNext());
        }
        if (query2.getCount() != 0) {
            str4 = str;
        }
        query2.close();
        return str4;
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void updateFontType(String str) {
        Typeface typeface = Typeface.SANS_SERIF;
        if (str.equalsIgnoreCase(this.fontNames[1])) {
            typeface = Typeface.SERIF;
        } else if (str.equalsIgnoreCase(this.fontNames[2])) {
            typeface = Typeface.MONOSPACE;
        }
        for (TextView textView : this.mTextViews) {
            textView.setTypeface(typeface);
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void postUpdateEvent() {
        EventBus.getDefault().post(new UpdatePageBySettingsChangeEvent());
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void updateTextSize(float f) {
        for (TextView textView : this.mTextViews) {
            textView.setTextSize(2, f);
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void updateSpacing(float f) {
        for (TextView textView : this.mTextViews) {
            textView.setLineSpacing(0.0f, f);
        }
    }

    private void openFolderView() {
        File file = new File(Environment.getExternalStorageDirectory().getPath());
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setDataAndType(Uri.fromFile(file), "*/*");
        startActivity(Intent.createChooser(intent, getString(R.string.app_name)));
        if (intent.resolveActivityInfo(getActivity().getPackageManager(), 0) != null) {
            startActivity(intent);
            return;
        }
        try {
            startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=com.estrongs.android.pop")));
        } catch (ActivityNotFoundException unused) {
            startActivity(new Intent("android.intent.action.VIEW", Uri.parse(getString(R.string.KJB_app_url) + "com.estrongs.android.pop")));
        }
    }

    @Override // king.james.bible.android.sound.listener.page.SoundVerseListener
    public void onPauseSound(int i) {
        if (getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() {
                /* class king.james.bible.android.fragment.$$Lambda$SettingsFragment$D0VPrpJrdxwiCnNPSG2nuPwJDog */

                public final void run() {
                    SettingsFragment.this.lambda$onPauseSound$5$SettingsFragment();
                }
            });
        }
    }

    public /* synthetic */ void lambda$onPauseSound$5$SettingsFragment() {
        this.settingsSoundButtonHolder.preparePauseBackground();
    }

    @Override // king.james.bible.android.sound.listener.page.SoundVerseListener
    public void onPlayError(String str) {
        if (getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() {
                /* class king.james.bible.android.fragment.$$Lambda$SettingsFragment$3Fn14d1VHTkWN8OewqdlmQQwtlk */

                public final void run() {
                    SettingsFragment.this.lambda$onPlayError$6$SettingsFragment();
                }
            });
        }
    }

    public /* synthetic */ void lambda$onPlayError$6$SettingsFragment() {
        DialogUtil.showSoundPlayErrorDialog(getChildFragmentManager());
    }

    @Override // androidx.fragment.app.Fragment
    public void onPause() {
        SoundHelper.getInstance().pause();
        super.onPause();
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroy() {
        SoundHelper.getInstance().stop(-14);
        postUpdateEvent();
        super.onDestroy();
    }

    @Override // king.james.bible.android.dialog.ExportImportDialog.ImportListener
    public void onSuccessImport() {
        if (getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() {
                /* class king.james.bible.android.fragment.$$Lambda$SettingsFragment$5fhwenxZpl2ajXs3891_Emazem4 */

                public final void run() {
                    SettingsFragment.this.updateView();
                }
            });
        }
    }

    @Override // king.james.bible.android.dialog.ExportImportDialog.ImportListener
    public void onErrorImport() {
        if (getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() {
                /* class king.james.bible.android.fragment.$$Lambda$SettingsFragment$ivdMfFWX3JdZErmpxUD8UAjPewo */

                public final void run() {
                    SettingsFragment.this.lambda$onErrorImport$7$SettingsFragment();
                }
            });
        }
    }

    public /* synthetic */ void lambda$onErrorImport$7$SettingsFragment() {
        BibleToast.showShortDurationToast(getActivity(), R.string.setting_import_error);
    }
}
