package king.james.bible.android.adapter.holder;

import android.text.Html;
import android.text.SpannableString;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;
import king.james.bible.android.R;
import king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter;
import king.james.bible.android.adapter.recycler.DailyVerseRecyclerViewAdapter;
import king.james.bible.android.model.DailyVerse;
import king.james.bible.android.model.DailyVerseAction;
import king.james.bible.android.utils.BiblePreferences;
import king.james.bible.android.utils.SettingsTextUtil;

public class DailyVerseViewHolder extends BaseRecyclerViewAdapter.BaseViewHolder implements View.OnClickListener {
    private DailyVerseRecyclerViewAdapter.DailyVerseActionListener actionListener;
    private TextView chapterTextView;
    private DailyVerse model;
    private TextView textTextView;
    private TextView titleTextView;

    public DailyVerseViewHolder(View view) {
        super(view);
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter.BaseViewHolder
    public void mapViews(View view) {
        boolean isNightMode = BiblePreferences.getInstance().isNightMode();
        int i = isNightMode ? R.drawable.daily_verse_selector_n : R.drawable.daily_verse_selector;
        int i2 = isNightMode ? R.color.highlight_color2 : R.color.title_text;
        View findViewById = view.findViewById(R.id.rootRelativeLayout);
        RelativeLayout relativeLayout = (RelativeLayout) view.findViewById(R.id.shareLayout);
        RelativeLayout relativeLayout2 = (RelativeLayout) view.findViewById(R.id.copyLayout);
        RelativeLayout relativeLayout3 = (RelativeLayout) view.findViewById(R.id.editLayout);
        RelativeLayout relativeLayout4 = (RelativeLayout) view.findViewById(R.id.updateLayout);
        RelativeLayout relativeLayout5 = (RelativeLayout) view.findViewById(R.id.deleteLayout);
        this.titleTextView = (TextView) view.findViewById(R.id.titleTextView);
        this.textTextView = (TextView) view.findViewById(R.id.textTextView);
        this.chapterTextView = (TextView) view.findViewById(R.id.chapterTextView);
        this.textTextView.setTextColor(view.getContext().getResources().getColor(isNightMode ? R.color.abc_decor_view_status_guard_light : R.color.ad_button_night_bg_center_color));
        this.chapterTextView.setTextColor(view.getContext().getResources().getColor(R.color.title_text));
        findViewById.setBackgroundResource(i2);
        relativeLayout.setBackgroundResource(i);
        relativeLayout2.setBackgroundResource(i);
        relativeLayout3.setBackgroundResource(i);
        relativeLayout4.setBackgroundResource(i);
        relativeLayout5.setBackgroundResource(i);
        relativeLayout.setOnClickListener(this);
        relativeLayout2.setOnClickListener(this);
        relativeLayout3.setOnClickListener(this);
        relativeLayout4.setOnClickListener(this);
        relativeLayout5.setOnClickListener(this);
        view.findViewById(R.id.topButtonDivider).setBackgroundResource(isNightMode ? com.google.android.material.R.color.design_dark_default_color_secondary : R.color.abc_decor_view_status_guard_light);
    }

    @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter.BaseViewHolder
    public void updateView(Object obj) {
        this.model = (DailyVerse) obj;
        SettingsTextUtil.setupTextViewSettings(this.titleTextView);
        SettingsTextUtil.setupTextViewSettings(this.textTextView);
        SettingsTextUtil.setupTextViewSettings(this.chapterTextView);
        SettingsTextUtil.prepareTitleTextView(this.titleTextView);
        this.titleTextView.setText(this.model.getTitle());
        this.textTextView.setText(Html.fromHtml(new SpannableString(SettingsTextUtil.prepareText(this.model.getText())).toString()));
        this.chapterTextView.setText(this.model.getChapter());
    }

    public void onClick(View view) {
        DailyVerseAction dailyVerseAction;
        DailyVerseRecyclerViewAdapter.DailyVerseActionListener dailyVerseActionListener;
        DailyVerseAction dailyVerseAction2 = DailyVerseAction.EMPTY;
        switch (view.getId()) {
            case R.id.copyLayout:
                dailyVerseAction = DailyVerseAction.COPY;
                break;
            case R.id.deleteLayout:
                dailyVerseAction = DailyVerseAction.DELETE;
                break;
            case R.id.editLayout:
                dailyVerseAction = DailyVerseAction.EDIT;
                break;
            case R.id.shareLayout:
                dailyVerseAction = DailyVerseAction.SHARE;
                break;
            case R.id.updateLayout:
                dailyVerseAction = DailyVerseAction.UPDATE;
                break;
            default:
                return;
        }
        if (dailyVerseAction != DailyVerseAction.EMPTY && (dailyVerseActionListener = this.actionListener) != null) {
            dailyVerseActionListener.onDailyVerseAction(this.model, dailyVerseAction, getAdapterPosition());
        }
    }

    public void setActionListener(DailyVerseRecyclerViewAdapter.DailyVerseActionListener dailyVerseActionListener) {
        this.actionListener = dailyVerseActionListener;
    }
}
