package king.james.bible.android.event;

public class OpenFromContents3Event {
    private int chapter;
    private Object object;
    private int position;
    private int positionRank;
    private int subChapter;

    public OpenFromContents3Event(int i, int i2, int i3, int i4, Object obj) {
        this.chapter = i;
        this.subChapter = i2;
        this.position = i3;
        this.positionRank = i4;
        this.object = obj;
    }

    public int getChapter() {
        return this.chapter;
    }

    public int getSubChapter() {
        return this.subChapter;
    }

    public int getPosition() {
        return this.position;
    }

    public int getPositionRank() {
        return this.positionRank;
    }

    public Object getObject() {
        return this.object;
    }
}
