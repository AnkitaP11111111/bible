package king.james.bible.android.holder;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import com.karumi.dexter.BuildConfig;
import java.util.ArrayList;
import java.util.List;
import king.james.bible.android.adapter.array.SearchAdapter;
import king.james.bible.android.model.SearchText;
import king.james.bible.android.task.SearchTask;
import king.james.bible.android.utils.BibleToast;
import king.james.bible.android.view.AutoCompleteCustomTextView;

public class SearchTextViewHolder {
    private SearchAdapter mSearchAdapter;
    private SearchTask mSearchTask;
    private SearchText mSearchText = new SearchText(0, BuildConfig.FLAVOR);
    private List<SearchText> mSearchTexts = new ArrayList();
    private AutoCompleteCustomTextView searchEdit;
    private SearchItemSelectHandler searchItemSelectHandler;

    public SearchTextViewHolder(AutoCompleteCustomTextView autoCompleteCustomTextView, SearchItemSelectHandler searchItemSelectHandler2) {
        this.searchEdit = autoCompleteCustomTextView;
        this.searchItemSelectHandler = searchItemSelectHandler2;
        initSearchEdit();
    }

    private void initSearchEdit() {
        this.mSearchTexts = new ArrayList();
        initAdapter();
        this.searchEdit.addTextChangedListener(new TextWatcher() {
            /* class king.james.bible.android.holder.SearchTextViewHolder.AnonymousClass1 */

            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void afterTextChanged(Editable editable) {
                String obj = SearchTextViewHolder.this.searchEdit.getText().toString();
                if (obj.length() >= 2 && !obj.equals(SearchTextViewHolder.this.mSearchText.getText())) {
                    SearchTextViewHolder.this.mSearchText = new SearchText();
                    SearchTextViewHolder.this.cancelTasks();
                    SearchTextViewHolder.this.mSearchTask = new SearchTask(SearchTextViewHolder.this.searchEdit.getContext(), new SearchTask.OnCallbackHandler() {
                        /* class king.james.bible.android.holder.SearchTextViewHolder.AnonymousClass1.AnonymousClass1 */

                        public void onSuccess(List<SearchText> list) {
                            if (SearchTextViewHolder.this.mSearchTexts == null) {
                                SearchTextViewHolder.this.mSearchTexts = new ArrayList();
                            }
                            try {
                                SearchTextViewHolder.this.mSearchTexts.clear();
                                SearchTextViewHolder.this.mSearchTexts.addAll(list);
                                SearchTextViewHolder.this.initAdapter();
                                SearchTextViewHolder.this.mSearchAdapter.notifyDataSetChanged();
                            } catch (Exception unused) {
                            }
                            SearchTextViewHolder.this.cancelTasks();
                        }

                        @Override // king.james.bible.android.task.BaseTask.OnCallbackHandler
                        public void onError(Exception exc) {
                            BibleToast.showLongDurationToast(SearchTextViewHolder.this.searchEdit.getContext(), exc.getMessage());
                        }
                    });
                    SearchTextViewHolder.this.mSearchTask.executeAsyncTask(obj);
                }
            }
        });
        this.searchEdit.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            /* class king.james.bible.android.holder.SearchTextViewHolder.AnonymousClass2 */

            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                try {
                    SearchTextViewHolder.this.mSearchText = (SearchText) SearchTextViewHolder.this.mSearchAdapter.getItem(i);
                    SearchTextViewHolder.this.searchEdit.setText(SearchTextViewHolder.this.mSearchText.getText());
                    SearchTextViewHolder.this.searchEdit.setSelection(SearchTextViewHolder.this.searchEdit.length());
                    if (SearchTextViewHolder.this.searchItemSelectHandler != null) {
                        SearchTextViewHolder.this.searchItemSelectHandler.makeSearchBySelectItem();
                    }
                } catch (Exception unused) {
                }
            }
        });
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void initAdapter() {
        SearchAdapter searchAdapter = new SearchAdapter(this.searchEdit.getContext(), this.mSearchTexts);
        this.mSearchAdapter = searchAdapter;
        this.searchEdit.setAdapter(searchAdapter);
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void cancelTasks() {
        SearchTask searchTask = this.mSearchTask;
        if (searchTask != null) {
            searchTask.cancel(true);
        }
    }
}
