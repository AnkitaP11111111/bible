package king.james.bible.android.fragment;

import android.annotation.SuppressLint;
import android.view.View;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import king.james.bible.android.R;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import king.james.bible.android.adapter.recycler.DailyReadingRecyclerViewAdapter;
import king.james.bible.android.db.BibleDataBase;
import king.james.bible.android.db.service.DailyReadingDataService;
import king.james.bible.android.dialog.DeleteDialog;
import king.james.bible.android.dialog.DialogUtil;
import king.james.bible.android.dialog.NotifyDialog;
import king.james.bible.android.dialog.StartPlanDialog;
import king.james.bible.android.model.Plan;
import king.james.bible.android.model.PlanChapterDay;
import king.james.bible.android.model.PlanDay;
import king.james.bible.android.model.PlanMode;
import king.james.bible.android.model.comparator.PlanComparator;
import king.james.bible.android.service.DailyReadingCheckedService;
import king.james.bible.android.service.DailyReadingService;
import king.james.bible.android.service.notifications.NotificationDataService;
import king.james.bible.android.service.notifications.NotificationMode;
import king.james.bible.android.service.notifications.NotificationsReadingForegroundUtil;
import king.james.bible.android.service.observable.DailyPlanObservable;
import king.james.bible.android.service.observable.DailyReadingActionObservable;
import king.james.bible.android.service.observable.DeleteListenerObservable;
import king.james.bible.android.service.observable.FragmentCallbackObservable;
import king.james.bible.android.service.observable.NotifyTimeListenerObservable;
import king.james.bible.android.utils.BiblePreferences;
import king.james.bible.android.utils.DailyReadingCache;
import king.james.bible.android.view.DividerItemDecoration;
@SuppressLint({"NewApi", "WrongConstant"})

public class DailyReadingFragment extends BaseDailyFragment implements DailyReadingRecyclerViewAdapter.DailyReadingActionListener, DeleteDialog.DeleteListener, NotifyDialog.NotifyTimeListener {
    private  boolean r344;
    private  PlanDay r244;
    private  int r44;
    private  boolean r34;
    private  PlanDay r234;
    private  PlanChapterDay r24;
    private  PlanMode r4;
    private  Plan r33;
    private  int r22;
    private  PlanMode r3;
    private  Plan r2;
    private DailyReadingRecyclerViewAdapter adapter;
    private RecyclerView dailyReadingRecyclerView;
    private DailyReadingService dailyReadingService;
    private List<Plan> planList;
    private BiblePreferences preferences;

    @Override // king.james.bible.android.dialog.NotifyDialog.NotifyTimeListener
    public void cancelNotifyDialog() {
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.fragment.BaseDailyFragment
    public int getViewResId() {
        return R.layout.fragment_daily_reading;
    }

    @Override // king.james.bible.android.dialog.DeleteDialog.DeleteListener
    public void selectNo() {
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.fragment.BaseDailyFragment
    public void mapViews(View view) {
        this.preferences = BiblePreferences.getInstance();
        setToolbarTitle(R.string.daily_readingtitle);
        RecyclerView recyclerView = (RecyclerView) view.findViewById(R.id.dailyReadingRecyclerView);
        this.dailyReadingRecyclerView = recyclerView;
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), 1, false));
        this.dailyReadingRecyclerView.addItemDecoration(new DividerItemDecoration(getActivity(), this.preferences.isNightMode() ? R.drawable.daily_reading_divider_n : R.drawable.daily_reading_divider));
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.fragment.BaseDailyFragment
    public void prepareModeView(View view) {
        int i;
        int i2;
        super.prepareModeView(view);
        if (this.preferences.isNightMode()) {
            i2 = R.color.red_text;
            i = R.color.abc_decor_view_status_guard_light;
        } else {
            i2 = R.color.daily_reading_divider;
            i = R.color.white;
        }
        view.findViewById(R.id.root_layout).setBackgroundResource(i2);
        view.findViewById(R.id.actionbar).setBackgroundResource(i);
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.fragment.BaseDailyFragment
    public void initActions() {
        this.dailyReadingService = DailyReadingService.getInstance();
        initLoadData();
        NotificationsReadingForegroundUtil.cancelNotifications(getActivity(), NotificationMode.PLAN);
    }

    private void initLoadData() {
        initLoadData(null);
    }

    private void initLoadData(Plan plan) {
        showProgress();
        new Thread(new Runnable() {
            /* class king.james.bible.android.fragment.$$Lambda$DailyReadingFragment$VpPVqTE8iW4q_GXDV7_MOKOmqjo */
            private final /* synthetic */ Plan f$1;

            {
                this.f$1 = r2;
            }

            public final void run() {
                DailyReadingFragment.this.lambda$initLoadData$1$DailyReadingFragment(this.f$1);
            }
        }).start();
    }

    public /* synthetic */ void lambda$initLoadData$1$DailyReadingFragment(Plan plan) {
        if (plan != null) {
            this.dailyReadingService.stopPlan(plan);
        }
        this.planList = this.dailyReadingService.getPlanList();
        if (getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() {
                /* class king.james.bible.android.fragment.$$Lambda$DailyReadingFragment$QT7xz7pXyjLj9YRC4SKApmkYMQI */

                public final void run() {
                    DailyReadingFragment.this.lambda$null$0$DailyReadingFragment();
                }
            });
        }
    }

    public /* synthetic */ void lambda$null$0$DailyReadingFragment() {
        if (getActivity() != null) {
            initRecycler();
        }
    }

    private void initRecycler() {
        DailyReadingRecyclerViewAdapter dailyReadingRecyclerViewAdapter = new DailyReadingRecyclerViewAdapter(this.planList);
        this.adapter = dailyReadingRecyclerViewAdapter;
        this.dailyReadingRecyclerView.setAdapter(dailyReadingRecyclerViewAdapter);
        this.dailyReadingRecyclerView.postDelayed(new Runnable() {
            /* class king.james.bible.android.fragment.$$Lambda$DailyReadingFragment$_9Mo_UgOUOttljFPFB5IXwsf6Y */

            public final void run() {
                DailyReadingFragment.this.lambda$initRecycler$2$DailyReadingFragment();
            }
        }, 500);
        hideProgress();
    }

    public /* synthetic */ void lambda$initRecycler$2$DailyReadingFragment() {
        int dailyReadingPosition = this.dailyReadingService.getDailyReadingPosition();
        if (getArguments() != null) {
            long j = getArguments().getLong("paramId", 0);
            if (j > 0) {
                dailyReadingPosition = getPlanPosition(Long.valueOf(j));
            }
        }
        this.dailyReadingRecyclerView.scrollToPosition(dailyReadingPosition);
        this.dailyReadingService.clearDailyReadingBackStack();
    }

    @Override // king.james.bible.android.adapter.recycler.DailyReadingRecyclerViewAdapter.DailyReadingActionListener
    public void onSelectPlan(Plan plan, int i, PlanMode planMode) {
        StartPlanDialog.show(getActivity(), new StartPlanDialog.StartPlanListener() {
            /* class king.james.bible.android.fragment.$$Lambda$DailyReadingFragment$0nMUAsVAe1hMDvvxLswqvUgmjWk */
            private final /* synthetic */ Plan f$1;
            private final /* synthetic */ PlanMode f$2;

            {
                this.f$1 = r2;
                this.f$2 = r3;
            }

            @Override // king.james.bible.android.dialog.StartPlanDialog.StartPlanListener
            public final void onSelectStartDay(int i) {
                DailyReadingFragment.this.lambda$onSelectPlan$3$DailyReadingFragment(this.f$1, this.f$2, i);
            }
        }, plan.getId(), planMode);
    }

    public /* synthetic */ void lambda$onSelectPlan$3$DailyReadingFragment(Plan plan, PlanMode planMode, int i) {
        showProgress();
        startPlan(i, plan, planMode);
    }

    private void startPlan(int i, Plan plan, PlanMode planMode) {
        new Thread(new Runnable() {
            /* class king.james.bible.android.fragment.$$Lambda$DailyReadingFragment$H3buk4QUt6NfBtqVnwmvm3UCZ_U */
            private final /* synthetic */ int f$1;
            private final /* synthetic */ Plan f$2;
            private final /* synthetic */ PlanMode f$3;

            {
                this.f$1 = r22;
                this.f$2 = r33;
                this.f$3 = r4;
            }

            public final void run() {
                DailyReadingFragment.this.lambda$startPlan$6$DailyReadingFragment(this.f$1, this.f$2, this.f$3);
            }
        }).start();
    }

    public /* synthetic */ void lambda$startPlan$6$DailyReadingFragment(int i, Plan plan, PlanMode planMode) {
        Plan startPlan = this.dailyReadingService.startPlan(i, plan, planMode, new DailyReadingDataService.CreatePlanListener() {
            /* class king.james.bible.android.fragment.$$Lambda$DailyReadingFragment$GWK9_fVvkM8aS2tFxp5rLBVJ4A */
            private final /* synthetic */ Plan f$1;

            {
                this.f$1 = r2;
            }

            @Override // king.james.bible.android.db.service.DailyReadingDataService.CreatePlanListener
            public final void createAllDays(List list) {
                DailyReadingFragment.this.lambda$null$4$DailyReadingFragment(this.f$1, list);
            }
        });
        DailyReadingCache.put(startPlan.getId(), i - 1);
        int i2 = 0;
        while (true) {
            if (i2 >= this.planList.size()) {
                break;
            }
            Plan plan2 = this.planList.get(i2);
            if (plan2.getId() == startPlan.getId()) {
                this.planList.remove(plan2);
                this.planList.add(startPlan);
                break;
            }
            i2++;
        }
        Collections.sort(this.planList, new PlanComparator());
        if (getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() {
                /* class king.james.bible.android.fragment.$$Lambda$DailyReadingFragment$LUVvxflEhPvEUlpg2SfPd_ED2Y */

                public final void run() {
                    DailyReadingFragment.this.lambda$null$5$DailyReadingFragment();
                }
            });
        }
    }

    public /* synthetic */ void lambda$null$5$DailyReadingFragment() {
        if (getActivity() != null) {
            this.adapter.notifyDataSetChanged();
            this.dailyReadingRecyclerView.scrollToPosition(0);
            hideProgress();
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: updateAllDays */
    public void lambda$null$4$DailyReadingFragment(Plan plan, List<PlanDay> list) {
        if (getActivity() != null) {
            Plan plan2 = null;
            Iterator<Plan> it = this.planList.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Plan next = it.next();
                if (plan.getId() == next.getId()) {
                    next.getPlanDays().clear();
                    next.getPlanDays().addAll(list);
                    plan2 = next;
                    break;
                }
            }
            getActivity().runOnUiThread(new Runnable() {
                private Plan f$1;

                @Override
                public void run() {

                    DailyReadingFragment.this.lambda$updateAllDays$7$DailyReadingFragment(this.f$1);

                }
            });

        }
    }

    public /* synthetic */ void lambda$updateAllDays$7$DailyReadingFragment(Plan plan) {
        if (getActivity() != null) {
            DailyPlanObservable.getInstance().loadDailyPlanComplete(plan);
            this.adapter.notifyDataSetChanged();
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void onStart() {
        super.onStart();
        DailyReadingActionObservable.getInstance().subscribe(this);
        DeleteListenerObservable.getInstance().subscribe(this);
        NotifyTimeListenerObservable.getInstance().subscribe(this);
    }

    @Override // androidx.fragment.app.Fragment
    public void onStop() {
        DailyReadingActionObservable.getInstance().remove(this);
        DeleteListenerObservable.getInstance().remove(this);
        NotifyTimeListenerObservable.getInstance().remove(this);
        super.onStop();
    }

    @Override // king.james.bible.android.adapter.recycler.DailyReadingRecyclerViewAdapter.DailyReadingActionListener
    public void onStopPlan(Plan plan) {
        if (getActivity() != null && plan != null) {
            DialogUtil.showDeleteDialog(getActivity().getSupportFragmentManager(), plan.getId(), R.string.daily_readingstop_text, -1);
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroy() {
        DailyReadingCheckedService.getInstance().clear();
        super.onDestroy();
    }

    @Override // king.james.bible.android.adapter.recycler.DailyReadingRecyclerViewAdapter.DailyReadingActionListener
    public void onViewChapter(PlanChapterDay planChapterDay) {
        showProgress();
        new Thread(new Runnable() {
            /* class king.james.bible.android.fragment.$$Lambda$DailyReadingFragment$DsTLQKYF61hNHhoLwQRFwV3gZ0 */
            private final /* synthetic */ PlanChapterDay f$1;

            {
                this.f$1 = r24;
            }

            public final void run() {
                DailyReadingFragment.this.lambda$onViewChapter$9$DailyReadingFragment(this.f$1);
            }
        }).start();
    }

    public /* synthetic */ void lambda$onViewChapter$9$DailyReadingFragment(PlanChapterDay planChapterDay) {
        if (getActivity() != null) {
            this.dailyReadingService.viewChapter(planChapterDay);
            if (getActivity() != null) {
                getActivity().runOnUiThread(new Runnable() {
                    /* class king.james.bible.android.fragment.$$Lambda$DailyReadingFragment$uslWcouh4Qt5ugiWoFtRWmAtQVA */
                    private final /* synthetic */ PlanChapterDay f$1;

                    {
                        this.f$1 = r24;
                    }

                    public final void run() {
                        DailyReadingFragment.this.lambda$null$8$DailyReadingFragment(this.f$1);
                    }
                });
            }
        }
    }

    public /* synthetic */ void lambda$null$8$DailyReadingFragment(PlanChapterDay planChapterDay) {
        if (getActivity() != null) {
            viewChapter(planChapterDay);
        }
    }

    private void viewChapter(PlanChapterDay planChapterDay) {
        DailyReadingCache.put(planChapterDay.getPlanId(), planChapterDay.getDay() - 1);
        this.dailyReadingService.setDailyReadingPosition(getPositionByPlanChapterDay(planChapterDay));
        this.dailyReadingService.setDailyReadingBackStack(true);
        int chapterByOrder = BibleDataBase.getInstance().getChapterByOrder(planChapterDay.getChapterOrder());
        if (getActivity() != null) {
            getActivity().onBackPressed();
        }
        FragmentCallbackObservable.getInstance().onFragmentResultOk(chapterByOrder, planChapterDay.getChapterNum() - 1, -1, -1, this);
    }

    @Override // king.james.bible.android.adapter.recycler.DailyReadingRecyclerViewAdapter.DailyReadingActionListener
    public void onSelectCompleteAll(PlanDay planDay, int i, boolean z, boolean z2) {
        new Thread(new Runnable() {
            /* class king.james.bible.android.fragment.$$Lambda$DailyReadingFragment$QwOWPWiqW6aO9cEwMorLoSPtvs */
            private final /* synthetic */ PlanDay f$1;
            private final /* synthetic */ boolean f$2;
            private final /* synthetic */ int f$3;

            {
                this.f$1 = r234;
                this.f$2 = r34;
                this.f$3 = r44;
            }

            public final void run() {
                DailyReadingFragment.this.lambda$onSelectCompleteAll$11$DailyReadingFragment(this.f$1, this.f$2, this.f$3);
            }
        }).start();
    }

    public /* synthetic */ void lambda$onSelectCompleteAll$11$DailyReadingFragment(PlanDay planDay, boolean z, int i) {
        this.dailyReadingService.completeAll(planDay, z, i);
        if (getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() {
                /* class king.james.bible.android.fragment.$$Lambda$DailyReadingFragment$S1WYzWgWYuOEduHtDWLIzEreI */
                private final /* synthetic */ PlanDay f$1;
                private final /* synthetic */ boolean f$2;

                {
                    this.f$1 = r244;
                    this.f$2 = r344;
                }

                public final void run() {
                    DailyReadingFragment.this.lambda$null$10$DailyReadingFragment(this.f$1, this.f$2);
                }
            });
        }
    }

    public /* synthetic */ void lambda$null$10$DailyReadingFragment(PlanDay planDay, boolean z) {
        if (getActivity() != null) {
            preparePlanDayModel(planDay, z);
            hideProgress();
        }
    }

    private int getPositionByPlanChapterDay(PlanChapterDay planChapterDay) {
        for (int i = 0; i < this.planList.size(); i++) {
            if (this.planList.get(i).getId() == planChapterDay.getPlanId()) {
                return i;
            }
        }
        return 0;
    }

    private void preparePlanDayModel(PlanDay planDay, boolean z) {
        for (Plan plan : this.planList) {
            if (plan.isStarted()) {
                for (PlanDay planDay2 : plan.getPlanDays()) {
                    if (planDay.getId() == planDay2.getId()) {
                        prepareLocalPlanDayModel(planDay2, z);
                        return;
                    }
                }
                continue;
            }
        }
    }

    private void prepareLocalPlanDayModel(PlanDay planDay, boolean z) {
        planDay.setReaded(z);
        for (PlanChapterDay planChapterDay : planDay.getPlanChapterDays()) {
            planChapterDay.setViewed(z);
        }
    }

    @Override // king.james.bible.android.adapter.recycler.DailyReadingRecyclerViewAdapter.DailyReadingActionListener
    public void onShowPlanDescription(Plan plan) {
        DailyReadingCheckedService.getInstance().clear();
        DialogUtil.showDailyPlanDialog(getChildFragmentManager(), plan);
    }

    @Override // king.james.bible.android.adapter.recycler.DailyReadingRecyclerViewAdapter.DailyReadingActionListener
    public void onDestroyDailyPlanDialog() {
        this.adapter.notifyDataSetChanged();
    }

    @Override // king.james.bible.android.dialog.DeleteDialog.DeleteListener
    public void selectYes(long j, int i) {
        Plan plan = getPlan(j);
        if (plan != null) {
            showProgress();
            DailyReadingCheckedService.getInstance().remove(plan.getId());
            NotificationDataService.getInstance().removePlan(plan.getId(), getActivity());
            DailyReadingCache.put(j, 0);
            initLoadData(plan);
        }
    }

    private Plan getPlan(long j) {
        for (Plan plan : this.planList) {
            if (j == plan.getId()) {
                return plan;
            }
        }
        return null;
    }

    private int getPlanPosition(Long l) {
        for (int i = 0; i < this.planList.size(); i++) {
            if (l.longValue() == this.planList.get(i).getId()) {
                return i;
            }
        }
        return -1;
    }

    @Override // king.james.bible.android.dialog.NotifyDialog.NotifyTimeListener
    public void selectNotifyTime(long j, boolean z, long j2) {
        Plan plan = getPlan(j);
        if (plan != null) {
            plan.setNotify(z);
            plan.setNotifyTime(j2);
            this.dailyReadingService.updateNotifyTime(plan, z, j2);
            NotificationDataService.getInstance().addOrUpdatePlan(plan, getActivity());
        }
    }
}
