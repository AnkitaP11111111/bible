package king.james.bible.android.fragment.contents;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;
import king.james.bible.android.R;
import java.util.List;
import king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter;
import king.james.bible.android.adapter.recycler.ContentsTabletRecyclerViewAdapter;
import king.james.bible.android.db.BibleDataBase;
import king.james.bible.android.event.OpenContents2Event;
import king.james.bible.android.model.chapter.ChapterShortNameAndMode;
import king.james.bible.android.service.LastChaptersService;
import king.james.bible.android.service.PowerManagerService;
import king.james.bible.android.utils.ScreenUtil;
import king.james.bible.android.view.ContentsGridLayoutManager;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
@SuppressLint({"NewApi", "WrongConstant"})

public class ContentsFragment extends Fragment implements AdapterView.OnItemClickListener, BaseRecyclerViewAdapter.OnItemClickListener {
    public static final String TAG = ContentsFragment.class.getSimpleName();
    private RecyclerView contentsRecyclerView;
    private GridView gridview;
    private List<ChapterShortNameAndMode> headerList;
    private List<ChapterShortNameAndMode> itemsList = getChaptersList();

    /* access modifiers changed from: protected */
    public List<ChapterShortNameAndMode> getChaptersList() {
        return BibleDataBase.getInstance().getChaptersList();
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        try {
            View inflate = layoutInflater.inflate(R.layout.fragment_contents_page, (ViewGroup) null);
            this.gridview = (GridView) inflate.findViewById(R.id.gridview);
            this.contentsRecyclerView = (RecyclerView) inflate.findViewById(R.id.contentsRecyclerView);
            inflate.findViewById(R.id.title_text).setVisibility(8);
            initRecyclerView();
            PowerManagerService.getInstance().start();
            return inflate;
        } catch (Exception unused) {
            getActivity().finish();
            return null;
        }
    }

    private void initRecyclerView() {
        this.gridview.setVisibility(8);
        this.contentsRecyclerView.setVisibility(0);
        this.headerList = LastChaptersService.getInstance().getLastChaptersModels();
        this.contentsRecyclerView.setVisibility(0);
        this.contentsRecyclerView.setLayoutManager(new ContentsGridLayoutManager(getActivity(), ScreenUtil.getInstance().getWidth(getActivity().getWindowManager()) / getResources().getDimensionPixelOffset(R.dimen.contents_item_width_long), this.headerList.size()));
        this.contentsRecyclerView.setAdapter(new ContentsTabletRecyclerViewAdapter(this.itemsList, this.headerList, this));
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
        if (getActivity() != null) {
            onClick(this.itemsList.get(i));
        }
    }

    @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter.OnItemClickListener
    public void onClick(int i) {
        ChapterShortNameAndMode chapterShortNameAndMode;
        if (getActivity() != null && i != this.headerList.size()) {
            if (i < this.headerList.size()) {
                chapterShortNameAndMode = this.headerList.get(i);
            } else {
                chapterShortNameAndMode = this.itemsList.get((i - this.headerList.size()) - 1);
            }
            onClick(chapterShortNameAndMode);
        }
    }

    private void onClick(ChapterShortNameAndMode chapterShortNameAndMode) {
        if (chapterShortNameAndMode != null) {
            onClick(chapterShortNameAndMode.getChapterID(), chapterShortNameAndMode.getLongName());
        }
    }

    private void onClick(int i, String str) {
        PowerManagerService.getInstance().start();
        Contents2Fragment contents2Fragment = new Contents2Fragment();
        Bundle bundle = new Bundle();
        bundle.putInt("chapter", i);
        bundle.putString("parameterTitle", str);
        contents2Fragment.setArguments(bundle);
        try {
            FragmentTransaction beginTransaction = getFragmentManager().beginTransaction();
            beginTransaction.replace(R.id.contents_page_frame_container, contents2Fragment, Contents2Fragment.TAG);
            beginTransaction.addToBackStack(Contents2Fragment.TAG);
            beginTransaction.commit();
        } catch (Exception unused) {
            getActivity().onBackPressed();
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void onStart() {
        super.onStart();
        EventBus.getDefault().register(this);
    }

    @Override // androidx.fragment.app.Fragment
    public void onStop() {
        EventBus.getDefault().unregister(this);
        super.onStop();
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(OpenContents2Event openContents2Event) {
        if (openContents2Event != null) {
            openContents2Event.getChapterID();
            throw null;
        }
    }
}
