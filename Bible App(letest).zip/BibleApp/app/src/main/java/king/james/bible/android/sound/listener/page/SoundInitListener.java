package king.james.bible.android.sound.listener.page;

public interface SoundInitListener {
    void completeInitService(int i);

    void startInitService(int i);
}
