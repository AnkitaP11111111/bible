package king.james.bible.android.service.notifications;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import king.james.bible.android.service.notifications.work.NotificationWorker;

public class AlarmBroadcast extends BroadcastReceiver {
    public void onReceive(final Context context, Intent intent) {
        final long longExtra = intent.getLongExtra(NotificationWorker.EXTRA_ID, -1);
        if (longExtra >= 1) {
            final String stringExtra = intent.getStringExtra(NotificationWorker.EXTRA_TYPE);
            final long longExtra2 = intent.getLongExtra(NotificationWorker.EXTRA_TIME, -1);
            new Thread(new Runnable() {
                /* class king.james.bible.android.service.notifications.AlarmBroadcast.AnonymousClass1 */

                public void run() {
                    NotificationService.actionTimer(context, stringExtra.equalsIgnoreCase(NotificationWorker.EXTRA_TYPE_PLAN), longExtra);
                    NotificationWorker.runAlarm(context, longExtra, stringExtra, longExtra2);
                }
            }).start();
        }
    }
}
