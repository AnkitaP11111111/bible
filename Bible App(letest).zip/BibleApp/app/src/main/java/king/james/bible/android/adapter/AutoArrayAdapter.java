package king.james.bible.android.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;
import king.james.bible.android.R;
import java.util.ArrayList;
import java.util.List;
import king.james.bible.android.utils.BiblePreferences;

public class AutoArrayAdapter extends BaseAdapter implements Filterable {
    private Context mContext;
    private List<String> mResults;
    private List<String> mResultsN;
    private List<String> mResultsRoot;
    private BiblePreferences preferences;

    public long getItemId(int i) {
        return (long) i;
    }

    public AutoArrayAdapter(Context context, List<String> list, List<String> list2) {
        this.mContext = context;
        this.mResults = list;
        this.mResultsRoot = list;
        this.mResultsN = list2;
        BiblePreferences instance = BiblePreferences.getInstance();
        this.preferences = instance;
        instance.lambda$restoreAsync$0$BiblePreferences();
    }

    public int getCount() {
        return this.mResults.size();
    }

    public String getItem(int i) {
        return this.mResults.get(i);
    }

    @SuppressLint("ResourceType")
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = LayoutInflater.from(this.mContext).inflate(this.preferences.isNightMode() ? R.layout.dropdown_item_layout_n : R.layout.dropdown_item_layout, viewGroup, false);
        }
        ((TextView) view.findViewById(16908308)).setText(getItem(i));
        return view;
    }

    /* access modifiers changed from: protected */
    public List<String> getCorrectFilter(CharSequence charSequence) {
        ArrayList arrayList = new ArrayList();
        for (String str : this.mResultsN) {
            if (str.toLowerCase().contains(charSequence.toString().toLowerCase())) {
                arrayList.add(this.mResultsRoot.get(this.mResultsN.indexOf(str)));
            }
        }
        return arrayList;
    }

    /* access modifiers changed from: protected */
    public List<String> getCorrectFilterAp(CharSequence charSequence) {
        ArrayList arrayList = new ArrayList();
        for (String str : this.mResults) {
            if (str.toLowerCase().contains(charSequence.toString().toLowerCase())) {
                arrayList.add(str);
            }
        }
        return arrayList;
    }

    public Filter getFilter() {
        return new Filter() {
            /* class king.james.bible.android.adapter.AutoArrayAdapter.AnonymousClass1 */

            /* access modifiers changed from: protected */
            public FilterResults performFiltering(CharSequence charSequence) {
                FilterResults filterResults = new FilterResults();
                if (charSequence == null) {
                    return filterResults;
                }
                try {
                    List<String> correctFilter = AutoArrayAdapter.this.getCorrectFilter(charSequence);
                    if (correctFilter.isEmpty()) {
                        correctFilter = AutoArrayAdapter.this.getCorrectFilterAp(charSequence);
                    }
                    filterResults.values = correctFilter;
                    filterResults.count = correctFilter.size();
                } catch (Exception unused) {
                }
                return filterResults;
            }

            /* access modifiers changed from: protected */
            public void publishResults(CharSequence charSequence, FilterResults filterResults) {
                if (filterResults != null) {
                    try {
                        if (filterResults.count > 0) {
                            AutoArrayAdapter.this.mResults = (List) filterResults.values;
                            AutoArrayAdapter.this.notifyDataSetChanged();
                            return;
                        }
                    } catch (Exception unused) {
                        return;
                    }
                }
                AutoArrayAdapter.this.notifyDataSetInvalidated();
            }
        };
    }
}
