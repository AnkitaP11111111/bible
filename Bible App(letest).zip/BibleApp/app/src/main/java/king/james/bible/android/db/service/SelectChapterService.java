package king.james.bible.android.db.service;

import java.util.ArrayList;
import java.util.List;
import king.james.bible.android.db.BibleDataBase;
import king.james.bible.android.model.SelectChapter;
import king.james.bible.android.model.chapter.ChapterShortNameAndMode;

public class SelectChapterService {
    private static SelectChapterService instance;
    private List<SelectChapter> selectChapters;

    private SelectChapterService() {
    }

    public static SelectChapterService getInstance() {
        if (instance == null) {
            synchronized (SelectChapterService.class) {
                if (instance == null) {
                    instance = new SelectChapterService();
                }
            }
        }
        return instance;
    }

    public List<SelectChapter> getAllSelectChapter() {
        List<SelectChapter> list = this.selectChapters;
        if (list == null || list.isEmpty()) {
            List<SelectChapter> allSelectChapterFromBD = getAllSelectChapterFromBD();
            this.selectChapters = allSelectChapterFromBD;
            if (allSelectChapterFromBD == null || allSelectChapterFromBD.isEmpty()) {
                return new ArrayList();
            }
            return getAllSelectChapter();
        }
        for (int i = 0; i < this.selectChapters.size(); i++) {
            this.selectChapters.get(i).setSelected(true);
        }
        return new ArrayList(this.selectChapters);
    }

    private List<SelectChapter> getAllSelectChapterFromBD() {
        List<ChapterShortNameAndMode> chaptersList = BibleDataBase.getInstance().getChaptersList();
        if (chaptersList == null || chaptersList.isEmpty()) {
            BibleDataBase.getInstance().initChapterList();
            chaptersList = BibleDataBase.getInstance().getChaptersList();
        }
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < chaptersList.size(); i++) {
            ChapterShortNameAndMode chapterShortNameAndMode = chaptersList.get(i);
            SelectChapter selectChapter = new SelectChapter(Long.valueOf((long) chapterShortNameAndMode.getChapterID()), chapterShortNameAndMode.getLongName());
            selectChapter.setSelected(true);
            selectChapter.setMode(chapterShortNameAndMode.getMode());
            arrayList.add(selectChapter);
        }
        return arrayList;
    }
}
