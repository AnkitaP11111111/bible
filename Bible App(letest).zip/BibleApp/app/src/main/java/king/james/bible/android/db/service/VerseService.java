package king.james.bible.android.db.service;

import android.database.Cursor;
import java.util.ArrayList;
import java.util.List;
import king.james.bible.android.db.BibleDataBase;
import king.james.bible.android.model.Verse;

public class VerseService {
    private BibleDataBase bibleDB = BibleDataBase.getInstance();

    public Verse getVerseById(long j) {
        Cursor verseById = this.bibleDB.getVerseById(j);
        if (verseById == null || verseById.getCount() < 1) {
            return null;
        }
        Verse verse = new Verse();
        try {
            verseById.moveToFirst();
            verse = buildVerse(verseById);
        } catch (Exception unused) {
        } catch (Throwable th) {
            verseById.close();
            throw th;
        }
        verseById.close();
        verse.setChapterName(this.bibleDB.getChapterNameById(verse.getChapterId()));
        return verse;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:14:0x0030, code lost:
        if (r1 != null) goto L_0x0043;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:23:0x0041, code lost:
        if (0 == 0) goto L_0x0046;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x0043, code lost:
        r1.close();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:25:0x0046, code lost:
        return r0;
     */
    public List<Verse> getVerseByChapterIdAndNum(long j, int i) {
        ArrayList arrayList = new ArrayList();
        Cursor cursor = null;
        try {
            cursor = this.bibleDB.getVerseByChapterIdAndNum(j, i);
            if (cursor != null && !cursor.isClosed()) {
                if (cursor.getCount() >= 1) {
                    if (cursor.moveToFirst()) {
                        while (cursor.moveToNext()) {
                            arrayList.add(buildVerse(cursor));
                        }
                    }
                }
            }
            if (cursor != null) {
                cursor.close();
            }
            return arrayList;
        } catch (Exception unused) {
        } catch (Throwable th) {
            if (0 != 0) {
                cursor.close();
            }
            throw th;
        }
        return arrayList;
    }

    private Verse buildVerse(Cursor cursor) throws Exception {
        Verse verse = new Verse();
        verse.setId((long) cursor.getInt(cursor.getColumnIndexOrThrow("_id")));
        verse.setChapterId((long) cursor.getInt(cursor.getColumnIndexOrThrow("chapter_id")));
        verse.setChapterNum(cursor.getInt(cursor.getColumnIndexOrThrow("chapter_num")));
        verse.setPosition(cursor.getInt(cursor.getColumnIndexOrThrow("position")));
        verse.setText(cursor.getString(cursor.getColumnIndexOrThrow("text")));
        verse.setHead(cursor.getInt(cursor.getColumnIndexOrThrow("head")));
        return verse;
    }
}
