package king.james.bible.android.event;

public class ClickAddEvent {
    private int unicId;

    public ClickAddEvent(int i) {
        this.unicId = i;
    }

    public int getUnicId() {
        return this.unicId;
    }
}
