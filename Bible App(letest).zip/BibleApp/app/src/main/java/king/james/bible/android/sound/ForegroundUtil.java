package king.james.bible.android.sound;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.widget.RemoteViews;
import androidx.core.app.NotificationCompat;
import king.james.bible.android.R;
import king.james.bible.android.activity.MainFragmentActivity;
import king.james.bible.android.sound.util.SoundAction;

public class ForegroundUtil {
    public static void startForeground(Service service, boolean z, SoundAction soundAction, String str, int i, int i2) {
        Intent intent = new Intent(service, MainFragmentActivity.class);
        intent.setAction("ACTION.MAIN_ACTION");
        intent.setFlags(603979776);
        intent.putExtra("pagePosition", i);
        intent.putExtra("itemPosition", i2);
        int i3 = Build.VERSION.SDK_INT >= 23 ? 1140850688 : 1073741824;
        PendingIntent activity = PendingIntent.getActivity(service, 100, intent, i3);
        RemoteViews remoteViews = new RemoteViews(service.getPackageName(), (int) R.layout.notification);
        String string = service.getResources().getString(R.string.app_name);
        remoteViews.setTextViewText(R.id.notification_text_title, str);
        remoteViews.setTextViewText(R.id.notification_text_artist, string);
        if (soundAction == SoundAction.PAUSE_ACTION) {
            remoteViews.setViewVisibility(R.id.notification_button_pause, 0);
            remoteViews.setViewVisibility(R.id.notification_button_play, 8);
            Intent intent2 = new Intent(service, SoundBroadcastReceiver.class);
            intent2.putExtra("action", SoundAction.PAUSE_ACTION.name());
            remoteViews.setOnClickPendingIntent(R.id.notification_button_pause, PendingIntent.getBroadcast(service, 101, intent2, i3));
        } else {
            remoteViews.setViewVisibility(R.id.notification_button_pause, 8);
            remoteViews.setViewVisibility(R.id.notification_button_play, 0);
            Intent intent3 = new Intent(service, SoundBroadcastReceiver.class);
            intent3.putExtra("action", SoundAction.PLAY_ACTION.name());
            remoteViews.setOnClickPendingIntent(R.id.notification_button_play, PendingIntent.getBroadcast(service, 102, intent3, i3));
        }
        Intent intent4 = new Intent(service, SoundBroadcastReceiver.class);
        intent4.putExtra("action", SoundAction.NEXT_ACTION.name());
        remoteViews.setOnClickPendingIntent(R.id.notification_button_skip, PendingIntent.getBroadcast(service, 103, intent4, i3));
        Intent intent5 = new Intent(service, SoundBroadcastReceiver.class);
        intent5.putExtra("action", SoundAction.STOP_ACTION.name());
        remoteViews.setOnClickPendingIntent(R.id.notification_button_close, PendingIntent.getBroadcast(service, 104, intent5, i3));
        if (z) {
            remoteViews.setViewVisibility(R.id.notification_button_skip, 8);
            remoteViews.setViewVisibility(R.id.notification_button_play, 8);
            remoteViews.setViewVisibility(R.id.notification_button_pause, 8);
        }
        Bitmap decodeResource = BitmapFactory.decodeResource(service.getResources(), R.drawable.ic_launcher);
        NotificationManager notificationManager = (NotificationManager) service.getSystemService("notification");
        createChanel(notificationManager);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(service, "bible_sound_notification_channel_5");
        builder.setContentTitle(string);
        builder.setTicker(string);
        builder.setContentIntent(activity);
        builder.setContentText(str);
        builder.setSound(null);
        builder.setPriority(-2);
        builder.setSmallIcon(R.drawable.ic_launcher);
        builder.setLargeIcon(Bitmap.createScaledBitmap(decodeResource, 128, 128, false));
        builder.setContent(remoteViews);
        builder.setOngoing(true);
        if (notificationManager != null) {
            if (Build.VERSION.SDK_INT >= 21) {
                builder.setVibrate(new long[0]);
            }
            stopForeground(service);
            try {
                notificationManager.notify(1041, builder.build());
            } catch (Exception unused) {
            }
        }
    }

    private static void createChanel(NotificationManager notificationManager) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel notificationChannel = new NotificationChannel("bible_sound_notification_channel_5", "BibleSound Notifications 5", 2);
            notificationChannel.setDescription("Channel description");
            notificationChannel.setSound(null, null);
            notificationChannel.enableLights(false);
            notificationChannel.setLightColor(-16776961);
            notificationChannel.enableVibration(false);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(notificationChannel);
            }
        }
    }

    public static void stopForeground(Context context) {
        NotificationManager notificationManager = (NotificationManager) context.getSystemService("notification");
        if (notificationManager != null) {
            notificationManager.cancel(1041);
        }
    }
}
