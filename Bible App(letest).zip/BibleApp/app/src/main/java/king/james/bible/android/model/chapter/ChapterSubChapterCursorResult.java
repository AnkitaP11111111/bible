package king.james.bible.android.model.chapter;

public class ChapterSubChapterCursorResult {
    private int chapter;
    private int position = 0;
    private int subChapter;

    public ChapterSubChapterCursorResult(int i, int i2, int i3) {
        this.subChapter = i;
        this.chapter = i2;
        this.position = i3;
    }

    public int getChapter() {
        return this.chapter;
    }

    public int getSubChapter() {
        return this.subChapter;
    }

    public int getPosition() {
        return this.position;
    }
}
