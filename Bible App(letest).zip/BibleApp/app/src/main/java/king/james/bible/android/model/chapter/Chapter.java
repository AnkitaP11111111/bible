package king.james.bible.android.model.chapter;

public class Chapter {
    private long id;
    private String name;

    public Chapter(long j, String str) {
        this.id = j;
        this.name = str;
    }

    public long getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }
}
