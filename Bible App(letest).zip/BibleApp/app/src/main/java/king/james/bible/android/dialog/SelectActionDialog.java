package king.james.bible.android.dialog;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import com.google.gson.GsonBuilder;
import king.james.bible.android.R;
import king.james.bible.android.model.DialogDataBookmark;
import king.james.bible.android.service.PowerManagerService;
import king.james.bible.android.service.observable.SelectActionDialogListenerObservable;
import king.james.bible.android.utils.BiblePreferences;

public class SelectActionDialog extends BaseForegroundDialog implements View.OnClickListener {
    private DialogDataBookmark mDataBookmark;
    private int pagePosition;

    public enum DialogActions {
        bookmark,
        note,
        uline,
        off,
        copy,
        share,
        color_1,
        color_2,
        color_3,
        color_4,
        color_5,
        color_6,
        color_7,
        color_8
    }

    public interface SelectActionDialogListener {
        void onActionSelected(int i, DialogActions dialogActions, DialogDataBookmark dialogDataBookmark);
    }

    /* access modifiers changed from: package-private */
    public void setParameters(int i, DialogDataBookmark dialogDataBookmark) {
        this.pagePosition = i;
        this.mDataBookmark = dialogDataBookmark;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.BaseDialogFragment
    public int getLayoutResourceId() {
        return BiblePreferences.getInstance().isNightMode() ? R.layout.select_action_dialog_n : R.layout.select_action_dialog;
    }

    @Override // androidx.fragment.app.DialogFragment
    public Dialog onCreateDialog(Bundle bundle) {
        if (bundle != null) {
            this.pagePosition = bundle.getInt("pagePosition", 0);
            String string = bundle.getString("data");
            if (string != null && !string.isEmpty()) {
                this.mDataBookmark = (DialogDataBookmark) new GsonBuilder().create().fromJson(string, DialogDataBookmark.class);
            }
        }
        Dialog onCreateDialog = super.onCreateDialog(bundle);
        onCreateDialog.getWindow().requestFeature(1);
        return onCreateDialog;
    }

    @Override // androidx.fragment.app.Fragment, androidx.fragment.app.DialogFragment
    public void onSaveInstanceState(Bundle bundle) {
        bundle.putInt("pagePosition", this.pagePosition);
        bundle.putString("data", new GsonBuilder().create().toJson(this.mDataBookmark));
        super.onSaveInstanceState(bundle);
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.BaseDialogFragment
    public void mapViews(View view) {
        view.findViewById(R.id.action_add_bookmark_btn).setOnClickListener(this);
        view.findViewById(R.id.action_add_note_btn).setOnClickListener(this);
        view.findViewById(R.id.action_color_1_btn).setOnClickListener(this);
        view.findViewById(R.id.action_color_2_btn).setOnClickListener(this);
        view.findViewById(R.id.action_color_3_btn).setOnClickListener(this);
        view.findViewById(R.id.action_color_4_btn).setOnClickListener(this);
        view.findViewById(R.id.action_color_5_btn).setOnClickListener(this);
        view.findViewById(R.id.action_color_6_btn).setOnClickListener(this);
        view.findViewById(R.id.action_color_7_btn).setOnClickListener(this);
        view.findViewById(R.id.action_color_8_btn).setOnClickListener(this);
        view.findViewById(R.id.action_uline_btn).setOnClickListener(this);
        view.findViewById(R.id.action_off_btn).setOnClickListener(this);
        view.findViewById(R.id.action_copy_btn).setOnClickListener(this);
        view.findViewById(R.id.action_share_btn).setOnClickListener(this);
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.BaseDialogFragment
    public void initActions() {
        PowerManagerService.getInstance().start();
    }

    @SuppressLint("NonConstantResourceId")
    public void onClick(View view) {
        DialogActions dialogActions = DialogActions.bookmark;
        int id = view.getId();
        if (id == R.id.action_copy_btn) {
            dialogActions = DialogActions.copy;
        } else if (id != R.id.action_uline_btn) {
            switch (id) {
                case R.id.action_add_bookmark_btn:
                    dialogActions = DialogActions.bookmark;
                    break;
                case R.id.action_add_note_btn:
                    dialogActions = DialogActions.note;
                    break;
                default:
                    switch (id) {
                        case R.id.action_color_1_btn:
                            dialogActions = DialogActions.color_1;
                            break;
                        case R.id.action_color_2_btn:
                            dialogActions = DialogActions.color_2;
                            break;
                        case R.id.action_color_3_btn:
                            dialogActions = DialogActions.color_3;
                            break;
                        case R.id.action_color_4_btn:
                            dialogActions = DialogActions.color_4;
                            break;
                        case R.id.action_color_5_btn:
                            dialogActions = DialogActions.color_5;
                            break;
                        case R.id.action_color_6_btn:
                            dialogActions = DialogActions.color_6;
                            break;
                        case R.id.action_color_7_btn:
                            dialogActions = DialogActions.color_7;
                            break;
                        case R.id.action_color_8_btn:
                            dialogActions = DialogActions.color_8;
                            break;
                        default:
                            switch (id) {
                                case R.id.action_off_btn:
                                    dialogActions = DialogActions.off;
                                    break;
                                case R.id.action_share_btn:
                                    dialogActions = DialogActions.share;
                                    break;
                            }
                    }
            }
        } else {
            dialogActions = DialogActions.uline;
        }
        SelectActionDialogListenerObservable.getInstance().onActionSelected(this.pagePosition, dialogActions, this.mDataBookmark);
        dismiss();
        PowerManagerService.getInstance().start();
    }
}
