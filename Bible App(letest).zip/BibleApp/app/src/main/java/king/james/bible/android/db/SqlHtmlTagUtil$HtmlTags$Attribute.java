package king.james.bible.android.db;

import java.util.ArrayList;
import java.util.List;

public enum SqlHtmlTagUtil$HtmlTags$Attribute {
    color;

    public static List<SqlHtmlTagUtil$HtmlTags$Attribute> getList() {
        ArrayList arrayList = new ArrayList();
        arrayList.add(color);
        return arrayList;
    }
}
