package king.james.bible.android.utils;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import king.james.bible.android.R;
import java.util.HashMap;
import java.util.Map;
import king.james.bible.android.model.SpanType;

public class BitmapSpanUtil {
    private Map<Integer, Bitmap> bitmapCache;
    private Map<String, Bitmap> bitmapFactoryCache;
    private int maxBitmapCache;
    private Resources resources;
    private Map<SpanType, Integer> spanTypeResourcesMap;

    /* access modifiers changed from: private */
    public static class SingletonHelper {
        private static final BitmapSpanUtil INSTANCE = new BitmapSpanUtil();
    }

    private int prepareHeight(int i) {
        if (i <= 0) {
            i = 10;
        }
        return (int) (((float) i) * 1.15f);
    }

    private int prepareWidth(int i) {
        if (i <= 0) {
            return 10;
        }
        return i;
    }

    private BitmapSpanUtil() {
        this.spanTypeResourcesMap = new HashMap();
        this.bitmapCache = new HashMap();
        this.bitmapFactoryCache = new HashMap();
        int i = Build.VERSION.SDK_INT;
        if (i < 19) {
            this.maxBitmapCache = 80;
        } else if (i < 21) {
            this.maxBitmapCache = 250;
        } else if (i >= 21) {
            this.maxBitmapCache = 300;
        } else {
            this.maxBitmapCache = 250;
        }
    }

    public static BitmapSpanUtil getInstance() {
        return SingletonHelper.INSTANCE;
    }

    public void init(Context context) {
        this.resources = context.getResources();
    }

    public void restore() {
        this.bitmapCache = new HashMap();
        this.spanTypeResourcesMap = new HashMap();
        BiblePreferences instance = BiblePreferences.getInstance();
        instance.lambda$restoreAsync$0$BiblePreferences();
        boolean isNightMode = instance.isNightMode();
        int i = isNightMode ? R.drawable.highlight_color_1_n : R.drawable.highlight_color_1;
        int i2 = isNightMode ? R.drawable.highlight_color_2_n : R.drawable.highlight_color_2;
        int i3 = isNightMode ? R.drawable.highlight_color_3_n : R.drawable.highlight_color_3;
        int i4 = isNightMode ? R.drawable.highlight_color_4_n : R.drawable.highlight_color_4;
        int i5 = isNightMode ? R.drawable.highlight_color_5_n : R.drawable.highlight_color_5;
        int i6 = isNightMode ? R.drawable.highlight_color_6_n : R.drawable.highlight_color_6;
        int i7 = isNightMode ? R.drawable.highlight_color_7_n : R.drawable.highlight_color_7;
        int i8 = isNightMode ? R.drawable.highlight_color_8_n : R.drawable.highlight_color_8;
        this.bitmapCache.put(Integer.valueOf(i), BitmapFactory.decodeResource(this.resources, i));
        this.bitmapCache.put(Integer.valueOf(i2), BitmapFactory.decodeResource(this.resources, i2));
        this.bitmapCache.put(Integer.valueOf(i3), BitmapFactory.decodeResource(this.resources, i3));
        this.bitmapCache.put(Integer.valueOf(i4), BitmapFactory.decodeResource(this.resources, i4));
        this.bitmapCache.put(Integer.valueOf(i5), BitmapFactory.decodeResource(this.resources, i5));
        this.bitmapCache.put(Integer.valueOf(i6), BitmapFactory.decodeResource(this.resources, i6));
        this.bitmapCache.put(Integer.valueOf(i7), BitmapFactory.decodeResource(this.resources, i7));
        this.bitmapCache.put(Integer.valueOf(i8), BitmapFactory.decodeResource(this.resources, i8));
        this.spanTypeResourcesMap.put(SpanType.COLOR_1, Integer.valueOf(i));
        this.spanTypeResourcesMap.put(SpanType.COLOR_2, Integer.valueOf(i2));
        this.spanTypeResourcesMap.put(SpanType.COLOR_3, Integer.valueOf(i3));
        this.spanTypeResourcesMap.put(SpanType.COLOR_4, Integer.valueOf(i4));
        this.spanTypeResourcesMap.put(SpanType.COLOR_5, Integer.valueOf(i5));
        this.spanTypeResourcesMap.put(SpanType.COLOR_6, Integer.valueOf(i6));
        this.spanTypeResourcesMap.put(SpanType.COLOR_7, Integer.valueOf(i7));
        this.spanTypeResourcesMap.put(SpanType.COLOR_8, Integer.valueOf(i8));
    }

    public Bitmap getBitmapFromResource(int i, int i2, int i3) {
        if (this.bitmapFactoryCache.size() > this.maxBitmapCache) {
            this.bitmapFactoryCache.clear();
            this.bitmapFactoryCache = new HashMap();
            System.gc();
        }
        int prepareWidth = prepareWidth(i2);
        int prepareHeight = prepareHeight(i3);
        String id = getId(i, prepareWidth, prepareHeight);
        if (this.bitmapFactoryCache.containsKey(id)) {
            return this.bitmapFactoryCache.get(id);
        }
        if (!this.bitmapCache.containsKey(Integer.valueOf(i))) {
            this.bitmapCache.put(Integer.valueOf(i), BitmapFactory.decodeResource(this.resources, i));
        }
        try {
            putBitmap(i, id, prepareWidth, prepareHeight);
        } catch (Exception unused) {
            clearBitmapCache();
            putBitmap(i, id, prepareWidth, prepareHeight);
        }
        return this.bitmapFactoryCache.get(id);
    }

    private void putBitmap(int i, String str, int i2, int i3) {
        Bitmap bitmap = this.bitmapCache.get(Integer.valueOf(i));
        if (bitmap != null) {
            this.bitmapFactoryCache.put(str, Bitmap.createScaledBitmap(bitmap, i2, i3, true));
        }
    }

    private String getId(int i, int i2, int i3) {
        return i + "_" + i2 + "x" + i3;
    }

    public void clearBitmapCache() {
        this.bitmapFactoryCache = new HashMap();
        restore();
    }
}
