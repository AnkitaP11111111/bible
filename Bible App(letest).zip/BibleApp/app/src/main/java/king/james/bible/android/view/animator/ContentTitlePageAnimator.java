package king.james.bible.android.view.animator;

import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.text.Html;
import android.widget.TextView;

public class ContentTitlePageAnimator {
    private ObjectAnimator textColorAnimator;
    private ObjectAnimator textSizeAnimator;

    public ContentTitlePageAnimator(TextView textView) {
        textView.setText(Html.fromHtml("<u>" + textView.getText().toString() + "</u>"));
        ObjectAnimator ofObject = ObjectAnimator.ofObject(textView, "textColor", new ArgbEvaluator(), -10453621, -10453621, -10453621, -10453621, -10453621);
        this.textColorAnimator = ofObject;
        ofObject.setDuration(2800L);
        float f = (float) 29;
        float f2 = (float) 26;
        ObjectAnimator ofFloat = ObjectAnimator.ofFloat(textView, "textSize", (float) 23, f, f2, f, f2);
        this.textSizeAnimator = ofFloat;
        ofFloat.setDuration(2800L);
    }

    public void start() {
        ObjectAnimator objectAnimator = this.textColorAnimator;
        if (objectAnimator != null && this.textSizeAnimator != null) {
            objectAnimator.start();
            this.textSizeAnimator.start();
        }
    }
}
