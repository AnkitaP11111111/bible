package king.james.bible.android.db;

import java.util.ArrayList;
import java.util.List;

public enum SqlHtmlTagUtil$HtmlTags$Tag {
    font,
    em,
    b,
    strong;

    public static List<SqlHtmlTagUtil$HtmlTags$Tag> getList() {
        ArrayList arrayList = new ArrayList();
        arrayList.add(font);
        arrayList.add(em);
        arrayList.add(b);
        arrayList.add(strong);
        return arrayList;
    }
}
