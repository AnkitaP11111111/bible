package king.james.bible.android.sound;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.karumi.dexter.BuildConfig;

public class SoundBroadcastReceiver extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent) {
        if (intent.getExtras() != null && intent.getExtras().size() >= 1) {
            Intent intent2 = new Intent(context, SoundService.class);
            intent2.setAction(intent.getExtras().getString("action", BuildConfig.FLAVOR));
            context.startService(intent2);
        }
    }
}
