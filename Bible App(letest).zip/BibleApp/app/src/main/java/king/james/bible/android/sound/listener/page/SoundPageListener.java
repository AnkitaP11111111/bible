package king.james.bible.android.sound.listener.page;

public interface SoundPageListener {
    void onNextSoundPage(int i, int i2);

    void prepareSoundHeaderPauseBackground(int i);
}
