package king.james.bible.android.adapter.recycler;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import king.james.bible.android.R;
import java.util.List;
import king.james.bible.android.adapter.holder.DailyVerseViewHolder;
import king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter;
import king.james.bible.android.model.DailyVerse;
import king.james.bible.android.model.DailyVerseAction;

public class DailyVerseRecyclerViewAdapter extends BaseRecyclerViewAdapter<DailyVerseViewHolder> {
    private DailyVerseActionListener actionListener;
    private int layout = R.layout.item_daily_verse;
    private List<DailyVerse> models;

    public interface DailyVerseActionListener {
        void onDailyVerseAction(DailyVerse dailyVerse, DailyVerseAction dailyVerseAction, int i);
    }

    public DailyVerseRecyclerViewAdapter(List<DailyVerse> list, OnItemClickListener onItemClickListener, DailyVerseActionListener dailyVerseActionListener) {
        super(onItemClickListener);
        this.models = list;
        this.actionListener = dailyVerseActionListener;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter
    public DailyVerseViewHolder doCreateViewHolder(ViewGroup viewGroup, int i) {
        return new DailyVerseViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(this.layout, viewGroup, false));
    }

    public void onBindViewHolder(DailyVerseViewHolder dailyVerseViewHolder, int i) {
        super.onBindViewHolder( dailyVerseViewHolder, i);
        dailyVerseViewHolder.setActionListener(this.actionListener);
    }

    @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter
    public Object getModel(int i) {
        return this.models.get(i);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.models.size();
    }
}
