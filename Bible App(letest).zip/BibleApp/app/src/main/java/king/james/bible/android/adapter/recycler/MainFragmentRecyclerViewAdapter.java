package king.james.bible.android.adapter.recycler;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.app.AppCompatActivity;
import king.james.bible.android.R;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import king.james.bible.android.adapter.holder.MainFragmentViewHolder;
import king.james.bible.android.adapter.holder.MainHeaderViewHolder;
import king.james.bible.android.adapter.holder.TextViewHolder;
import king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter;
import king.james.bible.android.db.listener.UpdateViewHolderListener;
import king.james.bible.android.dialog.DialogUtil;
import king.james.bible.android.model.SpanType;
import king.james.bible.android.model.Text;
import king.james.bible.android.sound.SoundHelper;
import king.james.bible.android.sound.holder.SoundButtonHolder;
import king.james.bible.android.sound.listener.page.SoundInitListener;
import king.james.bible.android.sound.listener.page.SoundPlayListener;
import king.james.bible.android.sound.listener.page.SoundVerseListener;
import king.james.bible.android.utils.BiblePreferences;
import king.james.bible.android.view.MarkerTextView;
@SuppressLint({"NewApi", "WrongConstant"})

public class MainFragmentRecyclerViewAdapter extends BaseRecyclerViewAdapter<MainFragmentViewHolder> implements SoundVerseListener, SoundInitListener {
    private  int r2;
    private Context context;
    private boolean loadHeader;
    private MainHeaderViewHolder mainHeaderViewHolder;
    private Integer menuItem = null;
    private View.OnClickListener menuListener;
    private List<Text> models;
    private MarkerTextView.OnSelectionListener onSelectionListener;
    private int pagePosition;
    private TreeSet<Integer> selectedSet;
    private Map<Integer, SoundButtonHolder> soundButtonHolders;
    private SoundPlayListener soundPlayListener;
    private int startPosition = 0;
    private int unicId;
    private UpdateViewHolderListener updateViewHolderListener;

    public MainFragmentRecyclerViewAdapter(Context context2, int i, int i2, OnItemClickListener onItemClickListener, View.OnClickListener onClickListener, UpdateViewHolderListener updateViewHolderListener2, MarkerTextView.OnSelectionListener onSelectionListener2) {
        super(onItemClickListener);
        this.pagePosition = i;
        this.selectedSet = new TreeSet<>();
        this.context = context2;
        this.soundButtonHolders = new HashMap();
        this.loadHeader = false;
        this.menuListener = onClickListener;
        this.updateViewHolderListener = updateViewHolderListener2;
        this.onSelectionListener = onSelectionListener2;
        this.unicId = i2;
        SoundHelper.getInstance().addSoundVerseListener(i, this);
    }

    public void setSoundPlayListener(SoundPlayListener soundPlayListener2) {
        this.soundPlayListener = soundPlayListener2;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemViewType(int i) {
        if (i == 0) {
            return getHeaderType();
        }
        return getItemType();
    }

    private int getHeaderType() {
        return BiblePreferences.getInstance().isNightMode() ? R.layout.header_text_item_layout_n : R.layout.header_text_item_layout;
    }

    private int getItemType() {
        return BiblePreferences.getInstance().isNightMode() ? R.layout.text_item_layout_n : R.layout.text_item_layout;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter
    public MainFragmentViewHolder doCreateViewHolder(ViewGroup viewGroup, int i) {
        if (i == getHeaderType()) {
            return doCreateHeader(viewGroup, i);
        }
        return new TextViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(i, viewGroup, false), this.menuListener, this.pagePosition, this.onSelectionListener);
    }

    private MainHeaderViewHolder doCreateHeader(ViewGroup viewGroup, int i) {
        if (this.mainHeaderViewHolder == null) {
            MainHeaderViewHolder mainHeaderViewHolder2 = new MainHeaderViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(i, viewGroup, false), this.updateViewHolderListener, this.onSelectionListener);
            this.mainHeaderViewHolder = mainHeaderViewHolder2;
            mainHeaderViewHolder2.setPagePosition(this.pagePosition);
            this.mainHeaderViewHolder.setTag(true);
            this.mainHeaderViewHolder.setUnicId(this.unicId);
        }
        return this.mainHeaderViewHolder;
    }

    public void onBindViewHolder(MainFragmentViewHolder mainFragmentViewHolder, int i) {
        super.onBindViewHolder( mainFragmentViewHolder, i);
        if (mainFragmentViewHolder instanceof TextViewHolder) {
            SoundButtonHolder updateView = ((TextViewHolder) mainFragmentViewHolder).updateView(this.menuItem, this.selectedSet, i, this);
            updateView.setSoundPlayListener(this.soundPlayListener);
            this.soundButtonHolders.put(Integer.valueOf(getModel(i).getRank()), updateView);
        }
        if (mainFragmentViewHolder instanceof MainHeaderViewHolder) {
            this.mainHeaderViewHolder.itemView.postDelayed(new Runnable() {
                /* class king.james.bible.android.adapter.recycler.$$Lambda$MainFragmentRecyclerViewAdapter$3csCNnMMSdCdnqU95uh3ZVccY4 */

                public final void run() {
                    MainFragmentRecyclerViewAdapter.this.lambda$onBindViewHolder$0$MainFragmentRecyclerViewAdapter();
                }
            }, 250);
        }
    }

    public /* synthetic */ void lambda$onBindViewHolder$0$MainFragmentRecyclerViewAdapter() {
        try {
            notifyItemChanged(0);
        } catch (Exception unused) {
        }
    }

    public MainHeaderViewHolder getHeaderHolder() {
        return this.mainHeaderViewHolder;
    }

    public int getAdapterPosition(int i) {
        List<Text> list = this.models;
        if (list != null && !list.isEmpty() && this.loadHeader) {
            for (int i2 = 0; i2 < this.models.size(); i2++) {
                if (this.models.get(i2).getRank() == i) {
                    return (i2 - this.startPosition) + 1;
                }
            }
        }
        return 1;
    }

    public void setModels(List<Text> list) {
        List<Text> list2 = this.models;
        if (list2 != null) {
            list2.clear();
        }
        this.models = list;
    }

    @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter
    public Text getModel(int i) {
        List<Text> list;
        int i2 = 0;
        if (i == 0 || (list = this.models) == null || !this.loadHeader || (i + this.startPosition) - 1 < 0 || i2 >= list.size() || this.models.isEmpty()) {
            return null;
        }
        return this.models.get(i2);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        if (!this.loadHeader) {
            return 1;
        }
        return (this.models.size() - this.startPosition) + 1;
    }

    public void setStartPosition(int i) {
        if (this.models == null) {
            this.models = new ArrayList();
        }
        int i2 = 0;
        int i3 = 0;
        while (true) {
            if (i3 >= this.models.size()) {
                break;
            } else if (this.models.get(i3).getRank() == i) {
                i2 = i3 + 1;
                break;
            } else {
                i3++;
            }
        }
        this.startPosition = i2;
        this.loadHeader = true;
    }

    public void clearSubscription() {
        SoundHelper.getInstance().clearSoundVerseListener(this.pagePosition);
    }

    public TreeSet<Integer> getSelectedSet() {
        if (this.selectedSet == null) {
            this.selectedSet = new TreeSet<>();
        }
        return this.selectedSet;
    }

    public void clear() {
        this.menuListener = null;
        this.context = null;
        Map<Integer, SoundButtonHolder> map = this.soundButtonHolders;
        if (map != null) {
            for (Map.Entry<Integer, SoundButtonHolder> entry : map.entrySet()) {
                entry.getValue().clearBitmap();
            }
            this.soundButtonHolders.clear();
        }
        this.soundButtonHolders = null;
    }

    public Integer getMenuItem() {
        Integer num = this.menuItem;
        if (num == null) {
            return -1;
        }
        return num;
    }

    public void setMenuItem(Integer num) {
        this.menuItem = num;
    }

    public void onNextVerse(int i, int i2) {
        ((Activity) this.context).runOnUiThread(new Runnable() {
            /* class king.james.bible.android.adapter.recycler.$$Lambda$MainFragmentRecyclerViewAdapter$EyB0jtdRQGgMWHdsrtkI4GUc_Y */
            private final /* synthetic */ int f$1;

            {
                this.f$1 = r2;
            }

            public final void run() {
                MainFragmentRecyclerViewAdapter.this.lambda$onNextVerse$1$MainFragmentRecyclerViewAdapter(this.f$1);
            }
        });
    }

    public /* synthetic */ void lambda$onNextVerse$1$MainFragmentRecyclerViewAdapter(int i) {
        if (this.soundButtonHolders.containsKey(Integer.valueOf(i))) {
            TreeSet<Integer> treeSet = new TreeSet<>();
            this.selectedSet = treeSet;
            treeSet.add(Integer.valueOf(i));
            Map<Integer, SoundButtonHolder> map = this.soundButtonHolders;
            if (map != null) {
                int i2 = i - 1;
                if (map.containsKey(Integer.valueOf(i2))) {
                    this.soundButtonHolders.get(Integer.valueOf(i2)).hideButton();
                }
            }
            setMenuItem(Integer.valueOf(i));
            notifyDataSetChanged();
            Map<Integer, SoundButtonHolder> map2 = this.soundButtonHolders;
            if (map2 != null && map2.get(Integer.valueOf(i)) != null) {
                this.soundButtonHolders.get(Integer.valueOf(i)).preparePlayBackground();
            }
        }
    }

    @Override // king.james.bible.android.sound.listener.page.SoundVerseListener
    public void onPauseSound(int i) {
        if (this.soundButtonHolders == null) {
            this.soundButtonHolders = new HashMap();
        }
        Context context2 = this.context;
        if (context2 != null) {
            ((Activity) context2).runOnUiThread(new Runnable() {
                /* class king.james.bible.android.adapter.recycler.$$Lambda$MainFragmentRecyclerViewAdapter$dJUQ93xtzvGBKMXvL7Se_BIZ8uA */
                private final /* synthetic */ int f$1;

                {
                    this.f$1 = r2;
                }

                public final void run() {
                    MainFragmentRecyclerViewAdapter.this.lambda$onPauseSound$3$MainFragmentRecyclerViewAdapter(this.f$1);
                }
            });
        }
    }

    public /* synthetic */ void lambda$onPauseSound$3$MainFragmentRecyclerViewAdapter(int i) {
        SoundButtonHolder soundButtonHolder;
        Map<Integer, SoundButtonHolder> map = this.soundButtonHolders;
        if (map != null && !map.isEmpty() && (soundButtonHolder = this.soundButtonHolders.get(Integer.valueOf(i))) != null && soundButtonHolder.getSoundButton() != null) {
            soundButtonHolder.getSoundButton().postDelayed(new Runnable() {
                /* class king.james.bible.android.adapter.recycler.$$Lambda$MainFragmentRecyclerViewAdapter$Q1BKhahofcwIbBO0I0vOD3SaY */
                private final /* synthetic */ int f$1;

                {
                    this.f$1 = r2;
                }

                public final void run() {
                    MainFragmentRecyclerViewAdapter.this.lambda$null$2$MainFragmentRecyclerViewAdapter(this.f$1);
                }
            }, 300);
        }
    }

    public /* synthetic */ void lambda$null$2$MainFragmentRecyclerViewAdapter(int i) {
        try {
            SoundButtonHolder soundButtonHolder = this.soundButtonHolders.get(Integer.valueOf(i));
            if (soundButtonHolder != null) {
                soundButtonHolder.preparePauseBackground();
                soundButtonHolder.prepareRepeatPauseBackground();
            }
        } catch (Exception unused) {
        }
    }

    @Override // king.james.bible.android.sound.listener.page.SoundVerseListener
    public void onPlayError(String str) {
        try {
            ((AppCompatActivity) this.context).runOnUiThread(new Runnable() {
                /* class king.james.bible.android.adapter.recycler.$$Lambda$MainFragmentRecyclerViewAdapter$KJKAzcMxvXOm3dkdIVaDvjbVQqA */

                public final void run() {
                    MainFragmentRecyclerViewAdapter.this.lambda$onPlayError$5$MainFragmentRecyclerViewAdapter();
                }
            });
        } catch (Exception unused) {
        }
    }

    public /* synthetic */ void lambda$onPlayError$5$MainFragmentRecyclerViewAdapter() {
        try {
            DialogUtil.showSoundPlayErrorDialog(((AppCompatActivity) this.context).getSupportFragmentManager());
        } catch (Exception unused) {
        }
    }

    @Override // king.james.bible.android.sound.listener.page.SoundInitListener
    public void startInitService(int i) {
        Context context2 = this.context;
        if (context2 != null) {
            ((Activity) context2).runOnUiThread(new Runnable() {
                /* class king.james.bible.android.adapter.recycler.$$Lambda$MainFragmentRecyclerViewAdapter$vDog7OvUHUe6Uv7OSz062VIA8R4 */
                private final /* synthetic */ int f$1;

                {
                    this.f$1 = r2;
                }

                public final void run() {
                    MainFragmentRecyclerViewAdapter.this.lambda$startInitService$7$MainFragmentRecyclerViewAdapter(this.f$1);
                }
            });
        }
    }

    public /* synthetic */ void lambda$startInitService$7$MainFragmentRecyclerViewAdapter(int i) {
        SoundButtonHolder soundButtonHolder;
        Map<Integer, SoundButtonHolder> map = this.soundButtonHolders;
        if (map != null && (soundButtonHolder = map.get(Integer.valueOf(i))) != null && soundButtonHolder.getSoundButton() != null) {
            soundButtonHolder.getSoundButton().postDelayed(new Runnable() {
                /* class king.james.bible.android.adapter.recycler.$$Lambda$MainFragmentRecyclerViewAdapter$APVRm6iKhQ1UbiZqMl0MiICI1LU */
                private final /* synthetic */ int f$1;

                {
                    this.f$1 = r2;
                }

                public final void run() {
                    MainFragmentRecyclerViewAdapter.this.lambda$null$6$MainFragmentRecyclerViewAdapter(this.f$1);
                }
            }, 300);
        }
    }

    public /* synthetic */ void lambda$null$6$MainFragmentRecyclerViewAdapter(int i) {
        try {
            SoundButtonHolder soundButtonHolder = this.soundButtonHolders.get(Integer.valueOf(i));
            if (soundButtonHolder != null) {
                soundButtonHolder.showProgress();
            }
        } catch (Exception unused) {
        }
    }

    @Override // king.james.bible.android.sound.listener.page.SoundInitListener
    public void completeInitService(int i) {
        Context context2 = this.context;
        if (context2 != null) {
            ((Activity) context2).runOnUiThread(new Runnable() {
                /* class king.james.bible.android.adapter.recycler.$$Lambda$MainFragmentRecyclerViewAdapter$uBb5spMy__ctLHQIBexmpvvNuk */
                private final /* synthetic */ int f$1;

                {
                    this.f$1 = r2;
                }

                public final void run() {
                    MainFragmentRecyclerViewAdapter.this.lambda$completeInitService$9$MainFragmentRecyclerViewAdapter(this.f$1);
                }
            });
        }
    }

    public /* synthetic */ void lambda$completeInitService$9$MainFragmentRecyclerViewAdapter(int i) {
        Map<Integer, SoundButtonHolder> map;
        SoundButtonHolder soundButtonHolder;
        if (this.context != null && (map = this.soundButtonHolders) != null && (soundButtonHolder = map.get(Integer.valueOf(i))) != null && soundButtonHolder.getSoundButton() != null) {
            soundButtonHolder.getSoundButton().postDelayed(new Runnable() {
                /* class king.james.bible.android.adapter.recycler.$$Lambda$MainFragmentRecyclerViewAdapter$8Fr7tKHy2gAOymRxlNuTLnEps0 */
                private final /* synthetic */ int f$1;

                {
                    this.f$1 = r2;
                }

                public final void run() {
                    MainFragmentRecyclerViewAdapter.this.lambda$null$8$MainFragmentRecyclerViewAdapter(this.f$1);
                }
            }, 300);
        }
    }

    public /* synthetic */ void lambda$null$8$MainFragmentRecyclerViewAdapter(int i) {
        try {
            SoundButtonHolder soundButtonHolder = this.soundButtonHolders.get(Integer.valueOf(i));
            if (soundButtonHolder != null) {
                soundButtonHolder.hideProgress();
            }
        } catch (Exception unused) {
        }
    }

    private Text getModelByRank(int i) {
        List<Text> list = this.models;
        if (list != null && !list.isEmpty()) {
            for (Text text : this.models) {
                if (text.getRank() == i) {
                    return text;
                }
            }
        }
        return null;
    }

    private Text getModelById(long j) {
        List<Text> list = this.models;
        if (list != null && !list.isEmpty()) {
            for (Text text : this.models) {
                if (text.getId() == j) {
                    return text;
                }
            }
        }
        return null;
    }

    public void addColor(int i, SpanType spanType) {
        Text modelByRank = getModelByRank(i);
        if (modelByRank != null) {
            modelByRank.setHighlight(spanType);
        }
    }

    public void clearColor(int i) {
        Text modelByRank = getModelByRank(i);
        if (modelByRank != null) {
            modelByRank.setHighlight(SpanType.EMPTY_TYPE);
        }
    }

    public void changeBookmark(int i) {
        Text modelByRank = getModelByRank(i);
        if (modelByRank != null) {
            modelByRank.setBookmark(i);
        }
    }

    public void setNote(int i, String str) {
        Text modelByRank = getModelByRank(i);
        if (modelByRank != null) {
            modelByRank.setNote(str);
        }
    }

    public void removeNote(long j) {
        Text modelById = getModelById(j);
        if (modelById != null) {
            modelById.setNote(null);
        }
    }
}
