package king.james.bible.android.utils;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import king.james.bible.android.R;

public class BibleToast {
    public static void showLongDurationToast(Context context, String str) {
        show(context, str, 1);
    }

    public static void showShortDurationToast(Context context, int i) {
        show(context, context.getString(i), 0);
    }

    public static void showLongDurationToast(Context context, int i) {
        show(context, context.getString(i), 1);
    }

    private static void show(Context context, String str, int i) {
        int i2;
        int i3;
        BiblePreferences instance = BiblePreferences.getInstance();
        instance.lambda$restoreAsync$0$BiblePreferences();
        try {
            View inflate = LayoutInflater.from(context).inflate(R.layout.fragment_toast, (ViewGroup) null);
            RelativeLayout relativeLayout = (RelativeLayout) inflate.findViewById(R.id.rootRelativeLayout);
            TextView textView = (TextView) inflate.findViewById(R.id.textTextView);
            if (instance.isNightMode()) {
                i3 = R.drawable.background_toast_night;
                i2 = R.color.menu_text_color_n;
            } else {
                i3 = R.drawable.background_toast_day;
                i2 = R.color.white;
            }
            relativeLayout.setBackgroundResource(i3);
            textView.setTextColor(context.getResources().getColor(i2));
            textView.setText(str);
            Toast toast = new Toast(context);
            toast.setGravity(80, 0, 0);
            toast.setDuration(i);
            toast.setView(inflate);
            toast.show();
        } catch (Exception unused) {
        }
    }
}
