package king.james.bible.android.sound.listener.page;

import java.util.Set;

public interface SoundPlayListener {
    Set<Integer> getSelectedSoundRepeatSet();

    void onSoundPlay(int i);
}
