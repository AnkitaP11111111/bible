package king.james.bible.android.model.comparator;

import java.util.Comparator;
import king.james.bible.android.model.SearchText;

public class SearchHistoryComparator implements Comparator<SearchText> {
    public int compare(SearchText searchText, SearchText searchText2) {
        long time = searchText.getTime();
        long time2 = searchText2.getTime();
        if (time == time2) {
            return 0;
        }
        return time > time2 ? -1 : 1;
    }
}
