package king.james.bible.android.adapter.array;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import java.util.List;

public abstract class AdjustableModelAdapter<T> extends ArrayAdapter<T> {
    protected int layoutResId;

    /* access modifiers changed from: protected */
    public abstract void onBindView(View view, int i);

    public AdjustableModelAdapter(Context context, List<T> list, int i) {
        super(context, i, list);
        this.layoutResId = i;
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = onCreateView(i);
        }
        onBindView(view, i);
        return view;
    }

    /* access modifiers changed from: protected */
    public View onCreateView(int i) {
        return View.inflate(getContext(), this.layoutResId, null);
    }
}
