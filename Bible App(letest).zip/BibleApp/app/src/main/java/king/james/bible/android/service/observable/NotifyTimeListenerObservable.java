package king.james.bible.android.service.observable;

import java.util.HashSet;
import java.util.Set;
import king.james.bible.android.dialog.NotifyDialog;

public class NotifyTimeListenerObservable implements NotifyDialog.NotifyTimeListener {
    private static NotifyTimeListenerObservable instance;
    private Set<NotifyDialog.NotifyTimeListener> listeners;

    private NotifyTimeListenerObservable() {
    }

    public static NotifyTimeListenerObservable getInstance() {
        if (instance == null) {
            synchronized (NotifyTimeListenerObservable.class) {
                if (instance == null) {
                    instance = new NotifyTimeListenerObservable();
                }
            }
        }
        return instance;
    }

    public void subscribe(NotifyDialog.NotifyTimeListener notifyTimeListener) {
        checkList();
        this.listeners.add(notifyTimeListener);
    }

    public void remove(NotifyDialog.NotifyTimeListener notifyTimeListener) {
        checkList();
        this.listeners.remove(notifyTimeListener);
    }

    private void checkList() {
        if (this.listeners == null) {
            this.listeners = new HashSet();
        }
    }

    @Override // king.james.bible.android.dialog.NotifyDialog.NotifyTimeListener
    public void selectNotifyTime(long j, boolean z, long j2) {
        checkList();
        for (NotifyDialog.NotifyTimeListener notifyTimeListener : this.listeners) {
            if (notifyTimeListener != null) {
                notifyTimeListener.selectNotifyTime(j, z, j2);
            }
        }
    }

    @Override // king.james.bible.android.dialog.NotifyDialog.NotifyTimeListener
    public void cancelNotifyDialog() {
        checkList();
        for (NotifyDialog.NotifyTimeListener notifyTimeListener : this.listeners) {
            if (notifyTimeListener != null) {
                notifyTimeListener.cancelNotifyDialog();
            }
        }
    }
}
