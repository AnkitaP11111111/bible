package king.james.bible.android.model;

public enum PlanModeColor {
    RED,
    GREEN,
    YELLOW
}
