package king.james.bible.android.view.holder;

import android.annotation.SuppressLint;
import android.view.View;
import king.james.bible.android.R;

public class PagesSwipeHintHolder {
    private  View.OnClickListener r2;
    private HideHintListener hideHintListener;
    private View viewParent;

    public interface HideHintListener {
        void onHide();
    }

    public PagesSwipeHintHolder(View view, HideHintListener hideHintListener2) {
        this.viewParent = view;
        this.hideHintListener = hideHintListener2;
         r2 = new View.OnClickListener() {
            /* class king.james.bible.android.view.holder.PagesSwipeHintHolder.AnonymousClass1 */

            public void onClick(View view) {
                PagesSwipeHintHolder.this.hide();
            }
        };
        this.viewParent.findViewById(R.id.bgContainer).setOnClickListener(r2);
        this.viewParent.findViewById(R.id.closeView).setOnClickListener(r2);
    }

    @SuppressLint("WrongConstant")
    public void show() {
        View view = this.viewParent;
        if (view != null) {
            view.setVisibility(0);
            this.viewParent.postDelayed(new Runnable() {
                /* class king.james.bible.android.view.holder.PagesSwipeHintHolder.AnonymousClass2 */

                public void run() {
                    PagesSwipeHintHolder.this.hide();
                }
            }, 9000);
        }
    }

    @SuppressLint("WrongConstant")
    public void hide() {
        View view = this.viewParent;
        if (view != null) {
            view.setVisibility(8);
            HideHintListener hideHintListener2 = this.hideHintListener;
            if (hideHintListener2 != null) {
                hideHintListener2.onHide();
            }
        }
    }
}
