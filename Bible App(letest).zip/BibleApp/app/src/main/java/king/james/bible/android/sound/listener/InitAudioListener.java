package king.james.bible.android.sound.listener;

public interface InitAudioListener {
    void completeInitAudio();
}
