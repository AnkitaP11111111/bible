package king.james.bible.android.model.comparator;

import java.util.Comparator;
import king.james.bible.android.model.Plan;

public class PlanComparator implements Comparator<Plan> {
    public int compare(Plan plan, Plan plan2) {
        if (plan.isStarted() && plan2.isStarted()) {
            return Long.valueOf(plan2.getStartDate()).compareTo(Long.valueOf(plan.getStartDate()));
        }
        if (plan.isStarted() && !plan2.isStarted()) {
            return -1;
        }
        if (plan.isStarted() || !plan2.isStarted()) {
            return Integer.valueOf(plan.getOrder()).compareTo(Integer.valueOf(plan2.getOrder()));
        }
        return 1;
    }
}
