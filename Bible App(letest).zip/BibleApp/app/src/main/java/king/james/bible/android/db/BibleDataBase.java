package king.james.bible.android.db;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.text.Html;
import android.text.TextUtils;
import com.karumi.dexter.BuildConfig;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import king.james.bible.android.MyApplication;
import king.james.bible.android.activity.base.BaseActivity;
import king.james.bible.android.db.listener.AddHighLightListener;
import king.james.bible.android.db.listener.AddRemoveNoteListener;
import king.james.bible.android.db.listener.ChangeBookmarkListener;
import king.james.bible.android.db.listener.RemoveHighLightListener;
import king.james.bible.android.event.ShowBackupHint;
import king.james.bible.android.exception.CopyDBException;
import king.james.bible.android.model.DialogDataBookmark;
import king.james.bible.android.model.Note;
import king.james.bible.android.model.ShareDBModel;
import king.james.bible.android.model.SpanType;
import king.james.bible.android.model.Text;
import king.james.bible.android.model.UpdateRecord;
import king.james.bible.android.model.chapter.Chapter;
import king.james.bible.android.model.chapter.ChapterShortNameAndMode;
import king.james.bible.android.model.chapter.ChapterSubChapter;
import king.james.bible.android.model.chapter.ChapterSubChapterCursorResult;
import king.james.bible.android.model.chapter.ChapterSubChapterPosition;
import king.james.bible.android.model.chapter.ChapterSubChapterResult;
import king.james.bible.android.model.comparator.ChapterComparator;
import king.james.bible.android.model.span.SpanItem;
import king.james.bible.android.sound.model.SoundModel;
import king.james.bible.android.utils.BiblePreferences;
import king.james.bible.android.utils.DateUtil;
import org.greenrobot.eventbus.EventBus;
@SuppressLint("Range")
public class BibleDataBase {
    private static BibleDataBase instance;
    private AddRemoveNoteListener r422;
    private  AddRemoveNoteListener r522;
    private  int r22;
    private  AddRemoveNoteListener r61;
    private  RemoveHighLightListener r42;
    private  RemoveHighLightListener r52;
    private  AddHighLightListener r6;
    private  SpanType r51;
    private  int r41;
    private  DialogDataBookmark r21;
    private long r2;
    private int r3;
    private ChangeBookmarkListener r4;
    private ChangeBookmarkListener r5;
    private String columName = null;
    private String columTitle = null;
    private HashMap<Long, ChapterSubChapterCursorResult> listAllStuffId = new HashMap<>();
    private ArrayList<String> listChapter = new ArrayList<>();
    private HashMap<Integer, ChapterSubChapterResult> listChapterByPosition = new HashMap<>();
    private HashMap<String, Integer> listChapterIdName = new HashMap<>();
    private ArrayList<String> listChapterN = new ArrayList<>();
    private HashMap<Long, String> listChapterNameId = new HashMap<>();
    private HashMap<ChapterSubChapter, Integer> listPositionChapter = new HashMap<>();
    private HashMap<ChapterSubChapterPosition, Integer> listRankChapter = new HashMap<>();
    private List<ChapterShortNameAndMode> listShortName = new ArrayList();
    private HashMap<ChapterSubChapter, Integer> listSubChapters = new HashMap<>();
    private SQLiteDatabase mDb;
    private BibleDataBaseHelper mDbHelper = new BibleDataBaseHelper();
    private Map<Integer, String> mNameMap = new HashMap();
    private Map<Integer, String> mNameMapN = new HashMap();
    private int pagesCount = 0;
    private Object r1;

    private BibleDataBase() {
    }

    public static BibleDataBase getInstance() {
        if (instance == null) {
            synchronized (BibleDataBase.class) {
                if (instance == null) {
                    instance = new BibleDataBase();
                }
            }
        }
        return instance;
    }

    static int getDbVersion(SQLiteDatabase sQLiteDatabase) {
        Cursor cursor = null;
        int i = 0;
        try {
            cursor = sQLiteDatabase.rawQuery("SELECT * FROM version", null);
            if (cursor != null && !cursor.isClosed() && cursor.moveToFirst()) {
                i = cursor.getInt(cursor.getColumnIndexOrThrow("code"));
            }
        } catch (Exception unused) {
        }
        if (cursor != null && !cursor.isClosed()) {
            cursor.close();
        }
        return i;
    }

    public static String[] getNormalizeWords(String[] strArr) {
        String[] strArr2 = new String[strArr.length];
        for (int i = 0; i < strArr.length; i++) {
            strArr2[i] = getNormalizeWord(strArr[i]);
        }
        return strArr2;
    }

    public static String getNormalizeWord(String str) {
        return Normalizer.normalize(str, Normalizer.Form.NFD).replaceAll("[^\\p{ASCII}]", BuildConfig.FLAVOR);
    }

    public static String[] getWords(String str, boolean z) {
        if (!z) {
            return str.split(" ");
        }
        return new String[]{str};
    }

    public static boolean checkSearchText(String str) {
        if (str.length() == 1) {
            return !str.equals("<") && !str.equals(">");
        }
        return true;
    }

    private boolean isNColum() {
        return this.columName.equals("ntext");
    }

    public void setNewPatch() throws CopyDBException {
        this.mDbHelper.setNewPatch();
    }

    public boolean isOpen() {
        SQLiteDatabase sQLiteDatabase = this.mDb;
        return sQLiteDatabase != null && sQLiteDatabase.isOpen();
    }

    /* access modifiers changed from: package-private */
    public void clearDbLink() {
        this.mDb = null;
    }

    public BibleDataBase open() throws SQLException {
        openForMigration();
        return this;
    }

    public BibleDataBase openForMigration() throws SQLException {
        if (isOpen()) {
            return this;
        }
        this.mDbHelper.openDataBase();
        this.mDb = this.mDbHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        this.mDbHelper.close();
    }

    private SQLiteDatabase getDb() {
        SQLiteDatabase sQLiteDatabase = this.mDb;
        if (sQLiteDatabase == null || !sQLiteDatabase.isOpen()) {
            this.mDbHelper.openDataBase();
            this.mDb = this.mDbHelper.getWritableDatabase();
        }
        return this.mDb;
    }

    /* access modifiers changed from: package-private */
    public int getDbVersion() {
        try {
            Cursor rawQuery = getDb().rawQuery("SELECT * FROM version", null);
            if (rawQuery == null || rawQuery.isClosed() || !rawQuery.moveToFirst()) {
                return 49;
            }
            return rawQuery.getInt(rawQuery.getColumnIndexOrThrow("code"));
        } catch (Exception unused) {
            return 49;
        }
    }

    public Cursor getChapterTextStart(int i, int i2) {
        try {
            return getDb().rawQuery("SELECT * FROM texts WHERE chapter_num = ? AND chapter_id = ? AND rank > ? ORDER BY rank", new String[]{Integer.toString(i), Integer.toString(i2), Integer.toString(0)});
        } catch (Exception unused) {
            return null;
        }
    }

    private Cursor getChaptersListCursor() {
        try {
            return getDb().rawQuery("SELECT * FROM chapters", null);
        } catch (Exception unused) {
            return null;
        }
    }

    public ChapterShortNameAndMode getChapterFromCache(long j) {
        for (int i = 0; i < this.listShortName.size(); i++) {
            if (this.listShortName.get(i) != null && j == ((long) this.listShortName.get(i).getChapterID())) {
                return this.listShortName.get(i);
            }
        }
        return null;
    }

    public void initChapterList() {
        Cursor chaptersListCursor;
        if (this.listChapter.isEmpty() && this.listChapterN.isEmpty() && this.listShortName.isEmpty() && (chaptersListCursor = getChaptersListCursor()) != null) {
            if (chaptersListCursor.isClosed() || !chaptersListCursor.moveToFirst()) {
                chaptersListCursor.close();
                return;
            }
            HashSet hashSet = new HashSet();
            ArrayList arrayList = new ArrayList();
            ArrayList<Chapter> arrayList2 = new ArrayList();
            do {
                try {
                    int i = chaptersListCursor.getInt(chaptersListCursor.getColumnIndexOrThrow("_id"));
                    if (!hashSet.contains(Integer.valueOf(i))) {
                        long j = (long) i;
                        arrayList.add(new Chapter(j, chaptersListCursor.getString(chaptersListCursor.getColumnIndexOrThrow("title"))));
                        arrayList2.add(new Chapter(j, chaptersListCursor.getString(chaptersListCursor.getColumnIndexOrThrow(getTileName()))));
                        String string = chaptersListCursor.getString(chaptersListCursor.getColumnIndexOrThrow("short_title"));
                        if (string == null) {
                            string = BuildConfig.FLAVOR;
                        }
                        String string2 = chaptersListCursor.getString(chaptersListCursor.getColumnIndexOrThrow("title"));
                        int i2 = chaptersListCursor.getInt(chaptersListCursor.getColumnIndexOrThrow("mode"));
                        int i3 = chaptersListCursor.getInt(chaptersListCursor.getColumnIndexOrThrow("num"));
                        ChapterShortNameAndMode chapterShortNameAndMode = new ChapterShortNameAndMode(string, string2, i2, i);
                        chapterShortNameAndMode.setNum(i3);
                        this.listShortName.add(chapterShortNameAndMode);
                        hashSet.add(Integer.valueOf(i));
                    }
                } catch (Exception unused) {
                }
            } while (chaptersListCursor.moveToNext());
            chaptersListCursor.close();
            Collections.sort(arrayList, new ChapterComparator());
            this.listChapter = new ArrayList<>();
            for (int i4 = 0; i4 < arrayList.size(); i4++) {
                try {
                    this.listChapter.add(((Chapter) arrayList.get(i4)).getName());
                } catch (Exception unused2) {
                }
            }
            Collections.sort(arrayList2, new ChapterComparator());
            this.listChapterN = new ArrayList<>();
            for (Chapter chapter : arrayList2) {
                this.listChapterN.add(chapter.getName());
            }
        }
    }

    public List<String> getValues() {
        return this.listChapter;
    }

    public List<String> getValuesN() {
        return this.listChapterN;
    }

    public int getFirstChaptersId() {
        if (getChaptersList() == null || getChaptersList().isEmpty()) {
            return -1;
        }
        return getChaptersList().get(0).getChapterID();
    }

    public List<ChapterShortNameAndMode> getChaptersList() {
        List<ChapterShortNameAndMode> list = this.listShortName;
        if (list == null || list.isEmpty()) {
            initChapterList();
        }
        return this.listShortName;
    }

    private Cursor getSubChaptersListCursor(long j) {
        try {
            return getDb().rawQuery("SELECT * FROM texts WHERE chapter_id = ? GROUP BY chapter_num", new String[]{Long.toString(j)});
        } catch (Exception unused) {
            return null;
        }
    }

    public List<Integer> getSubChaptersList(long j) {
        ArrayList arrayList = new ArrayList();
        try {
            Cursor subChaptersListCursor = getSubChaptersListCursor(j);
            if (subChaptersListCursor == null) {
                return arrayList;
            }
            if (subChaptersListCursor.isClosed() || !subChaptersListCursor.moveToFirst()) {
                subChaptersListCursor.close();
                return arrayList;
            }
            do {
                arrayList.add(Integer.valueOf(subChaptersListCursor.getInt(subChaptersListCursor.getColumnIndexOrThrow("chapter_num"))));
            } while (subChaptersListCursor.moveToNext());
            subChaptersListCursor.close();
            return arrayList;
        } catch (Exception unused) {
        }
        return arrayList;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:21:0x005f, code lost:
        if (r4 == null) goto L_0x006f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:27:0x006a, code lost:
        if (0 == 0) goto L_0x006f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:28:0x006c, code lost:
        r4.close();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:30:?, code lost:
        king.james.bible.android.MyApplication.getContext().getSharedPreferences("db_preference", 0).edit().putInt("page_count", r5.pagesCount).apply();
     */
    public int getTotalPagesCount() {
        int i;
        int i2 = this.pagesCount;
        if (i2 != 0) {
            return i2;
        }
        try {
            i = MyApplication.getContext().getSharedPreferences("db_preference", 0).getInt("page_count", 0);
        } catch (Exception unused) {
            i = 0;
        }
        if (i > 0) {
            this.pagesCount = i;
            return i;
        }
        Cursor cursor = null;
        try {
            cursor = rawQuery("SELECT sum(" + "num" + ") as suma FROM " + "chapters", null);
            if (cursor != null && !cursor.isClosed() && cursor.moveToFirst()) {
                do {
                    this.pagesCount = cursor.getInt(cursor.getColumnIndexOrThrow("suma"));
                } while (cursor.moveToNext());
            }
        } catch (Exception unused2) {
        } catch (Throwable th) {
            if (0 != 0) {
                cursor.close();
            }
            throw th;
        }
        return this.pagesCount;
    }

    public SoundModel getSoundModel(int i, int i2) throws Throwable {
        ChapterSubChapterResult chapterByPosition = getChapterByPosition(i + 1);
        if (chapterByPosition == null) {
            return null;
        }
        SoundModel soundModel = new SoundModel(i, i2);
        soundModel.setChapter(chapterByPosition.getTitle());
        soundModel.setSubChapter(chapterByPosition.getSubChapter());
        soundModel.setTextList(getItemsText(chapterByPosition.getChapter(), chapterByPosition.getSubChapter()));
        return soundModel;
    }

    private List<Text> getItemsText(int i, int i2) {
        ArrayList arrayList = new ArrayList();
        try {
            Cursor rawQuery = getDb().rawQuery("SELECT text, head, rank FROM texts WHERE chapter_id = ? AND chapter_num = ? ", new String[]{Integer.toString(i), Integer.toString(i2)});
            if (rawQuery != null) {
                if (rawQuery.isClosed() || !rawQuery.moveToFirst()) {
                    rawQuery.close();
                } else {
                    do {
                        String string = rawQuery.getString(rawQuery.getColumnIndexOrThrow("text"));
                        Text text = new Text();
                        text.setText(Html.fromHtml(string).toString());
                        text.setHead(rawQuery.getInt(rawQuery.getColumnIndexOrThrow("head")));
                        text.setRank(rawQuery.getInt(rawQuery.getColumnIndexOrThrow("rank")));
                        arrayList.add(text);
                    } while (rawQuery.moveToNext());
                    rawQuery.close();
                }
            }
        } catch (Exception unused) {
        }
        return arrayList;
    }

    public void fillChapterListPositionMap(int i) {
        Cursor rawQuery = getDb().rawQuery("SELECT * FROM chapters", null);
        for (int i2 = 1; i2 <= i; i2++) {
            getChapterByPosition(rawQuery, i2);
        }
        if (rawQuery != null) {
            rawQuery.close();
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x0026, code lost:
        if (r0 != null) goto L_0x0028;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:11:0x0028, code lost:
        r0.close();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0039, code lost:
        if (r0 != null) goto L_0x0028;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:22:0x003c, code lost:
        return r1;
     */
    /* JADX WARNING: Removed duplicated region for block: B:17:0x0034  */
    public ChapterSubChapterResult getChapterByPosition(int i) throws Throwable {
        Cursor cursor;
        Throwable th;
        ChapterSubChapterResult chapterSubChapterResult = null;
        if (this.listChapterByPosition.size() > 0 && (chapterSubChapterResult = this.listChapterByPosition.get(Integer.valueOf(i))) != null) {
            return chapterSubChapterResult;
        }
        Cursor cursor2 = null;
        r1 = null;
        ChapterSubChapterResult chapterSubChapterResult2 = null;
        try {
            cursor = getDb().rawQuery("SELECT * FROM chapters", null);
            try {
                chapterSubChapterResult2 = getChapterByPosition(cursor, i);
            } catch (Exception unused) {
            } catch (Throwable th2) {
                th = th2;
                cursor2 = cursor;
                if (cursor2 != null) {
                }
                throw th;
            }
        } catch (Exception unused2) {
            cursor = null;
        } catch (Throwable th3) {
            th = th3;
            if (cursor2 != null) {
                cursor2.close();
            }
            throw th;
        }
        return chapterSubChapterResult;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:35:0x00a9, code lost:
        if (r3 == null) goto L_0x00c3;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:36:0x00ab, code lost:
        r3.close();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:47:0x00c0, code lost:
        if (0 == 0) goto L_0x00c3;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:48:0x00c3, code lost:
        return r5;
     */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x00b6 A[SYNTHETIC, Splitter:B:42:0x00b6] */
    private ChapterSubChapterResult getChapterByPosition(Cursor cursor, int i) {
        ChapterSubChapterResult chapterSubChapterResult;
        int i2 = 0;
        int i3;
        int i4 = 0;
        Cursor cursor2 = null;
        if (cursor != null) {
            try {
                if (cursor.isClosed() || !cursor.moveToFirst()) {
                    return null;
                }
                i2 = i;
                int i5 = 0;
                do {
                    try {
                        i3 = cursor.getInt(cursor.getColumnIndexOrThrow("num"));
                        i5 = cursor.getInt(cursor.getColumnIndexOrThrow("_id"));
                    } catch (Exception unused) {
                        i3 = 0;
                    }
                    if (cursor.getPosition() + 1 < cursor.getCount() && i2 > i3) {
                        i2 -= i3;
                    }
                } while (cursor.moveToNext());
                i4 = i5;
            } catch (SQLException unused2) {
                chapterSubChapterResult = null;
                if (0 != 0) {
                }
            }
        } else {
            i2 = i;
        }
        chapterSubChapterResult = new ChapterSubChapterResult(i4, i2, cursor.getInt(cursor.getColumnIndexOrThrow("_id")), cursor.getString(cursor.getColumnIndexOrThrow("title")));
        try {
            cursor.close();
            cursor2 = getDb().rawQuery("SELECT min(chapter_num) AS min, max(chapter_num) AS max FROM texts WHERE chapter_id = " + i4, null);
            if (cursor2 == null || cursor2.isClosed() || !cursor2.moveToFirst()) {
                this.listChapterByPosition.put(Integer.valueOf(i), chapterSubChapterResult);
            } else {
                do {
                    int i6 = cursor2.getInt(cursor2.getColumnIndexOrThrow("min"));
                    if (i6 > 1) {
                        chapterSubChapterResult.setSubChapter(chapterSubChapterResult.getSubChapter() + (i6 - 1));
                    }
                } while (cursor2.moveToNext());
                this.listChapterByPosition.put(Integer.valueOf(i), chapterSubChapterResult);
            }
        } catch (SQLException unused3) {
            if (0 != 0) {
                try {
                    cursor2.close();
                } catch (Throwable th) {
                    if (0 != 0) {
                        cursor2.close();
                    }
                    throw th;
                }
            }
        }
        return null;
    }

    /* JADX WARNING: Removed duplicated region for block: B:25:0x007a  */
    /* JADX WARNING: Removed duplicated region for block: B:30:0x0081  */
    public ChapterSubChapterCursorResult getAllStuffById(long j) throws Throwable {
        ChapterSubChapterCursorResult chapterSubChapterCursorResult;
        Throwable th;
        ChapterSubChapterCursorResult chapterSubChapterCursorResult2;
        if (this.listAllStuffId.size() > 0 && (chapterSubChapterCursorResult2 = this.listAllStuffId.get(Long.valueOf(j))) != null) {
            return chapterSubChapterCursorResult2;
        }
        Cursor cursor = null;
        r1 = null;
        r1 = null;
        ChapterSubChapterCursorResult chapterSubChapterCursorResult3 = null;
        Cursor cursor2 = null;
        try {
            Cursor rawQuery = getDb().rawQuery("SELECT * FROM texts WHERE _id = ? ", new String[]{Long.toString(j)});
            if (rawQuery != null) {
                try {
                    if (!rawQuery.isClosed() && rawQuery.moveToFirst()) {
                        chapterSubChapterCursorResult3 = new ChapterSubChapterCursorResult(rawQuery.getInt(rawQuery.getColumnIndexOrThrow("chapter_num")) - 1, rawQuery.getInt(rawQuery.getColumnIndexOrThrow("chapter_id")), rawQuery.getInt(rawQuery.getColumnIndexOrThrow("position")));
                    }
                    rawQuery.close();
                } catch (SQLException unused) {
                    chapterSubChapterCursorResult = null;
                    cursor = rawQuery;
                    if (cursor != null) {
                        cursor.close();
                    }
                    return chapterSubChapterCursorResult;
                } catch (Throwable th2) {
                    th = th2;
                    cursor2 = rawQuery;
                    if (cursor2 != null) {
                        cursor2.close();
                    }
                    throw th;
                }
            }
            this.listAllStuffId.put(Long.valueOf(j), chapterSubChapterCursorResult3);
            if (rawQuery == null) {
                return chapterSubChapterCursorResult3;
            }
            rawQuery.close();
            return chapterSubChapterCursorResult3;
        } catch (SQLException unused2) {
            chapterSubChapterCursorResult = null;
            if (cursor != null) {
            }
            return chapterSubChapterCursorResult;
        } catch (Throwable th3) {
            th = th3;
            if (cursor2 != null) {
            }
            throw th;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0061, code lost:
        if (r1 != null) goto L_0x006e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:27:0x006c, code lost:
        if (0 == 0) goto L_0x0071;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:28:0x006e, code lost:
        r1.close();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:29:0x0071, code lost:
        return com.karumi.dexter.BuildConfig.FLAVOR;
     */
    public String getChapterNameById(long j) {
        String str;
        if (this.listChapterNameId.size() > 0 && (str = this.listChapterNameId.get(Long.valueOf(j))) != null) {
            return str;
        }
        Cursor cursor = null;
        try {
            cursor = getDb().rawQuery("SELECT * FROM chapters WHERE _id = ?", new String[]{Long.toString(j)});
            if (cursor != null) {
                if (cursor.isClosed() || !cursor.moveToFirst()) {
                    cursor.close();
                    if (cursor != null) {
                        cursor.close();
                    }
                    return BuildConfig.FLAVOR;
                }
                String string = cursor.getString(cursor.getColumnIndexOrThrow("title"));
                cursor.close();
                this.listChapterNameId.put(Long.valueOf(j), string);
                if (cursor != null) {
                    cursor.close();
                }
                return string;
            }
        } catch (SQLException unused) {
        } catch (Throwable th) {
            if (0 != 0) {
                cursor.close();
            }
            throw th;
        }
        return null;
    }

    public void initNameMapAsync() {
        new Thread(new Runnable() {
            /* class king.james.bible.android.db.$$Lambda$BibleDataBase$6vXJ33wAuO5pVEE6dxLurHhJvIM */

            public final void run() {
                BibleDataBase.this.lambda$initNameMapAsync$0$BibleDataBase();
            }
        }).start();
    }

    public /* synthetic */ void lambda$initNameMapAsync$0$BibleDataBase() {
        try {
            initColumSearchName();
            getChapterNameMap();
            getChapterNameMapN();
        } catch (Exception unused) {
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0045, code lost:
        if (r0 == null) goto L_0x0055;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x0050, code lost:
        if (0 == 0) goto L_0x0055;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:19:0x0052, code lost:
        r0.close();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0057, code lost:
        return r4.mNameMap;
     */
    public Map<Integer, String> getChapterNameMap() {
        if (this.mNameMap.size() > 0) {
            return this.mNameMap;
        }
        Cursor cursor = null;
        try {
            cursor = getDb().rawQuery("SELECT * FROM chapters", null);
            if (!cursor.isClosed() && cursor.moveToFirst()) {
                do {
                    this.mNameMap.put(Integer.valueOf(cursor.getInt(cursor.getColumnIndexOrThrow("_id"))), cursor.getString(cursor.getColumnIndexOrThrow("title")));
                } while (cursor.moveToNext());
            }
        } catch (SQLException unused) {
        } catch (Throwable th) {
            if (0 != 0) {
                cursor.close();
            }
            throw th;
        }
        return mNameMap;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0045, code lost:
        if (r0 == null) goto L_0x0055;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x0050, code lost:
        if (0 == 0) goto L_0x0055;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:19:0x0052, code lost:
        r0.close();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0057, code lost:
        return r4.mNameMapN;
     */
    public Map<Integer, String> getChapterNameMapN() {
        if (this.mNameMapN.size() > 0) {
            return this.mNameMapN;
        }
        Cursor cursor = null;
        try {
            cursor = getDb().rawQuery("SELECT * FROM chapters", null);
            if (!cursor.isClosed() && cursor.moveToFirst()) {
                do {
                    this.mNameMapN.put(Integer.valueOf(cursor.getInt(cursor.getColumnIndexOrThrow("_id"))), cursor.getString(cursor.getColumnIndexOrThrow(this.columTitle)));
                } while (cursor.moveToNext());
            }
        } catch (SQLException unused) {
        } catch (Throwable th) {
            if (0 != 0) {
                cursor.close();
            }
            throw th;
        }
        return this.mNameMapN;
    }

    public int getChapterByOrder(int i) {
        int i2 = i - 1;
        if (this.listChapter.isEmpty()) {
            initChapterList();
        }
        if (i2 > this.listChapter.size() - 1 || i2 < 0 || this.listChapter.isEmpty()) {
            return 0;
        }
        return getChapterIdByName(this.listChapter.get(i2));
    }

    /* JADX WARNING: Code restructure failed: missing block: B:15:0x0066, code lost:
        if (r0 != null) goto L_0x0068;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0068, code lost:
        r0.close();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:22:0x0074, code lost:
        if (0 == 0) goto L_0x0077;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:23:0x0077, code lost:
        return r1;
     */
    public int getChapterIdByName(String str) {
        Integer num = null;
        if (this.listChapterIdName.size() > 0 && (num = this.listChapterIdName.get(str)) != null) {
            return num.intValue();
        }
        Cursor cursor = null;
        int i = 1;
        try {
            String replace = str.replace("\"", "\"\"");
            cursor = getDb().rawQuery("SELECT * FROM chapters WHERE UPPER(title) LIKE \"" + replace + "\" ", new String[0]);
            if (cursor != null && !cursor.isClosed() && cursor.moveToFirst()) {
                i = cursor.getInt(cursor.getColumnIndexOrThrow("_id"));
                cursor.close();
                this.listChapterIdName.put(replace, Integer.valueOf(i));
            }
        } catch (SQLException unused) {
        } catch (Throwable th) {
            if (0 != 0) {
                cursor.close();
            }
            throw th;
        }
        return num.intValue();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:33:0x00a5, code lost:
        if (r1 != null) goto L_0x00a7;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:34:0x00a7, code lost:
        r1.close();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:40:0x00b3, code lost:
        if (0 == 0) goto L_0x00b6;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:41:0x00b6, code lost:
        return r0;
     */
    public int getPositionByChapter(int i, int i2) {
        int i3;
        int i4;
        Integer num;
        Cursor cursor = null;
        if (this.listPositionChapter.size() > 0) {
            Iterator<Map.Entry<ChapterSubChapter, Integer>> it = this.listPositionChapter.entrySet().iterator();
            while (true) {
                if (!it.hasNext()) {
                    num = null;
                    break;
                }
                Map.Entry<ChapterSubChapter, Integer> next = it.next();
                if (next.getKey().getChapter() == i && next.getKey().getSubChapter() == i2) {
                    num = next.getValue();
                    break;
                }
            }
            if (num != null) {
                return num.intValue();
            }
        }
        int i5 = 0;
        try {
            cursor = getDb().rawQuery("SELECT * FROM chapters", null);
            if (cursor != null && !cursor.isClosed() && cursor.moveToFirst()) {
                while (true) {
                    if (cursor.getInt(cursor.getColumnIndexOrThrow("_id")) < i) {
                        i5 += cursor.getInt(cursor.getColumnIndexOrThrow("num"));
                        if (!cursor.moveToNext()) {
                            break;
                        }
                    } else {
                        int i6 = cursor.getInt(cursor.getColumnIndexOrThrow("num")) - 1;
                        if (i2 <= i6) {
                            i4 = i5 + i2;
                            i3 = getStartSubChapter(i);
                        } else {
                            i4 = i5 + i6;
                            i3 = getStartSubChapter(i, i2 + 1);
                        }
                        i5 = i4 - i3;
                    }
                }
            }
            this.listPositionChapter.put(new ChapterSubChapter(i, i2), Integer.valueOf(i5));
        } catch (SQLException unused) {
        } catch (Throwable th) {
            if (0 != 0) {
                cursor.close();
            }
            throw th;
        }
        return i;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:28:0x008e, code lost:
        if (r1 == null) goto L_0x009f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:29:0x0090, code lost:
        r1.close();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:35:0x009c, code lost:
        if (0 == 0) goto L_0x009f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:36:0x009f, code lost:
        return r0;
     */
    /* JADX WARNING: Removed duplicated region for block: B:25:0x007d A[Catch:{ SQLException -> 0x009b, all -> 0x0094 }] */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x007f A[Catch:{ SQLException -> 0x009b, all -> 0x0094 }] */
    public int getSubChapter(int i, int i2) {
        Integer num = null;
        Cursor cursor = null;
        if (!this.listSubChapters.isEmpty()) {
            Iterator<Map.Entry<ChapterSubChapter, Integer>> it = this.listSubChapters.entrySet().iterator();
            while (true) {
                if (!it.hasNext()) {
                    num = null;
                    break;
                }
                ChapterSubChapter key = it.next().getKey();
                if (key.getChapter() == i && key.getSubChapter() == i2) {
                    num = this.listSubChapters.get(key);
                    break;
                }
            }
            if (num != null) {
                return num.intValue();
            }
        }
        int i3 = 0;
        int i4 = -1;
        try {
            cursor = getDb().rawQuery("SELECT max(chapter_num) FROM texts WHERE chapter_id=" + i, null);
            if (cursor == null || cursor.isClosed() || !cursor.moveToFirst()) {
                i3 = i2 <= i4 ? i4 : i2;
                this.listSubChapters.put(new ChapterSubChapter(i, i2), Integer.valueOf(i3));
            } else {
                do {
                    i4 = cursor.getInt(cursor.getColumnIndexOrThrow("max(chapter_num)"));
                } while (cursor.moveToNext());
                if (i2 <= i4) {
                }
                this.listSubChapters.put(new ChapterSubChapter(i, i2), Integer.valueOf(i3));
            }
        } catch (SQLException unused) {
        } catch (Throwable th) {
            if (0 != 0) {
                cursor.close();
            }
            throw th;
        }
        return num;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:14:0x004d, code lost:
        if (r1 != null) goto L_0x004f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:15:0x004f, code lost:
        r1.close();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x005b, code lost:
        if (0 == 0) goto L_0x005e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:22:0x005e, code lost:
        return r0;
     */
    private int getStartSubChapter(int i, int i2) {
        int i3;
        int i4 = 0;
        Cursor cursor = null;
        try {
            cursor = getDb().rawQuery("SELECT min(chapter_num) AS min, max(chapter_num) AS max FROM texts WHERE chapter_id=" + i, null);
            int i5 = -1;
            if (cursor == null || cursor.isClosed() || !cursor.moveToFirst()) {
                i3 = -1;
            } else {
                do {
                    i5 = cursor.getInt(cursor.getColumnIndexOrThrow("min"));
                    i3 = cursor.getInt(cursor.getColumnIndexOrThrow("max"));
                } while (cursor.moveToNext());
            }
            if (i5 > 1) {
                i4 = (i3 - i5) - (i2 - i5);
            }
        } catch (SQLException unused) {
        } catch (Throwable th) {
            if (0 != 0) {
                cursor.close();
            }
            throw th;
        }
        return Integer.parseInt(null);
    }

    private int getStartSubChapter(int i) {
        int i2;
        int i3 = -1;
        Cursor cursor = null;
        try {
            Cursor rawQuery = getDb().rawQuery("SELECT min(chapter_num) AS min FROM texts WHERE chapter_id=" + i, null);
            if (rawQuery != null) {
                if (!rawQuery.isClosed() && rawQuery.moveToFirst()) {
                    do {
                        i2 = rawQuery.getInt(rawQuery.getColumnIndexOrThrow("min"));
                    } while (rawQuery.moveToNext());
                    i3 = i2;
                }
                rawQuery.close();
            }
            if (i3 > 1) {
                return i3 - 1;
            }
            return 0;
        } catch (SQLException e) {
            if (0 != 0) {
                cursor.close();
            }
            throw e;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:63:0x0148  */
    public int getRankByChapter(int i, int i2, int i3) throws Exception {
        Exception e;
        int i4;
        int i5;
        int i6;
        Integer num;
        Cursor cursor = null;
        if (this.listRankChapter.size() > 0) {
            Iterator<Map.Entry<ChapterSubChapterPosition, Integer>> it = this.listRankChapter.entrySet().iterator();
            while (true) {
                if (!it.hasNext()) {
                    num = null;
                    break;
                }
                ChapterSubChapterPosition key = it.next().getKey();
                if (key.getChapter() == i && key.getSubChapter() == i2 && key.getPosition() == i3) {
                    num = this.listRankChapter.get(key);
                    break;
                }
            }
            if (num != null) {
                return num.intValue();
            }
        }
        try {
            Cursor rawQuery = getDb().rawQuery("SELECT max(chapter_num) FROM texts WHERE chapter_id=" + i, null);
            int i7 = -1;
            if (rawQuery != null) {
                try {
                    if (rawQuery.isClosed() || !rawQuery.moveToFirst()) {
                        i4 = -1;
                    } else {
                        do {
                            i4 = rawQuery.getInt(rawQuery.getColumnIndexOrThrow("max(chapter_num)"));
                        } while (rawQuery.moveToNext());
                    }
                    rawQuery.close();
                } catch (Exception e2) {
                    e = e2;
                    cursor = rawQuery;
                    if (cursor != null) {
                        cursor.close();
                    }
                    throw e;
                }
            } else {
                i4 = -1;
            }
            if (i2 > i4) {
                i2 = i4;
            }
            Cursor rawQuery2 = getDb().rawQuery("SELECT max(position) FROM texts WHERE chapter_id=" + i + " AND " + "chapter_num" + "=" + i2, null);
            if (rawQuery2 != null) {
                if (rawQuery2.isClosed() || !rawQuery2.moveToFirst()) {
                    i5 = -1;
                } else {
                    do {
                        i5 = rawQuery2.getInt(rawQuery2.getColumnIndexOrThrow("max(position)"));
                    } while (rawQuery2.moveToNext());
                }
                rawQuery2.close();
            } else {
                i5 = -1;
            }
            if (i3 > i5) {
                i3 = i5;
            }
            Cursor rawQuery3 = getDb().rawQuery("SELECT rank FROM texts WHERE chapter_id=" + i + " AND " + "chapter_num" + "=" + i2 + " AND " + "position" + "=" + i3, null);
            if (rawQuery3 != null) {
                if (!rawQuery3.isClosed() && rawQuery3.moveToFirst()) {
                    do {
                        i6 = rawQuery3.getInt(rawQuery3.getColumnIndexOrThrow("rank"));
                    } while (rawQuery3.moveToNext());
                    i7 = i6;
                }
                rawQuery3.close();
            }
            this.listRankChapter.put(new ChapterSubChapterPosition(i, i2, i3), Integer.valueOf(i7));
            return i7;
        } catch (Exception e3) {
            e = e3;
            if (cursor != null) {
            }
            throw e;
        }
    }

    public int getPositionByChapter(int i, int i2, int i3) {
        int i4 = 0;
        Cursor cursor = null;
        try {
            Cursor rawQuery = getDb().rawQuery("SELECT position FROM texts WHERE chapter_id=" + i + " AND " + "chapter_num" + "=" + i2 + " AND " + "rank" + "=" + i3, null);
            if (rawQuery == null) {
                return 0;
            }
            if (rawQuery.isClosed() || !rawQuery.moveToFirst()) {
                rawQuery.close();
                return i4;
            }
            do {
                i4 = rawQuery.getInt(rawQuery.getColumnIndexOrThrow("position"));
            } while (rawQuery.moveToNext());
            rawQuery.close();
            return i4;
        } catch (SQLException e) {
            if (0 != 0) {
                cursor.close();
            }
            throw e;
        }
    }

    private Cursor getSubChapterPosListCursor(int i, int i2) {
        try {
            return getDb().rawQuery("SELECT * FROM texts WHERE chapter_id = ? AND chapter_num = ? AND head = ?", new String[]{Integer.toString(i), Integer.toString(i2), Integer.toString(0)});
        } catch (SQLException unused) {
            return null;
        }
    }

    public List<Integer> getSubChaptersList(int i, int i2) {
        Cursor subChapterPosListCursor = getSubChapterPosListCursor(i, i2);
        ArrayList arrayList = new ArrayList();
        if (subChapterPosListCursor != null) {
            try {
                if (!subChapterPosListCursor.isClosed() && subChapterPosListCursor.moveToFirst()) {
                    do {
                        arrayList.add(Integer.valueOf(subChapterPosListCursor.getInt(subChapterPosListCursor.getColumnIndexOrThrow("position"))));
                    } while (subChapterPosListCursor.moveToNext());
                }
            } catch (Exception unused) {
            }
        }
        if (subChapterPosListCursor != null) {
            subChapterPosListCursor.close();
        }
        return arrayList;
    }

    private Cursor getPosCursor(int i, int i2, int i3) {
        return getDb().rawQuery("SELECT * FROM texts WHERE chapter_id = ? AND chapter_num = ? AND head = ? AND rank = ?", new String[]{Integer.toString(i), Integer.toString(i2), Integer.toString(0), Integer.toString(i3)});
    }

    /* JADX WARNING: Code restructure failed: missing block: B:11:0x00ad, code lost:
        if (r8 != null) goto L_0x00ba;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:17:0x00b8, code lost:
        if (0 == 0) goto L_0x00bd;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x00ba, code lost:
        r8.close();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:19:0x00bd, code lost:
        return r0;
     */
    public List<ShareDBModel> getShareDBModel(int i, int i2, int[] iArr) {
        ArrayList arrayList = new ArrayList();
        String[] strArr = new String[(iArr.length + 2)];
        strArr[0] = Integer.toString(i);
        strArr[1] = Integer.toString(i2);
        for (int i3 = 0; i3 < iArr.length; i3++) {
            strArr[i3 + 2] = Integer.toString(iArr[i3]);
        }
        Cursor cursor = null;
        try {
            cursor = getDb().rawQuery("SELECT " + "text" + "," + "position" + " FROM " + "texts" + " WHERE " + "chapter_id" + " = ? AND " + "chapter_num" + " = ? AND " + "rank" + " IN (" + makePlaceholders(iArr.length) + ")", strArr);
            if (cursor != null) {
                while (cursor.moveToNext()) {
                    ShareDBModel shareDBModel = new ShareDBModel();
                    shareDBModel.setText(cursor.getString(cursor.getColumnIndexOrThrow("text")));
                    shareDBModel.setPosition(cursor.getInt(cursor.getColumnIndexOrThrow("position")));
                    arrayList.add(shareDBModel);
                }
            }
        } catch (SQLException unused) {
        } catch (Throwable th) {
            if (0 != 0) {
                cursor.close();
            }
            throw th;
        }
        return arrayList;

    }

    private String makePlaceholders(int i) {
        if (i < 1) {
            return BuildConfig.FLAVOR;
        }
        StringBuilder sb = new StringBuilder((i * 2) - 1);
        sb.append("?");
        for (int i2 = 1; i2 < i; i2++) {
            sb.append(",?");
        }
        return sb.toString();
    }

    /* JADX WARNING: Removed duplicated region for block: B:16:0x0070  */
    public Note getNote(int i, int i2, int i3) {
        SQLException e;
        Cursor cursor = null;
        try {
            Cursor rawQuery = getDb().rawQuery("SELECT * FROM texts WHERE chapter_id = ? AND chapter_num = ? AND head = ? AND rank = ?", new String[]{Integer.toString(i), Integer.toString(i2), Integer.toString(0), Integer.toString(i3)});
            try {
                if (rawQuery.isClosed() || !rawQuery.moveToFirst()) {
                    rawQuery.close();
                    return null;
                }
                Note note = new Note();
                note.setNote(rawQuery.getString(rawQuery.getColumnIndexOrThrow("note")));
                note.setId(rawQuery.getLong(rawQuery.getColumnIndexOrThrow("_id")));
                note.setPosition(rawQuery.getInt(rawQuery.getColumnIndexOrThrow("position")));
                rawQuery.close();
                return note;
            } catch (SQLException e2) {
                e = e2;
                cursor = rawQuery;
                if (cursor != null) {
                    cursor.close();
                }
                throw e;
            }
        } catch (SQLException e3) {
            e = e3;
            if (cursor != null) {
            }
            throw e;
        }
    }

    public List<String> getFirstText(int i) {
        ArrayList arrayList = new ArrayList();
        Cursor cursor = null;
        try {
            Cursor rawQuery = getDb().rawQuery("SELECT * FROM texts WHERE head = ?  ORDER BY _id LIMIT ?", new String[]{Integer.toString(0), Integer.toString(i)});
            while (rawQuery.moveToNext()) {
                arrayList.add(rawQuery.getString(rawQuery.getColumnIndexOrThrow("text")));
            }
            rawQuery.close();
            return arrayList;
        } catch (SQLException unused) {
            if (0 != 0) {
                cursor.close();
            }
            return new ArrayList();
        }
    }

    private int getPositionIdByChapter(int i, int i2, int i3) {
        try {
            Cursor posCursor = getPosCursor(i, i2, i3);
            if (posCursor != null) {
                if (posCursor.isClosed() || !posCursor.moveToNext()) {
                    posCursor.close();
                } else {
                    int i4 = posCursor.getInt(posCursor.getColumnIndexOrThrow("_id"));
                    posCursor.close();
                    return i4;
                }
            }
        } catch (Exception unused) {
        }
        return 0;
    }

    private String getColumName() {
        Cursor rawQuery = rawQuery("SELECT * FROM texts LIMIT 1", null);
        if (rawQuery != null && !rawQuery.isClosed() && rawQuery.moveToNext()) {
            for (String str : rawQuery.getColumnNames()) {
                if (str.equals("ntext")) {
                    return "ntext";
                }
            }
            rawQuery.close();
        }
        return "text";
    }

    private Cursor rawQuery(String str, String[] strArr) {
        Cursor cursor = null;
        try {
            Cursor rawQuery = getDb().rawQuery(str, strArr);
            if (rawQuery != null) {
                try {
                    if (rawQuery.getCount() < 1 || !rawQuery.moveToFirst()) {
                        return null;
                    }
                    return rawQuery;
                } catch (Exception unused) {
                    cursor = rawQuery;
                    return cursor;
                }
            }
            return null;
        } catch (Exception unused2) {
            return cursor;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:15:0x0044, code lost:
        if (r2 != null) goto L_0x0046;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0046, code lost:
        r2.close();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:22:0x0052, code lost:
        if (0 == 0) goto L_0x0055;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:23:0x0055, code lost:
        return r1;
     */
    private String getTileName() {
        String str = "title";
        Cursor cursor = null;
        try {
            cursor = rawQuery("SELECT * FROM " + "chapters" + " LIMIT 1", null);
            if (cursor != null && !cursor.isClosed() && cursor.moveToNext()) {
                String[] columnNames = cursor.getColumnNames();
                int length = columnNames.length;
                int i = 0;
                while (true) {
                    if (i >= length) {
                        break;
                    } else if (columnNames[i].equals("ntitle")) {
                        str = "ntitle";
                        break;
                    } else {
                        i++;
                    }
                }
            }
        } catch (Exception unused) {
        } catch (Throwable th) {
            if (0 != 0) {
                cursor.close();
            }
            throw th;
        }
        return null;
    }

    public void initColumSearchName() {
        if (this.columTitle == null && this.columName == null) {
            new Thread(new Runnable() {
                /* class king.james.bible.android.db.$$Lambda$BibleDataBase$5AttfREy4u0PbCjTBE4V2ZNW88 */

                public final void run() {
                    BibleDataBase.this.lambda$initColumSearchName$1$BibleDataBase();
                }
            }).start();
        }
    }

    public /* synthetic */ void lambda$initColumSearchName$1$BibleDataBase() {
        this.columName = getColumName();
        this.columTitle = getTileName();
    }

    public Cursor searchText(String[] strArr, String[] strArr2, boolean z) {
        StringBuilder sb = new StringBuilder();
        sb.append("SELECT * FROM ");
        sb.append("texts");
        sb.append(" WHERE ");
        String prepareWordsQuery = prepareWordsQuery(strArr, "text", z);
        sb.append("(");
        sb.append(prepareWordsQuery);
        if (isNColum()) {
            String prepareWordsQuery2 = prepareWordsQuery(strArr2, "ntext", z);
            sb.append(" OR ");
            sb.append(prepareWordsQuery2);
        }
        sb.append(")");
        sb.append(SqlHtmlTagUtil.getIgnoreTagsAndAttributeQuery("text", strArr));
        sb.append(" AND head == 0");
        try {
            return getDb().rawQuery(sb.toString(), null);
        } catch (Exception unused) {
            return null;
        }
    }

    private String prepareWordsQuery(String[] strArr, String str, boolean z) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < strArr.length; i++) {
            sb.append(" ( ");
            sb.append(prepareWordQuery(" UPPER(" + str + ") ", strArr[i].toUpperCase(), z));
            sb.append("%\" ESCAPE '/'");
            sb.append(" OR ");
            sb.append(prepareWordQuery("LOWER(" + str + ") ", strArr[i].toLowerCase(), z));
            sb.append("%\" ESCAPE '/' )");
            if (i < strArr.length - 1) {
                sb.append("AND");
            }
        }
        return sb.toString();
    }

    private String prepareWordQuery(String str, String str2, boolean z) {
        StringBuilder sb = new StringBuilder();
        if (z) {
            sb.append(str);
            sb.append(" ");
            sb.append("LIKE");
            sb.append(" '% ");
            sb.append(str2);
            sb.append(" %' OR ");
            sb.append(str);
            sb.append(" ");
            sb.append("LIKE");
            sb.append(" '%(");
            sb.append(str2);
            sb.append(" %' OR ");
            sb.append(str);
            sb.append(" ");
            sb.append("LIKE");
            sb.append(" '% ");
            sb.append(str2);
            sb.append(")%' OR ");
            sb.append(str);
            sb.append(" ");
            sb.append("LIKE");
            sb.append(" '% ");
            sb.append(str2);
            sb.append(",%' OR ");
            sb.append(str);
            sb.append(" ");
            sb.append("LIKE");
            sb.append(" '% ");
            sb.append(str2);
            sb.append(".%' OR ");
            sb.append(str);
            sb.append(" ");
            sb.append("LIKE");
            sb.append(" '% ");
            sb.append(str2);
            sb.append("?%' OR ");
            sb.append(str);
            sb.append(" ");
            sb.append("LIKE");
            sb.append(" '% ");
            sb.append(str2);
            sb.append("!%' OR ");
            sb.append(str);
            sb.append(" ");
            sb.append("LIKE");
            sb.append(" '% ");
            sb.append(str2);
            sb.append(":%' OR ");
            sb.append(str);
            sb.append(" ");
            sb.append("LIKE");
            sb.append(" '% ");
            sb.append(str2);
            sb.append(";%' OR ");
            sb.append(str);
            sb.append(" ");
            sb.append("LIKE");
            sb.append(" '% ");
            sb.append(str2);
            sb.append("' OR ");
            sb.append(str);
            sb.append(" ");
            sb.append("LIKE");
            sb.append(" '");
            sb.append(str2);
            sb.append(" %' ");
        } else {
            sb.append(str);
            sb.append("LIKE \"%");
            sb.append(str2);
        }
        return sb.toString();
    }

    public String getChapterQueryByMode(int i) {
        StringBuilder sb = new StringBuilder("( ");
        List<ChapterShortNameAndMode> byMode = getByMode(i);
        if (byMode.isEmpty()) {
            return BuildConfig.FLAVOR;
        }
        sb.append("chapter_id");
        sb.append(" = ");
        sb.append(byMode.get(0).getChapterID());
        if (byMode.size() > 1) {
            for (int i2 = 1; i2 < byMode.size(); i2++) {
                sb.append(" OR ");
                sb.append("chapter_id");
                sb.append(" = ");
                sb.append(byMode.get(i2).getChapterID());
            }
        }
        sb.append(" )");
        return sb.toString();
    }

    private List<ChapterShortNameAndMode> getByMode(int i) {
        ArrayList arrayList = new ArrayList();
        for (int i2 = 0; i2 < this.listShortName.size(); i2++) {
            if (this.listShortName.get(i2).getMode() == i) {
                arrayList.add(this.listShortName.get(i2));
            }
        }
        return arrayList;
    }

    public Cursor searchByChapters(String[] strArr, String str, boolean z) {
        if (TextUtils.isEmpty(str)) {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("SELECT * FROM ");
        sb.append("texts");
        sb.append(" WHERE (");
        String prepareWordsQuery = prepareWordsQuery(strArr, "text", z);
        String[] normalizeWords = getNormalizeWords(strArr);
        sb.append("(");
        sb.append(prepareWordsQuery);
        if (isNColum()) {
            String prepareWordsQuery2 = prepareWordsQuery(normalizeWords, "ntext", z);
            sb.append(" OR ");
            sb.append(prepareWordsQuery2);
        }
        sb.append(")");
        sb.append(") AND ");
        sb.append(str);
        sb.append(" AND head == 0");
        sb.append(SqlHtmlTagUtil.getIgnoreTagsAndAttributeQuery("text", strArr));
        try {
            return getDb().rawQuery(sb.toString(), null);
        } catch (Exception unused) {
            return null;
        }
    }

    public void changeBookmark(int i, int i2, DialogDataBookmark dialogDataBookmark, ChangeBookmarkListener changeBookmarkListener) {
        new Thread(new Runnable() {
            /* class king.james.bible.android.db.$$Lambda$BibleDataBase$yrmmFKk7bYqMeqJ6tnLhvhIwI */
            private final /* synthetic */ DialogDataBookmark f$1;
            private final /* synthetic */ int f$2;
            private final /* synthetic */ int f$3;
            private final /* synthetic */ ChangeBookmarkListener f$4;

            {
                this.f$1 = r21;
                this.f$2 = r3;
                this.f$3 = r41;
                this.f$4 = r5;
            }

            public final void run() {
                BibleDataBase.this.lambda$changeBookmark$2$BibleDataBase(this.f$1, this.f$2, this.f$3, this.f$4);
            }
        }).start();
    }

    public /* synthetic */ void lambda$changeBookmark$2$BibleDataBase(DialogDataBookmark dialogDataBookmark, int i, int i2, ChangeBookmarkListener changeBookmarkListener) {
        Iterator<Integer> it = dialogDataBookmark.getSelectedSet().iterator();
        while (it.hasNext()) {
            Integer next = it.next();
            try {
                addRemoveBookmark((long) getPositionIdByChapter(i, i2, next.intValue()));
                changeBookmarkListener.changeBookmark((long) next.intValue());
            } catch (Exception unused) {
            }
        }
        changeBookmarkListener.onChangeComplete();
    }

    public void changeBookmark(long j, ChangeBookmarkListener changeBookmarkListener) {
        new Thread(new Runnable() {
            /* class king.james.bible.android.db.$$Lambda$BibleDataBase$YmUOGEpJPIu7Np5esoNK7kgESmg */
            private final /* synthetic */ long f$1;
            private final /* synthetic */ ChangeBookmarkListener f$2;

            {
                this.f$1 = r2;
                this.f$2 = r4;
            }

            public final void run() {
                BibleDataBase.this.lambda$changeBookmark$3$BibleDataBase(this.f$1, this.f$2);
            }
        }).start();
    }

    public /* synthetic */ void lambda$changeBookmark$3$BibleDataBase(long j, ChangeBookmarkListener changeBookmarkListener) {
        try {
            addRemoveBookmark(j);
            if (changeBookmarkListener != null) {
                changeBookmarkListener.onChangeComplete();
            }
        } catch (Exception unused) {
        }
    }

    private void addRemoveBookmark(long j) {
        try {
            Cursor rawQuery = getDb().rawQuery("SELECT * FROM texts WHERE _id = ? ", new String[]{Long.toString(j)});
            if (!rawQuery.isClosed() && rawQuery.moveToFirst()) {
                if (rawQuery.isNull(rawQuery.getColumnIndexOrThrow("bookmark"))) {
                    long currentTimeMillis = System.currentTimeMillis();
                    SQLiteDatabase db = getDb();
                    db.execSQL("UPDATE texts SET bookmark = 1, bookmark_date = " + currentTimeMillis + " WHERE " + "_id" + " = " + j);
                } else {
                    SQLiteDatabase db2 = getDb();
                    db2.execSQL("UPDATE texts SET bookmark = NULL WHERE _id = " + j);
                }
            }
            checkAndShowBackupHint();
        } catch (Exception unused) {
        }
    }

    public void addHighLight(int i, int i2, SpanType spanType, DialogDataBookmark dialogDataBookmark, AddHighLightListener addHighLightListener) {
        new Thread(new Runnable() {
            /* class king.james.bible.android.db.$$Lambda$BibleDataBase$VCfFgv8erx_pT8qzo_U1YZU7F0 */
            private final /* synthetic */ DialogDataBookmark f$1;
            private final /* synthetic */ int f$2;
            private final /* synthetic */ int f$3;
            private final /* synthetic */ SpanType f$4;
            private final /* synthetic */ AddHighLightListener f$5;

            {
                this.f$1 = r21;
                this.f$2 = r3;
                this.f$3 = r41;
                this.f$4 = r51;
                this.f$5 = r6;
            }

            public final void run() {
                BibleDataBase.this.lambda$addHighLight$4$BibleDataBase(this.f$1, this.f$2, this.f$3, this.f$4, this.f$5);
            }
        }).start();
    }

    public /* synthetic */ void lambda$addHighLight$4$BibleDataBase(DialogDataBookmark dialogDataBookmark, int i, int i2, SpanType spanType, AddHighLightListener addHighLightListener) {
        Iterator<Integer> it = dialogDataBookmark.getSelectedSet().iterator();
        while (it.hasNext()) {
            Integer next = it.next();
            try {
                addHighLight((long) getPositionIdByChapter(i, i2, next.intValue()), spanType);
                addHighLightListener.addToAdapter(next.intValue(), spanType);
            } catch (Exception unused) {
            }
        }
        addHighLightListener.onAddComplete();
    }

    private void addHighLight(long j, SpanType spanType) {
        try {
            long currentTimeMillis = System.currentTimeMillis();
            SQLiteDatabase db = getDb();
            db.execSQL("UPDATE texts SET highlight = " + spanType.ordinal() + ", " + "highlight_date" + " = " + currentTimeMillis + " WHERE " + "_id" + " = " + j);
            checkAndShowBackupHint();
        } catch (Exception unused) {
        }
    }

    private void checkAndShowBackupHint() {
        onChangeBackupState();
        if (BiblePreferences.getInstance().isShowBackupHint()) {
            EventBus.getDefault().post(new ShowBackupHint());
        }
    }

    private void onChangeBackupState() {
        BaseActivity.NEED_SAVE_BACKUP = true;
    }

    public void removeHighLight(int i, int i2, DialogDataBookmark dialogDataBookmark, RemoveHighLightListener removeHighLightListener) {
        new Thread(new Runnable() {
            /* class king.james.bible.android.db.$$Lambda$BibleDataBase$YpvJrJfP4ovEt6v1QkEWaHxsTY */
            private final /* synthetic */ DialogDataBookmark f$1;
            private final /* synthetic */ int f$2;
            private final /* synthetic */ int f$3;
            private final /* synthetic */ RemoveHighLightListener f$4;

            {
                this.f$1 = r21;
                this.f$2 = r3;
                this.f$3 = r41;
                this.f$4 = r52;
            }

            public final void run() {
                BibleDataBase.this.lambda$removeHighLight$5$BibleDataBase(this.f$1, this.f$2, this.f$3, this.f$4);
            }
        }).start();
    }

    public /* synthetic */ void lambda$removeHighLight$5$BibleDataBase(DialogDataBookmark dialogDataBookmark, int i, int i2, RemoveHighLightListener removeHighLightListener) {
        Iterator<Integer> it = dialogDataBookmark.getSelectedSet().iterator();
        while (it.hasNext()) {
            Integer next = it.next();
            try {
                removeHighLight((long) getPositionIdByChapter(i, i2, next.intValue()));
                removeHighLightListener.removeFromAdapter(next.intValue());
            } catch (Exception unused) {
            }
        }
        removeHighLightListener.onComplete();
    }

    public void removeHighLight(long j, RemoveHighLightListener removeHighLightListener) {
        new Thread(new Runnable() {
            /* class king.james.bible.android.db.$$Lambda$BibleDataBase$iPk0RRFsYrdZKBfH94Yvc8vtSIw */
            private final /* synthetic */ long f$1;
            private final /* synthetic */ RemoveHighLightListener f$2;

            {
                this.f$1 = r2;
                this.f$2 = r42;
            }

            public final void run() {
                BibleDataBase.this.lambda$removeHighLight$6$BibleDataBase(this.f$1, this.f$2);
            }
        }).start();
    }

    public /* synthetic */ void lambda$removeHighLight$6$BibleDataBase(long j, RemoveHighLightListener removeHighLightListener) {
        try {
            removeHighLight(j);
            if (removeHighLightListener != null) {
                removeHighLightListener.onComplete();
            }
        } catch (Exception unused) {
        }
    }

    private void removeHighLight(long j) {
        try {
            SQLiteDatabase db = getDb();
            db.execSQL("UPDATE texts SET highlight = NULL WHERE _id = " + j);
            onChangeBackupState();
        } catch (Exception unused) {
        }
    }

    public void addNote(int i, int i2, int i3, String str, AddRemoveNoteListener addRemoveNoteListener) {
        new Thread(new Runnable() {
            private  int r22;
            /* class king.james.bible.android.db.$$Lambda$BibleDataBase$QhIYLbQMW4dHZpI5N9SgxGJ6e1s */
            private final /* synthetic */ int f$1;
            private final /* synthetic */ int f$2;
            private final /* synthetic */ int f$3;
            private final /* synthetic */ String f$4;
            private final /* synthetic */ AddRemoveNoteListener f$5;

            {
                this.f$1 = r22;
                this.f$2 = r3;
                this.f$3 = r41;
                this.f$4 = String.valueOf(r51);
                this.f$5 = r61;
            }

            public final void run() {
                BibleDataBase.this.lambda$addNote$7$BibleDataBase(this.f$1, this.f$2, this.f$3, this.f$4, this.f$5);
            }
        }).start();
    }

    public /* synthetic */ void lambda$addNote$7$BibleDataBase(int i, int i2, int i3, String str, AddRemoveNoteListener addRemoveNoteListener) {
        long positionIdByChapter = (long) getPositionIdByChapter(i, i2, i3);
        addNote(positionIdByChapter, str);
        addRemoveNoteListener.onComplete(positionIdByChapter);
    }

    private void addNote(long j, String str) {
        try {
            long currentTimeMillis = System.currentTimeMillis();
            String replace = str.replace("'", "''").replace("?", "/?");
            SQLiteDatabase db = getDb();
            db.execSQL("UPDATE texts SET note = '" + replace + "'," + "note_date" + " = " + currentTimeMillis + " WHERE " + "_id" + " = " + j);
            checkAndShowBackupHint();
        } catch (Exception unused) {
        }
    }

    public void removeNote(int i, int i2, int i3, AddRemoveNoteListener addRemoveNoteListener) {
        new Thread(new Runnable() {
            /* class king.james.bible.android.db.$$Lambda$BibleDataBase$egeLHn7d_NUJY5f0LKwK8nh1vjA */
            private final /* synthetic */ int f$1;
            private final /* synthetic */ int f$2;
            private final /* synthetic */ int f$3;
            private final /* synthetic */ AddRemoveNoteListener f$4;

            {
                this.f$1 = r22;
                this.f$2 = r3;
                this.f$3 = r41;
                this.f$4 = r522;
            }

            public final void run() {
                BibleDataBase.this.lambda$removeNote$8$BibleDataBase(this.f$1, this.f$2, this.f$3, this.f$4);
            }
        }).start();
    }

    public /* synthetic */ void lambda$removeNote$8$BibleDataBase(int i, int i2, int i3, AddRemoveNoteListener addRemoveNoteListener) {
        long positionIdByChapter = (long) getPositionIdByChapter(i, i2, i3);
        removeNote(positionIdByChapter);
        addRemoveNoteListener.onComplete(positionIdByChapter);
    }

    public void removeNote(long j, AddRemoveNoteListener addRemoveNoteListener) {
        new Thread(new Runnable() {
            /* class king.james.bible.android.db.$$Lambda$BibleDataBase$DMJON6SMHxnz_vQ6GfZ47sYb8 */
            private final /* synthetic */ long f$1;
            private final /* synthetic */ AddRemoveNoteListener f$2;

            {
                this.f$1 = r2;
                this.f$2 = r422;
            }

            public final void run() {
                BibleDataBase.this.lambda$removeNote$9$BibleDataBase(this.f$1, this.f$2);
            }
        }).start();
    }

    public /* synthetic */ void lambda$removeNote$9$BibleDataBase(long j, AddRemoveNoteListener addRemoveNoteListener) {
        try {
            removeNote(j);
            if (addRemoveNoteListener != null) {
                addRemoveNoteListener.onComplete(j);
            }
        } catch (Exception unused) {
        }
    }

    private void removeNote(long j) {
        try {
            SQLiteDatabase db = getDb();
            db.execSQL("UPDATE texts SET note = NULL WHERE _id = " + j);
            onChangeBackupState();
        } catch (Exception unused) {
        }
    }

    public ArrayList<SpanItem> getBookmarksCursor(String str) {
        Cursor cursor = null;
        try {
            StringBuilder sb = new StringBuilder();
            sb.append("SELECT * FROM texts WHERE ");
            sb.append("bookmark IS NOT NULL");
            if (!TextUtils.isEmpty(str)) {
                String replace = str.replace("\"", "\"\"");
                sb.append(" AND (chapter_id IN (SELECT _id FROM chapters WHERE UPPER(title) LIKE \"%");
                sb.append(replace.toLowerCase());
                sb.append("%\") OR (");
                sb.append("chapter_id");
                sb.append(" IN (SELECT ");
                sb.append("_id");
                sb.append(" FROM ");
                sb.append("chapters");
                sb.append(" WHERE UPPER(");
                sb.append(this.columTitle);
                sb.append(") LIKE \"%");
                sb.append(replace.toLowerCase());
                sb.append("%\")))");
            }
            sb.append(" ORDER BY bookmark_date DESC");
            cursor = getDb().rawQuery(sb.toString(), null);
            cursor.moveToFirst();
        } catch (Exception unused) {
        }
        return parseModels(cursor, false, false);
    }

    private ArrayList<SpanItem> parseModels(Cursor cursor, boolean z, boolean z2) {
        ArrayList<SpanItem> arrayList = new ArrayList<>();
        if (cursor != null && cursor.getCount() >= 1) {
            do {
                try {
                    SpanItem spanItem = new SpanItem();
                    spanItem.id = cursor.getLong(cursor.getColumnIndexOrThrow("_id"));
                    spanItem.chapterId = cursor.getInt(cursor.getColumnIndexOrThrow("chapter_id"));
                    if (z2) {
                        spanItem.text = cursor.getString(cursor.getColumnIndexOrThrow("note"));
                    } else {
                        spanItem.text = cursor.getString(cursor.getColumnIndexOrThrow("text"));
                    }
                    spanItem.chapterNum = cursor.getInt(cursor.getColumnIndexOrThrow("chapter_num"));
                    spanItem.columnPosition = cursor.getInt(cursor.getColumnIndexOrThrow("position"));
                    if (!cursor.isNull(cursor.getColumnIndexOrThrow("bookmark_date"))) {
                        spanItem.date = DateUtil.getInstance().getBookmarkTime(cursor.getLong(cursor.getColumnIndexOrThrow("bookmark_date")), MyApplication.getContext());
                    }
                    if (z) {
                        spanItem.date = DateUtil.getInstance().getBookmarkTime(cursor.getLong(cursor.getColumnIndexOrThrow("highlight_date")), MyApplication.getContext());
                        spanItem.colorSpanType = cursor.getInt(cursor.getColumnIndexOrThrow("highlight"));
                    }
                    if (z2) {
                        spanItem.date = DateUtil.getInstance().getBookmarkTime(cursor.getLong(cursor.getColumnIndexOrThrow("note_date")), MyApplication.getContext());
                    }
                    arrayList.add(spanItem);
                } catch (Exception unused) {
                }
            } while (cursor.moveToNext());
            try {
                cursor.close();
            } catch (Exception unused2) {
            }
        }
        return arrayList;
    }

    public ArrayList<SpanItem> getHighlightsCursor(String str, SpanType spanType) {
        int ordinal = spanType.ordinal();
        Cursor cursor = null;
        try {
            StringBuilder sb = new StringBuilder();
            sb.append("SELECT * FROM texts WHERE ");
            if (ordinal == 0) {
                sb.append("highlight IS NOT NULL");
            } else {
                sb.append("highlight = ");
                sb.append(ordinal);
            }
            if (!TextUtils.isEmpty(str)) {
                String replace = str.replace("\"", "\"\"");
                sb.append(" AND (chapter_id IN (SELECT _id FROM chapters WHERE UPPER(title) LIKE \"%" + replace.toLowerCase() + "%\") OR (" + "chapter_id" + " IN (SELECT " + "_id" + " FROM " + "chapters" + " WHERE UPPER(" + this.columTitle + ") LIKE \"%" + replace.toLowerCase() + "%\")))");
            }
            sb.append(" ORDER BY highlight_date DESC");
            cursor = getDb().rawQuery(sb.toString(), null);
        } catch (Exception unused) {
        }
        return parseModels(cursor, true, false);
    }

    public ArrayList<SpanItem> getNotesCursor(String str) {
        Cursor cursor = null;
        try {
            StringBuilder sb = new StringBuilder();
            sb.append("SELECT * FROM texts WHERE ");
            sb.append("note IS NOT NULL");
            if (!TextUtils.isEmpty(str)) {
                String replace = str.replace("\"", "\"\"");
                sb.append(" AND (chapter_id IN (SELECT _id FROM chapters WHERE UPPER(title) LIKE \"%" + replace.toLowerCase() + "%\") OR (" + "chapter_id" + " IN (SELECT " + "_id" + " FROM " + "chapters" + " WHERE UPPER(" + this.columTitle + ") LIKE \"%" + replace.toLowerCase() + "%\")))");
            }
            sb.append(" ORDER BY note_date DESC");
            cursor = getDb().rawQuery(sb.toString(), null);
        } catch (Exception unused) {
        }
        return parseModels(cursor, false, true);
    }

    public List<UpdateRecord> getUpdateRecords() {
        Cursor rawQuery = getDb().rawQuery("SELECT * FROM texts WHERE bookmark IS NOT NULL OR highlight IS NOT NULL OR note IS NOT NULL", null);
        ArrayList arrayList = new ArrayList();
        rawQuery.moveToFirst();
        while (!rawQuery.isAfterLast()) {
           int i = rawQuery.getInt(rawQuery.getColumnIndex("_id"));
            int columnIndex = rawQuery.getColumnIndex("bookmark");
            int columnIndex2 = rawQuery.getColumnIndex("bookmark_date");
            int columnIndex3 = rawQuery.getColumnIndex("highlight");
            int columnIndex4 = rawQuery.getColumnIndex("highlight_date");
            int columnIndex5 = rawQuery.getColumnIndex("note");
            int columnIndex6 = rawQuery.getColumnIndex("note_date");
            arrayList.add(new UpdateRecord(i, rawQuery.isNull(columnIndex) ? null : Integer.valueOf(rawQuery.getInt(columnIndex)), rawQuery.isNull(columnIndex3) ? null : Integer.valueOf(rawQuery.getInt(columnIndex3)), rawQuery.isNull(columnIndex5) ? null : rawQuery.getString(columnIndex5), rawQuery.isNull(columnIndex2) ? null : Long.valueOf(rawQuery.getLong(columnIndex2)), rawQuery.isNull(columnIndex4) ? null : Long.valueOf(rawQuery.getLong(columnIndex4)), rawQuery.isNull(columnIndex6) ? null : Long.valueOf(rawQuery.getLong(columnIndex6))));
            rawQuery.moveToNext();
        }
        if (rawQuery != null) {
            rawQuery.close();
        }
        return arrayList;
    }

    public void removeDate() {
        try {
            getDb().execSQL("UPDATE texts SET bookmark=null,bookmark_date=null,highlight=null,highlight_date=null,note=null,note_date=null");
        } catch (Exception unused) {
        }
    }

    public void updateRecords(List<UpdateRecord> list) {
        for (UpdateRecord updateRecord : list) {
            String str = "UPDATE texts SET ";
            ArrayList arrayList = new ArrayList();
            String[] strArr = null;
            if (updateRecord.getBookmark() != null) {
                arrayList.add("bookmark = " + updateRecord.getBookmark() + ", " + "bookmark_date" + " = " + updateRecord.getBookmarkDate() + " ");
            }
            if (updateRecord.getHighlight() != null) {
                arrayList.add("highlight = " + updateRecord.getHighlight() + ", " + "highlight_date" + " = " + updateRecord.getHighlightDate() + " ");
            }
            if (updateRecord.getNote() != null) {
                strArr = new String[]{updateRecord.getNote()};
                arrayList.add("note = ?, note_date = " + updateRecord.getNoteDate() + " ");
            }
            int size = arrayList.size();
            if (size == 1) {
                str = str + ((String) arrayList.get(0));
            } else if (size == 2) {
                str = (str + ((String) arrayList.get(0)) + ", ") + ((String) arrayList.get(1));
            } else if (size == 3) {
                str = ((str + ((String) arrayList.get(0)) + ", ") + ((String) arrayList.get(1)) + ", ") + ((String) arrayList.get(2));
            }
            rawQuery(str + " WHERE _id = " + updateRecord.getId(), strArr);
        }
    }

    public Cursor getAllDailyVerse() {
        return getAllRecords("verses");
    }

    public Cursor getVerseById(long j) {
        try {
            return getDb().rawQuery("SELECT * FROM texts WHERE _id = ?", new String[]{Long.toString(j)});
        } catch (Exception unused) {
            return null;
        }
    }

    public Cursor getVerseByChapterIdAndNum(long j, int i) {
        try {
            return getDb().rawQuery("SELECT * FROM texts WHERE chapter_id = ? AND chapter_num = ?", new String[]{Long.toString(j), Integer.toString(i)});
        } catch (Exception unused) {
            return null;
        }
    }

    public long update(String str, long j, ContentValues contentValues) {
        return (long) getDb().update(str, contentValues, "_id = ?", new String[]{String.valueOf(j)});
    }

    private long insert(String str, ContentValues contentValues) {
        long j = -1;
        while (j == -1) {
            j = getDb().insert(str, null, contentValues);
        }
        return j;
    }

    public long updateDailyVerse(long j, ContentValues contentValues) {
        return update("verses", j, contentValues);
    }

    public long createDailyVerse(ContentValues contentValues) {
        return insert("verses", contentValues);
    }

    public void deleteDailyVerse(long j) {
        try {
            getDb().delete("verses", "_id = ?", new String[]{String.valueOf(j)});
        } catch (Exception unused) {
        }
    }

    private Cursor getAllRecords(String str) {
        try {
            return getDb().rawQuery("SELECT * FROM " + str, null);
        } catch (Exception unused) {
            return null;
        }
    }

    public Cursor getAllPlans() {
        return getAllRecords("plans");
    }

    public Cursor getPlanById(long j) {
        try {
            return getDb().rawQuery("SELECT * FROM plans WHERE _id = ?", new String[]{Long.toString(j)});
        } catch (Exception unused) {
            return null;
        }
    }

    public long updatePlan(long j, ContentValues contentValues) {
        try {
            return update("plans", j, contentValues);
        } catch (Exception unused) {
            return 0;
        }
    }

    public Cursor getAllPlanDay(long j) {
        try {
            return getDb().rawQuery("SELECT * FROM reading_days WHERE plan_id = ?", new String[]{Long.toString(j)});
        } catch (Exception unused) {
            return null;
        }
    }

    public long createPlanDay(ContentValues contentValues) {
        return insert("reading_days", contentValues);
    }

    public void deleteAllPlanDay(long j) {
        try {
            getDb().execSQL("DELETE FROM reading_days WHERE plan_id = ?", new String[]{Long.toString(j)});
        } catch (Exception unused) {
        }
    }

    public Cursor getReadingDays(long j, int i) {
        try {
            return getDb().rawQuery("SELECT * FROM reading_plans WHERE plan_id = ? AND mode_id = ?", new String[]{Long.toString(j), Integer.toString(i)});
        } catch (Exception unused) {
            return null;
        }
    }

    public int clearChapterDaysPlan(long j, int i) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("viewed", (Integer) 0);
        try {
            return getDb().update("reading_plans", contentValues, "plan_id = ? AND mode_id = ? AND viewed = ?", new String[]{Long.toString(j), Integer.toString(i), Integer.toString(1)});
        } catch (Exception unused) {
            return 0;
        }
    }

    public int completeAllChapterDaysPlan(long j, int i, int i2) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("viewed", (Integer) 1);
        try {
            return getDb().update("reading_plans", contentValues, "plan_id = ? AND mode_id = ? AND day = ?", new String[]{Long.toString(j), Integer.toString(i), Integer.toString(i2)});
        } catch (Exception unused) {
            return 0;
        }
    }

    public long updateChapterDay(long j, ContentValues contentValues) {
        try {
            return update("reading_plans", j, contentValues);
        } catch (Exception unused) {
            return 0;
        }
    }

    public long updatePlanDay(long j, ContentValues contentValues) {
        try {
            return update("reading_days", j, contentValues);
        } catch (Exception unused) {
            return 0;
        }
    }
}
