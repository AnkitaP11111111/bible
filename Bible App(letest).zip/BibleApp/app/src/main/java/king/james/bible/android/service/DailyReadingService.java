package king.james.bible.android.service;

import android.content.Context;
import king.james.bible.android.R;
import java.util.Collections;
import java.util.List;
import king.james.bible.android.db.service.DailyReadingDataService;
import king.james.bible.android.model.Plan;
import king.james.bible.android.model.PlanChapterDay;
import king.james.bible.android.model.PlanDay;
import king.james.bible.android.model.PlanMode;
import king.james.bible.android.model.PlanModeColor;
import king.james.bible.android.model.comparator.PlanComparator;
import king.james.bible.android.utils.BiblePreferences;
import king.james.bible.android.utils.DateUtil;

public class DailyReadingService {
    private static DailyReadingService instance;
    private boolean dailyReadingBackStack = false;
    private DailyReadingDataService dailyReadingDataService = new DailyReadingDataService();
    private int dailyReadingPosition;

    private DailyReadingService() {
    }

    public static DailyReadingService getInstance() {
        if (instance == null) {
            synchronized (DailyReadingService.class) {
                if (instance == null) {
                    instance = new DailyReadingService();
                }
            }
        }
        return instance;
    }

    public List<Plan> getPlanList() {
        List<Plan> planList = this.dailyReadingDataService.getPlanList();
        Collections.sort(planList, new PlanComparator());
        return planList;
    }

    public void updateNotifyTime(Plan plan, boolean z, long j) {
        plan.setNotify(z);
        plan.setNotifyTime(j);
        this.dailyReadingDataService.updatePlan(plan);
    }

    public Plan startPlan(int i, Plan plan, PlanMode planMode, DailyReadingDataService.CreatePlanListener createPlanListener) {
        plan.setStartDate(DateUtil.getStartDayTime() - (((long) (i - 1)) * 86400000));
        plan.setStarted(true);
        plan.setModeId(planMode.getId());
        plan.setStarted(true);
        plan.setModeId(planMode.getId());
        return this.dailyReadingDataService.startPlan(i, plan, planMode, createPlanListener);
    }

    public void stopPlan(Plan plan) {
        this.dailyReadingDataService.stopPlan(plan);
    }

    public void viewChapter(PlanChapterDay planChapterDay) {
        planChapterDay.setViewed(true);
        this.dailyReadingDataService.viewChapter(planChapterDay);
    }

    private void viewChapter(PlanChapterDay planChapterDay, boolean z) {
        planChapterDay.setViewed(z);
        this.dailyReadingDataService.viewChapter(planChapterDay);
    }

    public void completeAll(PlanDay planDay, boolean z, int i) {
        planDay.setReaded(z);
        this.dailyReadingDataService.completeAll(planDay, i);
        for (PlanChapterDay planChapterDay : planDay.getPlanChapterDays()) {
            viewChapter(planChapterDay, z);
        }
    }

    /* renamed from: king.james.bible.android.service.DailyReadingService$1  reason: invalid class name */
    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] $SwitchMap$king$james$bible$android$model$PlanModeColor;

        /* JADX WARNING: Can't wrap try/catch for region: R(6:0|1|2|3|4|(3:5|6|8)) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x001d */
        static {
            int[] iArr = new int[PlanModeColor.values().length];
            $SwitchMap$king$james$bible$android$model$PlanModeColor = iArr;
            iArr[PlanModeColor.GREEN.ordinal()] = 1;
            $SwitchMap$king$james$bible$android$model$PlanModeColor[PlanModeColor.RED.ordinal()] = 2;
            try {
                $SwitchMap$king$james$bible$android$model$PlanModeColor[PlanModeColor.YELLOW.ordinal()] = 3;
            } catch (NoSuchFieldError unused) {
            }
        }
    }

    public static int getModeTextColorResId(PlanModeColor planModeColor, Context context) {
        boolean isNightMode = BiblePreferences.getInstance().isNightMode();
        int i = AnonymousClass1.$SwitchMap$king$james$bible$android$model$PlanModeColor[planModeColor.ordinal()];
//        return context.getResources().getColor(i != 1 ? i != 2 ? i != 3 ? 0 : isNightMode ? R.color.daily_readingmodeyellow_n : R.color.daily_readingmodename_yellow : isNightMode ? R.color.daily_readingmodered_n : R.color.daily_readingmodered : isNightMode ? R.color.daily_readingmodegreen_n : R.color.daily_readingmodename_green);
        return context.getResources().getColor(i != 1 ? i != 2 ? i != 3 ? 0 : isNightMode ? R.color.dark_light_text_shadow : R.color.dark_light_text_shadow : isNightMode ? R.color.dark_light_text_shadow : R.color.dark_light_text_shadow : isNightMode ? R.color.main_text_color_n : R.color.dark_light_text);
    }

    public int getDailyReadingPosition() {
        return this.dailyReadingPosition;
    }

    public void setDailyReadingPosition(int i) {
        this.dailyReadingPosition = i;
    }

    public boolean isDailyReadingBackStack() {
        return this.dailyReadingBackStack;
    }

    public void setDailyReadingBackStack(boolean z) {
        this.dailyReadingBackStack = z;
    }

    public void clearDailyReadingBackStack() {
        setDailyReadingBackStack(false);
        setDailyReadingPosition(0);
    }
}
