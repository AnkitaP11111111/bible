package king.james.bible.android.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.karumi.dexter.BuildConfig;
import king.james.bible.android.R;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import king.james.bible.android.db.BibleDataBase;
import king.james.bible.android.model.PlanChapterDay;
import king.james.bible.android.model.PlanDay;
import king.james.bible.android.model.chapter.ChapterShortNameAndMode;
import king.james.bible.android.service.DailyReadingCheckedService;
import king.james.bible.android.service.observable.DailyReadingActionObservable;
import king.james.bible.android.utils.BiblePreferences;
import king.james.bible.android.utils.CalendarUtil;
import king.james.bible.android.utils.ScreenUtil;

public class DailyReadingDayItemView extends RelativeLayout {
    private FlowLayout chapterContainer;
    private LinearLayout chapterContainerLinearLayout;
    private TextView dayTextView;
    private PlanDay model;

    public DailyReadingDayItemView(Context context) {
        super(context);
    }

    public DailyReadingDayItemView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public DailyReadingDayItemView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    public DailyReadingDayItemView(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
    }

    /* access modifiers changed from: protected */
    public void onFinishInflate() {
        super.onFinishInflate();
        this.dayTextView = (TextView) findViewById(R.id.dayTextView);
        this.chapterContainer = (FlowLayout) findViewById(R.id.chapterContainer);
        this.chapterContainerLinearLayout = (LinearLayout) findViewById(R.id.chapterContainerLinearLayout);
        prepareModeView();
    }

    private void prepareModeView() {
        this.dayTextView.setTextColor(getContext().getResources().getColor(BiblePreferences.getInstance().isNightMode() ? R.color.f47daily_readingplan_text_n : R.color.title_text));
    }

    public void setModel(PlanDay planDay, long j) {
        this.model = planDay;
        if (planDay != null) {
            this.dayTextView.setText(getDayName(j));
            if (this.model.isCompeteDay()) {
                completeAll();
            }
            addChapterButtons();
        }
    }

    private ViewGroup getContainerView() {
        if (!ScreenUtil.getInstance().isTablet()) {
            return this.chapterContainerLinearLayout;
        }
        return this.chapterContainer;
    }

    public void completeAll() {
        getContainerView().postDelayed(new Runnable() {
            /* class king.james.bible.android.view.$$Lambda$DailyReadingDayItemView$ROY1chm30UumBLajzmM4bg8rB34 */

            public final void run() {
                DailyReadingDayItemView.this.lambda$completeAll$0$DailyReadingDayItemView();
            }
        }, 300);
    }

    public /* synthetic */ void lambda$completeAll$0$DailyReadingDayItemView() {
        if (!(getContainerView() == null || getContext() == null)) {
            for (int i = 0; i < this.model.getPlanChapterDays().size(); i++) {
                ((Button) getContainerView().getChildAt(i)).setTextColor(getContext().getResources().getColor(BiblePreferences.getInstance().isNightMode() ? R.color.f51daily_readingviewed_n : R.color.f50daily_readingviewed));
            }
        }
    }

    private String getDayName(long j) {
        Calendar instance = Calendar.getInstance();
        instance.setTime(new Date(j + (((long) (this.model.getDay() - 1)) * 86400000)));
        int i = instance.get(2);
        int i2 = instance.get(5);
        int i3 = instance.get(7);
        return i2 + " " + CalendarUtil.getInstance().getMonthName(getContext(), i) + ", " + CalendarUtil.getInstance().getDayOfWeek(getContext(), i3);
    }

    /* JADX WARNING: Removed duplicated region for block: B:33:0x0101  */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x0105  */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x010a  */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x0119 A[SYNTHETIC] */
    private void addChapterButtons() {
        String str;
        int i;
        if (getContainerView() != null) {
            for (int i2 = 0; i2 < getContainerView().getChildCount(); i2++) {
                getContainerView().getChildAt(i2).setVisibility(8);
            }
            if (!(this.model.getPlanChapterDays() == null || this.model.getPlanChapterDays().isEmpty())) {
                for (int childCount = getContainerView().getChildCount(); childCount < this.model.getPlanChapterDays().size(); childCount++) {
                    Button button = (Button) LayoutInflater.from(getContext()).inflate(R.layout.item_plan_chapter_day, getContainerView(), false);
                    button.setVisibility(8);
                    getContainerView().addView(button);
                }
                List<ChapterShortNameAndMode> chaptersList = BibleDataBase.getInstance().getChaptersList();
                for (int i3 = 0; i3 < this.model.getPlanChapterDays().size(); i3++) {
                    final PlanChapterDay planChapterDay = this.model.getPlanChapterDays().get(i3);
                    Button button2 = (Button) getContainerView().getChildAt(i3);
                    button2.setVisibility(0);
                    int chapterOrder = planChapterDay.getChapterOrder() - 1;
                    if (chapterOrder < 0 || chapterOrder > chaptersList.size() - 1) {
                        str = BuildConfig.FLAVOR;
                    } else {
                        str = chaptersList.get(chapterOrder).getLongName();
                        if (chaptersList.get(chapterOrder).getMode() == 2) {
                            i = R.color.red_text;
                            button2.setText(str + " " + planChapterDay.getChapterNum());
                            prepareButtonModeView(button2);
                            if (planChapterDay.isViewed() || this.model.isReaded()) {
                                i = !BiblePreferences.getInstance().isNightMode() ? R.color.f51daily_readingviewed_n : R.color.f50daily_readingviewed;
                            }
                            if (i <= 0) {
                                button2.setTextColor(getContext().getResources().getColor(i));
                            }
                            button2.setOnClickListener(new OnClickListener() {
                                /* class king.james.bible.android.view.DailyReadingDayItemView.AnonymousClass1 */

                                public void onClick(View view) {
                                    DailyReadingCheckedService.getInstance().remove(DailyReadingDayItemView.this.model.getPlanId());
                                    DailyReadingActionObservable.getInstance().onViewChapter(planChapterDay);
                                }
                            });
                        }
                    }
                    i = 0;
                    button2.setText(str + " " + planChapterDay.getChapterNum());
                    prepareButtonModeView(button2);
                    if (!BiblePreferences.getInstance().isNightMode()) {
                    }
                    if (i <= 0) {
                    }
                    button2.setOnClickListener(new OnClickListener() {
                        /* class king.james.bible.android.view.DailyReadingDayItemView.AnonymousClass1 */

                        public void onClick(View view) {
                            DailyReadingCheckedService.getInstance().remove(DailyReadingDayItemView.this.model.getPlanId());
                            DailyReadingActionObservable.getInstance().onViewChapter(planChapterDay);
                        }
                    });
                }
            }
        }
    }

    private void prepareButtonModeView(Button button) {
        int i;
        int i2;
        if (BiblePreferences.getInstance().isNightMode()) {
            i2 = R.color.f32daily_readingday_buttontext_color_n;
            i = R.drawable.daily_reading_button_n;
        } else {
            i2 = R.color.title_text;
            i = R.drawable.daily_reading_button;
        }
        button.setTextColor(getContext().getResources().getColor(i2));
        button.setBackgroundResource(i);
    }
}
