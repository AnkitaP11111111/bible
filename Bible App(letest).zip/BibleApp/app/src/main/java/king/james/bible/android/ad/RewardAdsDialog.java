//package king.james.bible.android.ad;
//
//import android.app.Dialog;
//import android.content.DialogInterface;
//import android.os.Bundle;
//import android.view.View;
//import android.widget.TextView;
//import androidx.fragment.app.FragmentManager;
//import com.karumi.dexter.BuildConfig;
//import king.james.bible.android.R;
//import king.james.bible.android.dialog.BaseForegroundDialog;
//import king.james.bible.android.service.PowerManagerService;
//import king.james.bible.android.utils.BiblePreferences;
//
//public class RewardAdsDialog extends BaseForegroundDialog implements View.OnClickListener {
//    private static RewardAdsDialog rewardAdsDialog;
//    private boolean emptyReward;
//    private boolean existAction;
//    private boolean isRewardLoading;
//
//    public interface RewardAdsListener {
//        void selectCancelRewardAdsDialog();
//
//        void selectShowRewardAds();
//    }
//
//    /* access modifiers changed from: protected */
//    @Override // king.james.bible.android.dialog.BaseDialogFragment
//    public void initActions() {
//    }
//
//    public static void show(FragmentManager fragmentManager, boolean z) {
//        show(fragmentManager, false, z);
//    }
//
//    public static void showEmptyReward(FragmentManager fragmentManager) {
//        show(fragmentManager, true, false);
//    }
//
//    public static void show(FragmentManager fragmentManager, boolean z, boolean z2) {
//        if (rewardAdsDialog != null) {
//            rewardAdsDialog = null;
//        }
//        try {
//            RewardAdsDialog rewardAdsDialog2 = new RewardAdsDialog();
//            rewardAdsDialog = rewardAdsDialog2;
//            rewardAdsDialog2.setEmptyReward(z);
//            rewardAdsDialog.setRewardLoading(z2);
//            rewardAdsDialog.show(fragmentManager, BuildConfig.FLAVOR);
//        } catch (Exception unused) {
//        }
//    }
//
//    public static void hideDialog() {
//        try {
//            rewardAdsDialog.dismiss();
//            rewardAdsDialog = null;
//        } catch (Exception unused) {
//        }
//    }
//
//    public void setEmptyReward(boolean z) {
//        this.emptyReward = z;
//    }
//
//    public void setRewardLoading(boolean z) {
//        this.isRewardLoading = z;
//    }
//
//    @Override // androidx.fragment.app.DialogFragment
//    public Dialog onCreateDialog(Bundle bundle) {
//        this.existAction = false;
//        Dialog onCreateDialog = super.onCreateDialog(bundle);
//        onCreateDialog.getWindow().requestFeature(1);
//        return onCreateDialog;
//    }
//
//    /* access modifiers changed from: protected */
//    @Override // king.james.bible.android.dialog.BaseDialogFragment
//    public int getLayoutResourceId() {
//        return BiblePreferences.getInstance().isNightMode() ? R.layout.fragment_reward_ads_dialog_n : R.layout.fragment_reward_ads_dialog;
//    }
//
//    /* access modifiers changed from: protected */
//    @Override // king.james.bible.android.dialog.BaseDialogFragment
//    public void mapViews(View view) {
//        View findViewById = view.findViewById(R.id.cancelButton);
//        if (this.emptyReward) {
//            findViewById.setVisibility(4);
//        } else {
//            findViewById.setVisibility(0);
//            findViewById.setOnClickListener(this);
//        }
//        View findViewById2 = view.findViewById(R.id.showButton);
//        View findViewById3 = view.findViewById(R.id.loadingContainer);
//        if (this.isRewardLoading) {
//            findViewById3.setVisibility(0);
//            findViewById2.setVisibility(8);
//        } else {
//            findViewById3.setVisibility(8);
//            findViewById2.setVisibility(0);
//            findViewById2.setOnClickListener(this);
//        }
//        view.findViewById(R.id.closeImageButton).setOnClickListener(this);
//        ((TextView) view.findViewById(R.id.textTextView)).setText(getTextResId());
//        ((TextView) view.findViewById(R.id.titleTextView)).setText(getTitleResId());
//        ((TextView) view.findViewById(R.id.showTextView)).setText(getActionTextResId());
//        PowerManagerService.getInstance().start();
//    }
//
//    /* access modifiers changed from: protected */
//    public int getTextResId() {
//        return this.emptyReward ? R.string.dialog_ads_load_video_error_content : R.string.dialog_ads_remove_video_content;
//    }
//
//    /* access modifiers changed from: protected */
//    public int getTitleResId() {
//        return this.emptyReward ? R.string.dialog_ads_load_video_error_title : R.string.dialog_ads_remove_video_title;
//    }
//
//    /* access modifiers changed from: protected */
//    public int getActionTextResId() {
//        return this.emptyReward ? R.string.dialog_ads_load_video_error_btn : R.string.dialog_ads_load_video_show_btn;
//    }
//
//    public void onClick(View view) {
//        int id = view.getId();
//        if (id == R.id.cancelButton || id == R.id.closeImageButton) {
//            this.existAction = true;
//            selectCancel();
//            dismiss();
//        } else if (id == R.id.showButton) {
//            this.existAction = true;
//            dismiss();
//            if (this.emptyReward) {
//                selectCancel();
//            } else {
//                selectShow();
//            }
//        }
//    }
//
//    @Override // androidx.fragment.app.DialogFragment
//    public void onDismiss(DialogInterface dialogInterface) {
//        super.onDismiss(dialogInterface);
//        if (!this.existAction) {
//            selectCancel();
//        }
//    }
//
//    /* access modifiers changed from: protected */
//    public void selectShow() {
//        RewardAdsListenerObservable.getInstance().selectShowRewardAds();
//    }
//
//    /* access modifiers changed from: protected */
//    public void selectCancel() {
//        RewardAdsListenerObservable.getInstance().selectCancelRewardAdsDialog();
//    }
//}
