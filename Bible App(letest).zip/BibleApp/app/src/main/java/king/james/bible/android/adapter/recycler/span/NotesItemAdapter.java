package king.james.bible.android.adapter.recycler.span;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.text.Html;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.karumi.dexter.BuildConfig;
import king.james.bible.android.R;
import java.util.ArrayList;
import java.util.Map;
import king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter;
import king.james.bible.android.adapter.recycler.OnItemSpanClickListener;
import king.james.bible.android.adapter.recycler.span.NotesItemAdapter;
import king.james.bible.android.db.BibleDataBase;
import king.james.bible.android.model.span.SpanItem;
import king.james.bible.android.utils.AppUtils;
import king.james.bible.android.utils.BiblePreferences;
import king.james.bible.android.utils.SettingsTextUtil;
@SuppressLint({"NewApi", "WrongConstant"})

public class NotesItemAdapter extends BaseRecyclerViewAdapter<NotesItemAdapter.NoteViewHolder> {
    private  NoteViewHolder r2;
    private int layoutResId;
    private Map<Integer, String> mChapterNameMap;
    private Map<Integer, String> mChapterNameMapN;
    private ArrayList<SpanItem> models;
    private OnItemSpanClickListener onItemSpanClickListener;
    private int screenWidth;
    private String searchText;

    public static NotesItemAdapter create(OnItemSpanClickListener onItemSpanClickListener2) {
        int i = BiblePreferences.getInstance().isNightMode() ? R.layout.notes_item_layout_n : R.layout.notes_item_layout;
        NotesItemAdapter notesItemAdapter = new NotesItemAdapter(null);
        notesItemAdapter.layoutResId = i;
        BibleDataBase instance = BibleDataBase.getInstance();
        instance.initColumSearchName();
        notesItemAdapter.mChapterNameMap = instance.getChapterNameMap();
        notesItemAdapter.mChapterNameMapN = instance.getChapterNameMapN();
        notesItemAdapter.onItemSpanClickListener = onItemSpanClickListener2;
        notesItemAdapter.models = new ArrayList<>();
        return notesItemAdapter;
    }

    public void setSearchText(String str) {
        this.searchText = str;
    }

    public void initWidth(Activity activity) {
        if (activity != null) {
            DisplayMetrics displayMetrics = new DisplayMetrics();
            activity.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
            this.screenWidth = displayMetrics.widthPixels;
        }
    }

    public void updateModels(ArrayList<SpanItem> arrayList) {
        this.models = arrayList;
        notifyDataSetChanged();
    }

    private NotesItemAdapter(OnItemClickListener onItemClickListener) {
        super(onItemClickListener);
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter
    public NoteViewHolder doCreateViewHolder(ViewGroup viewGroup, int i) {
        return new NoteViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(this.layoutResId, viewGroup, false));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter, king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter, king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter
    public NoteViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        NoteViewHolder noteViewHolder = (NoteViewHolder) super.onCreateViewHolder(viewGroup, i);
        noteViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            /* class king.james.bible.android.adapter.recycler.span.$$Lambda$NotesItemAdapter$38RgwXNEAVADmCXrYhhUVTq3k4c */
            private final /* synthetic */ NoteViewHolder f$1;

            {
                this.f$1 = r2;
            }

            public final void onClick(View view) {
                NotesItemAdapter.this.lambda$onCreateViewHolder$0$NotesItemAdapter(this.f$1, view);
            }
        });
        noteViewHolder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            /* class king.james.bible.android.adapter.recycler.span.$$Lambda$NotesItemAdapter$Q3Zaw688T2F0TcH0fdSCHb1jQ */
            private final /* synthetic */ NoteViewHolder f$1;

            {
                this.f$1 = r2;
            }

            public final boolean onLongClick(View view) {
                return NotesItemAdapter.this.lambda$onCreateViewHolder$1$NotesItemAdapter(this.f$1, view);
            }
        });
        return noteViewHolder;
    }

    public /* synthetic */ void lambda$onCreateViewHolder$0$NotesItemAdapter(NoteViewHolder noteViewHolder, View view) {
        OnItemSpanClickListener onItemSpanClickListener2 = this.onItemSpanClickListener;
        if (onItemSpanClickListener2 != null) {
            onItemSpanClickListener2.onClick(noteViewHolder.getAdapterPosition(), noteViewHolder.itemView, false);
        }
    }

    public /* synthetic */ boolean lambda$onCreateViewHolder$1$NotesItemAdapter(NoteViewHolder noteViewHolder, View view) {
        OnItemSpanClickListener onItemSpanClickListener2 = this.onItemSpanClickListener;
        if (onItemSpanClickListener2 == null) {
            return false;
        }
        onItemSpanClickListener2.onClick(noteViewHolder.getAdapterPosition(), noteViewHolder.itemView, true);
        return false;
    }

    @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter
    public SpanItem getModel(int i) {
        return this.models.get(i);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.models.size();
    }

    public class NoteViewHolder extends BaseViewHolder {
        private LinearLayout delLayout;
        private TextView text1TextView;
        private TextView timeTextView;
        private TextView titleTextView;

        NoteViewHolder(View view) {
            super(view);
        }

        /* access modifiers changed from: protected */
        @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter.BaseViewHolder
        public void mapViews(View view) {
            this.text1TextView = (TextView) view.findViewById(R.id.note_item_text);
            this.titleTextView = (TextView) view.findViewById(R.id.note_item_title);
            this.timeTextView = (TextView) view.findViewById(R.id.note_item_time);
            RelativeLayout relativeLayout = (RelativeLayout) view.findViewById(R.id.note_item_layout);
            relativeLayout.measure(0, 0);
            SettingsTextUtil.setupTextViewSettings(this.text1TextView);
            SettingsTextUtil.setupTextViewSettings(this.titleTextView);
            SettingsTextUtil.setupTextViewSettings(this.timeTextView);
            SettingsTextUtil.prepareTimeTextView(this.timeTextView);
            SettingsTextUtil.prepareTitleTextView(this.titleTextView);
            LinearLayout linearLayout = (LinearLayout) view.findViewById(R.id.note_item_del_layout);
            this.delLayout = linearLayout;
            linearLayout.getLayoutParams().height = relativeLayout.getMeasuredHeight();
        }

        @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter.BaseViewHolder
        public void updateView(Object obj) {
            String str;
            if (obj != null) {
                SpanItem spanItem = (SpanItem) obj;
                this.delLayout.setVisibility(8);
                boolean containsKey = NotesItemAdapter.this.mChapterNameMap.containsKey(Integer.valueOf(spanItem.chapterId));
                String str2 = BuildConfig.FLAVOR;
                if (containsKey) {
                    str2 = (String) NotesItemAdapter.this.mChapterNameMap.get(Integer.valueOf(spanItem.chapterId));
                    str = (String) NotesItemAdapter.this.mChapterNameMapN.get(Integer.valueOf(spanItem.chapterId));
                } else {
                    str = str2;
                }
                String str3 = str2 + " " + spanItem.chapterNum + ":" + spanItem.columnPosition;
                String str4 = str + " " + spanItem.chapterNum + ":" + spanItem.columnPosition;
                if (!TextUtils.isEmpty(NotesItemAdapter.this.searchText)) {
                    this.titleTextView.setText(Html.fromHtml(AppUtils.replaceOnBoldSearch(str3, str4, NotesItemAdapter.this.searchText, "<b>" + NotesItemAdapter.this.searchText + "</b>")));
                } else {
                    this.titleTextView.setText(str3);
                }
                if (!spanItem.date.isEmpty()) {
                    this.timeTextView.setText(spanItem.date);
                    this.timeTextView.setVisibility(0);
                } else {
                    this.timeTextView.setVisibility(4);
                }
                this.text1TextView.setText(Html.fromHtml(SettingsTextUtil.prepareText(spanItem.text)));
                this.text1TextView.setTag(Long.valueOf(spanItem.id));
                this.titleTextView.measure(0, 0);
                this.timeTextView.measure(0, 0);
                if (NotesItemAdapter.this.screenWidth - (this.itemView.getContext().getResources().getDimensionPixelSize(R.dimen.padding_element_nhb) * 2) <= this.titleTextView.getMeasuredWidth() + this.timeTextView.getMeasuredWidth()) {
                    RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) this.titleTextView.getLayoutParams();
                    layoutParams.addRule(10, 0);
                    layoutParams.addRule(3, R.id.note_item_time);
                    layoutParams.addRule(9, -1);
                    this.titleTextView.setLayoutParams(layoutParams);
                    return;
                }
                RelativeLayout.LayoutParams layoutParams2 = (RelativeLayout.LayoutParams) this.titleTextView.getLayoutParams();
                layoutParams2.addRule(3, 0);
                layoutParams2.addRule(10, -1);
                layoutParams2.addRule(9, -1);
                this.titleTextView.setLayoutParams(layoutParams2);
            }
        }
    }
}
