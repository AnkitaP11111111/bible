package king.james.bible.android.utils;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.text.Layout;
import android.text.style.LeadingMarginSpan;

public class MyLeadingMarginSpan2 implements LeadingMarginSpan.LeadingMarginSpan2 {
    private int lines;
    private int margin;

    public void drawLeadingMargin(Canvas canvas, Paint paint, int i, int i2, int i3, int i4, int i5, CharSequence charSequence, int i6, int i7, boolean z, Layout layout) {
    }

    public MyLeadingMarginSpan2(int i, int i2) {
        this.margin = i2;
        this.lines = i;
    }

    public int getLeadingMargin(boolean z) {
        if (z) {
            return this.margin;
        }
        return 0;
    }

    public int getLeadingMarginLineCount() {
        return this.lines;
    }
}
