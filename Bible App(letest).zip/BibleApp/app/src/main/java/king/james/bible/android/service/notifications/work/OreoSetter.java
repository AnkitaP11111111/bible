package king.james.bible.android.service.notifications.work;

import android.app.AlarmManager;
import android.app.PendingIntent;

/* access modifiers changed from: package-private */
public class OreoSetter extends ISetAlarmStrategy {
    OreoSetter() {
    }

    /* access modifiers changed from: package-private */
    @Override // king.james.bible.android.service.notifications.work.ISetAlarmStrategy
    public void setRTCAlarm(AlarmManager alarmManager, long j, PendingIntent pendingIntent) {
        alarmManager.setExactAndAllowWhileIdle(0, j, pendingIntent);
    }
}
