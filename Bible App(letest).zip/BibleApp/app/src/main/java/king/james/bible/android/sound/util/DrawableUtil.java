package king.james.bible.android.sound.util;

import android.content.Context;
import android.graphics.drawable.Drawable;
import king.james.bible.android.R;
import java.util.HashMap;
import java.util.Map;
import king.james.bible.android.utils.BiblePreferences;

public class DrawableUtil {
    private static DrawableUtil INSTANCE;
    private Map<SoundAction, Drawable> cache = new HashMap();

    private DrawableUtil() {
    }

    public static DrawableUtil getInstance() {
        if (INSTANCE == null) {
            synchronized (DrawableUtil.class) {
                if (INSTANCE == null) {
                    INSTANCE = new DrawableUtil();
                }
            }
        }
        return INSTANCE;
    }

    public void init(Context context) {
        if (this.cache == null) {
            this.cache = new HashMap();
        }
        if (context != null && context.getResources() != null) {
            this.cache.put(SoundAction.PLAY_ACTION, context.getResources().getDrawable(getResourceByAction(SoundAction.PLAY_ACTION)));
            this.cache.put(SoundAction.PAUSE_ACTION, context.getResources().getDrawable(getResourceByAction(SoundAction.PAUSE_ACTION)));
            this.cache.put(SoundAction.PLAY_REPEAT_ACTION, context.getResources().getDrawable(getResourceByAction(SoundAction.PLAY_REPEAT_ACTION)));
            this.cache.put(SoundAction.PAUSE_REPEAT_ACTION, context.getResources().getDrawable(getResourceByAction(SoundAction.PAUSE_REPEAT_ACTION)));
        }
    }

    public Drawable getDrawable(SoundAction soundAction) {
        return this.cache.get(soundAction);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: king.james.bible.android.sound.util.DrawableUtil$1  reason: invalid class name */
    public static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] $SwitchMap$king$james$bible$android$sound$util$SoundAction;

        /* JADX WARNING: Can't wrap try/catch for region: R(8:0|1|2|3|4|5|6|(3:7|8|10)) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x001d */
        /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x0028 */
        static {
            int[] iArr = new int[SoundAction.values().length];
            $SwitchMap$king$james$bible$android$sound$util$SoundAction = iArr;
            iArr[SoundAction.PAUSE_ACTION.ordinal()] = 1;
            $SwitchMap$king$james$bible$android$sound$util$SoundAction[SoundAction.PLAY_ACTION.ordinal()] = 2;
            $SwitchMap$king$james$bible$android$sound$util$SoundAction[SoundAction.PAUSE_REPEAT_ACTION.ordinal()] = 3;
            try {
                $SwitchMap$king$james$bible$android$sound$util$SoundAction[SoundAction.PLAY_REPEAT_ACTION.ordinal()] = 4;
            } catch (NoSuchFieldError unused) {
            }
        }
    }

    public int getResourceByAction(SoundAction soundAction) {
        boolean isNightMode = BiblePreferences.getInstance().isNightMode();
        int i = AnonymousClass1.$SwitchMap$king$james$bible$android$sound$util$SoundAction[soundAction.ordinal()];
        if (i == 1) {
            return isNightMode ? R.drawable.sound_button_pause_n : R.drawable.sound_button_pause;
        }
        if (i == 2) {
            return isNightMode ? R.drawable.sound_button_play_n : R.drawable.sound_button_play;
        }
        if (i == 3) {
            return isNightMode ? R.drawable.sound_repeat_button_pause_n : R.drawable.sound_repeat_button_pause;
        }
        if (i != 4) {
            return 0;
        }
        return isNightMode ? R.drawable.sound_repeat_button_play_n : R.drawable.sound_repeat_button_play;
    }
}
