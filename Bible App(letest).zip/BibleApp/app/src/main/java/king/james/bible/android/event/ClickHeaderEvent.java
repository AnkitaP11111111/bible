package king.james.bible.android.event;

public class ClickHeaderEvent {
    private int rank;
    private int unicId;

    public ClickHeaderEvent(int i, int i2) {
        this.rank = i;
        this.unicId = i2;
    }

    public int getUnicId() {
        return this.unicId;
    }

    public int getRank() {
        return this.rank;
    }
}
