package king.james.bible.android.service.notifications.work;

import android.os.Build;

/* access modifiers changed from: package-private */
public class SetterFabric {
    static ISetAlarmStrategy getAlarmStrategy() {
        int i = Build.VERSION.SDK_INT;
        if (i >= 26) {
            return new OreoSetter();
        }
        if (i >= 23) {
            return new MarshmallowSetter();
        }
        if (i >= 19) {
            return new KitKatSetter();
        }
        return new IceCreamSetter();
    }
}
