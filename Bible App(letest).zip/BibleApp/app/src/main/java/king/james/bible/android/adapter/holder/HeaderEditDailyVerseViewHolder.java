package king.james.bible.android.adapter.holder;

import android.annotation.SuppressLint;
import android.view.KeyEvent;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import king.james.bible.android.R;
import king.james.bible.android.dialog.DialogUtil;
import king.james.bible.android.dialog.NotifyDialog;
import king.james.bible.android.service.observable.NotifyTimeListenerObservable;
import king.james.bible.android.utils.BiblePreferences;
import king.james.bible.android.utils.DateUtil;
import king.james.bible.android.utils.ScreenUtil;
@SuppressLint({"NewApi", "WrongConstant"})

public class HeaderEditDailyVerseViewHolder extends EditDailyVerseViewHolder implements NotifyDialog.NotifyTimeListener {
    private EditText inputEditText;
    private boolean modelNotify;
    private boolean modelSelectAll;
    private String modelTitle;
    private TextView notificationTimeTextView;
    private SwitchCompat notifySwitchCompat;
    private long notifyTime;
    private CompoundButton.OnCheckedChangeListener onCheckedChangeListener;
    private CheckBox selectAllCheckBox;
    private TextView selectCountTextView;

    @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter.BaseViewHolder
    public void updateView(Object obj) {
    }

    public HeaderEditDailyVerseViewHolder(View view, boolean z, String str, boolean z2, long j) {
        super(view);
        this.modelSelectAll = z;
        this.modelTitle = str;
        this.modelNotify = z2;
        this.notifyTime = j;
        setModels();
        NotifyTimeListenerObservable.getInstance().subscribe(this);
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter.BaseViewHolder
    public void mapViews(View view) {
        this.selectAllCheckBox = (CheckBox) view.findViewById(R.id.selectAllCheckBox);
        this.selectCountTextView = (TextView) view.findViewById(R.id.selectCountTextView);
        this.inputEditText = (EditText) view.findViewById(R.id.inputEditText);
        this.notifySwitchCompat = (SwitchCompat) view.findViewById(R.id.notifySwitchCompat);
        this.notificationTimeTextView = (TextView) view.findViewById(R.id.notificationTimeTextView);
        initNotifyCheckListener();
        this.notifySwitchCompat.setOnCheckedChangeListener(this.onCheckedChangeListener);
        this.inputEditText.setBackgroundResource(BiblePreferences.getInstance().isNightMode() ? R.color.abc_decor_view_status_guard : R.color.ad_label_bg_night);
    }

    private void setModels() {
        this.selectAllCheckBox.setChecked(this.modelSelectAll);
        this.inputEditText.setText(this.modelTitle);
        EditText editText = this.inputEditText;
        editText.setSelection(editText.getText().length());
        selectNotifyTime(0, this.modelNotify, this.notifyTime);
        this.inputEditText.setOnKeyListener(new View.OnKeyListener() {
            /* class king.james.bible.android.adapter.holder.HeaderEditDailyVerseViewHolder.AnonymousClass1 */

            public boolean onKey(View view, int i, KeyEvent keyEvent) {
                if (i != 66) {
                    return false;
                }
                ScreenUtil.getInstance().hideKeyboard(view);
                return true;
            }
        });
        updateTime();
    }

    private void initNotifyCheckListener() {
        this.onCheckedChangeListener = new CompoundButton.OnCheckedChangeListener() {
            /* class king.james.bible.android.adapter.holder.HeaderEditDailyVerseViewHolder.AnonymousClass2 */

            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                if (!z) {
                    HeaderEditDailyVerseViewHolder.this.hideTimeView();
                } else {
                    DialogUtil.showNotifyDialog(((AppCompatActivity) HeaderEditDailyVerseViewHolder.this.itemView.getContext()).getSupportFragmentManager(), 0, z, HeaderEditDailyVerseViewHolder.this.notifyTime);
                }
            }
        };
    }

    public void updateView(boolean z, String str) {
        if (this.selectAllCheckBox.isChecked() != z) {
            this.selectAllCheckBox.setChecked(z);
        }
        this.selectCountTextView.setText(str);
    }

    public void setSelectAllCheckBoxListener(CompoundButton.OnCheckedChangeListener onCheckedChangeListener2) {
        this.selectAllCheckBox.setOnCheckedChangeListener(onCheckedChangeListener2);
    }

    private void updateTime() {
        this.notificationTimeTextView.setText(DateUtil.getInstance().getNotifyTime(this.notifyTime, this.itemView.getContext()));
    }

    private void showTimeView() {
        this.notificationTimeTextView.setVisibility(0);
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void hideTimeView() {
        this.notificationTimeTextView.setVisibility(8);
    }

    @Override // king.james.bible.android.dialog.NotifyDialog.NotifyTimeListener
    public void selectNotifyTime(long j, boolean z, long j2) {
        this.notifyTime = j2;
        if (z) {
            try {
                this.notifySwitchCompat.setOnCheckedChangeListener(null);
                showTimeView();
            } catch (Exception unused) {
                return;
            }
        } else {
            hideTimeView();
        }
        this.notifySwitchCompat.setChecked(z);
        updateTime();
        this.notifySwitchCompat.setOnCheckedChangeListener(this.onCheckedChangeListener);
    }

    @Override // king.james.bible.android.dialog.NotifyDialog.NotifyTimeListener
    public void cancelNotifyDialog() {
        selectNotifyTime(0, false, 0);
    }

    public String getTitle() {
        return this.inputEditText.getText().toString();
    }

    public boolean isNotify() {
        return this.notifySwitchCompat.isChecked();
    }

    public long getNotifyTime() {
        return this.notifyTime;
    }
}
