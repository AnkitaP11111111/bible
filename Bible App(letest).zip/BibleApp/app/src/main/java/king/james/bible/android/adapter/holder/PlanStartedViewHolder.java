package king.james.bible.android.adapter.holder;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;
import king.james.bible.android.R;
import java.util.Calendar;
import king.james.bible.android.adapter.pager.DailyReadingDayAdapter;
import king.james.bible.android.dialog.DialogUtil;
import king.james.bible.android.dialog.NotifyDialog;
import king.james.bible.android.model.Plan;
import king.james.bible.android.model.PlanChapterDay;
import king.james.bible.android.model.PlanDay;
import king.james.bible.android.model.PlanMode;
import king.james.bible.android.service.DailyReadingCheckedService;
import king.james.bible.android.service.DailyReadingService;
import king.james.bible.android.service.observable.DailyReadingActionObservable;
import king.james.bible.android.service.observable.NotifyTimeListenerObservable;
import king.james.bible.android.utils.AppUtils;
import king.james.bible.android.utils.BiblePreferences;
import king.james.bible.android.utils.DailyReadingCache;
import king.james.bible.android.utils.DateUtil;
import king.james.bible.android.utils.ScreenUtil;
import king.james.bible.android.view.DailyReadingDayItemView;
@SuppressLint({"NewApi", "WrongConstant"})

public class PlanStartedViewHolder extends DailyReadingBaseViewHolder implements DailyReadingCheckedService.DailyReadingCheckedHandler, NotifyDialog.NotifyTimeListener {
    private  boolean r2;
    private CheckBox completeAllCheckBox;
    private PlanDay currentDay;
    private DailyReadingDayAdapter dailyReadingDayAdapter;
    private RelativeLayout dayRelativeLayout;
    private TextView dayTextView;
    private ViewPager dayViewPager;
    private boolean firstCheck = true;
    private TextView modeNameTextView;
    private RelativeLayout notificationRelativeLayout;
    private TextView notificationTimeTextView;
    private Plan plan;
    private Button planButton;
    private PlanMode planMode;
    private ProgressBar progress;
    private TextView progressTextView;
    private Button stopButton;
    private TextView titleTextView;
    private ImageView toLeftImageView;
    private ImageView toRightImageView;
    private View.OnClickListener r0;

    @Override // king.james.bible.android.dialog.NotifyDialog.NotifyTimeListener
    public void cancelNotifyDialog() {
    }

    public PlanStartedViewHolder(View view) {
        super(view);
        NotifyTimeListenerObservable.getInstance().subscribe(this);
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter.BaseViewHolder
    public void mapViews(View view) {
        this.titleTextView = (TextView) view.findViewById(R.id.titleTextView);
        this.modeNameTextView = (TextView) view.findViewById(R.id.modeNameTextView);
        this.dayViewPager = (ViewPager) view.findViewById(R.id.dayViewPager);
        this.planButton = (Button) view.findViewById(R.id.planButton);
        this.stopButton = (Button) view.findViewById(R.id.stopButton);
        this.toLeftImageView = (ImageView) view.findViewById(R.id.toLeftImageView);
        this.toRightImageView = (ImageView) view.findViewById(R.id.toRightImageView);
        this.dayRelativeLayout = (RelativeLayout) view.findViewById(R.id.dayRelativeLayout);
        this.progress = (ProgressBar) view.findViewById(R.id.progress);
        this.progressTextView = (TextView) view.findViewById(R.id.progressTextView);
        this.completeAllCheckBox = (CheckBox) view.findViewById(R.id.completeAllCheckBox);
        this.notificationRelativeLayout = (RelativeLayout) view.findViewById(R.id.notificationRelativeLayout);
        this.notificationTimeTextView = (TextView) view.findViewById(R.id.notificationTimeTextView);
        this.dayTextView = (TextView) view.findViewById(R.id.dayTextView);
        this.stopButton.setOnClickListener(new View.OnClickListener() {
            /* class king.james.bible.android.adapter.holder.$$Lambda$PlanStartedViewHolder$CAosE7kDQwQhn4W6j0DdkwvrhlI */

            public final void onClick(View view) {
                PlanStartedViewHolder.this.lambda$mapViews$0$PlanStartedViewHolder(view);
            }
        });
        this.planButton.setOnClickListener(new View.OnClickListener() {
            /* class king.james.bible.android.adapter.holder.$$Lambda$PlanStartedViewHolder$1yV1p56ANXbP1hhJmcCVH7vR354 */

            public final void onClick(View view) {
                PlanStartedViewHolder.this.lambda$mapViews$1$PlanStartedViewHolder(view);
            }
        });
        this.notificationRelativeLayout.setOnClickListener(new View.OnClickListener() {
            /* class king.james.bible.android.adapter.holder.$$Lambda$PlanStartedViewHolder$gvCfG43asGb5FTqAEmb6HoAFgO4 */

            public final void onClick(View view) {
                PlanStartedViewHolder.this.lambda$mapViews$2$PlanStartedViewHolder(view);
            }
        });
        prepareModeView();
        prepareNavigationButtons();
        setPageListener();
        setLockTimeChecked();
    }

    public /* synthetic */ void lambda$mapViews$0$PlanStartedViewHolder(View view) {
        DailyReadingActionObservable.getInstance().onStopPlan(this.plan);
    }

    public /* synthetic */ void lambda$mapViews$1$PlanStartedViewHolder(View view) {
        DailyReadingActionObservable.getInstance().onShowPlanDescription(this.plan);
    }

    public /* synthetic */ void lambda$mapViews$2$PlanStartedViewHolder(View view) {
        DialogUtil.showNotifyDialog(((AppCompatActivity) this.itemView.getContext()).getSupportFragmentManager(), this.plan.getId(), this.plan.isNotify(), this.plan.getNotifyTime());
    }

    private void setLockTimeChecked() {
        this.completeAllCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            /* class king.james.bible.android.adapter.holder.$$Lambda$PlanStartedViewHolder$1exJB4C3T7fsqtGm4gxfjalB_Y */

            public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                PlanStartedViewHolder.this.lambda$setLockTimeChecked$3$PlanStartedViewHolder(compoundButton, z);
            }
        });
    }

    public /* synthetic */ void lambda$setLockTimeChecked$3$PlanStartedViewHolder(CompoundButton compoundButton, boolean z) {
        this.completeAllCheckBox.setEnabled(false);
        this.completeAllCheckBox.postDelayed(new Runnable() {
            /* class king.james.bible.android.adapter.holder.PlanStartedViewHolder.AnonymousClass1 */

            public void run() {
                if (PlanStartedViewHolder.this.itemView.getContext() != null && PlanStartedViewHolder.this.completeAllCheckBox != null) {
                    PlanStartedViewHolder.this.completeAllCheckBox.setEnabled(true);
                }
            }
        }, 900);
    }

    private void prepareModeView() {
        int i;
        int i2;
        int i3;
        int i4;
        int i5;
        int i6;
        int i7;
        boolean isNightMode = BiblePreferences.getInstance().isNightMode();
        int i8 = R.color.title_text;
        if (isNightMode) {
            i7 = R.drawable.daily_reading_button_n;
            i8 = R.color.ad_content_day_call_to_action;
            i6 = R.color.bright_foreground_material_light;
            i5 = R.drawable.daily_reading_left_n;
            i4 = R.drawable.daily_reading_right_n;
            i3 = R.color.white;
            i2 = R.drawable.daily_reading_progress_n;
            i = R.drawable.btn_check_holo_light_2_n;
        } else {
            i7 = R.drawable.daily_reading_button;
            i6 = R.color.ad_button_night_bg_start_color;
            i5 = R.drawable.daily_reading_left;
            i4 = R.drawable.daily_reading_right;
            i2 = R.drawable.daily_reading_progress;
            i = R.drawable.btn_check_holo_light_2;
            i3 = R.color.title_text;
        }
        this.planButton.setBackgroundResource(i7);
        this.planButton.setTextColor(this.itemView.getResources().getColor(i8));
        this.stopButton.setBackgroundResource(i7);
        this.stopButton.setTextColor(this.itemView.getResources().getColor(i6));
        this.toLeftImageView.setImageResource(i5);
        this.toRightImageView.setImageResource(i4);
        this.progressTextView.setTextColor(this.itemView.getResources().getColor(i3));
        this.progress.setProgressDrawable(this.itemView.getResources().getDrawable(i2));
        this.completeAllCheckBox.setButtonDrawable(i);
    }

    private void prepareNavigationButtons() {
      r0 = new View.OnClickListener() {
            /* class king.james.bible.android.adapter.holder.$$Lambda$PlanStartedViewHolder$gncbCQ908KUlHZpxglakXV_L8xo */

            public final void onClick(View view) {
                PlanStartedViewHolder.this.lambda$prepareNavigationButtons$4$PlanStartedViewHolder(view);
            }
        };
        this.toLeftImageView.setOnClickListener(r0);
        this.toRightImageView.setOnClickListener(r0);
    }

    public /* synthetic */ void lambda$prepareNavigationButtons$4$PlanStartedViewHolder(View view) {
        ViewPager viewPager = this.dayViewPager;
        if (viewPager != null) {
            int currentItem = viewPager.getCurrentItem();
            int i = view.getId() == R.id.toLeftImageView ? currentItem - 1 : currentItem + 1;
            DailyReadingDayAdapter dailyReadingDayAdapter2 = this.dailyReadingDayAdapter;
            if (dailyReadingDayAdapter2 != null && i < dailyReadingDayAdapter2.getCount() && i >= 0) {
                this.positionListener.newPosition(getLayoutPosition(), i);
                this.dayPosition = i;
                this.dayViewPager.setCurrentItem(i, true);
            }
        }
    }

    private void setPageListener() {
        this.dayViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            /* class king.james.bible.android.adapter.holder.PlanStartedViewHolder.AnonymousClass2 */

            @Override // androidx.viewpager.widget.ViewPager.OnPageChangeListener
            public void onPageScrollStateChanged(int i) {
            }

            @Override // androidx.viewpager.widget.ViewPager.OnPageChangeListener
            public void onPageScrolled(int i, float f, int i2) {
            }

            @Override // androidx.viewpager.widget.ViewPager.OnPageChangeListener
            public void onPageSelected(int i) {
                PlanStartedViewHolder.this.pageSelected(i);
            }
        });
    }

    @Override // king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter.BaseViewHolder
    public void updateView(Object obj) {
        this.plan = (Plan) obj;
        updateView(false);
    }

    public static long daysBetween(long j, long j2) {
        Calendar datePart = getDatePart(j);
        Calendar datePart2 = getDatePart(j2);
        long j3 = 0;
        while (datePart.before(datePart2)) {
            datePart.add(5, 1);
            j3++;
        }
        return j3;
    }

    public static Calendar getDatePart(long j) {
        Calendar instance = Calendar.getInstance();
        instance.setTimeInMillis(j);
        instance.set(11, 0);
        instance.set(12, 0);
        instance.set(13, 0);
        instance.set(14, 0);
        return instance;
    }

    private void updateView(boolean z) {
        Plan plan2 = this.plan;
        if (plan2 != null && plan2.getPlanDays() != null && !this.plan.getPlanDays().isEmpty()) {
            DailyReadingCheckedService.getInstance().remove(this.plan.getId());
            if (!z) {
                this.planMode = this.plan.getPlanMode();
            }
            if (!z) {
                DailyReadingDayAdapter dailyReadingDayAdapter2 = new DailyReadingDayAdapter(this.itemView.getContext(), this.plan.getPlanDays(), this.plan.getStartDate(), this.planMode.getDayCount());
                this.dailyReadingDayAdapter = dailyReadingDayAdapter2;
                this.dayViewPager.setAdapter(dailyReadingDayAdapter2);
            } else {
                this.dailyReadingDayAdapter.setItems(this.plan.getPlanDays());
            }
            this.dailyReadingDayAdapter.notifyDataSetChanged();
            long daysBetween = daysBetween(this.plan.getStartDate(), System.currentTimeMillis());
            int i = this.dayPosition;
            if (i <= 0) {
                i = (int) daysBetween;
            }
            if (i >= this.plan.getPlanDays().size()) {
                i = this.plan.getPlanDays().size() - 1;
                this.dayPosition = i;
                DailyReadingCache.put(this.plan.getId(), i);
            }
            if ((i >= this.dailyReadingDayAdapter.getCountModels() && !z) || i < 0) {
                this.dayPosition = 0;
                DailyReadingCache.put(this.plan.getId(), 0);
                i = 0;
            }
            updateHeightContainer(this.plan.getPlanDays().get(i).getPlanChapterDays().size());
            if (!z) {
                prepareNotifyView();
                this.dayViewPager.setCurrentItem(i);
                setDay(i + 1);
                firstUpdate(i);
                boolean isCompeteDay = this.plan.getPlanDays().get(i).isCompeteDay();
                this.completeAllCheckBox.setChecked(isCompeteDay);
                this.firstCheck = isCompeteDay;
                updateTextView();
                updateProgress();
            }
            DailyReadingCheckedService.getInstance().add(this.plan.getId(), this.completeAllCheckBox, this);
        }
    }

    private void prepareNotifyView() {
        if (this.plan.isNotify()) {
            this.notificationTimeTextView.setVisibility(0);
            this.notificationTimeTextView.setText(DateUtil.getInstance().getNotifyTime(this.plan.getNotifyTime(), this.itemView.getContext()));
            return;
        }
        this.notificationTimeTextView.setVisibility(8);
    }

    private void updateTextView() {
        this.titleTextView.setText(this.plan.getTitle());
        TextView textView = this.modeNameTextView;
        textView.setText(" (" + this.planMode.getNameString() + ")");
        this.modeNameTextView.setTextColor(DailyReadingService.getModeTextColorResId(this.planMode.getPlanModeColor(), this.itemView.getContext()));
    }

    private void firstUpdate(final int i) {
        this.dayViewPager.postDelayed(new Runnable() {
            /* class king.james.bible.android.adapter.holder.PlanStartedViewHolder.AnonymousClass3 */

            public void run() {
                PlanStartedViewHolder.this.pageSelected(i);
            }
        }, 300);
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void pageSelected(int i) {
        if (this.dailyReadingDayAdapter.getCount() >= 1) {
            PlanDay item = this.dailyReadingDayAdapter.getItem(this.dayViewPager.getCurrentItem());
            this.currentDay = item;
            if (item != null) {
                this.positionListener.newPosition(getLayoutPosition(), i);
                this.dayPosition = i;
                this.firstCheck = false;
                setDay(this.currentDay.getDay());
                updateNavigationButtonsPosition();
                if (this.currentDay.getPlanChapterDays() != null) {
                    updateHeightContainer(this.currentDay.getPlanChapterDays().size());
                }
                PlanDay planDay = this.currentDay;
                if (planDay != null) {
                    this.completeAllCheckBox.setChecked(planDay.isCompeteDay());
                }
            }
        }
    }

    @SuppressLint("StringFormatInvalid")
    private void setDay(int i) {
        this.dayTextView.setText(this.itemView.getContext().getString(R.string.daily_readingday, Integer.toString(i)));
    }

    private void updateNavigationButtonsPosition() {
        if (this.currentDay != null && !ScreenUtil.getInstance().isTablet()) {
            int i = R.dimen.daily_readingnavigation_buttonmargin_top;
            if (this.currentDay.getPlanChapterDays().size() == 2) {
                i = R.dimen.daily_readingnavigation_buttonmargin_top2;
            }
            if (this.currentDay.getPlanChapterDays().size() == 1) {
                i = R.dimen.daily_readingnavigation_buttonmargin_top3;
            }
            int dimensionPixelOffset = this.itemView.getContext().getResources().getDimensionPixelOffset(i);
            setNavigationMargin(this.toLeftImageView, dimensionPixelOffset);
            setNavigationMargin(this.toRightImageView, dimensionPixelOffset);
        }
    }

    private void setNavigationMargin(ImageView imageView, int i) {
        RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) imageView.getLayoutParams();
        layoutParams.setMargins(0, i, 0, 0);
        imageView.setLayoutParams(layoutParams);
    }

    @Override // king.james.bible.android.service.DailyReadingCheckedService.DailyReadingCheckedHandler
    public Boolean isCheckedModel() {
        PlanDay planDay = this.currentDay;
        return Boolean.valueOf(planDay != null && planDay.isCompeteDay());
    }

    @Override // king.james.bible.android.service.DailyReadingCheckedService.DailyReadingCheckedHandler
    public void setCheckedModel(boolean z) {
        if (this.itemView.getContext() != null) {
            ((Activity) this.itemView.getContext()).runOnUiThread(new Runnable() {
                /* class king.james.bible.android.adapter.holder.$$Lambda$PlanStartedViewHolder$FKlBsPGpYmiWnhmgJWqql7iwgV8 */
                private final /* synthetic */ boolean f$1;

                {
                    this.f$1 = r2;
                }

                public final void run() {
                    PlanStartedViewHolder.this.lambda$setCheckedModel$5$PlanStartedViewHolder(this.f$1);
                }
            });
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: completeAllCheck */
    public void lambda$setCheckedModel$5$PlanStartedViewHolder(boolean z) {
        this.currentDay = this.dailyReadingDayAdapter.getItem(this.dayViewPager.getCurrentItem());
        View view = this.itemView;
        if (!(view == null || view.getContext() == null || this.currentDay == null || this.progress == null)) {
            if (this.completeAllCheckBox.isChecked() != z) {
                this.completeAllCheckBox.setChecked(z);
            }
            DailyReadingActionObservable.getInstance().onSelectCompleteAll(this.currentDay, this.plan.getModeId(), z, false);
            this.currentDay.setReaded(z);
            for (PlanChapterDay planChapterDay : this.currentDay.getPlanChapterDays()) {
                planChapterDay.setViewed(z);
            }
            updateProgress();
            if (this.progress.getProgress() >= 100 && !this.firstCheck) {
                DialogUtil.showCompletePlanDialog(((AppCompatActivity) this.itemView.getContext()).getSupportFragmentManager());
            }
            DailyReadingCheckedService.getInstance().remove(this.plan.getId());
            for (int i = 0; i < this.plan.getPlanDays().size(); i++) {
                if (this.plan.getPlanDays().get(i).getId() == this.currentDay.getId()) {
                    this.plan.getPlanDays().get(i).setReaded(z);
                    for (PlanChapterDay planChapterDay2 : this.plan.getPlanDays().get(i).getPlanChapterDays()) {
                        planChapterDay2.setViewed(z);
                    }
                }
            }
            updateView(true);
            DailyReadingDayItemView dailyReadingDayItemView = (DailyReadingDayItemView) this.dailyReadingDayAdapter.getBindedView(this.dayViewPager.getCurrentItem());
            if (dailyReadingDayItemView != null) {
                dailyReadingDayItemView.setModel(this.currentDay, this.plan.getStartDate());
            }
            this.firstCheck = false;
        }
    }

    private void updateProgress() {
        if (!(this.planMode == null || this.plan == null)) {
            int i = 0;
            for (int i2 = 0; i2 < this.plan.getPlanDays().size(); i2++) {
                PlanDay planDay = this.plan.getPlanDays().get(i2);
                if (planDay != null && planDay.isCompeteDay()) {
                    i++;
                }
            }
            double percent = AppUtils.getPercent(i, this.planMode.getDayCount(), 1);
            if (percent > 100.0d) {
                percent = 100.0d;
            }
            this.progressTextView.setText(percent + "%");
            this.progress.setProgress((int) percent);
        }
    }

    private void updateHeightContainer(int i) {
        if (this.dayRelativeLayout != null) {
            int pixelSize = ScreenUtil.getInstance().getPixelSize(R.dimen.daily_readingitem_headerheight);
            int pixelSize2 = ScreenUtil.getInstance().getPixelSize(R.dimen.daily_readingitem_footerheight);
            int pixelSize3 = ScreenUtil.getInstance().getPixelSize(R.dimen.daily_readingitem_buttonheight);
            ViewGroup.LayoutParams layoutParams = this.dayRelativeLayout.getLayoutParams();
            layoutParams.height = (getChapterCountCoefficient(i) * pixelSize3) + pixelSize + pixelSize2;
            this.dayRelativeLayout.setLayoutParams(layoutParams);
        }
    }

    private int getChapterCountCoefficient(int i) {
        if (!ScreenUtil.getInstance().isTablet()) {
            return i;
        }
        int i2 = i % 2;
        int i3 = i / 2;
        return i2 > 0 ? i3 + 1 : i3;
    }

    @Override // king.james.bible.android.dialog.NotifyDialog.NotifyTimeListener
    public void selectNotifyTime(long j, boolean z, long j2) {
        View view = this.itemView;
        if (view != null && view.getContext() != null && this.currentDay != null && this.progress != null && this.plan.getId() == j) {
            this.plan.setNotify(z);
            this.plan.setNotifyTime(j2);
            prepareNotifyView();
        }
    }
}
