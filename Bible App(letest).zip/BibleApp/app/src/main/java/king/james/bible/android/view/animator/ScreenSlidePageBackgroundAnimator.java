package king.james.bible.android.view.animator;

import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.view.View;
import king.james.bible.android.utils.BiblePreferences;

public class ScreenSlidePageBackgroundAnimator {
    private ObjectAnimator backgroundColorAnimator;

    public ScreenSlidePageBackgroundAnimator(View view) {
        boolean isNightMode = BiblePreferences.getInstance().isNightMode();
        ObjectAnimator ofObject = ObjectAnimator.ofObject(view, "backgroundColor", new ArgbEvaluator(), Integer.valueOf(isNightMode ? -16777216 : -1), Integer.valueOf(isNightMode ? -14273992 : -6245959), Integer.valueOf(!isNightMode ? -1 : -16777216));
        this.backgroundColorAnimator = ofObject;
        ofObject.setDuration(2000L);
    }

    public void start() {
        ObjectAnimator objectAnimator = this.backgroundColorAnimator;
        if (objectAnimator != null) {
            objectAnimator.start();
        }
    }

    public void cancel() {
        ObjectAnimator objectAnimator = this.backgroundColorAnimator;
        if (objectAnimator != null) {
            objectAnimator.removeAllListeners();
            this.backgroundColorAnimator.end();
            this.backgroundColorAnimator.cancel();
        }
    }
}
