package king.james.bible.android.utils;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.Point;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;

import king.james.bible.android.MyApplication;
@SuppressLint("WrongConstant")

public class ScreenUtil {
    private static ScreenUtil instance;
    private boolean isTabletMode = false;
    private boolean isTabletModeDetermined = false;

    private ScreenUtil() {
    }

    public static ScreenUtil getInstance() {
        if (instance == null) {
            synchronized (ScreenUtil.class) {
                if (instance == null) {
                    instance = new ScreenUtil();
                }
            }
        }
        return instance;
    }

    public Context getContext() {
        return MyApplication.getContext();
    }

    public boolean isTablet() {
        if (!this.isTabletModeDetermined) {
            try {
                if (getContext().getResources().getConfiguration().smallestScreenWidthDp >= 600) {
                    this.isTabletMode = true;
                }
                this.isTabletModeDetermined = true;
            } catch (Exception unused) {
            }
        }
        return this.isTabletMode;
    }

    public void showKeyboard(View view) {
        if (view != null) {
            ((InputMethodManager) view.getContext().getSystemService("input_method")).showSoftInput(view, 0);
        }
    }

    public void hideKeyboard(View view) {
        if (view != null) {
            ((InputMethodManager) view.getContext().getSystemService("input_method")).hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    public void hideKeyboard(Activity activity) {
        View currentFocus;
        if (activity != null && (currentFocus = activity.getCurrentFocus()) != null) {
            hideKeyboard(currentFocus);
        }
    }

    public int getPixelSize(int i) {
        return getContext().getResources().getDimensionPixelSize(i);
    }

    public int getWidth(WindowManager windowManager) {
        try {
            Display defaultDisplay = windowManager.getDefaultDisplay();
            Point point = new Point();
            defaultDisplay.getSize(point);
            return point.x;
        } catch (Exception unused) {
            return 0;
        }
    }
}
