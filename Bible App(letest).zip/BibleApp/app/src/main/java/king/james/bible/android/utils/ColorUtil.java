package king.james.bible.android.utils;

import king.james.bible.android.R;
import king.james.bible.android.model.SpanType;

public class ColorUtil {

    /* renamed from: king.james.bible.android.utils.ColorUtil$1  reason: invalid class name */
    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] $SwitchMap$king$james$bible$android$model$SpanType;

        /* JADX WARNING: Can't wrap try/catch for region: R(18:0|1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|18) */
        /* JADX WARNING: Code restructure failed: missing block: B:19:?, code lost:
            return;
         */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:11:0x003e */
        /* JADX WARNING: Missing exception handler attribute for start block: B:13:0x0049 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:15:0x0054 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x001d */
        /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x0028 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:9:0x0033 */
        static {
            int[] iArr = new int[SpanType.values().length];
            $SwitchMap$king$james$bible$android$model$SpanType = iArr;
            iArr[SpanType.COLOR_1.ordinal()] = 1;
            $SwitchMap$king$james$bible$android$model$SpanType[SpanType.COLOR_2.ordinal()] = 2;
            $SwitchMap$king$james$bible$android$model$SpanType[SpanType.COLOR_3.ordinal()] = 3;
            $SwitchMap$king$james$bible$android$model$SpanType[SpanType.COLOR_4.ordinal()] = 4;
            $SwitchMap$king$james$bible$android$model$SpanType[SpanType.COLOR_5.ordinal()] = 5;
            $SwitchMap$king$james$bible$android$model$SpanType[SpanType.COLOR_6.ordinal()] = 6;
            $SwitchMap$king$james$bible$android$model$SpanType[SpanType.COLOR_7.ordinal()] = 7;
            $SwitchMap$king$james$bible$android$model$SpanType[SpanType.COLOR_8.ordinal()] = 8;
        }
    }

    public static int getColorDrawableByValue(SpanType spanType) {
        boolean isDayMode = BiblePreferences.getInstance().isDayMode();
        switch (AnonymousClass1.$SwitchMap$king$james$bible$android$model$SpanType[spanType.ordinal()]) {
            case 1:
                return isDayMode ? R.drawable.highlight_color_1 : R.drawable.highlight_color_1_n;
            case 2:
                return isDayMode ? R.drawable.highlight_color_2 : R.drawable.highlight_color_2_n;
            case 3:
                return isDayMode ? R.drawable.highlight_color_3 : R.drawable.highlight_color_3_n;
            case 4:
                return isDayMode ? R.drawable.highlight_color_4 : R.drawable.highlight_color_4_n;
            case 5:
                return isDayMode ? R.drawable.highlight_color_5 : R.drawable.highlight_color_5_n;
            case 6:
                return isDayMode ? R.drawable.highlight_color_6 : R.drawable.highlight_color_6_n;
            case 7:
                return isDayMode ? R.drawable.highlight_color_7 : R.drawable.highlight_color_7_n;
            case 8:
                return isDayMode ? R.drawable.highlight_color_8 : R.drawable.highlight_color_8_n;
            default:
                return 0;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:19:0x003e, code lost:
        if (r6 != false) goto L_0x002a;
     */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x0055  */
    /* JADX WARNING: Removed duplicated region for block: B:28:? A[RETURN, SYNTHETIC] */
    public static int getTextColorModeResId(int i, boolean z) {
        int i2;
        boolean isNightMode = BiblePreferences.getInstance().isNightMode();
        int i3 = 0;
        if (i == 0 || i == 1) {
            i3 = z ? R.color.dark_light_text_shadow : R.color.dark_light_text;
            if (!z) {
                i2 = R.color.menu_text_color_n;
                return isNightMode ? i2 : i3;
            }
        } else if (i != 2) {
            if (i != 3) {
                i2 = 0;
            } else {
                i3 = z ? R.color.dark_light_text_shadow : R.color.green_light_text;
                if (!z) {
                    i2 = R.color.green_light_text_n;
                }
            }
            if (isNightMode) {
            }
        } else {
            i2 = R.color.red_light_text;
            i3 = z ? R.color.dark_light_text_shadow : R.color.red_light_text;
        }
        i2 = R.color.menu_text_color_n_shadow;
        if (isNightMode) {
        }
        return i;
    }
}
