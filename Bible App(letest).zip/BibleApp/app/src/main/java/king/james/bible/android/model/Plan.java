package king.james.bible.android.model;

import java.io.Serializable;
import java.util.List;

public class Plan implements Serializable {
    private String description;
    private long endDate;
    private long id;
    private int modeId;
    private String modeIds;
    private boolean notify;
    private long notifyTime;
    private int order;
    private List<PlanDay> planDays;
    private List<PlanMode> planModes;
    private long startDate;
    private boolean started;
    private String title;

    public long getId() {
        return this.id;
    }

    public void setId(long j) {
        this.id = j;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String str) {
        this.title = str;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String str) {
        this.description = str;
    }

    public int getOrder() {
        return this.order;
    }

    public void setOrder(int i) {
        this.order = i;
    }

    public long getStartDate() {
        return this.startDate;
    }

    public void setStartDate(long j) {
        this.startDate = j;
    }

    public long getEndDate() {
        return this.endDate;
    }

    public void setEndDate(long j) {
        this.endDate = j;
    }

    public boolean isStarted() {
        return this.started;
    }

    public void setStarted(boolean z) {
        this.started = z;
    }

    public int getModeId() {
        return this.modeId;
    }

    public void setModeId(int i) {
        this.modeId = i;
    }

    public boolean isNotify() {
        return this.notify;
    }

    public void setNotify(boolean z) {
        this.notify = z;
    }

    public long getNotifyTime() {
        return this.notifyTime;
    }

    public void setNotifyTime(long j) {
        this.notifyTime = j;
    }

    public List<PlanMode> getPlanModes() {
        return this.planModes;
    }

    public void setPlanModes(List<PlanMode> list) {
        this.planModes = list;
    }

    public String getModeIds() {
        return this.modeIds;
    }

    public void setModeIds(String str) {
        this.modeIds = str;
    }

    public List<PlanDay> getPlanDays() {
        return this.planDays;
    }

    public void setPlanDays(List<PlanDay> list) {
        this.planDays = list;
    }

    public PlanMode getPlanMode() {
        if (this.modeId < 1) {
            return null;
        }
        for (PlanMode planMode : getPlanModes()) {
            if (this.modeId == planMode.getId()) {
                return planMode;
            }
        }
        return null;
    }

    public String toString() {
        return "id=" + this.id + " : title=" + this.title + " : notifyTime=" + this.notifyTime;
    }
}
