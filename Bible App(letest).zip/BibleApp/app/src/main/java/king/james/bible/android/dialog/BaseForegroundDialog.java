package king.james.bible.android.dialog;

public abstract class BaseForegroundDialog extends BaseDialogFragment {
    @Override // androidx.fragment.app.Fragment, androidx.fragment.app.DialogFragment
    public void onStart() {
        super.onStart();
        try {
            getDialog().getWindow().setBackgroundDrawableResource(17170445);
            setCancelable(true);
        } catch (Exception unused) {
        }
    }
}
