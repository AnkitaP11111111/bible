package king.james.bible.android.sound.listener;

public interface FirstPlayListener {
    void onCompleteFirstPlayInit();
}
