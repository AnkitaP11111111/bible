package king.james.bible.android.service.notifications;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.karumi.dexter.BuildConfig;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import king.james.bible.android.db.service.DailyReadingDataService;
import king.james.bible.android.db.service.DailyVerseDataService;
import king.james.bible.android.model.DailyVerse;
import king.james.bible.android.model.Plan;
import king.james.bible.android.service.notifications.work.NotificationWorker;

public class NotificationDataService {
    private static int DAILY_VERSE_SHIFT = 100;
    private Map<Long, NotifySimple> notificationPlanMap;
    private Map<Long, NotifySimple> notificationVerseMap;

    /* access modifiers changed from: private */
    public static class SingletonHelper {
        private static final NotificationDataService INSTANCE = new NotificationDataService();
    }

    public static class NotifySimple {
        public long id;
        public long notifyTime;
        public String title;

        NotifySimple(DailyVerse dailyVerse) {
            this.id = dailyVerse.getId();
            this.title = dailyVerse.getTitle();
            this.notifyTime = dailyVerse.getNotifyTime();
        }

        NotifySimple(Plan plan) {
            this.id = plan.getId();
            this.title = plan.getTitle();
            this.notifyTime = plan.getNotifyTime();
        }
    }

    private NotificationDataService() {
    }

    public static NotificationDataService getInstance() {
        return SingletonHelper.INSTANCE;
    }

    private void restore(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("BibleNotificationDataService_preference", 0);
        if (sharedPreferences != null) {
            Gson create = new GsonBuilder().create();
            Type type = new TypeToken<Map<Long, NotifySimple>>(this) {
                /* class king.james.bible.android.service.notifications.NotificationDataService.AnonymousClass1 */
            }.getType();

            Map<Long, NotifySimple> map = (Map) create.fromJson(sharedPreferences.getString("notificationVerse", BuildConfig.FLAVOR), type);
            this.notificationVerseMap = map;
            if (map == null) {
                this.notificationVerseMap = new HashMap();
            }
            Map<Long, NotifySimple> map2 = (Map) create.fromJson(sharedPreferences.getString("notificationPlan", BuildConfig.FLAVOR), type);
            this.notificationPlanMap = map2;
            if (map2 == null) {
                this.notificationPlanMap = new HashMap();
            }
        }
    }

    private void save(Context context) {
        SharedPreferences.Editor edit;
        SharedPreferences sharedPreferences = context.getSharedPreferences("BibleNotificationDataService_preference", 0);
        if (sharedPreferences != null && (edit = sharedPreferences.edit()) != null) {
            Gson create = new GsonBuilder().create();
            edit.putString("notificationVerse", create.toJson(this.notificationVerseMap));
            edit.putString("notificationPlan", create.toJson(this.notificationPlanMap));
            try {
                edit.apply();
            } catch (Exception unused) {
            }
        }
    }

    public void addOrUpdateVerse(DailyVerse dailyVerse, Context context) {
        if (dailyVerse != null) {
            restore(context);
            addOrUpdate(new NotifySimple(dailyVerse), context, this.notificationVerseMap);
            NotificationWorker.runAlarm(context, dailyVerse.getId() + ((long) DAILY_VERSE_SHIFT), NotificationWorker.EXTRA_TYPE_DAILY_VERSE, dailyVerse.getNotifyTime());
        }
    }

    public void addOrUpdatePlan(Plan plan, Context context) {
        if (plan != null) {
            restore(context);
            addOrUpdate(new NotifySimple(plan), context, this.notificationPlanMap);
            NotificationWorker.runAlarm(context, plan.getId(), NotificationWorker.EXTRA_TYPE_PLAN, plan.getNotifyTime());
        }
    }

    private void addOrUpdate(NotifySimple notifySimple, Context context, Map<Long, NotifySimple> map) {
        map.put(Long.valueOf(notifySimple.id), notifySimple);
        save(context);
    }

    public void removeVerse(long j, Context context) {
        remove(j, context, NotificationWorker.EXTRA_TYPE_DAILY_VERSE);
    }

    public void removePlan(long j, Context context) {
        remove(j, context, NotificationWorker.EXTRA_TYPE_PLAN);
    }

    private void remove(long j, Context context, String str) {
        restore(context);
        if (str.equals(NotificationWorker.EXTRA_TYPE_PLAN)) {
            this.notificationPlanMap.remove(Long.valueOf(j));
            NotificationWorker.removeAlarm(context, j);
        } else {
            this.notificationVerseMap.remove(Long.valueOf(j));
            NotificationWorker.removeAlarm(context, j + ((long) DAILY_VERSE_SHIFT));
        }
        save(context);
    }

    /* access modifiers changed from: package-private */
    public boolean updateNotificationModels(Context context) {
        try {
            setNewDailyVerses(new DailyVerseDataService().readAllForUpdateNotifications(), context);
            setNewPlans(new DailyReadingDataService().readAllForUpdateNotifications(), context);
        } catch (Exception unused) {
        }
        return !this.notificationPlanMap.isEmpty() || !this.notificationVerseMap.isEmpty();
    }

    private void setNewPlans(List<Plan> list, Context context) {
        if (context != null) {
            restore(context);
        }
        this.notificationPlanMap = new HashMap();
        for (Plan plan : list) {
            if (plan.isNotify()) {
                this.notificationPlanMap.put(Long.valueOf(plan.getId()), new NotifySimple(plan));
            }
        }
        if (context != null) {
            save(context);
        }
    }

    private void setNewDailyVerses(List<DailyVerse> list, Context context) {
        if (context != null) {
            restore(context);
        }
        this.notificationVerseMap = new HashMap();
        for (DailyVerse dailyVerse : list) {
            if (dailyVerse.isNotify()) {
                this.notificationVerseMap.put(Long.valueOf(dailyVerse.getId()), new NotifySimple(dailyVerse));
            }
        }
        if (context != null) {
            save(context);
        }
    }

    /* access modifiers changed from: package-private */
    public List<NotifySimple> getNotifyPlanList(long j, Context context) {
        restore(context);
        return getNotifyList(j, this.notificationPlanMap);
    }

    /* access modifiers changed from: package-private */
    public List<NotifySimple> getNotifyVersesList(long j, Context context) {
        restore(context);
        return getNotifyList(j - ((long) DAILY_VERSE_SHIFT), this.notificationVerseMap);
    }

    private List<NotifySimple> getNotifyList(long j, Map<Long, NotifySimple> map) {
        ArrayList arrayList = new ArrayList();
        if (map.isEmpty()) {
            return arrayList;
        }
        for (Map.Entry<Long, NotifySimple> entry : map.entrySet()) {
            if (entry.getValue().id == j) {
                arrayList.add(entry.getValue());
            }
        }
        return new ArrayList(arrayList);
    }

    /* access modifiers changed from: package-private */
    public void restart(Context context) {
        restore(context);
        for (NotifySimple notifySimple : this.notificationPlanMap.values()) {
            NotificationWorker.runAlarm(context, notifySimple.id, NotificationWorker.EXTRA_TYPE_PLAN, notifySimple.notifyTime);
        }
        for (NotifySimple notifySimple2 : this.notificationVerseMap.values()) {
            NotificationWorker.runAlarm(context, notifySimple2.id + ((long) DAILY_VERSE_SHIFT), NotificationWorker.EXTRA_TYPE_DAILY_VERSE, notifySimple2.notifyTime);
        }
    }
}
