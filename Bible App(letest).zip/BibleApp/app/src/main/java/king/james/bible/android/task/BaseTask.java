package king.james.bible.android.task;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Build;

public abstract class BaseTask<Params, Progress, Result> extends AsyncTask<Params, Progress, Result> {
    protected Exception mException;
    protected OnCallbackHandler<Result> mOnCallbackHandler;

    public interface OnCallbackHandler<T> {
        void onError(Exception exc);

        void onSuccess(T t);
    }

    /* access modifiers changed from: protected */
    public abstract Result doExecute(Params... paramsArr) throws Exception;

    public BaseTask(Context context, OnCallbackHandler<Result> onCallbackHandler) {
        this.mOnCallbackHandler = onCallbackHandler;
    }

    public AsyncTask<Params, Progress, Result> executeAsyncTask(Params... paramsArr) {
        if (Build.VERSION.SDK_INT >= 11) {
            return executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, paramsArr);
        }
        return execute(paramsArr);
    }

    /* access modifiers changed from: protected */
    @Override // android.os.AsyncTask
    public Result doInBackground(Params... paramsArr) {
        try {
            return doExecute(paramsArr);
        } catch (Exception e) {
            this.mException = e;
            return null;
        }
    }

    /* access modifiers changed from: protected */
    @Override // android.os.AsyncTask
    public void onPostExecute(Result result) {
        super.onPostExecute(result);
        if (this.mOnCallbackHandler != null && !isCancelled()) {
            Exception exc = this.mException;
            if (exc == null) {
                this.mOnCallbackHandler.onSuccess(result);
            } else {
                this.mOnCallbackHandler.onError(exc);
            }
        }
    }
}
