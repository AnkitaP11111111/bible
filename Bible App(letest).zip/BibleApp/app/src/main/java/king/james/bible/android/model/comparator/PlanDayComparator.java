package king.james.bible.android.model.comparator;

import java.util.Comparator;
import king.james.bible.android.model.PlanDay;

public class PlanDayComparator implements Comparator<PlanDay> {
    public int compare(PlanDay planDay, PlanDay planDay2) {
        return Integer.valueOf(planDay.getDay()).compareTo(Integer.valueOf(planDay2.getDay()));
    }
}
