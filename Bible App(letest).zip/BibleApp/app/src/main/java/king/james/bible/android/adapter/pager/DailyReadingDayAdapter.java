package king.james.bible.android.adapter.pager;

import android.content.Context;
import king.james.bible.android.R;
import java.util.List;
import king.james.bible.android.model.PlanDay;
import king.james.bible.android.view.DailyReadingDayItemView;

public class DailyReadingDayAdapter extends BasePagerAdapter<PlanDay, DailyReadingDayItemView> {
    private int dayCount;
    private long startDate;

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.adapter.pager.BasePagerAdapter
    public int getResViewId(int i) {
        return R.layout.item_plan_day;
    }

    public DailyReadingDayAdapter(Context context, List<PlanDay> list, long j, int i) {
        super(context, list);
        this.startDate = j;
        this.dayCount = i;
    }

    /* access modifiers changed from: protected */
    public void prepareView(int i, DailyReadingDayItemView dailyReadingDayItemView, PlanDay planDay) {
        dailyReadingDayItemView.setModel(planDay, this.startDate);
    }

    @Override // androidx.viewpager.widget.PagerAdapter
    public int getCount() {
        return this.dayCount;
    }

    @Override // king.james.bible.android.adapter.pager.BasePagerAdapter
    public PlanDay getItem(int i) {
        if (this.items.size() <= i) {
            return null;
        }
        return this.items.get(i);
    }

    public int getCountModels() {
        return this.items.size();
    }
}
