package king.james.bible.android.adapter.holder;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import com.bignerdranch.expandablerecyclerview.ViewHolder.ChildViewHolder;
import com.karumi.dexter.BuildConfig;
import king.james.bible.android.R;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import king.james.bible.android.db.BibleDataBase;
import king.james.bible.android.dialog.DailyPlanDialog;
import king.james.bible.android.model.PlanChapterDay;
import king.james.bible.android.model.PlanDay;
import king.james.bible.android.model.chapter.ChapterShortNameAndMode;
import king.james.bible.android.service.observable.DailyReadingActionObservable;
import king.james.bible.android.utils.BiblePreferences;
import king.james.bible.android.view.FlowLayout;
import king.james.bible.android.view.ItemDailyChapterView;
@SuppressLint({"NewApi", "WrongConstant"})

public class PlanMonthDayViewHolder extends ChildViewHolder {
    private FlowLayout chaptersFlowLayout;
    private CheckBox completeDayCheckBox;
    private DailyPlanDialog.DailyPlanDialogListener dailyPlanDialogListener;
    private DateFormat dayFormat = new SimpleDateFormat("M/dd/yy");
    private TextView dayTextView;
    private View divider;
    private int modeId;
    private boolean nightMode;
    private PlanDay planDay;

    public PlanMonthDayViewHolder(View view, DailyPlanDialog.DailyPlanDialogListener dailyPlanDialogListener2) {
        super(view);
        mapViews(view);
        this.nightMode = BiblePreferences.getInstance().isNightMode();
        this.dailyPlanDialogListener = dailyPlanDialogListener2;
    }

    private void mapViews(View view) {
        this.dayTextView = (TextView) view.findViewById(R.id.dayTextView);
        this.chaptersFlowLayout = (FlowLayout) view.findViewById(R.id.chaptersFlowLayout);
        this.completeDayCheckBox = (CheckBox) view.findViewById(R.id.completeDayCheckBox);
        this.divider = view.findViewById(R.id.divider);
        prepareModeView();
    }

    private void prepareModeView() {
        int i;
        int i2;
        int i3;
        if (this.nightMode) {
            i3 = R.color.daily_reading_viewed;
            i2 = R.color.daily_reading_plan_month_text_n;
            i = R.drawable.btn_check_holo_light_2_n;
        } else {
            i3 = R.color.browser_actions_text_color;
            i2 = R.color.title_text;
            i = R.drawable.btn_check_holo_light_2;
        }
        this.divider.setBackgroundResource(i3);
        this.dayTextView.setTextColor(this.itemView.getContext().getResources().getColor(i2));
        this.completeDayCheckBox.setButtonDrawable(i);
    }

    public void updateView(PlanDay planDay2, int i, long j) {
        this.planDay = planDay2;
        this.modeId = i;
        this.dayTextView.setText(this.dayFormat.format(new Date(j + (((long) (planDay2.getDay() - 1)) * 86400000))));
        this.completeDayCheckBox.setOnCheckedChangeListener(null);
        this.completeDayCheckBox.setChecked(this.planDay.isCompeteDay());
        this.completeDayCheckBox.setButtonDrawable(this.nightMode ? R.drawable.btn_check_holo_light_2_n : R.drawable.btn_check_holo_light_2);
        prepareChaptersFlowLayout();
        prepareCompleteDayCheck();
    }

    private void prepareCompleteDayCheck() {
        this.completeDayCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            /* class king.james.bible.android.adapter.holder.PlanMonthDayViewHolder.AnonymousClass1 */

            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                DailyReadingActionObservable.getInstance().onSelectCompleteAll(PlanMonthDayViewHolder.this.planDay, PlanMonthDayViewHolder.this.modeId, z, true);
                PlanMonthDayViewHolder.this.planDay.setReaded(z);
                for (PlanChapterDay planChapterDay : PlanMonthDayViewHolder.this.planDay.getPlanChapterDays()) {
                    planChapterDay.setViewed(z);
                }
                PlanMonthDayViewHolder.this.completeAll(z);
                PlanMonthDayViewHolder.this.completeDayCheckBox.setChecked(PlanMonthDayViewHolder.this.planDay.isReaded());
            }
        });
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void completeAll(boolean z) {
        for (int i = 0; i < this.planDay.getPlanChapterDays().size(); i++) {
            ItemDailyChapterView itemDailyChapterView = (ItemDailyChapterView) this.chaptersFlowLayout.getChildAt(i);
            int i2 = -1;
            if (z) {
                i2 = this.nightMode ? R.color.bright_foreground_inverse_material_light : R.color.common_google_signin_btn_text_dark_focused;
            } else if (itemDailyChapterView.getChapterMode() == 2) {
                i2 = R.color.red_text;
            }
            setColorItem(itemDailyChapterView, i2);
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:26:0x00f7  */
    /* JADX WARNING: Removed duplicated region for block: B:33:0x0126  */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x012a  */
    private void prepareChaptersFlowLayout() {
        String str;
        int i;
        for (int i2 = 0; i2 < this.chaptersFlowLayout.getChildCount(); i2++) {
            this.chaptersFlowLayout.getChildAt(i2).setVisibility(4);
            this.chaptersFlowLayout.getChildAt(i2).setVisibility(8);
        }
        if (!(this.planDay.getPlanChapterDays() == null || this.planDay.getPlanChapterDays().isEmpty())) {
            for (int childCount = this.chaptersFlowLayout.getChildCount(); childCount < this.planDay.getPlanChapterDays().size(); childCount++) {
                ItemDailyChapterView itemDailyChapterView = (ItemDailyChapterView) LayoutInflater.from(this.chaptersFlowLayout.getContext()).inflate(R.layout.item_daily_chapter, (ViewGroup) this.chaptersFlowLayout, false);
                itemDailyChapterView.setVisibility(8);
                this.chaptersFlowLayout.addView(itemDailyChapterView);
            }
            List<ChapterShortNameAndMode> chaptersList = BibleDataBase.getInstance().getChaptersList();
            for (int i3 = 0; i3 < this.planDay.getPlanChapterDays().size(); i3++) {
                final PlanChapterDay planChapterDay = this.planDay.getPlanChapterDays().get(i3);
                ItemDailyChapterView itemDailyChapterView2 = (ItemDailyChapterView) this.chaptersFlowLayout.getChildAt(i3);
                itemDailyChapterView2.setVisibility(0);
                int chapterOrder = planChapterDay.getChapterOrder() - 1;
                if (chapterOrder < 0 || chapterOrder > chaptersList.size() - 1) {
                    str = BuildConfig.FLAVOR;
                } else {
                    str = chaptersList.get(chapterOrder).getLongName();
                    itemDailyChapterView2.setChapterMode(chaptersList.get(chapterOrder).getMode());
                    if (chaptersList.get(chapterOrder).getMode() == 2) {
                        i = R.color.red_text;
                        String str2 = str + " " + planChapterDay.getChapterNum();
                        if (i3 < this.planDay.getPlanChapterDays().size() - 1) {
                            str2 = str2 + ",";
                        }
                        if (!this.planDay.getPlanChapterDays().get(i3).isViewed() || this.planDay.isReaded()) {
                            i = !this.nightMode ? R.color.bright_foreground_disabled_material_light : R.color.browser_actions_title_color;
                        }
                        setColorItem(itemDailyChapterView2, i);
                        itemDailyChapterView2.setNameText(str2);
                        itemDailyChapterView2.setOnClickListener(new View.OnClickListener() {
                            /* class king.james.bible.android.adapter.holder.PlanMonthDayViewHolder.AnonymousClass2 */

                            public void onClick(View view) {
                                if (PlanMonthDayViewHolder.this.dailyPlanDialogListener != null) {
                                    PlanMonthDayViewHolder.this.dailyPlanDialogListener.closeDialog();
                                }
                                DailyReadingActionObservable.getInstance().onViewChapter(planChapterDay);
                            }
                        });
                    }
                }
                i = 0;
                String str22 = str + " " + planChapterDay.getChapterNum();
                if (i3 < this.planDay.getPlanChapterDays().size() - 1) {
                }
                if (!this.planDay.getPlanChapterDays().get(i3).isViewed()) {
                }
                if (!this.nightMode) {
                }
                setColorItem(itemDailyChapterView2, i);
                itemDailyChapterView2.setNameText(str22);
                itemDailyChapterView2.setOnClickListener(new View.OnClickListener() {
                    /* class king.james.bible.android.adapter.holder.PlanMonthDayViewHolder.AnonymousClass2 */

                    public void onClick(View view) {
                        if (PlanMonthDayViewHolder.this.dailyPlanDialogListener != null) {
                            PlanMonthDayViewHolder.this.dailyPlanDialogListener.closeDialog();
                        }
                        DailyReadingActionObservable.getInstance().onViewChapter(planChapterDay);
                    }
                });
            }
        }
    }

    private void setColorItem(ItemDailyChapterView itemDailyChapterView, int i) {
        if (i > 0) {
            itemDailyChapterView.setModeColor(i);
        } else {
            itemDailyChapterView.setModeColor(this.nightMode ? R.color.ad_install_day_call_to_action_text : R.color.title_text);
        }
    }
}
