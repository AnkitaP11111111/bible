package king.james.bible.android.appad;

public class AppAd {
    private String id;
    private String name;
    private int periodicity;
    private int startCount;
    private String text;
    private String url;
    private int version;

    public String getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public int getPeriodicity() {
        return this.periodicity;
    }

    public String getText() {
        return this.text;
    }

    public int getVersion() {
        return this.version;
    }

    public int getStartCount() {
        return this.startCount;
    }

    public void setStartCount(int i) {
        this.startCount = i;
    }

    public String getUrl() {
        return this.url;
    }
}
