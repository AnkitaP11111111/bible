package king.james.bible.android.model;

public enum SpanType {
    EMPTY_TYPE,
    COLOR_1,
    COLOR_2,
    COLOR_3,
    COLOR_4,
    UNDERLINE,
    COLOR_5,
    COLOR_6,
    COLOR_7,
    COLOR_8;

    public static SpanType getSpanType(int i) {
        try {
            return values()[i];
        } catch (Exception unused) {
            return EMPTY_TYPE;
        }
    }

    public boolean isColor() {
        return (this == EMPTY_TYPE || this == UNDERLINE) ? false : true;
    }

    public boolean isUnderline() {
        return this == UNDERLINE;
    }
}
