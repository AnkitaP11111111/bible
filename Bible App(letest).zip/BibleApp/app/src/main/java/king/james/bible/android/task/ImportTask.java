package king.james.bible.android.task;

import android.content.Context;
import java.io.File;
import java.util.List;
import king.james.bible.android.db.BibleDataBase;
import king.james.bible.android.model.UpdateRecord;
import king.james.bible.android.task.BaseTask;
import king.james.bible.android.utils.ExportImportUtil;

public class ImportTask extends BaseTask<String, Void, Boolean> {
    private File file;
    private boolean importCheck;
    private boolean settingCheck;

    public interface OnCallbackHandler extends BaseTask.OnCallbackHandler<Boolean> {
    }

    public ImportTask(Context context, File file2, boolean z, boolean z2, BaseTask.OnCallbackHandler<Boolean> onCallbackHandler) {
        super(context, onCallbackHandler);
        this.file = file2;
        this.settingCheck = z;
        this.importCheck = z2;
    }

    /* access modifiers changed from: protected */
    public Boolean doExecute(String... strArr) throws Exception {
        BibleDataBase instance = BibleDataBase.getInstance();
        List<UpdateRecord> readArray = ExportImportUtil.getInstance().readArray(this.file, this.settingCheck);
        if (readArray == null) {
            return false;
        }
        if (!readArray.isEmpty()) {
            if (this.importCheck) {
                instance.removeDate();
            }
            instance.updateRecords(readArray);
        }
        return true;
    }
}
