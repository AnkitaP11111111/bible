package king.james.bible.android.adapter.holder;

import android.view.View;
import king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter;
import king.james.bible.android.adapter.recycler.DailyReadingRecyclerViewAdapter;

public abstract class DailyReadingBaseViewHolder extends BaseRecyclerViewAdapter.BaseViewHolder {
    protected int dayPosition;
    protected DailyReadingRecyclerViewAdapter.StartedPositionListener positionListener;

    public DailyReadingBaseViewHolder(View view) {
        super(view);
    }

    public void setActionListener(DailyReadingRecyclerViewAdapter.StartedPositionListener startedPositionListener) {
        this.positionListener = startedPositionListener;
    }

    public void setDayPosition(int i) {
        this.dayPosition = i;
    }
}
