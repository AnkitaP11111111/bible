package king.james.bible.android.sound.util;

import android.content.Context;
import com.karumi.dexter.BuildConfig;

import java.util.ArrayList;
import java.util.List;

import king.james.bible.android.R;
import king.james.bible.android.sound.model.LanguageModel;

public class SoundLanguageService {
    private static SoundLanguageService instance;
    private List<LanguageModel> languageModelList;

    private SoundLanguageService() {
    }

    public static SoundLanguageService getInstance() {
        if (instance == null) {
            synchronized (SoundLanguageService.class) {
                if (instance == null) {
                    instance = new SoundLanguageService();
                }
            }
        }
        return instance;
    }

    public void init(Context context) {
        String[] stringArray;
        this.languageModelList = new ArrayList();
        try {
            for (String str : context.getResources().getStringArray(R.array.language_array)) {
                String[] split = str.split("::");
                String[] split2 = split[0].split(":");
                this.languageModelList.add(new LanguageModel(split[1], split2[0], split2.length > 1 ? split2[1] : BuildConfig.FLAVOR));
            }
        } catch (Exception unused) {
        }
    }

    public List<LanguageModel> getLanguageModelList() {
        if (this.languageModelList == null) {
            this.languageModelList = new ArrayList();
        }
        return this.languageModelList;
    }

    public LanguageModel getLanguageModel(String str) {
        for (LanguageModel languageModel : this.languageModelList) {
            if (str.equals(languageModel.getId())) {
                return languageModel;
            }
        }
        List<LanguageModel> list = this.languageModelList;
        if (list == null || list.isEmpty()) {
            return null;
        }
        return this.languageModelList.get(0);
    }
}
