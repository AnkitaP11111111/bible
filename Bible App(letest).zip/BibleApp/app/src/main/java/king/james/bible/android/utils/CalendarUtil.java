package king.james.bible.android.utils;

import android.content.Context;
import com.karumi.dexter.BuildConfig;
import king.james.bible.android.R;
import java.util.HashMap;
import java.util.Map;

public class CalendarUtil {
    private static CalendarUtil instance;
    private Map<Integer, String> dayMap;
    private Map<Integer, String> monthMap;

    private CalendarUtil() {
    }

    public static CalendarUtil getInstance() {
        if (instance == null) {
            synchronized (CalendarUtil.class) {
                if (instance == null) {
                    instance = new CalendarUtil();
                }
            }
        }
        return instance;
    }

    public String getMonthName(Context context, int i) {
        Map<Integer, String> map = this.monthMap;
        if (map == null || map.isEmpty()) {
            HashMap hashMap = new HashMap();
            this.monthMap = hashMap;
            hashMap.put(0, context.getString(R.string.month_1));
            this.monthMap.put(1, context.getString(R.string.month_2));
            this.monthMap.put(2, context.getString(R.string.month_3));
            this.monthMap.put(3, context.getString(R.string.month_4));
            this.monthMap.put(4, context.getString(R.string.month_5));
            this.monthMap.put(5, context.getString(R.string.month_6));
            this.monthMap.put(6, context.getString(R.string.month_7));
            this.monthMap.put(7, context.getString(R.string.month_8));
            this.monthMap.put(8, context.getString(R.string.month_9));
            this.monthMap.put(9, context.getString(R.string.month_10));
            this.monthMap.put(10, context.getString(R.string.month_11));
            this.monthMap.put(11, context.getString(R.string.month_12));
        }
        if (!this.monthMap.containsKey(Integer.valueOf(i))) {
            return BuildConfig.FLAVOR;
        }
        return this.monthMap.get(Integer.valueOf(i));
    }

    public String getDayOfWeek(Context context, int i) {
        Map<Integer, String> map = this.dayMap;
        if (map == null || map.isEmpty()) {
            HashMap hashMap = new HashMap();
            this.dayMap = hashMap;
            hashMap.put(2, context.getString(R.string.day_of_week_1));
            this.dayMap.put(3, context.getString(R.string.day_of_week_2));
            this.dayMap.put(4, context.getString(R.string.day_of_week_3));
            this.dayMap.put(5, context.getString(R.string.day_of_week_4));
            this.dayMap.put(6, context.getString(R.string.day_of_week_5));
            this.dayMap.put(7, context.getString(R.string.day_of_week_6));
            this.dayMap.put(1, context.getString(R.string.day_of_week_7));
        }
        if (!this.dayMap.containsKey(Integer.valueOf(i))) {
            return BuildConfig.FLAVOR;
        }
        return this.dayMap.get(Integer.valueOf(i));
    }
}
