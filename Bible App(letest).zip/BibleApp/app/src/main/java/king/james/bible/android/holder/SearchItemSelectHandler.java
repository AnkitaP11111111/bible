package king.james.bible.android.holder;

public interface SearchItemSelectHandler {
    void makeSearchBySelectItem();
}
