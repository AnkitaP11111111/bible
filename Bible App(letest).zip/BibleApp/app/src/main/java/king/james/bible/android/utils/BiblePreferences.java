package king.james.bible.android.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.util.TypedValue;
import com.karumi.dexter.BuildConfig;
import king.james.bible.android.R;
import java.util.Calendar;
import king.james.bible.android.Constants;

import king.james.bible.android.sound.SoundHelper;
import king.james.bible.android.sound.model.LanguageModel;
import king.james.bible.android.sound.util.SoundLanguageService;

public class BiblePreferences {
    private static BiblePreferences instance;

    private long advertisingDisableTime;
    private boolean animateContentTitle;
    private float audioPitch;
    private float audioSpeechRate;
    private int currentPageBible;
    private String dbLocation;
    private int dbVersion;
    private boolean exactPhrase;
    private boolean firstStart = true;
    private String[] fontNames;
    private String fontType;
    private boolean hintPagesSwipe;
    private boolean italicWords;
    private boolean loadScreen;
    private Context mContext;
    private boolean needToBackMode;
    private boolean nightMode;
    private boolean noAdvertising;
    private int nonPersonalizedAds;
    private boolean partialSearch;
    private boolean redLettersMode;
    private boolean screenStay;
    private boolean showBackupHint;
    private String soundLanguageId;
    private float spacing;
    private int startAppCount;
    private int startAppCountShare;
    private float textSize;

    private BiblePreferences() {
    }

    public static BiblePreferences getInstance() {
        if (instance == null) {
            synchronized (BiblePreferences.class) {
                if (instance == null) {
                    instance = new BiblePreferences();
                }
            }
        }
        return instance;
    }

    public void init(Context context) {
        if (context != null) {
            this.mContext = context;
            this.currentPageBible = 0;
            this.textSize = 0.0f;
            this.spacing = 0.0f;
            this.fontType = "Sans";
            this.nightMode = false;
            this.exactPhrase = false;
            this.partialSearch = false;
            this.audioSpeechRate = 0.0f;
            this.audioPitch = 0.0f;
            try {
                this.fontNames = context.getResources().getStringArray(R.array.fonts);
            } catch (Exception unused) {
            }
            this.dbLocation = BuildConfig.FLAVOR;
            restoreAsync();
        }
    }

    public void restoreAsync() {
        new Thread(new Runnable() {
            /* class king.james.bible.android.utils.$$Lambda$BiblePreferences$HJzIB6Iu5_1P51R43Sx9b8jntGQ */

            public final void run() {
                BiblePreferences.this.lambda$restoreAsync$0$BiblePreferences();
            }
        }).start();
    }

    /* renamed from: restore */
    public void lambda$restoreAsync$0$BiblePreferences() {
        SharedPreferences sharedPreferences;
        Context context = this.mContext;
        if (context != null && (sharedPreferences = context.getSharedPreferences("king.james.bible.android.utils.BiblePreferences_preference", 0)) != null) {
            this.currentPageBible = sharedPreferences.getInt("CurrentPageBible", 0);
            this.textSize = sharedPreferences.getFloat("Size", 16.0f);
            this.spacing = sharedPreferences.getFloat("Spacing", 1.05f);
            this.fontType = sharedPreferences.getString("Font", "Sans");
            this.nightMode = sharedPreferences.getBoolean("NightMode", false);
            this.advertisingDisableTime = sharedPreferences.getLong("advertising_disable_time", 0);
            this.noAdvertising = sharedPreferences.getBoolean("no_advertising", false);
            this.loadScreen = sharedPreferences.getBoolean("load_screen", true);
            this.screenStay = sharedPreferences.getBoolean("screen_stay", true);
            this.redLettersMode = sharedPreferences.getBoolean("redletters_mode", true);
            this.italicWords = sharedPreferences.getBoolean("italic_words", true);
            this.exactPhrase = sharedPreferences.getBoolean("exact_phrase", false);
            this.partialSearch = sharedPreferences.getBoolean("partial_search", false);
            this.soundLanguageId = sharedPreferences.getString("sound_language_id", BuildConfig.FLAVOR);
            this.audioSpeechRate = sharedPreferences.getFloat("audio_speech_rate", 1.0f);
            this.audioPitch = sharedPreferences.getFloat("audio_pitch", 1.0f);
            this.needToBackMode = sharedPreferences.getBoolean("needToBackMode", false);
            this.startAppCount = sharedPreferences.getInt("startAppCount", 0);
            this.startAppCountShare = sharedPreferences.getInt("startAppCountShare", 0);
            this.dbLocation = sharedPreferences.getString("dbLocation", BuildConfig.FLAVOR);
            this.dbVersion = sharedPreferences.getInt("dbVersion", 0);
            this.nonPersonalizedAds = sharedPreferences.getInt("nonPersonalizedAds", 1);
            this.hintPagesSwipe = sharedPreferences.getBoolean("hintPagesSwipe", isFirstStart());
            this.animateContentTitle = sharedPreferences.getBoolean("animateContentTitle", isFirstStart());
            this.showBackupHint = sharedPreferences.getBoolean("showBackupHint", true);
        }
    }

    public void saveBg() {
        try {
            AsyncTask.execute(new Runnable() {
                /* class king.james.bible.android.utils.$$Lambda$BiblePreferences$xtit0ch69h6D_QOVMAtB9vJDL8 */

                public final void run() {
                    BiblePreferences.this.lambda$saveBg$1$BiblePreferences();
                }
            });
        } catch (Exception unused) {
        }
    }

    /* renamed from: save */
    public void lambda$saveBg$1$BiblePreferences() {
        SharedPreferences sharedPreferences;
        SharedPreferences.Editor edit;
        Context context = this.mContext;
        if (context != null && (sharedPreferences = context.getSharedPreferences("king.james.bible.android.utils.BiblePreferences_preference", 0)) != null && (edit = sharedPreferences.edit()) != null) {
            edit.putInt("CurrentPageBible", this.currentPageBible);
            edit.putFloat("Size", this.textSize);
            edit.putFloat("Spacing", this.spacing);
            edit.putString("Font", this.fontType);
            edit.putBoolean("NightMode", this.nightMode);
            edit.putLong("advertising_disable_time", this.advertisingDisableTime);
            edit.putBoolean("no_advertising", this.noAdvertising);
            edit.putBoolean("load_screen", this.loadScreen);
            edit.putBoolean("screen_stay", this.screenStay);
            edit.putBoolean("redletters_mode", this.redLettersMode);
            edit.putBoolean("italic_words", this.italicWords);
            edit.putBoolean("exact_phrase", this.exactPhrase);
            edit.putBoolean("partial_search", this.partialSearch);
            edit.putString("sound_language_id", this.soundLanguageId);
            edit.putFloat("audio_speech_rate", this.audioSpeechRate);
            edit.putFloat("audio_pitch", this.audioPitch);
            edit.putBoolean("needToBackMode", this.needToBackMode);
            edit.putInt("startAppCount", this.startAppCount);
            edit.putInt("startAppCountShare", this.startAppCountShare);
            edit.putString("dbLocation", this.dbLocation);
            edit.putInt("dbVersion", this.dbVersion);
            edit.putInt("nonPersonalizedAds", this.nonPersonalizedAds);
            edit.putBoolean("hintPagesSwipe", this.hintPagesSwipe);
            edit.putBoolean("animateContentTitle", this.animateContentTitle);
            edit.putBoolean("showBackupHint", this.showBackupHint);
            edit.apply();
        }
    }

    public int getDbVersion() {
        return this.dbVersion;
    }

    public void setDbVersion(int i) {
        this.dbVersion = i;
    }

    public float getTextSize() {
        float f = this.textSize;
        return f == 0.0f ? (float) this.mContext.getResources().getInteger(R.integer.def_font_size) : f;
    }

    public float getTextImageSize() {
        TypedValue typedValue = new TypedValue();
        this.mContext.getResources().getValue(R.dimen.image_size, typedValue, true);
        return getTextSize() * typedValue.getFloat();
    }

    public float getSpacing() {
        float f = this.spacing;
        return f == 0.0f ? ((float) this.mContext.getResources().getInteger(R.integer.def_font_spacing)) / 100.0f : f;
    }

    public float getAudioSpeechRate() {
        float f = this.audioSpeechRate;
        return f == 0.0f ? ((float) this.mContext.getResources().getInteger(R.integer.def_audio_speech_rate)) / 100.0f : f;
    }

    public float getAudioPitch() {
        float f = this.audioPitch;
        return f == 0.0f ? ((float) this.mContext.getResources().getInteger(R.integer.def_audio_pitch)) / 100.0f : f;
    }

    private Typeface getTypeface(String str) {
        Typeface typeface = Typeface.SANS_SERIF;
        String[] strArr = this.fontNames;
        if (strArr == null || strArr.length < 3) {
            return typeface;
        }
        if (str.equalsIgnoreCase(strArr[0])) {
            return Typeface.SANS_SERIF;
        }
        if (str.equalsIgnoreCase(this.fontNames[1])) {
            return Typeface.SERIF;
        }
        return str.equalsIgnoreCase(this.fontNames[2]) ? Typeface.MONOSPACE : typeface;
    }

    public Typeface getTypeface() {
        return getTypeface(this.fontType);
    }

    public int getCurrentPageBible() {
        return this.currentPageBible;
    }

    public void setCurrentPageBible(int i) {
        this.currentPageBible = i;
    }

    public void setTextSize(float f) {
        this.textSize = f;
    }

    public void setSpacing(float f) {
        this.spacing = f;
    }

    public void setAudioSpeechRate(float f) {
        this.audioSpeechRate = f;
        SoundHelper.getInstance().updateAudioSettings();
    }

    public void setAudioPitch(float f) {
        this.audioPitch = f;
        SoundHelper.getInstance().updateAudioSettings();
    }

    public boolean isNightMode() {
        return this.nightMode;
    }

    public boolean isDayMode() {
        return !this.nightMode;
    }

    public void changeDayMode() {
        this.nightMode = !this.nightMode;
    }

    public void setNightMode(boolean z) {
        this.nightMode = z;
    }



    public boolean isNoAdvertising() {
        return Boolean.parseBoolean(null);
//        return !isEnableAds() || this.noAdvertising;
    }

    public boolean isShowAdvertisingMenu() {
        return Boolean.parseBoolean(null);
//        return isEnableAdsMenu() && !isNoAdvertising();
    }

//    private boolean isEnableAds() {
//        boolean z;
//        boolean z2;
//        try {
//            z2 = this.advertisingDisableTime + Constants.AD_DISABLE_ADS_TIMEOUT.longValue() > Calendar.getInstance().getTimeInMillis();
//            try {
//                int i = AnonymousClass1.$SwitchMap$king$james$bible$android$ad$AdMode[this.adMode.ordinal()];
//                if (!(i == 1 || i == 2 || i == 3 || i != 4)) {
//                    z = false;
//                    if (!z && !z2) {
//                        return true;
//                    }
//                }
//            } catch (Exception unused) {
//            }
//        } catch (Exception unused2) {
//            z2 = false;
//        }
//        z = true;
//        return !z ? false : false;
//    }

    /* access modifiers changed from: package-private */
    /* renamed from: king.james.bible.android.utils.BiblePreferences$1  reason: invalid class name */
//    public static /* synthetic */ class AnonymousClass1 {
//        static final /* synthetic */ int[] $SwitchMap$king$james$bible$android$ad$AdMode;
//
//        /* JADX WARNING: Can't wrap try/catch for region: R(8:0|1|2|3|4|5|6|(3:7|8|10)) */
//        /* JADX WARNING: Failed to process nested try/catch */
//        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
//        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x001d */
//        /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x0028 */
//        static {
//            int[] iArr = new int[AdMode.values().length];
//            $SwitchMap$king$james$bible$android$ad$AdMode = iArr;
//            iArr[AdMode.MODE1.ordinal()] = 1;
//            $SwitchMap$king$james$bible$android$ad$AdMode[AdMode.MODE3.ordinal()] = 2;
//            $SwitchMap$king$james$bible$android$ad$AdMode[AdMode.MODE4.ordinal()] = 3;
//            try {
//                $SwitchMap$king$james$bible$android$ad$AdMode[AdMode.MODE2.ordinal()] = 4;
//            } catch (NoSuchFieldError unused) {
//            }
//        }
//    }

//    private boolean isEnableAdsMenu() {
//        try {
//            int i = AnonymousClass1.$SwitchMap$king$james$bible$android$ad$AdMode[this.adMode.ordinal()];
//            if (i != 1) {
//                return i != 2 && (i == 3 || i != 4);
//            }
//            return true;
//        } catch (Exception unused) {
//            return true;
//        }
//    }

    public void setNoAdvertising(boolean z) {
        this.noAdvertising = z;
    }

    public void setAdvertisingDisableTime() {
        this.advertisingDisableTime = Calendar.getInstance().getTimeInMillis();
    }

    public String getFontType() {
        return this.fontType;
    }

    public void setFontType(String str) {
        this.fontType = str;
    }

    public boolean isLoadScreen() {
        return this.loadScreen;
    }

    public void setLoadScreen(boolean z) {
        this.loadScreen = z;
    }

    public boolean isScreenStay() {
        return this.screenStay;
    }

    public void setScreenStay(boolean z) {
        this.screenStay = z;
    }

    public boolean isRedLettersMode() {
        return this.redLettersMode;
    }

    public void setRedLettersMode(boolean z) {
        this.redLettersMode = z;
    }

    public boolean isItalicWords() {
        return this.italicWords;
    }

    public void setItalicWords(boolean z) {
        this.italicWords = z;
    }

    public boolean isExactPhrase() {
        return this.exactPhrase;
    }

    public void setExactPhrase(boolean z) {
        this.exactPhrase = z;
    }

    public boolean isPartialSearch() {
        return this.partialSearch;
    }

    public void setPartialSearch(boolean z) {
        this.partialSearch = z;
    }

    public LanguageModel getSoundLanguage() {
        return SoundLanguageService.getInstance().getLanguageModel(this.soundLanguageId);
    }

    public void setSoundLanguage(LanguageModel languageModel) {
        this.soundLanguageId = languageModel.getId();
        lambda$saveBg$1$BiblePreferences();
        SoundHelper.getInstance().updateAudioSettings();
    }

    public boolean isNeedToBackMode() {
        return this.needToBackMode;
    }

    public void setNeedToBackMode(boolean z) {
        this.needToBackMode = z;
    }

    public void setBackMode() {
        setNeedToBackMode(false);
        setLoadScreen(false);
        lambda$saveBg$1$BiblePreferences();
    }

    public boolean isShowEvaluationDialog() {
        return this.startAppCount >= 2;
    }

    public void incStartAppCount() {
        int i = this.startAppCount;
        if (i >= 0 && i <= 2) {
            this.startAppCount = i + 1;
            lambda$saveBg$1$BiblePreferences();
        }
    }

    public void clearStartAppCount() {
        this.startAppCount = -1;
        lambda$saveBg$1$BiblePreferences();
    }

    public void restoreStartAppCount() {
        this.startAppCount = 0;
        lambda$saveBg$1$BiblePreferences();
    }

    public boolean isShowShareDialog() {
        return this.startAppCountShare >= 7;
    }

    public void incStartAppShareCount() {
        int i = this.startAppCountShare;
        if (i >= 0 && i <= 2) {
            this.startAppCountShare = i + 1;
            lambda$saveBg$1$BiblePreferences();
        }
    }

    public void clearStartAppShareCount() {
        this.startAppCountShare = -1;
        lambda$saveBg$1$BiblePreferences();
    }

    public void restoreStartAppShareCount() {
        this.startAppCountShare = 0;
        lambda$saveBg$1$BiblePreferences();
    }

    public String getDbLocation() {
        String str = this.dbLocation;
        return str != null ? str : BuildConfig.FLAVOR;
    }

    public void setDbLocation(String str) {
        this.dbLocation = str;
    }

    public int getNonPersonalizedAds() {
        return this.nonPersonalizedAds;
    }

    public String getNonPersonalizedAdsStr() {
        return Integer.toString(this.nonPersonalizedAds);
    }

    public void setNonPersonalizedAds(int i) {
        this.nonPersonalizedAds = i;
        lambda$saveBg$1$BiblePreferences();
    }

    public boolean isHintPagesSwipe() {
        return this.hintPagesSwipe;
    }

    public void setHintPagesSwipe(boolean z) {
        this.hintPagesSwipe = z;
    }

    public boolean isAnimateContentTitle() {
        return this.animateContentTitle;
    }

    public void setAnimateContentTitle(boolean z) {
        this.animateContentTitle = z;
    }

    public boolean isShowBackupHint() {
        return this.showBackupHint;
    }

    public void setShowBackupHint(boolean z) {
        this.showBackupHint = z;
        saveBg();
    }

    public boolean isFirstStart() {
        return this.firstStart;
    }

    public void setFirstStart(boolean z) {
        if (z) {
            this.firstStart = z;
        }
    }
}
