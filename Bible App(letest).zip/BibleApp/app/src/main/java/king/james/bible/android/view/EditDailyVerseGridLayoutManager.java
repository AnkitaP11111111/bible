package king.james.bible.android.view;

import android.content.Context;
import android.util.AttributeSet;
import androidx.recyclerview.widget.GridLayoutManager;

public class EditDailyVerseGridLayoutManager extends GridLayoutManager {
    private int rightColumnSize;

    public EditDailyVerseGridLayoutManager(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
        setSpanSizeLookup();
    }

    public EditDailyVerseGridLayoutManager(Context context, int i, int i2) {
        super(context, i);
        setSpanSizeLookup();
        this.rightColumnSize = i2;
    }

    private void setSpanSizeLookup() {
        setSpanSizeLookup(new VerseSpanSizeLookup(getSpanCount()));
    }

    /* access modifiers changed from: private */
    public class VerseSpanSizeLookup extends SpanSizeLookup {
        private int mSpanCount;

        public VerseSpanSizeLookup(int i) {
            this.mSpanCount = i;
        }

        @Override // androidx.recyclerview.widget.GridLayoutManager.SpanSizeLookup
        public int getSpanSize(int i) {
            if (i == 0) {
                return this.mSpanCount;
            }
            if (EditDailyVerseGridLayoutManager.this.rightColumnSize == 0 || i <= this.mSpanCount * EditDailyVerseGridLayoutManager.this.rightColumnSize) {
                return 1;
            }
            return this.mSpanCount;
        }
    }
}
