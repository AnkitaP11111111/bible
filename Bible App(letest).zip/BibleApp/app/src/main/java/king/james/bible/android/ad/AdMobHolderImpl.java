//package king.james.bible.android.ad;
//
//import android.annotation.SuppressLint;
//import android.content.Context;
//import android.os.Build;
//import android.os.Bundle;
//import com.google.ads.mediation.admob.AdMobAdapter;
//import com.google.android.gms.ads.AdListener;
//import com.google.android.gms.ads.AdRequest;
//import com.google.android.gms.ads.AdSize;
//import com.google.android.gms.ads.AdView;
//import com.google.android.gms.ads.LoadAdError;
//import king.james.bible.android.utils.BiblePreferences;
//import king.james.bible.android.utils.ScreenUtil;
//
//public class AdMobHolderImpl implements AdHolder {
//    private AdHolderListener adListener;
//    private AdRequest adRequest;
//    private AdView adView;
//
//    @Override // king.james.bible.android.ad.AdHolder
//    public void createAd(Context context) {
//        AdSize adSize;
//        int i = Build.VERSION.SDK_INT;
//        if (i == 21 || i == 22) {
//            this.adView = new AdView(context.getApplicationContext());
//        } else {
//            this.adView = new AdView(context);
//        }
//        this.adView.setTag("AdMob");
//        if (this.adView.getContext().getResources().getConfiguration().orientation == 2) {
//            adSize = AdSize.BANNER;
//        } else {
//            adSize = AdSize.SMART_BANNER;
//        }
//        try {
//            AdView adView2 = this.adView;
//            if (ScreenUtil.getInstance().isTablet()) {
//                adSize = AdSize.LEADERBOARD;
//            }
//            adView2.setAdSize(adSize);
//            this.adView.setAdUnitId("ca-app-pub-9489298482310064/4557078033");
//        } catch (Exception unused) {
//        }
//        this.adView.setAdListener(new AdListener() {
//            /* class king.james.bible.android.ad.AdMobHolderImpl.AnonymousClass1 */
//
//            @Override // com.google.android.gms.ads.AdListener
//            public void onAdLoaded() {
//                super.onAdLoaded();
//                if (AdMobHolderImpl.this.adListener != null) {
//                    AdMobHolderImpl.this.adListener.onAdLoaded();
//                }
//            }
//
//            @Override // com.google.android.gms.ads.AdListener
//            public void onAdFailedToLoad(LoadAdError loadAdError) {
//                super.onAdFailedToLoad(loadAdError);
//                if (AdMobHolderImpl.this.adListener != null) {
//                    AdMobHolderImpl.this.adListener.onAdFailedToLoad(false);
//                }
//            }
//        });
//        rebuildRequest();
//    }
//
//    @Override // king.james.bible.android.ad.AdHolder
//    public void rebuildRequest() {
//        Bundle bundle = new Bundle();
//        bundle.putString("npa", BiblePreferences.getInstance().getNonPersonalizedAdsStr());
//        AdRequest.Builder builder = new AdRequest.Builder();
//        builder.addNetworkExtrasBundle(AdMobAdapter.class, bundle);
//        this.adRequest = builder.build();
//    }
//
//    @Override // king.james.bible.android.ad.AdHolder
//    public void showAdView() {
//        AdView adView2 = this.adView;
//        if (adView2 != null) {
//            adView2.setVisibility(0);
//        }
//    }
//
//    @Override // king.james.bible.android.ad.AdHolder
//    public void hideAdView() {
//        AdView adView2 = this.adView;
//        if (adView2 != null) {
//            adView2.setVisibility(8);
//        }
//    }
//
//    @Override // king.james.bible.android.ad.AdHolder
//    public void destroyAd() {
//        AdView adView2 = this.adView;
//        if (adView2 != null) {
//            adView2.destroy();
//            this.adView = null;
//        }
//    }
//
//    @Override // king.james.bible.android.ad.AdHolder
//    public void pauseAd() {
//        AdView adView2 = this.adView;
//        if (adView2 != null) {
//            adView2.pause();
//        }
//    }
//
//    @Override // king.james.bible.android.ad.AdHolder
//    public void resumeAd() {
//        AdView adView2 = this.adView;
//        if (adView2 != null && adView2.getVisibility() == 0) {
//            this.adView.resume();
//        }
//    }
//
//    @Override // king.james.bible.android.ad.AdHolder
//    @SuppressLint({"MissingPermission"})
//    public void initAD(AdHolderListener adHolderListener) {
//        AdView adView2 = this.adView;
//        if (adView2 != null) {
//            this.adListener = adHolderListener;
//            try {
//                adView2.loadAd(this.adRequest);
//            } catch (Exception unused) {
//                if (adHolderListener != null) {
//                    adHolderListener.onAdFailedToLoad(false);
//                }
//            }
//            if (adHolderListener != null) {
//                adHolderListener.addView(this.adView);
//            }
//        }
//    }
//}
