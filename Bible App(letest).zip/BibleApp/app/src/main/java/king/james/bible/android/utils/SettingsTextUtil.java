package king.james.bible.android.utils;

import android.widget.TextView;
import com.karumi.dexter.BuildConfig;
import king.james.bible.android.db.SqlHtmlTagUtil$HtmlTags$Attribute;
import king.james.bible.android.db.SqlHtmlTagUtil$HtmlTags$Tag;

public class SettingsTextUtil {
    public static String prepareText(String str) {
        if (str == null) {
            return BuildConfig.FLAVOR;
        }
        BiblePreferences instance = BiblePreferences.getInstance();
        if (!instance.isRedLettersMode()) {
            String replace = str.replace("<" + SqlHtmlTagUtil$HtmlTags$Tag.font.name() + " " + SqlHtmlTagUtil$HtmlTags$Attribute.color.name() + "=\"" + "#bf360c" + "\"" + ">", BuildConfig.FLAVOR);
            StringBuilder sb = new StringBuilder();
            sb.append("</");
            sb.append(SqlHtmlTagUtil$HtmlTags$Tag.font.name());
            sb.append(">");
            str = replace.replace(sb.toString(), BuildConfig.FLAVOR);
        }
        if (instance.isItalicWords()) {
            return str;
        }
        String replace2 = str.replace("<" + SqlHtmlTagUtil$HtmlTags$Tag.em.name() + ">", BuildConfig.FLAVOR);
        return replace2.replace("</" + SqlHtmlTagUtil$HtmlTags$Tag.em.name() + ">", BuildConfig.FLAVOR);
    }

    public static void setupTextViewSettings(TextView textView) {
        float spacing = BiblePreferences.getInstance().getSpacing();
        textView.setTypeface(BiblePreferences.getInstance().getTypeface());
        textView.setTextSize(2, (float) ((int) BiblePreferences.getInstance().getTextSize()));
        textView.setLineSpacing(0.0f, spacing);
    }

    public static void prepareTitleTextView(TextView textView) {
        textView.setTextSize(2, (float) ((((int) BiblePreferences.getInstance().getTextSize()) * 20) / 16));
    }

    public static void prepareTimeTextView(TextView textView) {
        textView.setTextSize(2, (float) ((((int) BiblePreferences.getInstance().getTextSize()) * 12) / 16));
    }

    public static boolean containsIgnoreCase(String str, String str2) {
        if (!(str == null || str2 == null)) {
            int length = str2.length();
            if (length == 0) {
                return true;
            }
            for (int length2 = str.length() - length; length2 >= 0; length2--) {
                if (str.regionMatches(true, length2, str2, 0, length)) {
                    return true;
                }
            }
        }
        return false;
    }
}
