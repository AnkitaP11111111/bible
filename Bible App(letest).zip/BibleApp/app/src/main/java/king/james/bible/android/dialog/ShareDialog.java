package king.james.bible.android.dialog;

import king.james.bible.android.R;
import king.james.bible.android.utils.AppUtils;
import king.james.bible.android.utils.BiblePreferences;

public class ShareDialog extends EvaluationDialog {
    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.EvaluationDialog
    public int getActionTextResId() {
        return R.string.share_dialog_button_share;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.EvaluationDialog
    public int getTextResId() {
        return R.string.share_dialog_text;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.EvaluationDialog
    public int getTitleResId() {
        return R.string.share_dialog_title;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.EvaluationDialog
    public void selectAction() {
        BiblePreferences.getInstance().clearStartAppShareCount();
        AppUtils.shareApp(getActivity());
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.EvaluationDialog
    public void selectLater() {
        BiblePreferences.getInstance().restoreStartAppShareCount();
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.EvaluationDialog
    public void selectNo() {
        BiblePreferences.getInstance().clearStartAppShareCount();
    }
}
