package king.james.bible.android.model;

import android.text.SpannableString;

public class SettingsSoundModel {
    private SpannableString spannableString;
    private String text;

    public SettingsSoundModel(String str, SpannableString spannableString2) {
        this.text = str;
        this.spannableString = spannableString2;
    }

    public String getText() {
        return this.text;
    }

    public SpannableString getSpannableString() {
        return this.spannableString;
    }
}
