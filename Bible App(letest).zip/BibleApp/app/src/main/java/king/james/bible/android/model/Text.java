package king.james.bible.android.model;

public class Text extends Verse {
    private int bookmark;
    private int highlight;
    private String note;
    private int rank;

    public void setBookmarkDate(long j) {
    }

    public void setHighlightDate(long j) {
    }

    public void setNoteDate(long j) {
    }

    public void setnText(String str) {
    }

    public int getRank() {
        return this.rank;
    }

    public void setRank(int i) {
        this.rank = i;
    }

    public boolean isBookmark() {
        return this.bookmark == 1;
    }

    public void setBookmark(int i) {
        this.bookmark = i;
    }

    public SpanType getHighlight() {
        return SpanType.getSpanType(this.highlight);
    }

    public boolean isUnderline() {
        return SpanType.getSpanType(this.highlight).isUnderline();
    }

    public boolean isColor() {
        return SpanType.getSpanType(this.highlight).isColor();
    }

    public void setHighlight(SpanType spanType) {
        this.highlight = spanType.ordinal();
    }

    public String getNote() {
        return this.note;
    }

    public void setNote(String str) {
        this.note = str;
    }

    public boolean isNote() {
        String str = this.note;
        return str != null && !str.isEmpty();
    }
}
