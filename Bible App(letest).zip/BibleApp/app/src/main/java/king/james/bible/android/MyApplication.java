package king.james.bible.android;

import android.app.Application;
import android.content.Context;
import android.os.Handler;
import android.os.Process;

import king.james.bible.android.appad.AppAdStorage;
import king.james.bible.android.db.BibleDataBase;
import king.james.bible.android.db.BibleDataBaseHelper;
import king.james.bible.android.service.DailyVerseService;
import king.james.bible.android.service.LastChaptersService;
import king.james.bible.android.service.SearchHistoryService;
import king.james.bible.android.service.net.NetworkService;
import king.james.bible.android.sound.util.SoundLanguageService;
import king.james.bible.android.utils.BiblePreferences;
import king.james.bible.android.utils.BitmapSpanUtil;
import king.james.bible.android.utils.ExternalStorage;

public class MyApplication extends Application {
    private static Context mContext;

    public void onCreate() {
        super.onCreate();
        if (getResources() == null) {
            Process.killProcess(Process.myPid());
            return;
        }
        mContext = this;
        initDBPaths();
        NetworkService.getInstance().startObservable();
        AppAdStorage.getInstance().init(this);
        LastChaptersService.getInstance().init(this);
        BitmapSpanUtil.getInstance().init(this);
        SearchHistoryService.getInstance().init(this);
        DailyVerseService.getInstance().init(this);
        initSoundLanguage();

    }

    private void initSoundLanguage() {
        new Handler().postDelayed(new Runnable() {
            /* class king.james.bible.android.$$Lambda$Application$6znWn8WN_p27cCu75P_JEuncDEo */

            public final void run() {
                Application.this.lambda$initSoundLanguage$1$Application();
            }
        }, 3000);
    }

    public /* synthetic */ void lambda$initSoundLanguage$1$Application() {
        new Thread(new Runnable() {
            /* class king.james.bible.android.$$Lambda$Application$oEGAXnoyrM2cONUfkwmlK57fiWc */

            public final void run() {
                Application.this.lambda$null$0$Application();
            }
        }).start();
    }

    public /* synthetic */ void lambda$null$0$Application() {
        try {
            SoundLanguageService.getInstance().init(this);
        } catch (Exception unused) {
        }
    }

    private void initDBPaths() {
        new Thread(new Runnable() {
            /* class king.james.bible.android.$$Lambda$Application$BlULBt2f590bmFRl938wkrNg4P4 */

            public final void run() {
                Application.this.lambda$initDBPaths$3$Application();
            }
        }).start();
    }

    public /* synthetic */ void lambda$initDBPaths$3$Application() {
        try {
            ExternalStorage.getAllPaths(this);
            BiblePreferences.getInstance().init(this);
            BibleDataBaseHelper.init(this);
            new Handler().postDelayed($$Lambda$Application$2wEDs_8LJpqm1xbRWBXONVIt9w.INSTANCE, 5000);
        } catch (Exception unused) {
        }
    }

    static /* synthetic */ void lambda$null$2() {
        try {
            BibleDataBase instance = BibleDataBase.getInstance();
            instance.fillChapterListPositionMap(instance.getTotalPagesCount());
        } catch (Exception unused) {
        }
    }

    public static Context getContext() {
        return mContext;
    }
}
