package king.james.bible.android.model;

import java.io.File;
import java.io.FileFilter;

public class ExportImportFilter implements FileFilter {
    private final String[] okFileExtensions = {"setting"};

    public boolean accept(File file) {
        for (String str : this.okFileExtensions) {
            if (file.getName().toLowerCase().endsWith(str)) {
                return true;
            }
        }
        return false;
    }
}
