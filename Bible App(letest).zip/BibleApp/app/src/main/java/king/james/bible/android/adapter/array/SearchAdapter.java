package king.james.bible.android.adapter.array;

import android.content.Context;
import android.view.View;
import android.widget.TextView;
import king.james.bible.android.R;
import java.util.List;
import king.james.bible.android.model.SearchText;
import king.james.bible.android.utils.BiblePreferences;

public class SearchAdapter extends AdjustableModelAdapter<SearchText> {
    private BiblePreferences mBiblePreferences;

    public SearchAdapter(Context context, List<SearchText> list) {
        super(context, list, R.layout.item_search);
        BiblePreferences instance = BiblePreferences.getInstance();
        this.mBiblePreferences = instance;
        instance.lambda$restoreAsync$0$BiblePreferences();
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.adapter.array.AdjustableModelAdapter
    public void onBindView(View view, int i) {
        prepareView(view, i);
        ((TextView) view.findViewById(R.id.searchTextView)).setText(((SearchText) getItem(i)).getText());
    }

    private void prepareView(View view, int i) {
        view.findViewById(R.id.rootSearchItemLinearLayout).setPadding(2, 0, 2, 0);
        if (this.mBiblePreferences.isNightMode()) {
            view.setBackgroundColor(getContext().getResources().getColor(R.color.main_text_color));
            view.findViewById(R.id.bgSearchItemLinearLayout).setBackgroundColor(getContext().getResources().getColor(R.color.title_bar_color_n));
            ((TextView) view.findViewById(R.id.searchTextView)).setTextColor(getContext().getResources().getColor(R.color.main_text_color_n));
            if (i == getCount() - 1) {
                view.findViewById(R.id.rootSearchItemLinearLayout).setPadding(2, 0, 2, 2);
            }
            if (i == 0) {
                view.findViewById(R.id.rootSearchItemLinearLayout).setPadding(2, 2, 2, 0);
            }
            if (getCount() == 1) {
                view.findViewById(R.id.rootSearchItemLinearLayout).setPadding(2, 2, 2, 2);
            }
        }
    }
}
