package king.james.bible.android.db.service;

import android.content.ContentValues;
import android.database.Cursor;
import com.karumi.dexter.BuildConfig;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;
import king.james.bible.android.db.BibleDataBase;
import king.james.bible.android.model.DailyVerse;
import king.james.bible.android.model.Verse;
import king.james.bible.android.model.chapter.ChapterShortNameAndMode;
import king.james.bible.android.service.DailyVerseService;

public class DailyVerseDataService {
    private BibleDataBase bibleDB;
    private VerseService verseService;

    public DailyVerseDataService() {
        BibleDataBase instance = BibleDataBase.getInstance();
        this.bibleDB = instance;
        if (instance.isOpen()) {
            this.verseService = new VerseService();
            return;
        }
        try {
            this.bibleDB.open();
            this.verseService = new VerseService();
        } catch (Exception unused) {
        }
    }

    public List<DailyVerse> getDailyVersesSimple() {
        List<DailyVerse> dailyVerses = getDailyVerses(this.bibleDB.getAllDailyVerse());
        if (dailyVerses == null || dailyVerses.isEmpty()) {
            return new ArrayList();
        }
        return dailyVerses;
    }

    public List<DailyVerse> getDailyVerses() {
        List<DailyVerse> dailyVersesSimple = getDailyVersesSimple();
        if (checkAndUpdateTextId(dailyVersesSimple)) {
            dailyVersesSimple = getDailyVersesSimple();
        }
        return updateForNewDay(dailyVersesSimple);
    }

    public List<DailyVerse> readAllForUpdateNotifications() {
        List<DailyVerse> dailyVerses = getDailyVerses(this.bibleDB.getAllDailyVerse());
        if (dailyVerses == null || dailyVerses.isEmpty()) {
            return new ArrayList();
        }
        return dailyVerses;
    }

    private List<DailyVerse> getDailyVerses(Cursor cursor) {
        return getDailyVerses(cursor, false);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x0022, code lost:
        if (r4 != null) goto L_0x002f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:16:0x002d, code lost:
        if (r4 == null) goto L_0x0032;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:17:0x002f, code lost:
        r4.close();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x0032, code lost:
        return r0;
     */
    private List<DailyVerse> getDailyVerses(Cursor cursor, boolean z) {
        ArrayList arrayList = new ArrayList();
        if (cursor != null) {
            try {
                if (cursor.getCount() >= 1) {
                    if (cursor.moveToFirst()) {
                        do {
                            arrayList.add(createModel(cursor, z));
                        } while (cursor.moveToNext());
                    }
                }
            } catch (Exception unused) {
            } catch (Throwable th) {
                if (cursor != null) {
                    cursor.close();
                }
                throw th;
            }
        }
        if (cursor != null) {
            cursor.close();
        }
        return arrayList;
    }

    private boolean checkAndUpdateTextId(List<DailyVerse> list) {
        boolean z = false;
        for (DailyVerse dailyVerse : list) {
            if (dailyVerse.getVerseId() < 1) {
                z = true;
                updateDailyVerse(dailyVerse.getId(), dailyVerse.getChapters(), dailyVerse.getTitle(), dailyVerse.isNotify(), dailyVerse.getNotifyTime(), dailyVerse.isUserCreate());
            }
        }
        return z;
    }

    private void addVerseData(List<DailyVerse> list) {
        for (DailyVerse dailyVerse : list) {
            Verse verseById = this.verseService.getVerseById(dailyVerse.getVerseId());
            if (verseById == null) {
                dailyVerse.setText(BuildConfig.FLAVOR);
                dailyVerse.setChapter(BuildConfig.FLAVOR);
            } else {
                dailyVerse.setText(verseById.getText());
                dailyVerse.setChapter(verseById.getChapterName() + " " + verseById.getChapterNum() + ":" + verseById.getPosition());
            }
        }
    }

    private List<DailyVerse> updateForNewDay(List<DailyVerse> list) {
        if (DailyVerseService.getInstance().isNewDay()) {
            ArrayList arrayList = new ArrayList();
            for (DailyVerse dailyVerse : list) {
                DailyVerse updateDailyVerse = updateDailyVerse(dailyVerse.getId(), dailyVerse.getChapters(), dailyVerse.getTitle(), dailyVerse.isNotify(), dailyVerse.getNotifyTime(), dailyVerse.isUserCreate());
                if (updateDailyVerse != null) {
                    dailyVerse = updateDailyVerse;
                }
                arrayList.add(dailyVerse);
            }
            return arrayList;
        }
        addVerseData(list);
        return list;
    }

    private DailyVerse createModel(Cursor cursor, boolean z) {
        DailyVerse dailyVerse = new DailyVerse();
        dailyVerse.setId((long) cursor.getInt(cursor.getColumnIndexOrThrow("_id")));
        dailyVerse.setTitle(cursor.getString(cursor.getColumnIndexOrThrow("title")));
        if (z) {
            return dailyVerse;
        }
        dailyVerse.setVerseId((long) cursor.getInt(cursor.getColumnIndexOrThrow("verse_id")));
        boolean z2 = true;
        dailyVerse.setUserCreate(cursor.getInt(cursor.getColumnIndexOrThrow("user_create")) == 1);
        String[] split = cursor.getString(cursor.getColumnIndexOrThrow("chapter_ids")).split(",");
        dailyVerse.setChapters(new HashSet());
        if (split.length > 0) {
            for (String str : split) {
                dailyVerse.getChapters().add(Long.valueOf(Long.parseLong(str)));
            }
        }
        try {
            if (cursor.getInt(cursor.getColumnIndexOrThrow("notify")) <= 0) {
                z2 = false;
            }
            dailyVerse.setNotify(Boolean.valueOf(z2).booleanValue());
            Long valueOf = Long.valueOf(cursor.getLong(cursor.getColumnIndexOrThrow("notify_time")));
            dailyVerse.setNotifyTime(valueOf != null ? valueOf.longValue() : 0);
        } catch (Exception unused) {
            dailyVerse.setNotify(false);
            dailyVerse.setNotifyTime(0);
        }
        return dailyVerse;
    }

    public void save(List<DailyVerse> list) {
        for (DailyVerse dailyVerse : list) {
            save(dailyVerse);
        }
    }

    public DailyVerse save(DailyVerse dailyVerse) {
        if (dailyVerse == null) {
            return dailyVerse;
        }
        if (dailyVerse.getId() < 1) {
            dailyVerse.setUserCreate(true);
        }
        ContentValues dailyVerseContentValues = getDailyVerseContentValues(dailyVerse);
        long j = -1;
        try {
            if (dailyVerse.getId() > 0) {
                j = dailyVerse.getId();
                this.bibleDB.updateDailyVerse(dailyVerse.getId(), dailyVerseContentValues);
            } else {
                j = this.bibleDB.createDailyVerse(dailyVerseContentValues);
            }
        } catch (Exception unused) {
        }
        dailyVerse.setId(j);
        return dailyVerse;
    }

    private ContentValues getDailyVerseContentValues(DailyVerse dailyVerse) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("title", dailyVerse.getTitle());
        contentValues.put("verse_id", Long.valueOf(dailyVerse.getVerseId()));
        contentValues.put("chapter_ids", convertChapterIdsToString(dailyVerse.getChapters()));
        contentValues.put("user_create", Integer.valueOf(dailyVerse.isUserCreate() ? 1 : 0));
        contentValues.put("notify", Integer.valueOf(dailyVerse.isNotify() ? 1 : 0));
        contentValues.put("notify_time", Long.valueOf(dailyVerse.getNotifyTime()));
        return contentValues;
    }

    private String convertChapterIdsToString(Set<Long> set) {
        StringBuilder sb = new StringBuilder();
        Iterator<Long> it = set.iterator();
        while (it.hasNext()) {
            sb.append("," + it.next());
        }
        return sb.toString().replaceFirst(",", BuildConfig.FLAVOR);
    }

    public DailyVerse createModel(Set<Long> set, String str, boolean z, long j) {
        DailyVerse dailyVerse = new DailyVerse();
        dailyVerse.setTitle(str);
        dailyVerse.setChapters(set);
        long j2 = 0;
        int i = 70;
        ChapterShortNameAndMode chapterShortNameAndMode = null;
        while (chapterShortNameAndMode == null && i > 0) {
            j2 = ((Long) getRandomObject(set)).longValue();
            chapterShortNameAndMode = this.bibleDB.getChapterFromCache(j2);
            i--;
        }
        if (chapterShortNameAndMode == null) {
            return null;
        }
        String longName = chapterShortNameAndMode.getLongName();
        Random random = new Random();
        int i2 = 30;
        Verse verse = null;
        while (true) {
            if ((verse == null || !verse.isVerse()) && i2 > 0) {
                int nextInt = random.nextInt(chapterShortNameAndMode.getNum()) + 1;
                VerseService verseService2 = this.verseService;
                if (verseService2 == null) {
                    return null;
                }
                verse = (Verse) getRandomObject(verseService2.getVerseByChapterIdAndNum(j2, nextInt));
                i2--;
            }
        }
        if (verse == null || !verse.isVerse()) {
            return createModel(set, str, z, j);
        }
        dailyVerse.setText(verse.getText());
        dailyVerse.setVerseId(verse.getId());
        dailyVerse.setChapter(longName + " " + verse.getChapterNum() + ":" + verse.getPosition());
        dailyVerse.setNotify(z);
        dailyVerse.setNotifyTime(j);
        return dailyVerse;
    }

    private Object getRandomObject(Collection collection) {
        if (collection == null || collection.isEmpty()) {
            return null;
        }
        return collection.toArray()[new Random().nextInt(collection.size())];
    }

    public long delete(long j) {
        this.bibleDB.deleteDailyVerse(j);
        return j;
    }

    public DailyVerse updateDailyVerse(long j, Set<Long> set, String str, boolean z, long j2, boolean z2) {
        return updateDailyVerse(j, set, str, z2, z, j2);
    }

    public DailyVerse updateDailyVerse(long j, Set<Long> set, String str, boolean z, boolean z2, long j2) {
        DailyVerse createModel = createModel(set, str, z2, j2);
        if (createModel == null) {
            return null;
        }
        createModel.setId(j);
        createModel.setUserCreate(z);
        save(createModel);
        return createModel;
    }
}
