package king.james.bible.android.appad;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.karumi.dexter.BuildConfig;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public class AppAdStorage {
    private List<AppAd> appAds;
    private Context mContext;

    /* access modifiers changed from: private */
    public static class SingletonHelper {
        private static final AppAdStorage INSTANCE = new AppAdStorage();
    }

    private AppAdStorage() {
    }

    public static AppAdStorage getInstance() {
        return SingletonHelper.INSTANCE;
    }

    public void init(Context context) {
        this.mContext = context;
        new Thread(new Runnable() {
            /* class king.james.bible.android.appad.AppAdStorage.AnonymousClass1 */

            public void run() {
                try {
                    AppAdStorage.this.restore();
                } catch (Exception unused) {
                }
            }
        }).start();
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void restore() {
        try {
            SharedPreferences sharedPreferences = this.mContext.getSharedPreferences("AppAdStorage_preference", 0);
            if (sharedPreferences == null) {
                this.appAds = new ArrayList();
                return;
            }
//            this.appAds = (List) new GsonBuilder().create().fromJson(sharedPreferences.getString("appAds", BuildConfig.FLAVOR), new TypeToken<List<AppAd>>(this) {
//                /* class king.james.bible.android.appad.AppAdStorage.AnonymousClass2 */
//            }.getType());
            if (this.appAds == null) {
                this.appAds = new ArrayList();
            }
        } catch (Exception unused) {
        }
    }

    private void save() {
        new Thread(new Runnable() {
            /* class king.james.bible.android.appad.AppAdStorage.AnonymousClass3 */

            public void run() {
                try {
                    AppAdStorage.this.saveAsync();
                } catch (Exception unused) {
                }
            }
        }).start();
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void saveAsync() {
        SharedPreferences.Editor edit;
        try {
            SharedPreferences sharedPreferences = this.mContext.getSharedPreferences("AppAdStorage_preference", 0);
            if (sharedPreferences != null && (edit = sharedPreferences.edit()) != null) {
                edit.putString("appAds", new GsonBuilder().create().toJson(this.appAds));
                edit.apply();
            }
        } catch (Exception unused) {
        }
    }

    public void setAppAds(List<AppAd> list) {
        try {
            if (this.appAds != null) {
                if (!this.appAds.isEmpty()) {
                    HashMap hashMap = new HashMap();
                    for (AppAd appAd : this.appAds) {
                        if (appAd != null) {
                            hashMap.put(appAd.getId(), appAd);
                        }
                    }
                    ArrayList arrayList = new ArrayList();
                    for (AppAd appAd2 : list) {
                        if (appAd2 != null) {
                            if (!hashMap.containsKey(appAd2.getId())) {
                                arrayList.add(appAd2);
                            } else if (appAd2.getVersion() > ((AppAd) hashMap.get(appAd2.getId())).getVersion()) {
                                arrayList.add(appAd2);
                            } else {
                                appAd2.setStartCount(((AppAd) hashMap.get(appAd2.getId())).getStartCount());
                                arrayList.add(appAd2);
                            }
                        }
                    }
                    this.appAds.clear();
                    this.appAds = arrayList;
                    save();
                    return;
                }
            }
            this.appAds = list;
            save();
        } catch (Exception unused) {
        }
    }

    public AppAd getAppAdModel() {
        try {
            if (this.appAds == null) {
                this.appAds = new ArrayList();
                save();
                return null;
            }
            for (AppAd appAd : this.appAds) {
                if (appAd != null && appAd.getStartCount() >= appAd.getPeriodicity() && appAd.getPeriodicity() > 0) {
                    return appAd;
                }
            }
            return null;
        } catch (Exception unused) {
        }
        return  null;
    }

    public void incStartCount() {
        try {
            for (AppAd appAd : this.appAds) {
                if (appAd != null) {
                    if (appAd.getStartCount() >= 0) {
                        if (appAd.getStartCount() <= appAd.getPeriodicity()) {
                            appAd.setStartCount(appAd.getStartCount() + 1);
                        }
                    }
                }
            }
            save();
        } catch (Exception unused) {
        }
    }

    public void clearStartCount(String str) {
        try {
            Iterator<AppAd> it = this.appAds.iterator();
            while (true) {
                if (it.hasNext()) {
                    AppAd next = it.next();
                    if (next != null && next.getId().equals(str)) {
                        next.setStartCount(-1);
                        break;
                    }
                } else {
                    break;
                }
            }
            save();
        } catch (Exception unused) {
        }
    }

    public void restoreStartCount(String str) {
        try {
            Iterator<AppAd> it = this.appAds.iterator();
            while (true) {
                if (it.hasNext()) {
                    AppAd next = it.next();
                    if (next != null && next.getId().equals(str)) {
                        next.setStartCount(0);
                        break;
                    }
                } else {
                    break;
                }
            }
            save();
        } catch (Exception unused) {
        }
    }

    public String getAppId() {
        Context context = this.mContext;
        if (context == null) {
            return BuildConfig.FLAVOR;
        }
        return context.getPackageName().replace(".", "_");
    }
}
