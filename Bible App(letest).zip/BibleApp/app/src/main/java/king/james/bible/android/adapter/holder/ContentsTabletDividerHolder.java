package king.james.bible.android.adapter.holder;

import android.view.View;
import king.james.bible.android.R;
import king.james.bible.android.utils.BiblePreferences;

public class ContentsTabletDividerHolder extends ContentsTabletViewHolder {
    private View divider;
    private boolean showDivider;

    @Override // king.james.bible.android.adapter.holder.ContentsTabletViewHolder, king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter.BaseViewHolder
    public void updateView(Object obj) {
    }

    public ContentsTabletDividerHolder(View view, boolean z) {
        super(view);
        this.showDivider = z;
        prepareView();
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.adapter.holder.ContentsTabletViewHolder, king.james.bible.android.adapter.recycler.BaseRecyclerViewAdapter.BaseViewHolder
    public void mapViews(View view) {
        this.divider = view.findViewById(R.id.divider);
    }

    private void prepareView() {
        this.divider.setBackgroundResource(this.showDivider ? BiblePreferences.getInstance().isNightMode() ? R.color.grey_divider_n : R.color.grey_divider : 17170445);
    }
}
