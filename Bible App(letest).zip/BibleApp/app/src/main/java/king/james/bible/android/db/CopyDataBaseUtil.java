package king.james.bible.android.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import com.karumi.dexter.BuildConfig;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import king.james.bible.android.MyApplication;
import king.james.bible.android.exception.CopyDBException;
import king.james.bible.android.exception.CopyDBFileException;
import king.james.bible.android.utils.BiblePreferences;
import king.james.bible.android.utils.ExternalStorage;

public class CopyDataBaseUtil {
    private static CopyDataBaseUtil instance;
    private boolean copySDCard = false;
    private int copyTry = 0;
    private String dbName;
    private String dbPath;
    private int errorCount = 0;
    private Context mContext;

    private CopyDataBaseUtil() {
    }

    public static CopyDataBaseUtil getInstance() {
        if (instance == null) {
            synchronized (CopyDataBaseUtil.class) {
                if (instance == null) {
                    instance = new CopyDataBaseUtil();
                }
            }
        }
        return instance;
    }

    public void init(Context context, String str) {
        this.mContext = context;
        this.dbName = str;
    }

    public void setNewPatch() {
        if (this.mContext == null) {
            this.mContext = MyApplication.getContext();
        }
        Context context = this.mContext;
        if (context != null) {
            List allPaths = ExternalStorage.getAllPaths(context);
            if (allPaths == null || allPaths.isEmpty()) {
                allPaths = new ArrayList();
                allPaths.add("/storage/emulated/0/Android/data/" + this.mContext.getPackageName() + "/files");
            }
            this.dbPath = ((String) allPaths.get(0)) + "/databases/";
            int i = 0;
            while (true) {
                if (i >= allPaths.size()) {
                    break;
                }
                if (BibleDataBaseHelper.checkFileDataBase(((String) allPaths.get(i)) + "/databases/" + this.dbName)) {
                    this.dbPath = ((String) allPaths.get(i)) + "/databases/";
                    if (i != 1 && allPaths.size() > 1) {
                        String str = this.dbPath;
                        if (ExternalStorage.copyFileDB(str, ((String) allPaths.get(1)) + "/databases/")) {
                            this.dbPath = ((String) allPaths.get(1)) + "/databases/";
                        }
                    }
                } else {
                    i++;
                }
            }
            BiblePreferences instance2 = BiblePreferences.getInstance();
            instance2.setDbLocation(this.dbPath);
            instance2.lambda$saveBg$1$BiblePreferences();
            this.copySDCard = false;
            this.copyTry = 0;
        }
    }

    public void initPath(boolean z) {
        this.copySDCard = z;
        BiblePreferences instance2 = BiblePreferences.getInstance();
        instance2.lambda$restoreAsync$0$BiblePreferences();
        if (BibleDataBaseHelper.checkFileDataBase(getDefPath() + "/databases/" + this.dbName)) {
            String str = getDefPath() + "/databases/";
            this.dbPath = str;
            instance2.setDbLocation(str);
            instance2.lambda$saveBg$1$BiblePreferences();
        }
        if (instance2.getDbLocation().isEmpty()) {
            setNewPatch();
            this.dbPath = instance2.getDbLocation();
            if (!new File(this.dbPath + this.dbName).exists()) {
                this.dbPath = getDefPath() + "/databases/";
            }
        } else {
            if (BibleDataBaseHelper.checkFileDataBase(instance2.getDbLocation() + this.dbName)) {
                this.dbPath = instance2.getDbLocation();
            } else {
                this.dbPath = getDefPath() + "/databases/";
            }
        }
        File file = new File(this.dbPath);
        if (!file.exists()) {
            file.mkdirs();
        }
        instance2.setDbLocation(this.dbPath);
        instance2.lambda$saveBg$1$BiblePreferences();
    }

    private String getDefPath() {
        List<String> allPaths;
        Context context = this.mContext;
        if (context == null || (allPaths = ExternalStorage.getAllPaths(context)) == null || allPaths.isEmpty()) {
            return BuildConfig.FLAVOR;
        }
        if (allPaths.size() > 1) {
            return allPaths.get(1);
        }
        return allPaths.get(0);
    }

    public String getDBAbsolutePath() {
        return this.dbPath + this.dbName;
    }

    public void copyDataBase() throws Throwable {
        try {
            this.copyTry++;
            clearFolder();
            BiblePreferences.getInstance().setDbLocation("null");
            BiblePreferences.getInstance().lambda$saveBg$1$BiblePreferences();
            initPath(false);
            clearFolder();
            copy();
            if (!connectDB()) {
                if (this.copyTry >= 3) {
                    if (this.copySDCard) {
                        throw new CopyDBException();
                    }
                }
                copyError();
            }
        } catch (CopyDBFileException unused) {
            copyError();
        } catch (Exception unused2) {
            throw new CopyDBException();
        }
    }

    private void copyError() throws Throwable {
        int i = this.errorCount + 1;
        this.errorCount = i;
        if (i > 9 || (this.copyTry >= 3 && this.copySDCard)) {
            throw new CopyDBException();
        }
        if (this.copyTry >= 3) {
            this.copyTry = 0;
            initPath(true);
        }
        copyDataBase();
    }

    private boolean connectDB() {
        try {
            BibleDataBase openForMigration = BibleDataBase.getInstance().openForMigration();
            openForMigration.openForMigration();
            int dbVersion = openForMigration.getDbVersion();
            openForMigration.close();
            if (dbVersion < 0) {
                return false;
            }
            return true;
        } catch (Exception unused) {
            return false;
        }
    }

    private void clearFolder() {
        new File(this.dbPath).mkdirs();
        deleteDBFile();
    }

    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:4:0x0031 */
    /* JADX WARNING: Removed duplicated region for block: B:11:? A[RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:9:0x0049  */
    private void deleteDBFile() {
        BiblePreferences.getInstance().setDbLocation(BuildConfig.FLAVOR);
        BiblePreferences.getInstance().lambda$saveBg$1$BiblePreferences();
        if (Build.VERSION.SDK_INT >= 16) {
            SQLiteDatabase.deleteDatabase(new File(this.dbPath + this.dbName));
        }
        try {
            this.mContext.deleteDatabase(this.dbName);
        } catch (Exception unused) {
        }
        File file = new File(getDBAbsolutePath());
        if (!file.exists()) {
            file.delete();
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:43:0x0074 A[SYNTHETIC, Splitter:B:43:0x0074] */
    /* JADX WARNING: Removed duplicated region for block: B:49:0x007f A[SYNTHETIC, Splitter:B:49:0x007f] */
    private void copy() throws Throwable {
        FileOutputStream fileOutputStream;
        Throwable th;
        InputStream inputStream;
        Exception e;
        try {
            inputStream = this.mContext.getApplicationContext().getAssets().open(this.dbName);
            try {
                File file = new File(this.dbPath);
                if (!file.exists()) {
                    file.mkdirs();
                }
                File file2 = new File(this.dbPath, this.dbName);
                if (!file2.exists()) {
                    file2.createNewFile();
                }
                fileOutputStream = new FileOutputStream(file2);
                try {
                    byte[] bArr = new byte[5120];
                    while (true) {
                        int read = inputStream.read(bArr);
                        if (read <= 0) {
                            break;
                        }
                        fileOutputStream.write(bArr, 0, read);
                    }
                    fileOutputStream.flush();
                    try {
                        fileOutputStream.close();
                        if (inputStream != null) {
                            try {
                                inputStream.close();
                            } catch (IOException e2) {
                                logException(e2);
                                throw null;
                            }
                        }
                    } catch (Exception e3) {
                        logException(e3);
                        throw null;
                    }
                } catch (Exception e4) {
                    e = e4;
                    try {
                        logException(e);
                        throw null;
                    } catch (Throwable th2) {
                        th = th2;
                        if (fileOutputStream != null) {
                            try {
                                fileOutputStream.close();
                            } catch (Exception e5) {
                                logException(e5);
                                throw null;
                            }
                        }
                        if (inputStream != null) {
                            try {
                                inputStream.close();
                            } catch (IOException e6) {
                                logException(e6);
                                throw null;
                            }
                        }
                        throw th;
                    }
                }
            } catch (Exception e7) {
                e = e7;
                fileOutputStream = null;
                logException(e);
                throw null;
            } catch (Throwable th3) {
                th = th3;
                fileOutputStream = null;
                if (fileOutputStream != null) {
                }
                if (inputStream != null) {
                }
                throw th;
            }
        } catch (Exception e8) {
            e = e8;
            inputStream = null;
            fileOutputStream = null;
            logException(e);
            throw null;
        } catch (Throwable th4) {
            th = th4;
            inputStream = null;
            fileOutputStream = null;
            if (fileOutputStream != null) {
            }
            if (inputStream != null) {
            }
            throw th;
        }
    }

    private void logException(Exception exc) throws CopyDBFileException {
        throw new CopyDBFileException();
    }
}
