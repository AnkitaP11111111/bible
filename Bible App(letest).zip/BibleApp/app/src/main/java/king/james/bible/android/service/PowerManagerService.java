package king.james.bible.android.service;

import android.annotation.SuppressLint;
import android.os.PowerManager;

import king.james.bible.android.MyApplication;
import king.james.bible.android.utils.BiblePreferences;

public class PowerManagerService {
    private static final String TAG = "king.james.bible.android.service.PowerManagerService";

    /* access modifiers changed from: private */
    public static class SingletonHelper {
        private static final PowerManagerService INSTANCE = new PowerManagerService();
    }

    private PowerManagerService() {
    }

    public static PowerManagerService getInstance() {
        return SingletonHelper.INSTANCE;
    }

    public synchronized void start() {
        new Thread(new Runnable() {
            /* class king.james.bible.android.service.$$Lambda$PowerManagerService$S5R_HRCJDIFqGbVec5n4HWvH7c */

            public final void run() {
                PowerManagerService.this.lambda$start$0$PowerManagerService();
            }
        }).start();
    }

    public /* synthetic */ void lambda$start$0$PowerManagerService() {
        try {
            if (BiblePreferences.getInstance().isScreenStay()) {
                acquire();
            }
        } catch (Exception unused) {
        }
    }

    public synchronized void updateState(boolean z) {
        if (z) {
            acquire();
        }
    }

    /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
    @SuppressLint({"InvalidWakeLockTag", "WrongConstant"})
    private synchronized void acquire() {
        ((PowerManager) MyApplication.getContext().getSystemService("power")).newWakeLock(805306394, TAG).acquire(120000);
    }
}
