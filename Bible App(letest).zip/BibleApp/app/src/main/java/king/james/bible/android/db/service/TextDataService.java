package king.james.bible.android.db.service;

import android.database.Cursor;
import com.karumi.dexter.BuildConfig;
import java.util.ArrayList;
import java.util.List;
import king.james.bible.android.db.BibleDataBase;
import king.james.bible.android.model.SpanType;
import king.james.bible.android.model.Text;
import king.james.bible.android.utils.SettingsTextUtil;

public class TextDataService {
    private static int chap;
    private static List<Text> list;
    private static int page;

    private static synchronized void clear() {
        synchronized (TextDataService.class) {
            page = -1;
            chap = -1;
            if (list != null) {
                list.clear();
            }
            list = null;
        }
    }

    public static void doLoadPageModels(int i, int i2) {
        page = i;
        chap = i2;
        list = getTextList(i, i2);
    }

    private static List<Text> getFirstTextModels(List<Text> list2) {
        ArrayList arrayList = new ArrayList();
        byte b = 0;
        for (int i = 0; i < list2.size(); i++) {
            Text text = list2.get(i);
            arrayList.add(text);
            if (text.isVerse()) {
                b = (byte) (b + 1);
            }
            if (b >= 2) {
                break;
            }
        }
        return arrayList;
    }

    public static synchronized List<Text> getTextList(int i, int i2) {
        synchronized (TextDataService.class) {
            if (page != i || chap != i2 || list == null || list.isEmpty()) {
                clear();
                List<Text> arrayList = new ArrayList<>();
                try {
                    Cursor chapterTextStart = BibleDataBase.getInstance().getChapterTextStart(i, i2);
                    if (chapterTextStart != null) {
                        if (chapterTextStart.getCount() >= 1) {
                            arrayList = getTextList(chapterTextStart);
                            return arrayList;
                        }
                    }
                    return arrayList;
                } catch (Exception unused) {
                }
            } else {
                return list;
            }
        }
    }

    public static synchronized List<Text> getFirstTextModels(int i, int i2) {
        synchronized (TextDataService.class) {
            if (page != i || chap != i2 || list == null || list.isEmpty()) {
                clear();
                Cursor chapterTextStart = BibleDataBase.getInstance().getChapterTextStart(i, i2);
                ArrayList arrayList = new ArrayList();
                byte b = 0;
                if (chapterTextStart != null) {
                    try {
                        if (!chapterTextStart.isClosed()) {
                            if (chapterTextStart.getCount() >= 1) {
                                if (!chapterTextStart.moveToFirst()) {
                                    return arrayList;
                                }
                                do {
                                    Text buildText = buildText(chapterTextStart);
                                    int size = arrayList.size() - 1;
                                    if (arrayList.isEmpty() || buildText.getHead() <= 0 || ((Text) arrayList.get(size)).getHead() != buildText.getHead()) {
                                        if (buildText.isVerse()) {
                                            b = (byte) (b + 1);
                                        }
                                        arrayList.add(buildText);
                                    } else {
                                        ((Text) arrayList.get(size)).setText(((Text) arrayList.get(size)).getText() + " " + buildText.getText());
                                    }
                                    if (!chapterTextStart.moveToNext()) {
                                        break;
                                    }
                                } while (b < 2);
                                return arrayList;
                            }
                        }
                    } catch (Exception unused) {
                    }
                }
                return arrayList;
            }
            return getFirstTextModels(list);
        }
    }

    private static List<Text> getTextList(Cursor cursor) {
        ArrayList arrayList = new ArrayList();
        try {
            if (cursor.moveToFirst()) {
                do {
                    Text buildText = buildText(cursor);
                    int size = arrayList.size() - 1;
                    if (arrayList.isEmpty() || buildText.getHead() <= 0 || ((Text) arrayList.get(size)).getHead() != buildText.getHead()) {
                        arrayList.add(buildText);
                    } else {
                        ((Text) arrayList.get(size)).setText(((Text) arrayList.get(size)).getText() + " " + buildText.getText());
                    }
                } while (cursor.moveToNext());
            }
        } catch (Exception unused) {
        } catch (Throwable th) {
            cursor.close();
            throw th;
        }
        cursor.close();
        return arrayList;
    }

    private static Text buildText(Cursor cursor) {
        Text text = new Text();
        text.setId((long) cursor.getInt(cursor.getColumnIndexOrThrow("_id")));
        text.setChapterId((long) cursor.getInt(cursor.getColumnIndexOrThrow("chapter_id")));
        text.setChapterNum(cursor.getInt(cursor.getColumnIndexOrThrow("chapter_num")));
        text.setPosition(cursor.getInt(cursor.getColumnIndexOrThrow("position")));
        text.setText(SettingsTextUtil.prepareText(cursor.getString(cursor.getColumnIndexOrThrow("text"))));
        text.setRank(cursor.getInt(cursor.getColumnIndexOrThrow("rank")));
        text.setHead(cursor.getInt(cursor.getColumnIndexOrThrow("head")));
        text.setBookmark(cursor.getInt(cursor.getColumnIndexOrThrow("bookmark")));
        text.setHighlight(SpanType.getSpanType(cursor.getInt(cursor.getColumnIndexOrThrow("highlight"))));
        text.setNote(cursor.getString(cursor.getColumnIndexOrThrow("note")));
        text.setBookmarkDate(cursor.getLong(cursor.getColumnIndexOrThrow("bookmark_date")));
        text.setHighlightDate(cursor.getLong(cursor.getColumnIndexOrThrow("highlight_date")));
        text.setNoteDate(cursor.getLong(cursor.getColumnIndexOrThrow("note_date")));
        try {
            text.setnText(cursor.getString(cursor.getColumnIndexOrThrow("ntext")));
        } catch (Exception unused) {
            text.setnText(BuildConfig.FLAVOR);
        }
        return text;
    }
}
