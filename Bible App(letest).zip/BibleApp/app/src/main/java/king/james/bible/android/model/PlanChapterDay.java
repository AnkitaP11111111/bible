package king.james.bible.android.model;

import java.io.Serializable;

public class PlanChapterDay implements Serializable {
    private int chapterNum;
    private int chapterOrder;
    private int day;
    private long id;
    private long modeId;
    private long planId;
    private boolean viewed;

    public long getId() {
        return this.id;
    }

    public void setId(long j) {
        this.id = j;
    }

    public long getPlanId() {
        return this.planId;
    }

    public void setPlanId(long j) {
        this.planId = j;
    }

    public long getModeId() {
        return this.modeId;
    }

    public void setModeId(long j) {
        this.modeId = j;
    }

    public int getDay() {
        return this.day;
    }

    public void setDay(int i) {
        this.day = i;
    }

    public int getChapterOrder() {
        return this.chapterOrder;
    }

    public void setChapterOrder(int i) {
        this.chapterOrder = i;
    }

    public boolean isViewed() {
        return this.viewed;
    }

    public void setViewed(boolean z) {
        this.viewed = z;
    }

    public int getChapterNum() {
        return this.chapterNum;
    }

    public void setChapterNum(int i) {
        this.chapterNum = i;
    }
}
