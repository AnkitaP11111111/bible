package king.james.bible.android.fragment;

public interface FragmentCallbackListener {
    void onFragmentResultOk(int i, int i2, int i3, int i4, Object obj);

    void onFragmentResultOk(int i, int i2, int i3, int i4, Object obj, boolean z);
}
