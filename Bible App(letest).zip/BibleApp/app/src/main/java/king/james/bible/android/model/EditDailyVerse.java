package king.james.bible.android.model;

import java.util.Set;

public class EditDailyVerse {
    private boolean notify;
    private long notifyTime;
    private Set<Long> selectChapters;
    private String title;

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String str) {
        this.title = str;
    }

    public boolean isNotify() {
        return this.notify;
    }

    public void setNotify(boolean z) {
        this.notify = z;
    }

    public long getNotifyTime() {
        return this.notifyTime;
    }

    public void setNotifyTime(long j) {
        this.notifyTime = j;
    }

    public Set<Long> getSelectChapters() {
        return this.selectChapters;
    }

    public void setSelectChapters(Set<Long> set) {
        this.selectChapters = set;
    }
}
