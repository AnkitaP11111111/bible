package king.james.bible.android.db.service;

import android.database.Cursor;
import android.text.Html;
import android.text.SpannableString;
import android.util.Log;
import com.karumi.dexter.BuildConfig;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import king.james.bible.android.db.BibleDataBase;
import king.james.bible.android.model.SearchTextResult;
import king.james.bible.android.model.SearchType;
import king.james.bible.android.task.SearchPartsTask;
import king.james.bible.android.utils.SearchCache;
import king.james.bible.android.utils.SettingsTextUtil;

public class SearchService {
    private static SearchPartsTask.SearchListener listener;

    public static void setSearchListener(SearchPartsTask.SearchListener searchListener) {
        listener = searchListener;
    }

    public static void searchTextModels(SearchType searchType, String str, int i, boolean z, boolean z2) {
        Cursor cursor;
        SearchCache.getInstance().setSearchType(searchType);
        if (str.isEmpty() || !BibleDataBase.checkSearchText(str)) {
            listener.onCount(0, false);
            return;
        }
        Cursor cursor2 = null;
        try {
            BibleDataBase instance = BibleDataBase.getInstance();
            String[] words = BibleDataBase.getWords(str.replace("?", "/?").replace("\"", "\"\"").replace("'", "''"), false);
            String[] normalizeWords = BibleDataBase.getNormalizeWords(words);
            int i2 = AnonymousClass1.$SwitchMap$king$james$bible$android$model$SearchType[searchType.ordinal()];
            if (i2 == 1) {
                cursor = instance.searchText(words, normalizeWords, z2);
            } else if (i2 != 2) {
                cursor = instance.searchByChapters(words, instance.getChapterQueryByMode(getModeByType(searchType)), z2);
            } else {
                cursor = instance.searchByChapters(words, "chapter_id" + " = " + i, z2);
            }
            cursor2 = cursor;
            if (listener == null) {
                closeCursor(cursor2);
                return;
            }
            listener.onCount(z ? 0 : cursor2.getCount(), z);
            if (cursor2.getCount() > 0) {
                HashSet hashSet = new HashSet(Arrays.asList(words));
                hashSet.addAll(Arrays.asList(normalizeWords));
                parseSearchModels(cursor2, hashSet, z2, z, str);
            } else {
                listener.onParseComplete(0, 0);
            }
            closeCursor(cursor2);
        } catch (Exception unused) {
            listener.onError();
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: king.james.bible.android.db.service.SearchService$1  reason: invalid class name */
    public static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] $SwitchMap$king$james$bible$android$model$SearchType;

        /* JADX WARNING: Can't wrap try/catch for region: R(12:0|1|2|3|4|5|6|7|8|9|10|12) */
        /* JADX WARNING: Code restructure failed: missing block: B:13:?, code lost:
            return;
         */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x001d */
        /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x0028 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:9:0x0033 */
        static {
            int[] iArr = new int[SearchType.values().length];
            $SwitchMap$king$james$bible$android$model$SearchType = iArr;
            iArr[SearchType.ALL.ordinal()] = 1;
            $SwitchMap$king$james$bible$android$model$SearchType[SearchType.CURRENT.ordinal()] = 2;
            $SwitchMap$king$james$bible$android$model$SearchType[SearchType.AP.ordinal()] = 3;
            $SwitchMap$king$james$bible$android$model$SearchType[SearchType.OT.ordinal()] = 4;
            $SwitchMap$king$james$bible$android$model$SearchType[SearchType.NT.ordinal()] = 5;
        }
    }

    private static void closeCursor(Cursor cursor) {
        try {
            cursor.close();
        } catch (Exception unused) {
        }
    }

    private static int getModeByType(SearchType searchType) {
        int i = AnonymousClass1.$SwitchMap$king$james$bible$android$model$SearchType[searchType.ordinal()];
        if (i != 3) {
            return i != 5 ? 1 : 2;
        }
        return 3;
    }

    /* JADX WARNING: Removed duplicated region for block: B:52:0x0165 A[LOOP:0: B:5:0x0022->B:52:0x0165, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:55:0x0141 A[SYNTHETIC] */
    private static void parseSearchModels(Cursor cursor, Set<String> set, boolean z, boolean z2, String str) {
        String str2;
        Cursor cursor2 = cursor;
        ArrayList arrayList = new ArrayList();
        Map<Integer, String> chapterNameMap = BibleDataBase.getInstance().getChapterNameMap();
        int count = cursor.getCount();
        int i = 0;
        int i2 = z2 ? 0 : count;
        cursor.moveToFirst();
        String normalizeWord = BibleDataBase.getNormalizeWord(str);
        while (listener != null) {
            String string = cursor2.getString(cursor2.getColumnIndexOrThrow("text"));
            try {
                str2 = cursor2.getString(cursor2.getColumnIndexOrThrow("ntext"));
            } catch (Exception unused) {
                str2 = BuildConfig.FLAVOR;
            }
            if (str2 == null) {
                str2 = BuildConfig.FLAVOR;
            }
            if (z2) {
                String obj = Html.fromHtml(string).toString();
                String obj2 = Html.fromHtml(str2).toString();
                if (!SettingsTextUtil.containsIgnoreCase(obj, str) && !SettingsTextUtil.containsIgnoreCase(obj2, normalizeWord)) {
                    if (!cursor.moveToNext()) {
                        cursor2 = cursor;
                    } else if (listener != null) {
                        if (i == 0 && !arrayList.isEmpty() && z2) {
                            i2 += arrayList.size();
                            listener.onPartLoad(i2, new ArrayList(arrayList));
                        }
                        listener.onParseComplete(i2, i);
                        return;
                    } else {
                        return;
                    }
                }
            }
            int i3 = cursor2.getInt(cursor2.getColumnIndexOrThrow("_id"));
            int i4 = cursor2.getInt(cursor2.getColumnIndexOrThrow("chapter_id"));
            int i5 = cursor2.getInt(cursor2.getColumnIndexOrThrow("chapter_num"));
            int i6 = cursor2.getInt(cursor2.getColumnIndexOrThrow("position"));
            SpannableString spannableString = new SpannableString(Html.fromHtml(("<b>" + (chapterNameMap.containsKey(Integer.valueOf(i4)) ? chapterNameMap.get(Integer.valueOf(i4)) : BuildConfig.FLAVOR) + " " + i5 + ":" + i6 + "</b>" + "<br>") + (set.size() > 0 ? replaceSearchOnBold(SettingsTextUtil.prepareText(string), set, z, str2) : BuildConfig.FLAVOR)));
            SearchTextResult searchTextResult = new SearchTextResult();
            searchTextResult.setId((long) i3);
            searchTextResult.setText(spannableString);
            arrayList.add(searchTextResult);
            if (listener != null) {
                if (arrayList.size() >= 500 || cursor.getPosition() == count - 1) {
                    if (z2) {
                        i2 += arrayList.size();
                    }
                    listener.onPartLoad(i2, new ArrayList(arrayList));
                    i++;
                    arrayList.clear();
                }
                if (!cursor.moveToNext()) {
                }
            } else {
                return;
            }
        }
    }

    public static String replaceSearchOnBold(String str, Set<String> set, boolean z, String str2) {
        int indexOf;
        HashSet hashSet = new HashSet();
        String str3 = str;
        for (String str4 : set) {
            if (str3.toLowerCase().contains(str4.toLowerCase())) {
                str3 = replaceSearchOnBold(str3, str4, z);
                hashSet.add(BibleDataBase.getNormalizeWord(str4));
            } else if (!hashSet.contains(str4) && (indexOf = str2.toLowerCase().indexOf(str4.toLowerCase())) > -1) {
                str3 = replaceSearchOnBold(str3, str.substring(indexOf, str4.length() + indexOf), z);
            }
        }
        return str3;
    }

    public static String replaceSearchOnBold(String str, String str2, boolean z) {
        if (z) {
            return str.replaceAll("(?i)(\\b" + str2 + "\\b)", "<b><font color='#bf360c'>$1</font></b>");
        }
        try {
            return str.replaceAll("(?i)(" + str2 + ")", "<b><font color='#bf360c'>$1</font></b>");
        } catch (Exception e) {
            Log.e(e.getMessage(), e.getMessage(), e);
            return str2;
        }
    }
}
