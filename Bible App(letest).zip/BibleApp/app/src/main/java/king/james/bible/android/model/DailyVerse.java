package king.james.bible.android.model;

import java.io.Serializable;
import java.util.Set;
import king.james.bible.android.model.export.DailyVerseSimple;

public class DailyVerse implements Serializable {
    private String chapter;
    private Set<Long> chapters;
    private long id;
    private boolean notify;
    private long notifyTime;
    private String text;
    private String title;
    private boolean userCreate;
    private long verseId;

    public DailyVerse() {
    }

    public DailyVerse(DailyVerseSimple dailyVerseSimple) {
        this.title = dailyVerseSimple.getTitle();
        this.verseId = dailyVerseSimple.getVerseId();
        this.userCreate = true;
        this.chapters = dailyVerseSimple.getChapters();
        this.notify = dailyVerseSimple.isNotify();
        this.notifyTime = dailyVerseSimple.getNotifyTime();
    }

    public long getId() {
        return this.id;
    }

    public void setId(long j) {
        this.id = j;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String str) {
        this.title = str;
    }

    public String getText() {
        return this.text;
    }

    public void setText(String str) {
        this.text = str;
    }

    public String getChapter() {
        return this.chapter;
    }

    public void setChapter(String str) {
        this.chapter = str;
    }

    public long getVerseId() {
        return this.verseId;
    }

    public void setVerseId(long j) {
        this.verseId = j;
    }

    public boolean isUserCreate() {
        return this.userCreate;
    }

    public void setUserCreate(boolean z) {
        this.userCreate = z;
    }

    public Set<Long> getChapters() {
        return this.chapters;
    }

    public void setChapters(Set<Long> set) {
        this.chapters = set;
    }

    public boolean isNotify() {
        return this.notify;
    }

    public void setNotify(boolean z) {
        this.notify = z;
    }

    public long getNotifyTime() {
        return this.notifyTime;
    }

    public void setNotifyTime(long j) {
        this.notifyTime = j;
    }

    public String toString() {
        return "id=" + this.id + " : title=" + this.title + " : notifyTime=" + this.notifyTime;
    }
}
