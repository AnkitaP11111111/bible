package king.james.bible.android.event;

public class UpdateMainFragmentEvent {
    public long getOuterChapter() {
        throw null;
    }
}
