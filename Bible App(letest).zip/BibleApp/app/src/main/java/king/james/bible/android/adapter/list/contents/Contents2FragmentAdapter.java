package king.james.bible.android.adapter.list.contents;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.karumi.dexter.BuildConfig;
import king.james.bible.android.R;
import java.util.List;
import king.james.bible.android.utils.BiblePreferences;

public class Contents2FragmentAdapter extends BaseAdapter {
    private Context context;
    private List<Integer> itemsList;
    private int layoutId;
    private BiblePreferences preferences;

    public long getItemId(int i) {
        return 0;
    }

    public Contents2FragmentAdapter(List<Integer> list, Context context2) {
        this.itemsList = list;
        this.context = context2;
        BiblePreferences instance = BiblePreferences.getInstance();
        this.preferences = instance;
        instance.lambda$restoreAsync$0$BiblePreferences();
        this.layoutId = this.preferences.isNightMode() ? R.layout.content_item_layout_n : R.layout.content_item_layout;
    }

    public int getCount() {
        return this.itemsList.size();
    }

    public Object getItem(int i) {
        return this.itemsList.get(i);
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = LayoutInflater.from(this.context).inflate(this.layoutId, viewGroup, false);
        }
        TextView textView = (TextView) view.findViewById(R.id.content_item_text);
        textView.setText(BuildConfig.FLAVOR + getItem(i));
        return textView;
    }
}
