package king.james.bible.android.service;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.Calendar;
import java.util.Date;

public class DailyVerseService {
    private static DailyVerseService instance;
    private Context context;
    private boolean dailyVerseBackStack = false;
    private int dailyVersePosition;
    private int day;
    private int month;
    private int year;

    private DailyVerseService() {
    }

    public static DailyVerseService getInstance() {
        if (instance == null) {
            synchronized (DailyVerseService.class) {
                if (instance == null) {
                    instance = new DailyVerseService();
                }
            }
        }
        return instance;
    }

    public void init(Context context2) {
        this.context = context2;
    }

    private void restore() {
        SharedPreferences sharedPreferences = this.context.getSharedPreferences("king.james.bible.android.service.DailyVerseService_preference", 0);
        if (sharedPreferences != null) {
            this.year = sharedPreferences.getInt("year", 0);
            this.month = sharedPreferences.getInt("month", 0);
            this.day = sharedPreferences.getInt("day", 0);
        }
    }

    private void save() {
        SharedPreferences.Editor edit;
        SharedPreferences sharedPreferences = this.context.getSharedPreferences("king.james.bible.android.service.DailyVerseService_preference", 0);
        if (sharedPreferences != null && (edit = sharedPreferences.edit()) != null) {
            edit.putInt("year", this.year);
            edit.putInt("month", this.month);
            edit.putInt("day", this.day);
            edit.apply();
        }
    }

    public boolean isNewDay() {
        restore();
        Calendar instance2 = Calendar.getInstance();
        instance2.setTime(new Date());
        int i = instance2.get(1);
        int i2 = instance2.get(2);
        int i3 = instance2.get(5);
        if (this.year == 0 && this.month == 0 && this.day == 0) {
            update(i, i2, i3);
            return false;
        }
        int i4 = this.year;
        if (i > i4 || i < i4) {
            update(i, i2, i3);
            return true;
        }
        int i5 = this.month;
        if (i2 > i5 || i2 < i5) {
            update(i, i2, i3);
            return true;
        }
        int i6 = this.day;
        if (i3 <= i6 && i3 >= i6) {
            return false;
        }
        update(i, i2, i3);
        return true;
    }

    private void update(int i, int i2, int i3) {
        this.year = i;
        this.month = i2;
        this.day = i3;
        save();
    }

    public int getDailyVersePosition() {
        return this.dailyVersePosition;
    }

    public void setDailyVersePosition(int i) {
        this.dailyVersePosition = i;
    }

    public boolean isDailyVerseBackStack() {
        return this.dailyVerseBackStack;
    }

    public void setDailyVerseBackStack(boolean z) {
        this.dailyVerseBackStack = z;
    }

    public void clearDailyVerseBackStack() {
        setDailyVerseBackStack(false);
        setDailyVersePosition(0);
    }
}
