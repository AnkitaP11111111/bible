package king.james.bible.android.dialog;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.widget.SwitchCompat;
import king.james.bible.android.R;
import king.james.bible.android.service.PowerManagerService;
import king.james.bible.android.service.observable.NotifyTimeListenerObservable;
import king.james.bible.android.utils.BiblePreferences;
import king.james.bible.android.view.InputTimeView;

public class NotifyDialog extends BaseForegroundDialog implements View.OnClickListener {
    private boolean existAction;
    private InputTimeView inputTimeView;
    private boolean notify;
    private SwitchCompat notifySwitchCompat;
    private long notifyTime;
    private long planId;

    public interface NotifyTimeListener {
        void cancelNotifyDialog();

        void selectNotifyTime(long j, boolean z, long j2);
    }

    @Override // androidx.fragment.app.DialogFragment
    public Dialog onCreateDialog(Bundle bundle) {
        this.existAction = false;
        if (bundle != null) {
            this.planId = bundle.getLong("planId", -1);
            this.notify = bundle.getBoolean("notify", false);
            this.notifyTime = bundle.getLong("notifyTime", 32400000);
        }
        Dialog onCreateDialog = super.onCreateDialog(bundle);
        onCreateDialog.getWindow().requestFeature(1);
        return onCreateDialog;
    }

    @Override // androidx.fragment.app.Fragment, androidx.fragment.app.DialogFragment
    public void onSaveInstanceState(Bundle bundle) {
        if (bundle == null) {
            bundle = new Bundle();
        }
        bundle.putLong("planId", this.planId);
        bundle.putBoolean("notify", getNotifyInput());
        bundle.putLong("notifyTime", this.inputTimeView.getValue());
        super.onSaveInstanceState(bundle);
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.BaseDialogFragment
    public int getLayoutResourceId() {
        return BiblePreferences.getInstance().isNightMode() ? R.layout.notify_dialog_n : R.layout.notify_dialog;
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.BaseDialogFragment
    public void mapViews(View view) {
        view.findViewById(R.id.yesButton).setOnClickListener(this);
        view.findViewById(R.id.noButton).setOnClickListener(this);
        this.inputTimeView = (InputTimeView) view.findViewById(R.id.inputTimeView);
        this.notifySwitchCompat = (SwitchCompat) view.findViewById(R.id.notifySwitchCompat);
        view.findViewById(R.id.topDivider).setBackgroundResource(BiblePreferences.getInstance().isNightMode() ? R.color.bright_foreground_material_dark : R.color.ad_button_night_bg_start_color);
        PowerManagerService.getInstance().start();
    }

    /* access modifiers changed from: protected */
    @Override // king.james.bible.android.dialog.BaseDialogFragment
    public void initActions() {
        this.inputTimeView.setValue(this.notifyTime);
        this.notifySwitchCompat.setChecked(this.notify);
    }

    public void setParameters(long j, boolean z, long j2) {
        this.planId = j;
        this.notify = z;
        this.notifyTime = j2;
        if (j2 == 0) {
            this.notifyTime = 32400000;
        }
        this.notify = true;
    }

    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.noButton) {
            selectNo();
            dismiss();
        } else if (id == R.id.yesButton) {
            selectYes();
            dismiss();
        }
    }

    private boolean getNotifyInput() {
        return this.notifySwitchCompat.isChecked();
    }

    private void selectYes() {
        this.existAction = true;
        NotifyTimeListenerObservable.getInstance().selectNotifyTime(this.planId, getNotifyInput(), this.inputTimeView.getValue());
    }

    private void selectNo() {
        this.existAction = true;
        NotifyTimeListenerObservable.getInstance().cancelNotifyDialog();
    }

    @Override // androidx.fragment.app.DialogFragment
    public void onDismiss(DialogInterface dialogInterface) {
        super.onDismiss(dialogInterface);
        if (!this.existAction) {
            selectNo();
        }
    }
}
