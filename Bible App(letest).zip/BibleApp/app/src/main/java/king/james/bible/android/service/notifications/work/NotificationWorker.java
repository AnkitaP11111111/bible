package king.james.bible.android.service.notifications.work;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import king.james.bible.android.service.notifications.AlarmBroadcast;
import king.james.bible.android.utils.DateUtil;
@SuppressLint({"NewApi", "WrongConstant"})

public class NotificationWorker {
    public static String EXTRA_ID = "intent.extra.alarm";
    public static String EXTRA_TIME = "intent.extra.time";
    public static String EXTRA_TYPE = "intent.extra.type";
    public static String EXTRA_TYPE_DAILY_VERSE = "intent.extra.type.dailyVerse";
    public static String EXTRA_TYPE_PLAN = "intent.extra.type.plan";

    public static void runAlarm(Context context, long j, String str, long j2) {
        int i = Build.VERSION.SDK_INT >= 23 ? 1140850688 : 1073741824;
        Intent intent = new Intent("english.tagalog.bible.ACTION_INEXACT_FIRED");
        intent.setClass(context, AlarmBroadcast.class);
        intent.putExtra(EXTRA_ID, j);
        intent.putExtra(EXTRA_TYPE, str);
        intent.putExtra(EXTRA_TIME, j2);
        SetterFabric.getAlarmStrategy().setInexactAlarm((AlarmManager) context.getSystemService("alarm"), getNotifyTime(j2), PendingIntent.getBroadcast(context, (int) j, intent, i));
    }

    private static long getNotifyTime(long j) {
        long startDayTime = DateUtil.getStartDayTime();
        long j2 = startDayTime + j;
        return System.currentTimeMillis() < j2 ? j2 : startDayTime + 86400000 + j;
    }

    public static void removeAlarm(Context context, long j) {
        int i = Build.VERSION.SDK_INT >= 23 ? 1140850688 : 1073741824;
        Intent intent = new Intent("english.tagalog.bible.ACTION_INEXACT_FIRED");
        intent.setClass(context, AlarmBroadcast.class);
        ((AlarmManager) context.getSystemService("alarm")).cancel(PendingIntent.getBroadcast(context, (int) j, intent, i));
    }
}
