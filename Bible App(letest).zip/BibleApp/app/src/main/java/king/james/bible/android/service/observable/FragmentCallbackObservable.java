package king.james.bible.android.service.observable;

import java.util.HashSet;
import java.util.Set;
import king.james.bible.android.fragment.FragmentCallbackListener;

public class FragmentCallbackObservable implements FragmentCallbackListener {
    private static FragmentCallbackObservable instance;
    private Set<FragmentCallbackListener> callbackListeners;

    private FragmentCallbackObservable() {
    }

    public static FragmentCallbackObservable getInstance() {
        if (instance == null) {
            synchronized (FragmentCallbackObservable.class) {
                if (instance == null) {
                    instance = new FragmentCallbackObservable();
                }
            }
        }
        return instance;
    }

    public void subscribe(FragmentCallbackListener fragmentCallbackListener) {
        checkList();
        this.callbackListeners.add(fragmentCallbackListener);
    }

    public void remove(FragmentCallbackListener fragmentCallbackListener) {
        checkList();
        this.callbackListeners.remove(fragmentCallbackListener);
    }

    private void checkList() {
        if (this.callbackListeners == null) {
            this.callbackListeners = new HashSet();
        }
    }

    @Override // king.james.bible.android.fragment.FragmentCallbackListener
    public void onFragmentResultOk(int i, int i2, int i3, int i4, Object obj) {
        onFragmentResultOk(i, i2, i3, i4, obj, false);
    }

    @Override // king.james.bible.android.fragment.FragmentCallbackListener
    public void onFragmentResultOk(int i, int i2, int i3, int i4, Object obj, boolean z) {
        checkList();
        for (FragmentCallbackListener fragmentCallbackListener : this.callbackListeners) {
            if (fragmentCallbackListener != null) {
                fragmentCallbackListener.onFragmentResultOk(i, i2, i3, i4, obj, z);
            }
        }
    }
}
