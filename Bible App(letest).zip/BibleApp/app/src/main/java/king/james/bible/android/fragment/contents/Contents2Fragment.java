package king.james.bible.android.fragment.contents;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ListAdapter;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import com.karumi.dexter.BuildConfig;
import king.james.bible.android.R;
import java.util.List;
import king.james.bible.android.adapter.list.contents.Contents2FragmentAdapter;
import king.james.bible.android.db.BibleDataBase;
import king.james.bible.android.service.PowerManagerService;
import king.james.bible.android.utils.BiblePreferences;

public class Contents2Fragment extends Fragment implements AdapterView.OnItemClickListener {
    public static final String TAG = Contents2Fragment.class.getSimpleName();
    protected int chapter;
    protected GridView gridview;
    private List<Integer> itemsList;
    protected TextView titleTextView;

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        BiblePreferences instance = BiblePreferences.getInstance();
        instance.lambda$restoreAsync$0$BiblePreferences();
        View inflate = layoutInflater.inflate(R.layout.fragment_contents_page, viewGroup, false);
        inflate.setBackgroundColor(getActivity().getResources().getColor(instance.isNightMode() ? R.color.black_bg : R.color.white));
        this.titleTextView = (TextView) inflate.findViewById(R.id.title_text);
        if (instance.isNightMode()) {
            this.titleTextView.setTextColor(getResources().getColor(R.color.menu_text_color_n));
        }
        this.gridview = (GridView) inflate.findViewById(R.id.gridview);
        if (getArguments() != null) {
            this.titleTextView.setText(getArguments().getString("parameterTitle", BuildConfig.FLAVOR));
            this.titleTextView.setVisibility(0);
            this.chapter = getArguments().getInt("chapter", 0);
        }
        initGrid(this.chapter);
        PowerManagerService.getInstance().start();
        return inflate;
    }

    /* access modifiers changed from: protected */
    public void initGrid(int i) {
        loadItemsGrid(i);
    }

    /* access modifiers changed from: protected */
    public void loadItemsGrid(final int i) {
        new Thread(new Runnable() {
            /* class king.james.bible.android.fragment.contents.Contents2Fragment.AnonymousClass1 */

            public void run() {
                Contents2Fragment.this.itemsList = BibleDataBase.getInstance().getSubChaptersList((long) i);
                GridView gridView = Contents2Fragment.this.gridview;
                if (gridView != null) {
                    gridView.post(new Runnable() {
                        /* class king.james.bible.android.fragment.contents.Contents2Fragment.AnonymousClass1.AnonymousClass1 */

                        public void run() {
                            Contents2Fragment.this.initList();
                        }
                    });
                }
            }
        }).start();
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void initList() {
        if (isAdded()) {
            try {
                this.gridview.setColumnWidth(getResources().getDimensionPixelOffset(R.dimen.contents_item_width));
                this.gridview.setAdapter((ListAdapter) new Contents2FragmentAdapter(this.itemsList, getActivity()));
                this.gridview.setOnItemClickListener(this);
            } catch (Exception unused) {
            }
        }
    }

    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:8:0x0061 */
    @Override // android.widget.AdapterView.OnItemClickListener
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
        if (getActivity() != null) {
            PowerManagerService.getInstance().start();
            Contents3Fragment contents3Fragment = getContents3Fragment();
            Bundle bundle = new Bundle();
            bundle.putInt("subChapter", getParameterSubChapter(i));
            bundle.putInt("chapter", this.chapter);
            bundle.putString("parameterTitle", this.titleTextView.getText().toString() + " " + getParameterSubChapter(i));
            contents3Fragment.setArguments(bundle);
            FragmentManager fragmentManager = getFragmentManager();
            if (fragmentManager.getBackStackEntryCount() > 4) {
                fragmentManager.popBackStackImmediate(3, 1);
            }
            try {
                FragmentTransaction beginTransaction = fragmentManager.beginTransaction();
                beginTransaction.replace(R.id.contents_page_frame_container, contents3Fragment, Contents3Fragment.TAG);
                beginTransaction.addToBackStack(Contents3Fragment.TAG);
                beginTransaction.commit();
            } catch (Exception unused) {
            }
        }
    }

    /* access modifiers changed from: protected */
    public Contents3Fragment getContents3Fragment() {
        return new Contents3Fragment();
    }

    /* access modifiers changed from: protected */
    public int getParameterSubChapter(int i) {
        return this.itemsList.get(i).intValue();
    }
}
