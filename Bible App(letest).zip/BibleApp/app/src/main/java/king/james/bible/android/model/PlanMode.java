package king.james.bible.android.model;

import java.io.Serializable;

public class PlanMode implements Serializable {
    private int dayCount;
    private int id;
    private String nameString;
    private PlanModeColor planModeColor;

    public PlanMode(int i, int i2, String str, PlanModeColor planModeColor2) {
        this.id = i;
        this.dayCount = i2;
        this.nameString = str;
        this.planModeColor = planModeColor2;
    }

    public int getId() {
        return this.id;
    }

    public int getDayCount() {
        return this.dayCount;
    }

    public String getNameString() {
        return this.nameString;
    }

    public PlanModeColor getPlanModeColor() {
        return this.planModeColor;
    }
}
