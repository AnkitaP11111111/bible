package king.james.bible.android.fragment.contents;

import android.annotation.SuppressLint;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import com.karumi.dexter.BuildConfig;
import king.james.bible.android.R;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import king.james.bible.android.activity.MainFragmentActivity;
import king.james.bible.android.adapter.AutoArrayAdapter;
import king.james.bible.android.db.BibleDataBase;
import king.james.bible.android.event.ContentsMainBackEvent;
import king.james.bible.android.fragment.BaseFragment;
import king.james.bible.android.fragment.FragmentCallbackListener;
import king.james.bible.android.service.PowerManagerService;
import king.james.bible.android.utils.BiblePreferences;
import king.james.bible.android.utils.ScreenUtil;
import king.james.bible.android.view.AutoCompleteCustomTextView;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

public class ContentsMainFragment extends Fragment implements View.OnClickListener, TextView.OnEditorActionListener {
    private  int r5;
    private  int r4;
    private  int r3;
    private int r2;
    protected View actionbarContent;
    private AutoCompleteCustomTextView actv;
    private AutoArrayAdapter adapter;
    private BibleDataBase bibleDB;
    private List<String> values = new ArrayList();
    private List<String> valuesN = new ArrayList();

    @Override // androidx.fragment.app.Fragment
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        EventBus.getDefault().register(this);
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroy() {
        EventBus.getDefault().unregister(this);
        super.onDestroy();
    }

    @Override // androidx.fragment.app.Fragment
    @SuppressLint({"NewApi"})
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        BiblePreferences instance = BiblePreferences.getInstance();
        instance.lambda$restoreAsync$0$BiblePreferences();
        View inflate = layoutInflater.inflate(instance.isNightMode() ? R.layout.activity_contents_n : R.layout.activity_contents, (ViewGroup) null);
        this.actionbarContent = inflate.findViewById(R.id.actionbarContent);
        BibleDataBase instance2 = BibleDataBase.getInstance();
        this.bibleDB = instance2;
        instance2.initColumSearchName();
        this.bibleDB.initChapterList();
        this.values = this.bibleDB.getValues();
        List<String> valuesN2 = this.bibleDB.getValuesN();
        this.valuesN = valuesN2;
        if (valuesN2.isEmpty() || this.valuesN.get(0) == null) {
            this.valuesN = this.values;
        }
        this.actv = (AutoCompleteCustomTextView) inflate.findViewById(R.id.content_page_search_text);
        if (instance.isNightMode()) {
            this.actv.setDropDownBackgroundResource(R.color.black_bg);
        }
        AutoArrayAdapter autoArrayAdapter = new AutoArrayAdapter(getActivity(), this.values, this.valuesN);
        this.adapter = autoArrayAdapter;
        this.actv.setAdapter(autoArrayAdapter);
        this.actv.addTextChangedListener(new TextWatcher() {
            /* class king.james.bible.android.fragment.contents.ContentsMainFragment.AnonymousClass1 */

            public void afterTextChanged(Editable editable) {
            }

            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                try {
                    ContentsMainFragment.this.adapter.getFilter().filter(charSequence.toString());
                    ContentsMainFragment.this.actv.showDropDown();
                } catch (Exception unused) {
                }
            }
        });
        this.actv.setOnEditorActionListener(this);
        this.actv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            /* class king.james.bible.android.fragment.contents.ContentsMainFragment.AnonymousClass2 */

            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                try {
                    AutoCompleteCustomTextView autoCompleteCustomTextView = ContentsMainFragment.this.actv;
                    autoCompleteCustomTextView.setText(ContentsMainFragment.this.actv.getText().toString() + " ");
                    ContentsMainFragment.this.actv.setSelection(ContentsMainFragment.this.actv.getText().length());
                } catch (Exception unused) {
                }
            }
        });
        initToolBar(getToolbarView());
        if (bundle != null) {
            restoreFragments();
            return inflate;
        }
        if (inflate.findViewById(R.id.contents_page_frame_container) != null) {
            ContentsFragment contentsFragment = new ContentsFragment();
            if (bundle != null) {
                getFragmentManager().popBackStack();
            }
            try {
                FragmentTransaction beginTransaction = getLocalFragmentManager().beginTransaction();
                beginTransaction.replace(R.id.contents_page_frame_container, contentsFragment, ContentsFragment.TAG);
                beginTransaction.commit();
            } catch (Exception unused) {
                getFragmentManager().popBackStack(ContentsFragment.TAG, 1);
                getFragmentManager().popBackStack("mainPage", 1);
            }
        }
        PowerManagerService.getInstance().start();
        return inflate;
    }

    /* access modifiers changed from: protected */
    public void restoreFragments() {
        FragmentManager childFragmentManager = getChildFragmentManager();
        FragmentTransaction beginTransaction = childFragmentManager.beginTransaction();
        for (int i = 0; i < childFragmentManager.getBackStackEntryCount() - 1; i++) {
            beginTransaction.hide(childFragmentManager.findFragmentByTag(childFragmentManager.getBackStackEntryAt(i).getName()));
        }
        beginTransaction.commitAllowingStateLoss();
        ScreenUtil.getInstance().hideKeyboard(getActivity());
    }

    /* access modifiers changed from: protected */
    public void updateFromBackPressed() {
        FragmentManager childFragmentManager = getChildFragmentManager();
        if (childFragmentManager.getBackStackEntryCount() > 1) {
            Fragment findFragmentByTag = childFragmentManager.findFragmentByTag(childFragmentManager.getBackStackEntryAt(childFragmentManager.getBackStackEntryCount() - 2).getName());
            if (findFragmentByTag instanceof BaseFragment) {
                ((BaseFragment) findFragmentByTag).onResumeFromBackStack();
            }
            FragmentTransaction beginTransaction = getChildFragmentManager().beginTransaction();
            beginTransaction.show(findFragmentByTag);
            beginTransaction.commitAllowingStateLoss();
        }
    }

    private FragmentManager getLocalFragmentManager() {
        if (Build.VERSION.SDK_INT < 17) {
            return getFragmentManager();
        }
        return getChildFragmentManager();
    }

    @Override // androidx.fragment.app.Fragment
    public void onPause() {
        ScreenUtil.getInstance().hideKeyboard(getActivity());
        try {
            this.actv.clearListSelection();
        } catch (Exception unused) {
        }
        super.onPause();
    }

    /* access modifiers changed from: protected */
    public View getToolbarView() {
        return this.actionbarContent;
    }

    /* access modifiers changed from: protected */
    public void initToolBar(View view) {
        view.findViewById(R.id.contents_page_back_btn).setOnClickListener(this);
    }

    /* access modifiers changed from: protected */
    public String getCorrectFilter(CharSequence charSequence) {
        boolean z;
        boolean z2;
        ArrayList arrayList = new ArrayList();
        Iterator<String> it = this.valuesN.iterator();
        String str = null;
        while (true) {
            z = true;
            if (!it.hasNext()) {
                z2 = true;
                break;
            }
            String next = it.next();
            if (next != null && next.toLowerCase().contains(charSequence.toString().toLowerCase())) {
                str = this.values.get(this.valuesN.indexOf(next));
                arrayList.add(str);
                if (next.equalsIgnoreCase(charSequence.toString())) {
                    z2 = false;
                    break;
                }
            }
        }
        if (arrayList.size() > 0 && z2) {
            str = (String) arrayList.get(0);
        }
        if (str != null) {
            return str;
        }
        ArrayList arrayList2 = new ArrayList();
        Iterator<String> it2 = this.values.iterator();
        while (true) {
            if (!it2.hasNext()) {
                break;
            }
            String next2 = it2.next();
            if (next2.toLowerCase().contains(charSequence.toString().toLowerCase())) {
                List<String> list = this.values;
                str = list.get(list.indexOf(next2));
                arrayList2.add(str);
                if (next2.equalsIgnoreCase(charSequence.toString())) {
                    z = false;
                    break;
                }
            }
        }
        return (arrayList2.isEmpty() || !z) ? str : (String) arrayList2.get(0);
    }

    public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
        String trim;
        if (i == 2 && (trim = ((EditText) textView).getText().toString().trim()) != null && !trim.isEmpty()) {
            searhPerform(trim);
        }
        return false;
    }

    private void searhPerform(String str) {
        int i;
        int i2;
        String[] split = str.split(" ");
        String str2 = split.length > 1 ? split[split.length - 1] : BuildConfig.FLAVOR;
        try {
            i = Integer.parseInt(str2) - 1;
            str = split[0];
            for (int i3 = 1; i3 < split.length - 1; i3++) {
                str = str + " " + split[i3];
            }
            i2 = -1;
        } catch (Exception unused) {
            String[] split2 = str2.split(":");
            try {
                i = Integer.parseInt(split2[0]) - 1;
                i2 = Integer.parseInt(split2[1]) - 1;
                str = split[0];
                for (int i4 = 1; i4 < split.length - 1; i4++) {
                    str = str + " " + split[i4];
                }
            } catch (Exception unused2) {
                i2 = -1;
                i = -1;
            }
        }
        if (getCorrectFilter(str) != null) {
            String lowerCase = getCorrectFilter(str).toLowerCase();
            Iterator<String> it = this.values.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                String next = it.next();
                if (next.toLowerCase().equals(lowerCase)) {
                    lowerCase = next;
                    break;
                }
            }
            int chapterIdByName = this.bibleDB.getChapterIdByName(lowerCase);
            if (chapterIdByName != 1) {
                if (i == -1 && i2 == -1) {
                    openContents2Fragment(chapterIdByName, lowerCase);
                } else if ((i == -1 || i2 != -1) && (getFragmentManager().findFragmentByTag(Contents3Fragment.TAG) == null || i2 != -1)) {
                    new Thread(new Runnable() {
                        /* class king.james.bible.android.fragment.contents.$$Lambda$ContentsMainFragment$obPzbyhAGvh6qW1ShoB8Qhx0 */
                        private final /* synthetic */ int f$1;
                        private final /* synthetic */ int f$2;
                        private final /* synthetic */ int f$3;

                        {
                            this.f$1 = r2;
                            this.f$2 = r3;
                            this.f$3 = r4;
                        }

                        public final void run() {
                            try {
                                ContentsMainFragment.this.lambda$searhPerform$0$ContentsMainFragment(this.f$1, this.f$2, this.f$3);
                            } catch (Exception e) {
                                throw new RuntimeException(e);
                            }
                        }
                    }).start();
                } else {
                    openContents3Fragment(chapterIdByName, this.bibleDB.getSubChapter(chapterIdByName, i + 1), lowerCase);
                }
                this.actv.setText(BuildConfig.FLAVOR);
            }
        }
    }

    public /* synthetic */ void lambda$searhPerform$0$ContentsMainFragment(int i, int i2, int i3) throws Exception {
        moveToReadingScreen(i, i2, i3, this.bibleDB.getRankByChapter(i, i2 == 0 ? 1 : i2, i3 + 1));
    }

    private void moveToReadingScreen(int i, int i2, int i3, int i4) {
        if (getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() {
                /* class king.james.bible.android.fragment.contents.$$Lambda$ContentsMainFragment$ZixyjfwmUMirJ_vTmygR1zp3e8 */
                private final /* synthetic */ int f$1;
                private final /* synthetic */ int f$2;
                private final /* synthetic */ int f$3;
                private final /* synthetic */ int f$4;

                {
                    this.f$1 = r2;
                    this.f$2 = r3;
                    this.f$3 = r4;
                    this.f$4 = r5;
                }

                public final void run() {
                    ContentsMainFragment.this.lambda$moveToReadingScreen$1$ContentsMainFragment(this.f$1, this.f$2, this.f$3, this.f$4);
                }
            });
        }
    }

    public /* synthetic */ void lambda$moveToReadingScreen$1$ContentsMainFragment(int i, int i2, int i3, int i4) {
        if (getFragmentManager().findFragmentByTag(Contents3Fragment.TAG) != null) {
            FragmentTransaction beginTransaction = getFragmentManager().beginTransaction();
            beginTransaction.remove(getFragmentManager().findFragmentByTag(Contents3Fragment.TAG));
            beginTransaction.commit();
            getFragmentManager().popBackStack();
        }
        getFragmentManager().popBackStack();
        if (getActivity() instanceof FragmentCallbackListener) {
            ((FragmentCallbackListener) getActivity()).onFragmentResultOk(i, i2, i3, i4, null);
        }
    }

    private void openContents2Fragment(int i, String str) {
        Contents2Fragment contents2Fragment = new Contents2Fragment();
        Bundle bundle = new Bundle();
        bundle.putInt("chapter", i);
        bundle.putString("parameterTitle", str);
        contents2Fragment.setArguments(bundle);
        if (getFragmentManager().findFragmentByTag(Contents2Fragment.TAG) != null) {
            getActivity().onBackPressed();
        }
        if (getFragmentManager().findFragmentByTag(Contents3Fragment.TAG) != null) {
            getActivity().onBackPressed();
        }
        try {
            FragmentTransaction beginTransaction = getLocalFragmentManager().beginTransaction();
            beginTransaction.replace(R.id.contents_page_frame_container, contents2Fragment, Contents2Fragment.TAG);
            beginTransaction.addToBackStack(Contents2Fragment.TAG);
            beginTransaction.commit();
        } catch (Exception unused) {
            getFragmentManager().popBackStack(ContentsFragment.TAG, 1);
            getFragmentManager().popBackStack("mainPage", 1);
        }
        ScreenUtil.getInstance().hideKeyboard(getActivity());
    }

    private void openContents3Fragment(int i, int i2, String str) {
        Contents3Fragment contents3Fragment = new Contents3Fragment();
        Bundle bundle = new Bundle();
        bundle.putInt("subChapter", i2);
        bundle.putInt("chapter", i);
        if (getFragmentManager().findFragmentByTag(Contents2Fragment.TAG) != null) {
            getActivity().onBackPressed();
        }
        if (getFragmentManager().findFragmentByTag(Contents3Fragment.TAG) != null) {
            getActivity().onBackPressed();
        }
        openContents2Fragment(i, str);
        bundle.putString("parameterTitle", str + " " + i2);
        contents3Fragment.setArguments(bundle);
        try {
            FragmentTransaction beginTransaction = getLocalFragmentManager().beginTransaction();
            beginTransaction.replace(R.id.contents_page_frame_container, contents3Fragment, Contents3Fragment.TAG);
            beginTransaction.addToBackStack(Contents3Fragment.TAG);
            beginTransaction.commit();
        } catch (Exception unused) {
            getFragmentManager().popBackStack(ContentsFragment.TAG, 1);
            getFragmentManager().popBackStack("mainPage", 1);
        }
    }

    public void onClick(View view) {
        if (getActivity() != null && view.getId() == R.id.contents_page_back_btn && !onBackClick()) {
            getActivity().onBackPressed();
        }
    }

    public boolean onBackClick() {
        ScreenUtil.getInstance().hideKeyboard(getActivity());
        if (getActivity() == null) {
            return true;
        }
        ScreenUtil.getInstance().hideKeyboard(getActivity());
        Fragment findFragmentById = getFragmentManager().findFragmentById(R.id.contents_page_frame_container);
        if (findFragmentById == null && (findFragmentById = getLocalFragmentManager().findFragmentById(R.id.contents_page_frame_container)) == null) {
            return true;
        }
        if (findFragmentById.getClass().equals(Contents3Fragment.class)) {
            getLocalFragmentManager().popBackStack(Contents3Fragment.TAG, 1);
            updateFromBackPressed();
            return true;
        } else if (findFragmentById.getClass().equals(Contents2Fragment.class)) {
            getLocalFragmentManager().popBackStack(Contents2Fragment.TAG, 1);
            updateFromBackPressed();
            return true;
        } else {
            PowerManagerService.getInstance().start();
            return false;
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(ContentsMainBackEvent contentsMainBackEvent) {
        if (getActivity() != null) {
            onBackClick();
            onBackClick();
            onBackClick();
            ((MainFragmentActivity) getActivity()).onBackPressedSuper();
            ((MainFragmentActivity) getActivity()).onBackPressedSuper();
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        FragmentManager fragmentManager = getFragmentManager();
        if (fragmentManager.findFragmentByTag(Contents3Fragment.TAG) == null && fragmentManager.findFragmentByTag(Contents2Fragment.TAG) == null && getLocalFragmentManager().findFragmentByTag(ContentsFragment.TAG) != null && getLocalFragmentManager().getBackStackEntryCount() == 0) {
            ContentsFragment contentsFragment = new ContentsFragment();
            String str = ContentsFragment.TAG;
            try {
                FragmentTransaction beginTransaction = getLocalFragmentManager().beginTransaction();
                beginTransaction.replace(R.id.contents_page_frame_container, contentsFragment, str);
                beginTransaction.commitAllowingStateLoss();
            } catch (Exception unused) {
                getFragmentManager().popBackStack(ContentsFragment.TAG, 1);
                getFragmentManager().popBackStack("mainPage", 1);
            }
        }
    }
}
