package king.james.bible.android.adapter.recycler;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import com.bignerdranch.expandablerecyclerview.Adapter.ExpandableRecyclerAdapter;

import com.bignerdranch.expandablerecyclerview.Model.ParentListItem;
import com.bignerdranch.expandablerecyclerview.Model.ParentWrapper;
import king.james.bible.android.R;
import java.util.HashSet;
import java.util.List;
import king.james.bible.android.adapter.holder.PlanMonthDayViewHolder;
import king.james.bible.android.adapter.holder.PlanMonthViewHolder;
import king.james.bible.android.dialog.DailyPlanDialog;
import king.james.bible.android.model.DailyPlanMonth;
import king.james.bible.android.model.PlanDay;

public class PlanExpandableAdapter extends ExpandableRecyclerAdapter<PlanMonthViewHolder, PlanMonthDayViewHolder> {
    private DailyPlanDialog.DailyPlanDialogListener dailyPlanDialogListener;
    private int modeId;
    private long startDate;

    public PlanExpandableAdapter(List<? extends ParentListItem> list, long j, int i, DailyPlanDialog.DailyPlanDialogListener dailyPlanDialogListener2) {
        super(list);
        this.startDate = j;
        this.modeId = i;
        this.dailyPlanDialogListener = dailyPlanDialogListener2;
    }

    @Override // com.bignerdranch.expandablerecyclerview.Adapter.ExpandableRecyclerAdapter
    public PlanMonthViewHolder onCreateParentViewHolder(ViewGroup viewGroup) {
        return new PlanMonthViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_plan_month, viewGroup, false));
    }

    @Override // com.bignerdranch.expandablerecyclerview.Adapter.ExpandableRecyclerAdapter
    public PlanMonthDayViewHolder onCreateChildViewHolder(ViewGroup viewGroup) {
        return new PlanMonthDayViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_plan_month_day, viewGroup, false), this.dailyPlanDialogListener);
    }

    public void onBindParentViewHolder(PlanMonthViewHolder planMonthViewHolder, int i, ParentListItem parentListItem) {
        planMonthViewHolder.updateView((DailyPlanMonth) parentListItem, isExpanded(i));
    }

    public void onBindChildViewHolder(PlanMonthDayViewHolder planMonthDayViewHolder, int i, Object obj) {
        planMonthDayViewHolder.updateView((PlanDay) obj, this.modeId, this.startDate);
    }

    public boolean isExpanded(int i) {
        Object listItem = getListItem(i);
        if (listItem instanceof ParentWrapper) {
            return ((ParentWrapper) listItem).isExpanded();
        }
        return false;
    }

    public HashSet<String> getOpenItems() {
        HashSet<String> hashSet = new HashSet<>();
        for (int i = 0; i < getItemCount(); i++) {
            if (isExpanded(i)) {
                hashSet.add(((DailyPlanMonth) ((ParentWrapper) getListItem(i)).getParentListItem()).getName());
            }
        }
        return hashSet;
    }

    @Override // com.bignerdranch.expandablerecyclerview.Adapter.ExpandableRecyclerAdapter, com.bignerdranch.expandablerecyclerview.ViewHolder.ParentViewHolder.ParentListItemExpandCollapseListener
    public void onParentListItemExpanded(int i) {
        super.onParentListItemExpanded(i);
        notifyItemChanged(i);
    }

    @Override // com.bignerdranch.expandablerecyclerview.Adapter.ExpandableRecyclerAdapter, com.bignerdranch.expandablerecyclerview.ViewHolder.ParentViewHolder.ParentListItemExpandCollapseListener
    public void onParentListItemCollapsed(int i) {
        super.onParentListItemCollapsed(i);
        notifyItemChanged(i);
    }
}
