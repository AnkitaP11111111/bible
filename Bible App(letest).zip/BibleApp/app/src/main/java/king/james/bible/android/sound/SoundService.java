package king.james.bible.android.sound;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import com.karumi.dexter.BuildConfig;
import king.james.bible.android.R;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import king.james.bible.android.db.BibleDataBase;
import king.james.bible.android.event.HideAudioWaitDialogEvent;
import king.james.bible.android.event.PlayEvent;
import king.james.bible.android.event.ShowAudioWaitDialogEvent;
import king.james.bible.android.model.Text;
import king.james.bible.android.sound.listener.FirstPlayListener;
import king.james.bible.android.sound.listener.InitAudioListener;
import king.james.bible.android.sound.listener.SoundProgressListener;
import king.james.bible.android.sound.listener.page.SoundPageListener;
import king.james.bible.android.sound.listener.page.SoundVerseListener;
import king.james.bible.android.sound.model.LanguageModel;
import king.james.bible.android.sound.model.SoundModel;
import king.james.bible.android.sound.util.SoundAction;
import king.james.bible.android.utils.BiblePreferences;
import king.james.bible.android.utils.BibleToast;
import org.greenrobot.eventbus.EventBus;

public class SoundService extends Service {
    private  String r5;
    private  String r4;
    private  int r3;
    private  int r2;
    private BibleDataBase bibleDataBase;
    private SoundServiceBinder binder = new SoundServiceBinder(this);
    private boolean existLanguage = false;
    private boolean firstPlay = true;
    private FirstPlayListener firstPlayListener;
    private InitAudioListener initAudioListener;
    private boolean needShowDialog = false;
    private TextToSpeech.OnInitListener onTextToSpeechInitListener = new TextToSpeech.OnInitListener() {
        /* class king.james.bible.android.sound.SoundService.AnonymousClass2 */

        public void onInit(int i) {
            if (i == 0) {
                SoundService.this.updateAudioSettings(true);
                SoundService.this.textToSpeech.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    /* class king.james.bible.android.sound.SoundService.AnonymousClass2.AnonymousClass1 */

                    public void onStart(String str) {
                        SoundService.this.needShowDialog = false;
                        EventBus.getDefault().post(new HideAudioWaitDialogEvent());
                        SoundService.this.soundProgressListener.onStart(str);
                        if (SoundService.this.firstPlayListener != null && SoundService.this.firstPlay && Build.VERSION.SDK_INT >= 21) {
                            SoundService.this.firstPlay = false;
                            SoundService.this.firstPlayListener.onCompleteFirstPlayInit();
                        }
                    }

                    public void onDone(String str) {
                        if (SoundService.this.play || SoundService.this.playRepeat) {
                            try {
                                SoundService.this.soundProgressListener.onDone(str);
                            } catch (Throwable e) {
                                throw new RuntimeException(e);
                            }
                        }
                    }

                    public void onError(String str) {
                        SoundService.this.soundProgressListener.onError(str);
                    }
                });
            }
        }
    };
    private boolean play = false;
    private boolean playList = false;
    private boolean playRepeat = false;
    private int repeatCount;
    private String repeatText;
    private boolean repeatTextPart1;
    private String repeatTextPart2;
    private SoundModel soundModel;
    private SoundPageListener soundPageListener;
    private SoundProgressListener soundProgressListener = new SoundProgressListener() {
        /* class king.james.bible.android.sound.SoundService.AnonymousClass1 */

        @Override // king.james.bible.android.sound.listener.SoundProgressListener
        public void onStart(String str) {
            SoundService.this.play = true;
        }

        @Override // king.james.bible.android.sound.listener.SoundProgressListener
        public void onDone(String str) throws Throwable {
            if (!SoundService.this.playRepeat || SoundService.this.soundModel == null) {
                SoundService.this.onEndProgress(str);
            } else if (!SoundService.this.repeatTextPart1 || SoundService.this.repeatCount <= 0 || SoundService.this.repeatTextPart2 == null || SoundService.this.repeatTextPart2.isEmpty()) {
                SoundService.access$510(SoundService.this);
                if (SoundService.this.repeatCount > 0) {
                    SoundService.this.repeatTextPart1 = true;
                    SoundService soundService = SoundService.this;
                    soundService.play( soundService.repeatText, BuildConfig.FLAVOR,  SoundService.this.soundModel.getPagePosition(), SoundService.this.soundModel.getRank());
                    return;
                }
                SoundService.this.onEndProgress(str);
            } else {
                SoundService.this.repeatTextPart1 = false;
                if (SoundService.this.soundModel != null) {
                    SoundService soundService2 = SoundService.this;
                    soundService2.play(soundService2.repeatTextPart2, BuildConfig.FLAVOR,  SoundService.this.soundModel.getPagePosition(), SoundService.this.soundModel.getRank());
                }
            }
        }

        @Override // king.james.bible.android.sound.listener.SoundProgressListener
        public void onError(String str) {
            SoundService.this.pause();
            SoundService.this.onPlayError(BuildConfig.FLAVOR);
        }
    };
    private Map<Integer, SoundVerseListener> soundVerseListeners;
    private String subChapterWord = BuildConfig.FLAVOR;
    private TextToSpeech textToSpeech;
    private long time;
    private Timer timer;
    private long timerTime = 400;

    public class SoundServiceBinder extends Binder {
        public SoundServiceBinder(SoundService soundService) {
        }
    }

    static /* synthetic */ int access$510(SoundService soundService) {
        int i = soundService.repeatCount;
        soundService.repeatCount = i - 1;
        return i;
    }

    public void onCreate() {
        super.onCreate();
        init();
        SoundHelper.getInstance().setSoundService(this);
    }

    public IBinder onBind(Intent intent) {
        return this.binder;
    }

    public void setFirstPlayListener(FirstPlayListener firstPlayListener2) {
        this.firstPlayListener = firstPlayListener2;
    }

    private void init() {
        this.bibleDataBase = BibleDataBase.getInstance();
        this.subChapterWord = getResources().getString(R.string.soundchapter);
        this.soundVerseListeners = new HashMap();
        initPlay();
        SoundModel soundModel2 = new SoundModel(-1, 1);
        this.soundModel = soundModel2;
        soundModel2.setTextList(new ArrayList());
        this.soundModel.setChapter(BuildConfig.FLAVOR);
        this.soundModel.setSubChapter(0);
    }

    private void initPlay() {
        if (this.textToSpeech == null) {
            try {
                this.textToSpeech = new TextToSpeech(this, this.onTextToSpeechInitListener);
            } catch (Exception unused) {
            }
        }
    }

    public void play(int i, int i2) throws Throwable {
        pauseClear();
        this.needShowDialog = true;
        play(false, i, i2);
        new Handler().postDelayed(new Runnable() {
            /* class king.james.bible.android.sound.$$Lambda$SoundService$2JKUGHCLV76PZpE76O4qEOgQaeQ */

            public final void run() {
                SoundService.this.lambda$play$0$SoundService();
            }
        }, 3000);
    }

    public /* synthetic */ void lambda$play$0$SoundService() {
        if (this.needShowDialog) {
            EventBus.getDefault().post(new ShowAudioWaitDialogEvent());
        }
    }

    private void pauseClear() {
        this.playList = false;
        this.soundModel = null;
    }

    private void updateModel(int i, int i2) throws Throwable {
        SoundModel soundModel2 = this.soundModel;
        if (soundModel2 == null || soundModel2.getPagePosition() != i) {
            this.soundModel = this.bibleDataBase.getSoundModel(i, i2);
            BiblePreferences.getInstance().setCurrentPageBible(i);
            BiblePreferences.getInstance().lambda$saveBg$1$BiblePreferences();
            return;
        }
        this.soundModel.setRank(i2);
    }

    private void play(boolean z, int i, int i2) throws Throwable {
        String str;
        this.playRepeat = false;
        updateModel(i, i2);
        stop();
        if (this.soundModel == null) {
            pause();
            return;
        }
        this.play = true;
        String str2 = this.soundModel.getChapter() + " " + this.subChapterWord + " " + this.soundModel.getSubChapter();
        String str3 = str2 + " " + i2;
        if (z) {
            str = str2 + ";  ";
        } else {
            str = BuildConfig.FLAVOR;
        }
        int i3 = i2 - 1;
        if (i3 >= 0 && i3 < this.soundModel.getTextList().size()) {
            this.playList = true;
            Text nextText = getNextText(i3);
            if (nextText != null) {
                play(str + nextText.getText(), str3, i, nextText.getRank());
            }
        }
    }

    private Text getNextText(int i) {
        if (this.soundModel.getTextList().get(i).isVerse()) {
            return this.soundModel.getTextList().get(i);
        }
        int i2 = i + 1;
        if (i2 >= this.soundModel.getTextList().size()) {
            return null;
        }
        return getNextText(i2);
    }

    public void play(boolean z, int i, int i2, String str) throws Throwable {
        play(z, i, i2, str, null);
    }

    public void play(boolean z, int i, int i2, String str, Set<Integer> set) throws Throwable {
        SoundModel soundModel2;
        this.playRepeat = z;
        if (z) {
            pauseClear();
            this.repeatCount = 10;
            SoundModel soundModel3 = this.bibleDataBase.getSoundModel(i, i2);
            this.repeatText = BuildConfig.FLAVOR;
            this.repeatTextPart2 = BuildConfig.FLAVOR;
            this.repeatTextPart1 = true;
            String textSingle = getTextSingle(soundModel3, set, i2);
            this.repeatText = textSingle;
            soundModel2 = soundModel3;
            str = textSingle;
        } else {
            soundModel2 = null;
        }
        this.soundModel = new SoundModel(i, i2);
        ArrayList arrayList = new ArrayList();
        Text text = new Text();
        text.setText(str);
        arrayList.add(text);
        this.soundModel.setTextList(arrayList);
        this.playList = false;
        this.play = true;
        play(str, BuildConfig.FLAVOR, i, i2);
        stopForeground();
        if (z && soundModel2 != null) {
            this.soundModel.setChapter(soundModel2.getChapter());
            this.soundModel.setSubChapter(soundModel2.getSubChapter());
            startForeground(SoundAction.PAUSE_ACTION, soundModel2, i, i2);
        }
    }

    private String getTextSingle(SoundModel soundModel2, Set<Integer> set, int i) {
        String str = BuildConfig.FLAVOR;
        if (soundModel2 == null) {
            return str;
        }
        if (set == null || set.isEmpty()) {
            return soundModel2.getTextList().get(i - 1).getText();
        }
        boolean z = false;
        for (Text text : soundModel2.getTextList()) {
            if (set.contains(Integer.valueOf(text.getRank()))) {
                int i2 = 4000;
                if (Build.VERSION.SDK_INT >= 18) {
                    i2 = TextToSpeech.getMaxSpeechInputLength();
                }
                if ((str + text.getText()).length() >= i2 - 3) {
                    z = true;
                }
                if (z) {
                    this.repeatTextPart2 += ";  " + text.getText();
                } else {
                    str = str + ";  " + text.getText();
                }
            }
        }
        return str;
    }

    private void startForeground(SoundAction soundAction, int i, int i2) {
        startForeground(soundAction, this.soundModel, i, i2);
    }

    private void startForeground(SoundAction soundAction, SoundModel soundModel2, int i, int i2) {
        String str;
        if (soundModel2 == null || soundModel2.getChapter() == null || soundModel2.getSubChapter() <= 0) {
            str = BuildConfig.FLAVOR;
        } else {
            str = soundModel2.getChapter() + " " + soundModel2.getSubChapter();
        }
        if (this.playRepeat) {
            str = str + " (" + getString(R.string.repeat) + ")";
        }
        ForegroundUtil.startForeground(this, this.playRepeat, soundAction, str, i, i2);
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void play(String str, final String str2, int i, int i2) {
        if (!this.existLanguage) {
            onSoundError();
            return;
        }
        EventBus.getDefault().post(new PlayEvent());
        startForeground(SoundAction.PAUSE_ACTION, i, i2);
        if (Build.VERSION.SDK_INT >= 21) {
            this.textToSpeech.speak(str, 0, null, str2);
            return;
        }
        this.textToSpeech.speak(BuildConfig.FLAVOR, 0, null);
        if (this.firstPlay) {
            long j = 10000;
            if (Build.VERSION.SDK_INT < 21) {
                j = 15000;
            }
            new Handler().postDelayed(new Runnable() {
                /* class king.james.bible.android.sound.$$Lambda$SoundService$rxqSRyoAclqnXK8Ki79HQqHg_EE */
                private final /* synthetic */ int f$1;
                private final /* synthetic */ int f$2;
                private final /* synthetic */ String f$3;
                private final /* synthetic */ String f$4;

                {
                    this.f$1 = r2;
                    this.f$2 = r3;
                    this.f$3 = r4;
                    this.f$4 = r5;
                }

                public final void run() {
                    SoundService.this.lambda$play$1$SoundService(this.f$1, this.f$2, this.f$3, this.f$4);
                }
            }, j);
            return;
        }
        this.textToSpeech.speak(str, 0, null);
        this.soundProgressListener.onStart(str2);
        stopTimer();
        this.time = 0;
        this.timer = new Timer();
        final int i3 = Build.VERSION.SDK_INT < 21 ? 3 : 6;
        Timer timer2 = this.timer;
        if (timer2 != null) {
            try {
                timer2.schedule(new TimerTask() {
                    /* class king.james.bible.android.sound.SoundService.AnonymousClass3 */

                    public void run() {
                        SoundService.this.time += SoundService.this.timerTime;
                        if (!SoundService.this.textToSpeech.isSpeaking() && SoundService.this.time > ((long) i3) * SoundService.this.timerTime) {
                            SoundService.this.stopTimer();
                            try {
                                SoundService.this.soundProgressListener.onDone(str2);
                            } catch (Throwable e) {
                                throw new RuntimeException(e);
                            }
                        }
                    }
                }, 0, this.timerTime);
            } catch (Exception unused) {
                pause();
            }
        }
    }

    public /* synthetic */ void lambda$play$1$SoundService(int i, int i2, String str, String str2) {
        this.firstPlay = false;
        this.textToSpeech.stop();
        boolean isPlayRepeatItem = this.playRepeat ? isPlayRepeatItem(i, i2) : isPlayItem(i, i2);
        FirstPlayListener firstPlayListener2 = this.firstPlayListener;
        if (firstPlayListener2 != null) {
            firstPlayListener2.onCompleteFirstPlayInit();
        }
        if (isPlay() && isPlayRepeatItem) {
            play(str, str2, i, i2);
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void stopTimer() {
        Timer timer2 = this.timer;
        if (timer2 != null) {
            timer2.cancel();
            this.timer = null;
        }
    }

    public int getCurrentPage() {
        SoundModel soundModel2 = this.soundModel;
        if (soundModel2 == null) {
            return 0;
        }
        return soundModel2.getPagePosition();
    }

    public int getCurrentPosition() {
        return this.soundModel.getRank();
    }

    public void pause() {
        SoundModel soundModel2;
        SoundModel soundModel3;
        if (isPlay() && this.playList) {
            startForeground(SoundAction.PLAY_ACTION, this.soundModel.getPagePosition(), 0);
        }
        if (this.playRepeat) {
            stopForeground();
        }
        stop();
        Map<Integer, SoundVerseListener> map = this.soundVerseListeners;
        if (!(map == null || (soundModel3 = this.soundModel) == null || !map.containsKey(Integer.valueOf(soundModel3.getPagePosition())))) {
            this.soundVerseListeners.get(Integer.valueOf(this.soundModel.getPagePosition())).onPauseSound(this.soundModel.getRank());
        }
        SoundPageListener soundPageListener2 = this.soundPageListener;
        if (!(soundPageListener2 == null || (soundModel2 = this.soundModel) == null)) {
            soundPageListener2.prepareSoundHeaderPauseBackground(soundModel2.getPagePosition());
        }
        this.playRepeat = false;
    }

    public void stop(int i) {
        this.soundVerseListeners.remove(Integer.valueOf(i));
    }

    public void stop() {
        stopTimer();
        this.play = false;
        try {
            this.textToSpeech.stop();
        } catch (Exception unused) {
        }
    }

    public boolean isPlayItem(int i, int i2) {
        SoundModel soundModel2;
        if (this.playRepeat || (soundModel2 = this.soundModel) == null || i != soundModel2.getPagePosition() || i2 != this.soundModel.getRank() || !this.play) {
            return false;
        }
        return true;
    }

    public boolean isPlayRepeatItem(int i, int i2) {
        SoundModel soundModel2 = this.soundModel;
        if (soundModel2 == null) {
            return false;
        }
        if (!(i == soundModel2.getPagePosition() && i2 == this.soundModel.getRank() && this.play) || !this.playRepeat) {
            return false;
        }
        return true;
    }

    public boolean isPlay() {
        return this.play;
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void onPlayError(String str) {
        Map<Integer, SoundVerseListener> map = this.soundVerseListeners;
        if (map == null || map.isEmpty()) {
            SoundHelper.getInstance().setSoundService(this);
        }
        if (this.soundVerseListeners.containsKey(Integer.valueOf(this.soundModel.getPagePosition())) && this.soundVerseListeners.get(Integer.valueOf(this.soundModel.getPagePosition())) != null) {
            this.soundVerseListeners.get(Integer.valueOf(this.soundModel.getPagePosition())).onPlayError(str);
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void onEndProgress(String str) throws Throwable {
        SoundModel soundModel2;
        Map<Integer, SoundVerseListener> map;
        boolean z;
        Map<Integer, SoundVerseListener> map2 = this.soundVerseListeners;
        if (map2 == null || map2.isEmpty()) {
            SoundHelper.getInstance().setSoundService(this);
        }
        if (this.play && (soundModel2 = this.soundModel) != null && (map = this.soundVerseListeners) != null) {
            this.play = false;
            if (this.playList) {
                int i = 1;
                int rank = soundModel2.getRank() + 1;
                int pagePosition = this.soundModel.getPagePosition();
                if (rank > this.soundModel.getTextList().size()) {
                    pagePosition++;
                    try {
                        if (update(pagePosition, 1)) {
                            pause();
                            rank = 1;
                            z = true;
                        } else {
                            return;
                        }
                    } catch (Throwable e) {
                        throw new RuntimeException(e);
                    }
                } else {
                    z = false;
                }
                Text nextText = getNextText(rank - 1);
                if (nextText != null) {
                    i = nextText.getRank();
                } else {
                    pagePosition++;
                    try {
                        if (update(pagePosition, 1)) {
                            pause();
                            Text nextText2 = getNextText(0);
                            if (nextText2 != null) {
                                i = nextText2.getRank();
                            }
                            z = true;
                        } else {
                            return;
                        }
                    } catch (Throwable e) {
                        throw new RuntimeException(e);
                    }
                }
                nextItem(i, pagePosition, z);
            } else if (map.containsKey(Integer.valueOf(soundModel2.getPagePosition())) && this.soundVerseListeners.get(Integer.valueOf(this.soundModel.getPagePosition())) != null) {
                this.soundVerseListeners.get(Integer.valueOf(this.soundModel.getPagePosition())).onPauseSound(this.soundModel.getRank());
            }
        }
    }

    private boolean update(int i, int i2) throws Throwable {
        updateModel(i, i2);
        SoundModel soundModel2 = this.soundModel;
        if (soundModel2 != null && !soundModel2.getTextList().isEmpty()) {
            return true;
        }
        SoundPageListener soundPageListener2 = this.soundPageListener;
        if (soundPageListener2 != null) {
            soundPageListener2.onNextSoundPage(i, i2);
        }
        stopForeground();
        return false;
    }

    private void nextItem(int i, int i2, boolean z) throws Throwable {
        SoundPageListener soundPageListener2 = this.soundPageListener;
        if (soundPageListener2 != null) {
            soundPageListener2.onNextSoundPage(i2, i);
        }
        play(z, i2, i);
    }

    private void onSoundError() {
        pause();
    }

    public void setInitAudioListener(InitAudioListener initAudioListener2) {
        this.initAudioListener = initAudioListener2;
    }

    public void updateAudioSettings() {
        updateAudioSettings(false);
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void updateAudioSettings(boolean z) {
        try {
            this.textToSpeech.setSpeechRate(BiblePreferences.getInstance().getAudioSpeechRate());
            this.textToSpeech.setPitch(BiblePreferences.getInstance().getAudioPitch());
            LanguageModel soundLanguage = BiblePreferences.getInstance().getSoundLanguage();
            int language = this.textToSpeech.setLanguage(new Locale(soundLanguage.getLanguage(), soundLanguage.getCountry()));
            if (language != -1) {
                if (language != -2) {
                    this.existLanguage = true;
                    if (this.initAudioListener != null) {
                        this.initAudioListener.completeInitAudio();
                        return;
                    }
                    return;
                }
            }
            this.existLanguage = false;
            if (!z) {
                BibleToast.showLongDurationToast(this, (int) R.string.sounderrorlanguage_not_supported);
            }
        } catch (Exception unused) {
            this.existLanguage = false;
            BibleToast.showLongDurationToast(this, (int) R.string.sounderrorlanguage_not_supported);
        }
    }

    public void addSoundVerseListener(int i, SoundVerseListener soundVerseListener) {
        if (this.soundVerseListeners == null) {
            this.soundVerseListeners = new HashMap();
        }
        this.soundVerseListeners.put(Integer.valueOf(i), soundVerseListener);
    }

    public void clearSoundVerseListener(int i) {
        if (this.soundVerseListeners == null) {
            this.soundVerseListeners = new HashMap();
        }
        this.soundVerseListeners.remove(Integer.valueOf(i));
    }

    public void setSoundVerseListener(Map<Integer, SoundVerseListener> map) {
        Map<Integer, SoundVerseListener> map2 = this.soundVerseListeners;
        if (map2 != null) {
            map2.clear();
            this.soundVerseListeners = null;
        }
        this.soundVerseListeners = map;
    }

    public void stopForeground() {
        ForegroundUtil.stopForeground(this);
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        if (intent == null || intent.getAction() == null) {
            return super.onStartCommand(intent, i, i2);
        }
        try {
            int i3 = AnonymousClass4.$SwitchMap$king$james$bible$android$sound$util$SoundAction[SoundAction.valueOf(intent.getAction()).ordinal()];
            if (i3 == 1) {
                if (this.soundPageListener != null) {
                    this.soundPageListener.onNextSoundPage(this.soundModel.getPagePosition(), this.soundModel.getRank());
                }
                if (this.soundModel != null) {
                    try {
                        play(this.playRepeat, this.soundModel.getPagePosition(), this.soundModel.getRank());
                    } catch (Throwable e) {
                        throw new RuntimeException(e);
                    }
                }
            } else if (i3 == 2) {
                pause();
            } else if (i3 == 3) {
                stop();
                this.play = true;
                onEndProgress(BuildConfig.FLAVOR);
            } else if (i3 == 4) {
                pause();
                stopForeground();
            }
        } catch (Exception unused) {
        } catch (Throwable e) {
            throw new RuntimeException(e);
        }
        return super.onStartCommand(intent, i, i2);
    }

    /* renamed from: king.james.bible.android.sound.SoundService$4  reason: invalid class name */
    static /* synthetic */ class AnonymousClass4 {
        static final /* synthetic */ int[] $SwitchMap$king$james$bible$android$sound$util$SoundAction;

        /* JADX WARNING: Can't wrap try/catch for region: R(8:0|1|2|3|4|5|6|(3:7|8|10)) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x001d */
        /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x0028 */
        static {
            int[] iArr = new int[SoundAction.values().length];
            $SwitchMap$king$james$bible$android$sound$util$SoundAction = iArr;
            iArr[SoundAction.PLAY_ACTION.ordinal()] = 1;
            $SwitchMap$king$james$bible$android$sound$util$SoundAction[SoundAction.PAUSE_ACTION.ordinal()] = 2;
            $SwitchMap$king$james$bible$android$sound$util$SoundAction[SoundAction.NEXT_ACTION.ordinal()] = 3;
            try {
                $SwitchMap$king$james$bible$android$sound$util$SoundAction[SoundAction.STOP_ACTION.ordinal()] = 4;
            } catch (NoSuchFieldError unused) {
            }
        }
    }

    public void setSoundPageListener(SoundPageListener soundPageListener2) {
        this.soundPageListener = soundPageListener2;
    }

    private void clear() {
        SoundHelper.getInstance().clear();
        Map<Integer, SoundVerseListener> map = this.soundVerseListeners;
        if (map != null) {
            map.clear();
        }
        this.soundVerseListeners = null;
        stop();
        stopForeground();
        this.onTextToSpeechInitListener = null;
        TextToSpeech textToSpeech2 = this.textToSpeech;
        if (textToSpeech2 != null) {
            textToSpeech2.stop();
            this.textToSpeech.shutdown();
        }
        this.soundModel = null;
        this.binder = null;
        stopSelf();
    }

    public void onDestroy() {
        clear();
        super.onDestroy();
    }
}
