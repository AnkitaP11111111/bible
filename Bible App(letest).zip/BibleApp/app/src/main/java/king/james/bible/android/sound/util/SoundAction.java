package king.james.bible.android.sound.util;

public enum SoundAction {
    PLAY_ACTION,
    PAUSE_ACTION,
    PLAY_REPEAT_ACTION,
    PAUSE_REPEAT_ACTION,
    NEXT_ACTION,
    STOP_ACTION
}
