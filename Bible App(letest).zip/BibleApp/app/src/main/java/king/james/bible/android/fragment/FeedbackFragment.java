package king.james.bible.android.fragment;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import king.james.bible.android.R;
import king.james.bible.android.service.PowerManagerService;
import king.james.bible.android.utils.AppUtils;
import king.james.bible.android.utils.BiblePreferences;
import king.james.bible.android.utils.EmailUtils;
import king.james.bible.android.utils.ScreenUtil;

public class FeedbackFragment extends Fragment implements View.OnClickListener {
    private BiblePreferences preferences;

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        BiblePreferences instance = BiblePreferences.getInstance();
        this.preferences = instance;
        instance.lambda$restoreAsync$0$BiblePreferences();
        View inflate = layoutInflater.inflate(this.preferences.isNightMode() ? R.layout.activity_feedback_new_n : R.layout.activity_feedback_new, (ViewGroup) null);
        inflate.findViewById(R.id.feedback_page_back_btn).setOnClickListener(this);
        inflate.findViewById(R.id.rate_us_button).setOnClickListener(this);
        inflate.findViewById(R.id.share_button).setOnClickListener(this);
        inflate.findViewById(R.id.feedback_button).setOnClickListener(this);
        ((TextView) inflate.findViewById(R.id.feedback_text)).setText(Html.fromHtml(getResources().getString(R.string.feedback_text_html)));
        inflate.findViewById(R.id.rate_us_row).setOnClickListener(this);
        inflate.findViewById(R.id.share_row).setOnClickListener(this);
        inflate.findViewById(R.id.feedback_row).setOnClickListener(this);
        TextView textView = (TextView) inflate.findViewById(R.id.privacyPolicy);
        textView.setText(Html.fromHtml("<u>" + getString(R.string.privacy_policy) + "</u>"));
        textView.setOnClickListener(new View.OnClickListener() {
            /* class king.james.bible.android.fragment.FeedbackFragment.AnonymousClass1 */

            public void onClick(View view) {
                AppUtils.openPrivatePolicyLink(FeedbackFragment.this.getActivity());
            }
        });
        PowerManagerService.getInstance().start();
        return inflate;
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.feedback_button:
            case R.id.feedback_row:
                sendFeedback();
                return;
            case R.id.feedback_page_back_btn:
                ScreenUtil.getInstance().hideKeyboard(getActivity());
                getActivity().onBackPressed();
                return;
            case R.id.rate_us_button:
            case R.id.rate_us_row:
                AppUtils.openMarketPage(getActivity());
                return;
            case R.id.share_button:
            case R.id.share_row:
                share();
                return;
            default:
                return;
        }
    }

    private void share() {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("text/plain");
        intent.putExtra("android.intent.extra.TEXT", getResources().getString(R.string.KJB_androidApp) + getString(R.string.space) + getString(R.string.KJB_app_url) + getActivity().getPackageName());
        startActivity(Intent.createChooser(intent, getResources().getString(R.string.share_text)));
    }

    private void sendFeedback() {
        EmailUtils.sentEmail(getActivity(), new String[]{getResources().getString(R.string.feedback_email)}, getResources().getString(R.string.feedback_subject), getString(R.string.space), null, null);
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            FragmentCallbackListener fragmentCallbackListener = (FragmentCallbackListener) activity;
        } catch (ClassCastException unused) {
            throw new ClassCastException(activity.toString() + " must implement OnHeadlineSelectedListener");
        }
    }
}
